#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""yyb凌波双低 — 本地 Tushare CBOND EOD 信号 / T+1 开盘成交 回测 R1.

TASK_CLASS = BACKTEST
SOURCE = TUSHARE_CBOND_DAILY_MARKET_R1 + TUSHARE_CBOND_BASIC_R1
NOT Jisilu live / NOT cookie / NOT QMT / NOT R26d
JQ_EQUIVALENCE = NOT_CLAIMED
FULL_PIT_READY = FALSE
CBOND_EVENT_PIT_READY = NO  → 强赎公告不作为同日过滤
CBOND_CONVERT_PRICE_PIT_READY = NO → 不用 conv_price 回填
"""
from __future__ import annotations

import json
import math
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _base import ROOT, FAIL, OK, guarded_write_path, set_runtime_context  # noqa: E402

CN = timezone(timedelta(hours=8))
TASK_CLASS = "BACKTEST"
TASK_SLUG = "可转债双低日频回测_2026YTD_R1"
TASK_DIR = ROOT / "任务" / TASK_SLUG
START = "20260101"
END = "20260814"
REBALANCE_EVERY_N = 10
COST_ONE_WAY = 0.0001
INIT_NAV = 1_000_000.0
RUN_ID = "CBOND_DUAL_LOW_2026YTD_EOD_TPLUS1_R1"
STRATEGY_ID = "YYB_LINGBO_DUAL_LOW_EOD_TPLUS1_R1"

CBOND_PTR = ROOT / "数据" / "回测缓存" / "可转债指针" / "CURRENT_CBOND_CACHE_RELEASE.json"

RATING_ORDER = {
    "C": -8, "CC": -7, "CCC": -6, "CCC-": -6, "CCC+": -5,
    "B-": -4, "B": -3, "B+": -2,
    "BB-": -1, "BB": 0, "BB+": 1,
    "BBB-": 2, "BBB": 3, "BBB+": 4,
    "A-": 5, "A": 6, "A+": 7,
    "AA-": 8, "AA": 9, "AA+": 10,
    "AAA": 11,
}
MIN_RATING_SCORE = RATING_ORDER["AA"]


def now_cn() -> str:
    return datetime.now(CN).strftime("%Y-%m-%dT%H:%M:%S%z")


def wjson(path: Path, obj: Any) -> None:
    guarded_write_path(path, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def ymd(v: Any) -> str | None:
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return None
    s = str(v).strip()
    if not s or s.lower() in {"nan", "none", "nat", "-", ""}:
        return None
    s = s.replace("-", "").replace("/", "")[:8]
    if len(s) != 8 or not s.isdigit():
        return None
    return s


def ymd_dash(v: Any) -> str | None:
    s = ymd(v)
    return None if s is None else f"{s[:4]}-{s[4:6]}-{s[6:8]}"


def rating_passes(rating: Any) -> bool:
    if rating is None or (isinstance(rating, float) and math.isnan(rating)):
        return False
    score = RATING_ORDER.get(str(rating).strip().upper())
    if score is None:
        return False
    return score >= MIN_RATING_SCORE


def remain_years(maturity: Any, trade: str) -> float | None:
    m = ymd(maturity)
    t = ymd(trade)
    if m is None or t is None:
        return None
    try:
        md = datetime.strptime(m, "%Y%m%d")
        td = datetime.strptime(t, "%Y%m%d")
    except ValueError:
        return None
    return (md - td).days / 365.25


def listed_on(list_date: Any, delist_date: Any, trade: str) -> bool:
    ld = ymd(list_date)
    if ld is None or ld > trade:
        return False
    dd = ymd(delist_date)
    if dd is not None and dd <= trade:
        return False
    return True


def valid_px(v: Any) -> bool:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return False
    return x > 0 and math.isfinite(x)


def holding_count(n_total: int) -> int:
    if n_total < 100:
        return 5
    if n_total < 200:
        return 10
    if n_total < 300:
        return 15
    return 20


def position_frac(dl_mean: float | None) -> tuple[float, str]:
    if dl_mean is None or not math.isfinite(dl_mean):
        return 0.0, "数据不足"
    if dl_mean > 170:
        return 0.0, "空仓（0%）"
    if dl_mean > 165:
        return 0.0, "清仓线（0%）"
    if dl_mean > 160:
        return 0.15, "轻仓（约15%）"
    if dl_mean > 155:
        return 0.30, "30%仓位"
    if dl_mean > 150:
        return 0.60, "60%仓位"
    return 1.00, "满仓（100%）"


def detect_size_to_yi(series: pd.Series) -> tuple[str, float]:
    xs = pd.to_numeric(series, errors="coerce").dropna()
    xs = xs[xs > 0]
    if xs.empty:
        return "UNKNOWN", 1.0
    med = float(xs.median())
    if med > 1e6:
        return "YUAN", 1e8
    if med > 200:
        return "WAN_YUAN", 1e4
    return "YI_YUAN", 1.0


def run_must_read_inprocess() -> dict[str, Any]:
    import blackbox_must_read_preflight_r1 as mr

    classes = mr._parse_classes(TASK_CLASS)
    required = mr._required_keys(classes)
    kernel_meta = mr._meta(mr.KERNEL_PATH)
    file_metas = {k: mr._meta(mr.PACK_DIR / name) for k, name in mr.FILE_KEYS.items()}
    manifest = json.loads(mr.read_text(mr.MANIFEST_PATH))
    budgets = {**mr.DEFAULT_BUDGETS, **(manifest.get("budgets") or {})}
    problems: list[str] = []
    if not kernel_meta["exists"]:
        problems.append("KERNEL_MISSING")
    elif kernel_meta["bytes"] > budgets["ALWAYS_APPLY_BUDGET_BYTES"]:
        problems.append("ALWAYS_APPLY_BUDGET_EXCEEDED")
    rules_loaded = []
    task_bytes = 0
    for k in required:
        m = file_metas[k]
        expected = ((manifest.get("files") or {}).get(k) or {}).get("sha256")
        status = "MISSING"
        if not m["exists"]:
            problems.append(f"MISSING_{k}")
        elif m["lines"] > budgets["LINE_CAP"]:
            problems.append(f"LINE_CAP_{k}")
            status = "LINE_CAP_FAIL"
        elif expected and m["sha256"] != expected:
            problems.append(f"SHA_MISMATCH_{k}")
            status = "SHA_MISMATCH"
        else:
            status = "VERIFIED"
            task_bytes += m["bytes"]
        rules_loaded.append({"key": k, "status": status, "sha256": m.get("sha256")})
    if len(required) > budgets["MAX_REQUIRED_RULE_FILES"]:
        problems.append("RULESET_OVERLOADED_FILE_COUNT")
    if task_bytes > budgets["TASK_RULE_BUDGET_BYTES"]:
        problems.append("RULESET_OVERLOADED_BYTES")
    k_expected = (manifest.get("kernel") or {}).get("sha256")
    if k_expected and kernel_meta.get("sha256") != k_expected:
        problems.append("SHA_MISMATCH_KERNEL")
    ok = not problems
    return {
        "returncode": 0 if ok else 2,
        "MUST_READ_PRECHECK": "PASS" if ok else "FAIL",
        "AUTHORITY_READY": "YES" if ok else "NO",
        "problems": problems,
        "rules_loaded": rules_loaded,
        "KERNEL_SHA256": kernel_meta.get("sha256"),
    }


def resolve_cbond_paths() -> dict[str, Any]:
    if not CBOND_PTR.is_file():
        raise FileNotFoundError(f"CBOND CURRENT missing: {CBOND_PTR}")
    ptr = json.loads(CBOND_PTR.read_text(encoding="utf-8"))
    root = Path(ptr["release_root"])
    daily = root / "TUSHARE_CBOND_DAILY_MARKET_R1" / "year=2026" / "data.parquet"
    basic = root / "TUSHARE_CBOND_BASIC_R1" / "data.parquet"
    if not daily.is_file() or not basic.is_file():
        raise FileNotFoundError(f"CBOND product parquet missing daily={daily.is_file()} basic={basic.is_file()}")
    return {
        "cache_release_id": ptr.get("cache_release_id"),
        "release_root": str(root),
        "daily_path": str(daily),
        "basic_path": str(basic),
        "asof": ptr.get("asof"),
        "source_vendor": ptr.get("source_vendor"),
        "jq_native_data": ptr.get("jq_native_data"),
        "CBOND_CONVERT_PRICE_PIT": ptr.get("CBOND_CONVERT_PRICE_PIT"),
    }


def write_receipts(paths: dict[str, Any], signal_day: str, fill_day: str) -> dict[str, Path]:
    sig = f"{ymd_dash(signal_day)}T15:00:00"
    fill = f"{ymd_dash(fill_day)}T09:30:00"
    labels = [
        "RESEARCH_RAW_NONE_EXPLICIT",
        "CBOND_VENDOR_QUOTE_NO_STOCK_ADJ",
        "NOT_LIVE_OR_JQ_MATCH_EXECUTION",
        "EVENT_PIT_NOT_READY_REDEEM_FILTER_OMITTED",
        "RATING_USES_ISSUE_RATING_NOT_NEWEST",
        "SIZE_USES_ISSUE_SIZE_STATIC",
    ]
    causal = {
        "strategy_id": STRATEGY_ID,
        "run_id": RUN_ID,
        "information_mode": "EOD_CAUSAL_NEXT_DAY",
        "signal_time": sig,
        "fill_time": fill,
        "order_time": fill,
        "fill_price_source": "OPEN",
        "eod_to_same_day_open": False,
        "EOD_TO_SAME_DAY_OPEN": "NO",
        "date_le_signal_date_as_sufficient": False,
        "mandatory_precheck": {
            "HAND_CAUSAL_READ": "YES",
            "INFORMATION_MODE": "EOD_CAUSAL_NEXT_DAY",
            "EOD_TO_SAME_DAY_OPEN": "NO",
            "MINUTE_POLICY": "UNUSED",
            "SIGNAL_TIME": sig,
            "FILL_TIME": fill,
            "SIGNAL_LT_FILL": "YES",
            "UNIFIED_MINUTE_PLANE_IF_NEEDED": "NOT_APPLICABLE",
        },
        "fields": [
            {
                "field_name": "close",
                "source_product": "TUSHARE_CBOND_DAILY_MARKET_R1",
                "observation_date": ymd_dash(signal_day),
                "known_at": sig,
                "eod_daily": True,
                "timestamp_authority": "VENDOR_EOD_AFTER_CLOSE",
            },
            {
                "field_name": "cb_over_rate",
                "source_product": "TUSHARE_CBOND_DAILY_MARKET_R1",
                "observation_date": ymd_dash(signal_day),
                "known_at": sig,
                "eod_daily": True,
                "timestamp_authority": "VENDOR_EOD_AFTER_CLOSE",
            },
            {
                "field_name": "issue_rating",
                "source_product": "TUSHARE_CBOND_BASIC_R1",
                "observation_date": "1970-01-01",
                "known_at": "1970-01-01T15:00:00",
                "eod_daily": False,
                "timestamp_authority": "ISSUE_TIME_DICTIONARY",
                "note": "issue_rating treated as known at issuance; newest_rating NOT used",
            },
            {
                "field_name": "maturity_date",
                "source_product": "TUSHARE_CBOND_BASIC_R1",
                "observation_date": "1970-01-01",
                "known_at": "1970-01-01T15:00:00",
                "eod_daily": False,
                "timestamp_authority": "CONTRACTUAL_DICTIONARY",
            },
            {
                "field_name": "issue_size",
                "source_product": "TUSHARE_CBOND_BASIC_R1",
                "observation_date": "1970-01-01",
                "known_at": "1970-01-01T15:00:00",
                "eod_daily": False,
                "timestamp_authority": "ISSUE_TIME_DICTIONARY",
            },
            {
                "field_name": "cb_type",
                "source_product": "TUSHARE_CBOND_BASIC_R1",
                "observation_date": "1970-01-01",
                "known_at": "1970-01-01T15:00:00",
                "eod_daily": False,
                "timestamp_authority": "DICTIONARY",
            },
        ],
    }
    preflight = {
        "strategy_id": STRATEGY_ID,
        "run_id": RUN_ID,
        "empty_rank_policy": "EMPTY_KEEP_HOLDING",
        "price_adj_tag": "TUSHARE_CBOND_VENDOR_QUOTE_RAW_NONE",
        "price_source": paths["daily_path"],
        "claim_jq_or_live_match": False,
        "rebalance_clock_rule": f"EOD_SIGNAL_T_THEN_TPLUS1_OPEN_FILL; rebalance every {REBALANCE_EVERY_N} sessions; pulse may fire any EOD",
        "bridge_method": "none",
        "BACKTEST_PRICE_PLANE": "RAW_NONE",
        "SIGNAL_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_EXECUTION_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_VALUATION_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_PNL_PRICE_PLANE": "RAW_NONE",
        "LIVE_EXECUTION_PRICE_PLANE": "RAW_REAL_PRICE",
        "labels": labels,
        "JQ_EQUIVALENCE": "NOT_CLAIMED",
        "FULL_PIT_READY": False,
        "CBOND_EVENT_PIT_READY": False,
        "CBOND_CONVERT_PRICE_PIT_READY": False,
    }
    plane = {
        "strategy_id": STRATEGY_ID,
        "run_id": RUN_ID,
        "BACKTEST_PRICE_PLANE": "RAW_NONE",
        "SIGNAL_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_EXECUTION_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_VALUATION_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_PNL_PRICE_PLANE": "RAW_NONE",
        "LIVE_EXECUTION_PRICE_PLANE": "RAW_REAL_PRICE",
        "signal_adjustment_method": "NONE_CBOND_VENDOR_QUOTE",
        "signal_adjustment_anchor": "EACH_HISTORICAL_TRADE_DAY_T",
        "pit_causal": True,
        "adjust_factor_product_id": "N/A_CBOND_VENDOR_QUOTE_NO_STOCK_ADJ",
        "adjust_factor_release": "N/A_RAW_NONE",
        "adjust_factor_reader": "N/A_CBOND_VENDOR_QUOTE",
        "factor_coverage_ratio": 1.0,
        "missing_factor_count": 0,
        "missing_factor_codes": [],
        "raw_fallback_used": False,
        "future_adjustment_used": False,
        "execution_uses_adjusted_price": False,
        "mixed_plane_used": False,
        "PRICE_PLANE_DEFAULT_APPLIED": False,
        "silent_factor_eq_1": False,
        "BLACKBOX_PRE_PIT_EQ_JQ_PRE": "NOT_CLAIMED",
        "labels": labels,
        "note": "Convertible-bond quotes have no A-share PRE_PIT adjust-factor chain; explicit RESEARCH_RAW_NONE.",
    }
    out = {
        "causal": TASK_DIR / "CAUSAL_RECEIPT.json",
        "preflight": TASK_DIR / "BACKTEST_PREFLIGHT_RECEIPT.json",
        "plane": TASK_DIR / "BACKTEST_PRICE_PLANE_RECEIPT.json",
    }
    wjson(out["causal"], causal)
    wjson(out["preflight"], preflight)
    wjson(out["plane"], plane)
    return out


def run_gates(receipts: dict[str, Path]) -> dict[str, Any]:
    from blackbox_backtest_causal_information_gate_r1 import validate_receipt as val_causal
    from blackbox_backtest_preflight_gate import validate_receipt as val_pre
    from blackbox_backtest_price_plane_gate_r1 import validate_receipt as val_plane

    results: dict[str, Any] = {"must_read": run_must_read_inprocess()}
    causal_data = json.loads(receipts["causal"].read_text(encoding="utf-8"))
    st, fails, classes = val_causal(causal_data)
    results["causal"] = {"returncode": 0 if st == "PASS" else 2, "status": st, "fails": fails, "classes": classes}
    pre_data = json.loads(receipts["preflight"].read_text(encoding="utf-8"))
    pre_fails = val_pre(pre_data)
    results["preflight"] = {"returncode": 0 if not pre_fails else 2, "fails": pre_fails}
    plane_data = json.loads(receipts["plane"].read_text(encoding="utf-8"))
    pst, pfail = val_plane(plane_data)
    results["price_plane"] = {"returncode": 0 if pst == "PASS" else 2, "status": pst, "fails": pfail}
    results["all_pass"] = all(results[k].get("returncode") == 0 for k in ("must_read", "causal", "preflight", "price_plane"))
    return results


def load_panel(paths: dict[str, Any]) -> tuple[pd.DataFrame, dict[str, Any]]:
    daily = pd.read_parquet(paths["daily_path"])
    basic = pd.read_parquet(paths["basic_path"])
    daily["trade_date"] = daily["trade_date"].map(ymd)
    daily = daily[(daily["trade_date"] >= START) & (daily["trade_date"] <= END)].copy()
    if "cb_type" not in basic.columns:
        raise RuntimeError("cb_type missing in BASIC")
    keep_basic = basic[basic["cb_type"].astype(str).str.upper() == "CB"].copy()
    size_col = "issue_size" if "issue_size" in keep_basic.columns else "remain_size"
    unit_name, div = detect_size_to_yi(keep_basic[size_col])
    keep_basic["size_yi"] = pd.to_numeric(keep_basic[size_col], errors="coerce") / div
    keep_basic["rating_ok"] = keep_basic.get("issue_rating", pd.Series(index=keep_basic.index)).map(rating_passes)
    meta_cols = [
        "bond_code_ts",
        "bond_short_name",
        "cb_type",
        "list_date",
        "delist_date",
        "maturity_date",
        "issue_rating",
        "size_yi",
        "rating_ok",
    ]
    for c in meta_cols:
        if c not in keep_basic.columns:
            keep_basic[c] = None
    meta = keep_basic[meta_cols].drop_duplicates("bond_code_ts")
    panel = daily.merge(meta, on="bond_code_ts", how="inner")
    panel["_ld"] = panel["list_date"].map(ymd)
    panel["_dd"] = panel["delist_date"].map(ymd)
    panel = panel[panel["_ld"].notna() & (panel["_ld"] <= panel["trade_date"])]
    panel = panel[panel["_dd"].isna() | (panel["_dd"] > panel["trade_date"])]
    panel["close"] = pd.to_numeric(panel["close"], errors="coerce")
    panel["open"] = pd.to_numeric(panel["open"], errors="coerce")
    panel["cb_over_rate"] = pd.to_numeric(panel["cb_over_rate"], errors="coerce")
    panel["dl"] = panel["close"] + panel["cb_over_rate"]
    panel["remain"] = [
        remain_years(m, t) for m, t in zip(panel["maturity_date"], panel["trade_date"])
    ]
    info = {
        "daily_rows": int(len(daily)),
        "panel_rows": int(len(panel)),
        "cb_basic_rows": int(len(meta)),
        "size_unit_detected": unit_name,
        "size_divisor": div,
        "size_col": size_col,
        "unique_dates": int(panel["trade_date"].nunique()),
        "unique_bonds": int(panel["bond_code_ts"].nunique()),
    }
    return panel, info


def survivors_of(day: pd.DataFrame) -> pd.DataFrame:
    ok = day[
        day["close"].map(valid_px)
        & day["cb_over_rate"].notna()
        & day["dl"].notna()
        & (day["rating_ok"] == True)  # noqa: E712
        & (day["close"] <= 145)
        & ((day["remain"].isna()) | (day["remain"] >= 0.5))
    ].copy()
    return ok


def rank_key(row: pd.Series) -> tuple:
    dl = float(row["dl"]) if pd.notna(row["dl"]) else 9999.0
    size = float(row["size_yi"]) if pd.notna(row["size_yi"]) else 9999.0
    bonus = 0.0 if size < 30 else 100.0
    return (dl + bonus, dl, size)


def pick_targets(surv: pd.DataFrame, held: set[str], n_hold: int) -> list[str]:
    if surv.empty or n_hold <= 0:
        return []
    ranked = sorted((rank_key(r), r["bond_code_ts"]) for _, r in surv.iterrows())
    codes = [c for _, c in ranked]
    n = len(codes)
    top10_n = max(1, int(math.ceil(n * 0.10)))
    top20_n = max(1, int(math.ceil(n * 0.20)))
    top10 = set(codes[:top10_n])
    top20 = set(codes[:top20_n])
    keep = [c for c in held if c in top20]
    out = list(keep)
    for c in codes[:top10_n]:
        if len(out) >= n_hold:
            break
        if c not in out:
            out.append(c)
    if len(out) < n_hold:
        for c in codes:
            if len(out) >= n_hold:
                break
            if c not in out:
                out.append(c)
    return out[:n_hold]


def pulse_hits(day: pd.DataFrame, held: set[str]) -> list[str]:
    prices = [float(x) for x in day.loc[day["bond_code_ts"].isin(held), "close"] if valid_px(x)]
    if not prices:
        return []
    med = sorted(prices)[len(prices) // 2] if len(prices) % 2 == 1 else (
        sorted(prices)[len(prices) // 2 - 1] + sorted(prices)[len(prices) // 2]
    ) / 2
    hits = []
    sub = day[day["bond_code_ts"].isin(held)]
    for _, r in sub.iterrows():
        if not valid_px(r["close"]) or not pd.notna(r["dl"]):
            continue
        px, dl = float(r["close"]), float(r["dl"])
        if med < 110:
            if px > 120 and dl > 125:
                hits.append(r["bond_code_ts"])
        else:
            if px > 125 and dl > 130:
                hits.append(r["bond_code_ts"])
    return hits


def simulate(panel: pd.DataFrame) -> dict[str, Any]:
    dates = sorted(panel["trade_date"].unique())
    by_date = {d: g.copy() for d, g in panel.groupby("trade_date")}
    cash = INIT_NAV
    shares: dict[str, float] = {}
    pending_sells: list[tuple[str, str]] = []
    pending_buys: list[tuple[str, str]] = []
    pending_frac = 0.0
    pending_nhold = 0
    trades: list[dict[str, Any]] = []
    equity: list[dict[str, Any]] = []
    snapshots: list[dict[str, Any]] = []
    n_signal = 0

    for i, d in enumerate(dates):
        day = by_date[d]
        # --- open: fill pending from previous EOD ---
        if i > 0 and (pending_sells or pending_buys):
            px_open = {r["bond_code_ts"]: float(r["open"]) for _, r in day.iterrows() if valid_px(r["open"])}
            for c, reason in pending_sells:
                q = shares.get(c, 0.0)
                if q <= 0 or c not in px_open:
                    continue
                p = px_open[c]
                cash += q * p * (1.0 - COST_ONE_WAY)
                trades.append({"date": d, "code": c, "side": "SELL", "price": round(p, 4), "shares": round(q, 6), "reason": reason})
                shares.pop(c, None)
            # if target cash (frac=0), sell remaining too
            if pending_frac <= 0:
                for c in list(shares.keys()):
                    if c not in px_open:
                        continue
                    q = shares[c]
                    p = px_open[c]
                    cash += q * p * (1.0 - COST_ONE_WAY)
                    trades.append({"date": d, "code": c, "side": "SELL", "price": round(p, 4), "shares": round(q, 6), "reason": "POS_FRAC_ZERO"})
                    shares.pop(c, None)
            else:
                buy_codes = [c for c, _ in pending_buys if c in px_open]
                # skip already held (keep old shares; optional top-up omitted for first version)
                buy_codes = [c for c in buy_codes if c not in shares]
                n_buy = len(buy_codes)
                if n_buy > 0:
                    nav_now = cash
                    for c, q in shares.items():
                        nav_now += q * px_open.get(c, 0.0)
                    slot = (nav_now * pending_frac) / max(pending_nhold, n_buy)
                    # do not exceed cash
                    for c in buy_codes:
                        p = px_open[c]
                        budget = min(slot, cash)
                        q = budget / (p * (1.0 + COST_ONE_WAY))
                        if q <= 0:
                            continue
                        cost = q * p * (1.0 + COST_ONE_WAY)
                        cash -= cost
                        shares[c] = q
                        reason = next(r for x, r in pending_buys if x == c)
                        trades.append({"date": d, "code": c, "side": "BUY", "price": round(p, 4), "shares": round(q, 6), "reason": reason})
            pending_sells = []
            pending_buys = []

        # --- close: mark + signal ---
        px_close = {r["bond_code_ts"]: float(r["close"]) for _, r in day.iterrows() if valid_px(r["close"])}
        # drop names missing from panel (delist): liquidate at last close already held through this close
        missing = [c for c in list(shares) if c not in px_close]
        for c in missing:
            # no T close either: drop with 0 (halt/delist unknown) — keep until next valid
            pass
        nav = cash + sum(q * px_close[c] for c, q in shares.items() if c in px_close)
        mkt = day[day["close"].map(valid_px) & day["cb_over_rate"].notna()]
        dls = [float(x) for x in mkt["dl"] if pd.notna(x)]
        dl_mean = sum(dls) / len(dls) if dls else None
        n_univ = int(len(mkt))
        n_hold = holding_count(n_univ)
        frac, pos_txt = position_frac(dl_mean)
        surv = survivors_of(day)
        is_rebalance = (n_signal % REBALANCE_EVERY_N == 0)
        held = set(shares)
        pulse = pulse_hits(day, held)
        targets: list[str] = []
        if frac <= 0:
            pending_sells.extend((c, "POS_FRAC_ZERO") for c in held)
            pending_buys = []
            pending_frac = 0.0
            pending_nhold = 0
        else:
            if pulse:
                pending_sells.extend((c, "PULSE") for c in pulse)
                held_after = held - set(pulse)
            else:
                held_after = set(held)
            if is_rebalance:
                targets = pick_targets(surv, held_after, n_hold)
                sell_extra = [c for c in held_after if c not in set(targets)]
                pending_sells.extend((c, "REBALANCE_OUT") for c in sell_extra)
                pending_buys = [(c, "REBALANCE_IN") for c in targets if c not in held_after]
                pending_frac = frac
                pending_nhold = max(n_hold, 1)
            else:
                pending_buys = []
                pending_frac = frac
                pending_nhold = max(len(held_after), n_hold, 1)
        n_signal += 1
        qdist = {"Q1": 0, "Q2": 0, "Q3": 0, "Q4": 0}
        for _, r in mkt.iterrows():
            px, prem = float(r["close"]), float(r["cb_over_rate"])
            if px < 110 and prem < 30:
                qdist["Q1"] += 1
            elif px >= 110 and prem < 30:
                qdist["Q2"] += 1
            elif px >= 110 and prem >= 30:
                qdist["Q3"] += 1
            else:
                qdist["Q4"] += 1
        equity.append({"date": d, "nav": round(nav, 2), "cash": round(cash, 2), "n_hold_actual": len(shares), "dl_mean": None if dl_mean is None else round(dl_mean, 4), "pos_frac": frac, "pos_text": pos_txt, "n_universe": n_univ, "n_survivors": int(len(surv)), "rebalance": is_rebalance, "pulse_n": len(pulse)})
        if is_rebalance or d == dates[-1]:
            snapshots.append({
                "date": d,
                "dl_mean": dl_mean,
                "pos_text": pos_txt,
                "n_universe": n_univ,
                "n_survivors": int(len(surv)),
                "n_hold": n_hold,
                "targets": targets,
                "held": sorted(shares),
                "qdist": qdist,
            })

    # last day: no fill after END
    eq = pd.DataFrame(equity)
    navs = eq["nav"].astype(float)
    peak = navs.cummax()
    dd = navs / peak - 1.0
    total_ret = float(navs.iloc[-1] / INIT_NAV - 1.0) if len(navs) else None
    n_days = max(len(navs) - 1, 1)
    ann = (1.0 + total_ret) ** (242 / n_days) - 1.0 if total_ret is not None and navs.iloc[-1] > 0 else None
    return {
        "start": dates[0] if dates else None,
        "end": dates[-1] if dates else None,
        "n_sessions": len(dates),
        "init_nav": INIT_NAV,
        "final_nav": None if eq.empty else float(navs.iloc[-1]),
        "total_return": total_ret,
        "ann_return_242": ann,
        "max_drawdown": None if eq.empty else float(dd.min()),
        "n_trades": len(trades),
        "n_buy": sum(1 for t in trades if t["side"] == "BUY"),
        "n_sell": sum(1 for t in trades if t["side"] == "SELL"),
        "final_holdings": sorted(shares),
        "final_cash": cash,
        "equity": equity,
        "trades": trades,
        "snapshots": snapshots,
        "last_snapshot": snapshots[-1] if snapshots else None,
    }


def summarize_for_humans(sim: dict[str, Any], info: dict[str, Any], gates: dict[str, Any], paths: dict[str, Any]) -> dict[str, Any]:
    tr = sim.get("total_return")
    return {
        "TASK_CLASS": TASK_CLASS,
        "MUST_READ_BOOTSTRAP": "YES",
        "MUST_READ_DATA_ACCESS": "YES",
        "MUST_READ_BACKTEST": "YES",
        "HAND_READ": "YES",
        "AUTHORITY_READY": "YES" if gates.get("all_pass") else "NO",
        "BACKTEST_RETURN_VALID": bool(gates.get("all_pass")),
        "JQ_EQUIVALENCE": "NOT_CLAIMED",
        "FULL_PIT_READY": False,
        "INFORMATION_MODE": "EOD_CAUSAL_NEXT_DAY",
        "EOD_TO_SAME_DAY_OPEN": "NO",
        "SIGNAL_LT_FILL": "YES",
        "window": f"{ymd_dash(sim.get('start'))} .. {ymd_dash(sim.get('end'))}",
        "source": paths,
        "panel": info,
        "deviations_from_live_jisilu_script": [
            "数据源=本地 Tushare CBOND，不是集思录实时 API",
            "强赎公告未过滤（EVENT_PIT_NOT_READY）",
            "评级用 issue_rating，不用 newest_rating 快照",
            "规模用发行规模 issue_size，不用 remain_size 快照",
            "轮动按每 10 个交易日（半月近似），脉冲可每日 EOD 触发、次日开盘成交",
            "成交=T+1 开盘；停牌/开盘无效则跳过该笔",
            "单边成本 1bp，无滑点",
        ],
        "performance": {
            "total_return": tr,
            "total_return_pct": None if tr is None else round(tr * 100, 2),
            "ann_return_242": sim.get("ann_return_242"),
            "max_drawdown": sim.get("max_drawdown"),
            "max_drawdown_pct": None if sim.get("max_drawdown") is None else round(float(sim["max_drawdown"]) * 100, 2),
            "n_trades": sim.get("n_trades"),
            "final_nav": sim.get("final_nav"),
            "n_sessions": sim.get("n_sessions"),
        },
        "last_snapshot": sim.get("last_snapshot"),
        "generated_at_cn": now_cn(),
    }


def main() -> int:
    TASK_DIR.mkdir(parents=True, exist_ok=True)
    set_runtime_context(task_dir=TASK_DIR, task_slug=TASK_SLUG, task_type="BACKTEST")
    paths = resolve_cbond_paths()
    panel, info = load_panel(paths)
    dates = sorted(panel["trade_date"].unique())
    if len(dates) < 2:
        wjson(TASK_DIR / "FAIL.json", {"reason": "NOT_ENOUGH_DATES", "info": info})
        print("BACKTEST_RETURN_VALID=FALSE reason=NOT_ENOUGH_DATES")
        return FAIL
    receipts = write_receipts(paths, dates[0], dates[1])
    gates = run_gates(receipts)
    wjson(TASK_DIR / "GATE_RESULTS.json", {k: ({kk: vv for kk, vv in v.items() if kk != "cmd"} if isinstance(v, dict) else v) for k, v in gates.items()})
    if not gates.get("all_pass"):
        wjson(TASK_DIR / "SUMMARY.json", {"BACKTEST_RETURN_VALID": False, "reason": "GATE_FAIL", "gates": {k: v.get("returncode") if isinstance(v, dict) else v for k, v in gates.items()}})
        print("BACKTEST_RETURN_VALID=FALSE reason=GATE_FAIL")
        for k, v in gates.items():
            if isinstance(v, dict) and v.get("returncode") not in (0, None):
                print(f"gate_fail={k} code={v.get('returncode')}")
                print((v.get("stdout") or "")[-800:])
        return FAIL
    sim = simulate(panel)
    summary = summarize_for_humans(sim, info, gates, paths)
    wjson(TASK_DIR / "SUMMARY.json", summary)
    wjson(TASK_DIR / "EQUITY.json", sim["equity"])
    wjson(TASK_DIR / "TRADES.json", sim["trades"])
    wjson(TASK_DIR / "SNAPSHOTS.json", sim["snapshots"])
    # compact stdout
    perf = summary["performance"]
    print("BACKTEST_RETURN_VALID=TRUE")
    print(f"window={summary['window']}")
    print(f"total_return_pct={perf['total_return_pct']}")
    print(f"max_drawdown_pct={perf['max_drawdown_pct']}")
    print(f"n_trades={perf['n_trades']}")
    print(f"n_sessions={perf['n_sessions']}")
    print(f"final_nav={perf['final_nav']}")
    print(f"task_dir={TASK_DIR}")
    return OK


if __name__ == "__main__":
    raise SystemExit(main())
