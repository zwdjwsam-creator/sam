# -*- coding: utf-8 -*-
"""Gate1 golden + Gate2 NH120 population from CACHE 044403 via resolver. No download/clean/rule rewrite."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_ADJUST_FACTOR_PIT_R1_FULL_REBUILD_AND_BACKWARD_REFRESH_R1")
CACHE_PTR = Path(r"E:\BLACKBOX\数据\回测缓存\CURRENT_CACHE_RELEASE.json")
EXPECT_CACHE = "BLACKBOX_CACHE_R1_ADJFACTOR_PIT_CLEAN_ASOF_20260814_20260816_044403"
sys.path.insert(0, r"E:\BLACKBOX\脚本")
from jq_download_base import auth  # noqa: E402
from blackbox_data_access_resolver_r1 import read_currents, resolve_product  # noqa: E402

sys.path.insert(0, str(TASK))
from nh120_population_calibrate_r1 import (  # noqa: E402
    bb_pre_close,
    golden_nh,
    jq_pre_close,
    load_raw,
    nh120_from_close,
    pop_at,
)


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print(f"[{now_cn()}] {msg}", flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def load_factor_from_resolver() -> tuple[pd.DataFrame, dict]:
    currents = read_currents()
    res = resolve_product("adjust_factor", None, None, currents)
    if not res.get("resolved"):
        raise SystemExit("HARD_BLOCK: resolver ADJUST_FACTOR_PIT_R1 not resolved")
    root = Path(json.loads(CACHE_PTR.read_text(encoding="utf-8"))["release_root"])
    files = sorted((root / "ADJUST_FACTOR_PIT_R1" / "data").glob("year=*/part_*.parquet"))
    df = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
    df["date"] = pd.to_datetime(df["date"]).dt.normalize()
    df["code"] = df["code"].astype(str)
    df["factor"] = pd.to_numeric(df["factor"], errors="coerce")
    return df, res


def factor_at(fac: pd.DataFrame, code: str, ds: str) -> float | None:
    sub = fac.loc[(fac["code"] == code) & (fac["date"] == pd.Timestamp(ds))]
    if sub.empty:
        return None
    return float(sub.iloc[-1]["factor"])


def raw_close_at(raw: pd.DataFrame, code: str, ds: str) -> float | None:
    sub = raw.loc[(raw["code"] == code) & (raw["date"] == pd.Timestamp(ds))]
    if sub.empty:
        return None
    return float(sub.iloc[-1]["close"])


def jq_norm(frame: pd.DataFrame) -> pd.DataFrame:
    x = frame.copy()
    if "time" in x.columns:
        x = x.rename(columns={"time": "date"})
    if "date" not in x.columns:
        x = x.reset_index()
        x = x.rename(columns={x.columns[0]: "date"})
    x["date"] = pd.to_datetime(x["date"]).dt.normalize()
    return x


def golden_reconstruction(fac: pd.DataFrame, raw: pd.DataFrame) -> dict:
    import jqdatasdk as jq

    cases = [
        {"code": "001230.XSHE", "T": "2026-08-11", "d": "2026-05-12", "expect_pre": 20.21},
        {"code": "600351.XSHG", "T": "2026-08-13", "d": "2026-04-30", "expect_pre": 6.91},
        {"code": "000001.XSHE", "T": "2026-08-11", "d": "2026-05-12", "expect_pre": 10.89},
    ]
    out = []
    for c in cases:
        code, T, d = c["code"], c["T"], c["d"]
        pre = jq_norm(
            jq.get_price(
                security=code,
                start_date=d,
                end_date=T,
                frequency="daily",
                fields=["close", "factor"],
                fq="pre",
            )
        )
        jq_pre = float(pre.loc[pre["date"] == pd.Timestamp(d)].iloc[-1]["close"])
        jq_fd = float(pre.loc[pre["date"] == pd.Timestamp(d)].iloc[-1]["factor"])
        jq_fT = float(pre.loc[pre["date"] == pd.Timestamp(T)].iloc[-1]["factor"])
        local_raw = raw_close_at(raw, code, d)
        fd = factor_at(fac, code, d)
        fT = factor_at(fac, code, T)
        recon = None if None in (local_raw, fd, fT) or fT == 0 else local_raw * fd / fT
        rec = {
            "code": code,
            "T": T,
            "d": d,
            "cache_raw_close_d": local_raw,
            "cache_factor_d": fd,
            "cache_factor_T": fT,
            "jq_pre_close_d": jq_pre,
            "jq_pre_factor_d": jq_fd,
            "jq_pre_factor_T": jq_fT,
            "reconstructed_pre": recon,
            "abs_err": None if recon is None else abs(recon - jq_pre),
            "match_1fen": False if recon is None else abs(recon - jq_pre) <= 0.01,
            "factor_matches_jq": fd is not None and abs(fd - jq_fd) < 1e-12 and abs(fT - jq_fT) < 1e-12,
        }
        out.append(rec)
    required = {"001230.XSHE", "600351.XSHG"}
    required_pass = all(x["match_1fen"] and x["factor_matches_jq"] for x in out if x["code"] in required)
    return {
        "cases": out,
        "required_codes": sorted(required),
        "required_pass": required_pass,
        "extra_000001_not_in_user_gate": next((x for x in out if x["code"] == "000001.XSHE"), None),
        "all_pass": required_pass,
    }


def main() -> int:
    cur = json.loads(CACHE_PTR.read_text(encoding="utf-8"))
    cid = cur.get("cache_release_id")
    if cid != EXPECT_CACHE:
        wjson(TASK / "GATE1_GOLDEN.json", {"pass": False, "error": "WRONG_CACHE", "got": cid, "expect": EXPECT_CACHE})
        return 2
    fac, res = load_factor_from_resolver()
    raw = load_raw()
    log(f"resolver product={res.get('product_id')} cache={cid} factor_rows={len(fac)}")
    auth()
    gold = golden_reconstruction(fac, raw)
    wjson(TASK / "GOLDEN_RECONSTRUCTION.json", gold)
    gnh = golden_nh(raw, fac)
    wjson(TASK / "GOLDEN_NH120.json", gnh)
    gate1 = {
        "PRE_PIT_GOLDEN_CASE_VALIDATED": bool(gold["all_pass"] and all(v["pass"] for v in gnh.values())),
        "reconstruction_all_pass": gold["all_pass"],
        "nh120_golden": {k: {"RAW_NH120": v["RAW_NH120"], "PRE_PIT_NH120": v["PRE_PIT_NH120"], "pass": v["pass"]} for k, v in gnh.items()},
        "cache_release_id": cid,
        "resolver_product_id": res.get("product_id"),
        "RAW_FALLBACK_ALLOWED": False,
    }
    wjson(TASK / "GATE1_GOLDEN.json", gate1)
    log(json.dumps(gate1, ensure_ascii=False))
    if not gate1["PRE_PIT_GOLDEN_CASE_VALIDATED"]:
        return 2
    codes = sorted(set(raw.loc[raw["date"] >= "2026-08-01", "code"]))
    jq_pre = jq_pre_close(codes, "2026-01-05", "2026-08-13")
    pops = [
        pop_at(raw, fac, pd.Timestamp("2026-08-11"), jq_pre),
        pop_at(raw, fac, pd.Timestamp("2026-08-13"), jq_pre),
    ]
    residual_path = TASK / "NH120_POPULATION_CALIBRATION.json"
    old = json.loads(residual_path.read_text(encoding="utf-8")) if residual_path.exists() else {}
    same_only = [p["BLACKBOX_ONLY"] for p in pops] == [p.get("BLACKBOX_ONLY") for p in (old.get("pops") or [])]
    gate2 = {
        "pops": pops,
        "all_match": all(p["match"] for p in pops),
        "JQ_ONLY_empty": all(not p["JQ_ONLY"] for p in pops),
        "same_residual_codes_as_prior": same_only,
        "pass_class": (
            "PASS_EXACT"
            if all(p["match"] for p in pops)
            else ("PASS_WITH_DECLARED_RESIDUAL_NOT_FACTOR_MISS" if all(not p["JQ_ONLY"] for p in pops) else "FAIL")
        ),
        "cache_release_id": cid,
        "residual": old.get("residual") if same_only else {"class": "RECOMPUTE_NEEDED", "BLACKBOX_ONLY": [p["BLACKBOX_ONLY"] for p in pops], "JQ_ONLY": [p["JQ_ONLY"] for p in pops]},
    }
    gate2["NH120_POPULATION_CALIBRATION_PASS"] = gate2["pass_class"] != "FAIL"
    wjson(TASK / "NH120_POPULATION_CALIBRATION.json", gate2)
    wjson(TASK / "GATE2_NH120_POPULATION.json", gate2)
    log(json.dumps({k: gate2[k] for k in ("all_match", "JQ_ONLY_empty", "pass_class", "NH120_POPULATION_CALIBRATION_PASS")}, ensure_ascii=False))
    if not gate2["NH120_POPULATION_CALIBRATION_PASS"]:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
