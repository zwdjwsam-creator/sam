#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INDEX_MINUTE: antileak + calendar/dict align clean + Market State binding + seal.

Supports:
  --mode incremental  (default) MODEL A successor via index_minute_align_incremental_engine_r1
  --mode full         legacy full-history rewrite (bootstrap / emergency only)

Does not rewrite 原始只读. Writes cleaning release under 数据/清洗成品/releases/.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import p7_gate_common as gc
import index_minute_align_incremental_engine_r1 as incr

SCRIPT = Path(__file__).resolve()
ROOT = Path(r"E:\BLACKBOX")
P3 = ROOT / "数据/原始只读/JQData_9999_official_raw/P3_index_minute"
REG = ROOT / "规则库/hand_hard_rules/INDEX_CLASSIFICATION_AND_BENCHMARK_REGISTRY_R1.json"
JQ_MINUTE_CODES = (
    ROOT
    / "任务/BLACKBOX_JQ_INDEX_DOWNLOADABLE_PROBE_R1/10_REPORT/DOWNLOADABLE_MINUTE_CODES.csv"
)
JQ_MINUTE_CODES_186 = (
    ROOT
    / "任务/20260808_194845_BLACKBOX_JQ_INDEX_MINUTE_acc523/10_REPORT/NEW_MINUTE_OK_CODES.csv"
)
JQ_MINUTE_CODES_732 = (
    ROOT
    / "任务/20260808_194845_BLACKBOX_JQ_INDEX_MINUTE_acc523/10_REPORT/JQ_INDEX_MINUTE_ALL_732_CODES.csv"
)
MASTER = (
    ROOT
    / "任务/20260804_230632_BLACKBOX_BUILD_CANONICAL_786aec/artifacts/CANONICAL_INDEX_SECURITY_MASTER_R1.parquet"
)
RELEASES = ROOT / "数据/清洗成品/releases"
FREQS = ["5m", "1m", "30m", "60m"]


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda: f.read(1024 * 1024), b""):
            h.update(c)
    return h.hexdigest()


def load_calendar(cutoff_date: str) -> tuple[set[str], Path]:
    return incr.load_calendar(cutoff_date)


def latest_partition_map() -> dict[tuple[str, str, str], Path]:
    return incr.latest_raw_partition_map(P3)


def run_full_legacy(args: argparse.Namespace) -> int:
    """Legacy full rewrite — retained for bootstrap only. Prefer --mode incremental."""
    CUTOFF_DATE = args.cutoff
    CUTOFF = pd.Timestamp(f"{CUTOFF_DATE} 15:30:00")

    hand_pre = gc.load_hand_decision() or {}
    executor = str(hand_pre.get("allowed_executor") or gc.ALLOWED_EXECUTOR)
    if not args.skip_hand_gate:
        hand = gc.enforce_hand_gate(
            script_path=SCRIPT,
            required_stage="INDEX_MINUTE_ALIGN_CLEAN_ANTILEAK",
            executor=executor,
        )
        print("HAND_OK", hand.get("hand_release_level"), "mode=full", flush=True)

    print(
        "WARNING: FULL_HISTORY_REWRITE mode — physical rewrite of all partitions. "
        "Use --mode incremental for asof bumps.",
        flush=True,
    )

    reg = json.loads(REG.read_text(encoding="utf-8"))
    ms_codes = list(reg["required_1m_codes"])
    if args.universe == "jq_downloadable":
        required = pd.read_csv(JQ_MINUTE_CODES)["code"].astype(str).tolist()
        min_years = 1
    elif args.universe == "jq_all_732":
        if JQ_MINUTE_CODES_732.exists():
            required = pd.read_csv(JQ_MINUTE_CODES_732)["code"].astype(str).tolist()
        else:
            a = set(pd.read_csv(JQ_MINUTE_CODES)["code"].astype(str))
            b = set(pd.read_csv(JQ_MINUTE_CODES_186)["code"].astype(str))
            required = sorted(a | b)
        min_years = 1
    else:
        required = list(ms_codes)
        min_years = 10
    required_set = set(required)
    cal_days, cal_path = load_calendar(CUTOFF_DATE)
    active = incr.load_active_windows(required)

    parts = latest_partition_map()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    release_id = f"BLACKBOX_INDEX_MINUTE_ALIGN_R1_ASOF_{CUTOFF_DATE.replace('-', '')}_{stamp}"
    staging = RELEASES / f"{release_id}.STAGING"
    aligned_root = staging / "standard" / "index_minute"
    aligned_root.mkdir(parents=True, exist_ok=True)
    (staging / "CANDIDATE_STATUS.json").write_text(
        json.dumps({"status": "STAGING", "mode": "full"}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    antileak = {
        "INDEX_MINUTE_ANTILEAK_PASS": True,
        "INDEX_MINUTE_DICTIONARY_DATE_ALIGN_PASS": True,
        "INDEX_MINUTE_UNIVERSE_REGISTRY_ALIGN_PASS": True,
        "MARKET_STATE_SLICE_COMPLETED_BAR_PASS": False,
        "universe_mode": args.universe,
        "universe_n": len(required),
        "failures": [],
        "stats": {
            "partitions_seen": 0,
            "partitions_written": 0,
            "rows_in": 0,
            "rows_out": 0,
            "rows_dropped_lookahead": 0,
            "rows_dropped_non_calendar": 0,
            "rows_dropped_inactive": 0,
            "rows_dropped_dup": 0,
        },
    }

    for code in required:
        for freq in FREQS:
            years = [y for (c, f, y) in parts if c == code and f == freq]
            if len(years) < min_years:
                antileak["INDEX_MINUTE_UNIVERSE_REGISTRY_ALIGN_PASS"] = False
                antileak["failures"].append({"marker": "UNIVERSE", "code": code, "freq": freq, "years": len(years)})

    binding_paths: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))

    try:
        for (code, freq, year), src in sorted(parts.items()):
            if code not in required_set:
                continue
            antileak["stats"]["partitions_seen"] += 1
            df = pd.read_parquet(src)
            out, st = incr.align_raw_frame(
                df,
                code=code,
                freq=freq,
                cutoff=CUTOFF,
                cal_days=cal_days,
                active=active,
                cal_path_name=cal_path.name,
                raw_source_path=str(src),
            )
            for k in antileak["stats"]:
                if k in st:
                    antileak["stats"][k] += int(st[k])
            if st.get("lookahead_fail"):
                antileak["INDEX_MINUTE_ANTILEAK_PASS"] = False
                antileak["failures"].append({"marker": "LOOKAHEAD", "code": code, "freq": freq, "year": year})
            if st.get("fq_fail"):
                antileak["INDEX_MINUTE_ANTILEAK_PASS"] = False
                antileak["failures"].append({"marker": "FQ", "code": code, "freq": freq, "year": year})
            if out.empty:
                continue
            dest_dir = aligned_root / code.replace(".", "_") / freq
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = (
                dest_dir
                / f"index_minute_aligned__{code.replace('.', '_')}__{freq}__{year}__asof_{CUTOFF_DATE.replace('-', '')}.parquet"
            )
            out.to_parquet(dest, index=False)
            binding_paths[code][freq].append(str(dest))
            antileak["stats"]["partitions_written"] += 1

        probe_code = "000300.XSHG"
        files_1m = binding_paths.get(probe_code, {}).get("1m", [])
        ms_ok = False
        ms_detail = {}
        if files_1m:
            frames = [pd.read_parquet(f) for f in files_1m if CUTOFF_DATE[:4] in f]
            if frames:
                g = pd.concat(frames, ignore_index=True)
                g["bar_end_ts"] = pd.to_datetime(g["bar_end_ts"])
                probe_cutoff = pd.Timestamp(f"{CUTOFF_DATE} 13:10:00")
                sub = g[g["bar_end_ts"] <= probe_cutoff]
                if len(sub):
                    last = sub.sort_values("bar_end_ts").iloc[-1]
                    ms_ok = pd.Timestamp(last["bar_end_ts"]) <= probe_cutoff
                    ms_detail = {
                        "probe_code": probe_code,
                        "signal_cutoff_ts": str(probe_cutoff),
                        "last_completed_bar_end_ts": str(last["bar_end_ts"]),
                        "index_close": float(last["close"]),
                    }
        antileak["MARKET_STATE_SLICE_COMPLETED_BAR_PASS"] = bool(ms_ok)
        antileak["INDEX_MINUTE_DICTIONARY_DATE_ALIGN_PASS"] = antileak["stats"]["partitions_written"] > 0
        all_pass = all(
            [
                antileak["INDEX_MINUTE_ANTILEAK_PASS"],
                antileak["INDEX_MINUTE_DICTIONARY_DATE_ALIGN_PASS"],
                antileak["INDEX_MINUTE_UNIVERSE_REGISTRY_ALIGN_PASS"],
                antileak["MARKET_STATE_SLICE_COMPLETED_BAR_PASS"],
            ]
        )
        if not all_pass:
            raise RuntimeError("QA_FAIL")

        seal = {
            "seal_id": f"BLACKBOX_INDEX_MINUTE_ALIGN_SEAL_R1_{stamp}",
            "release_id": release_id,
            "generated_at": now_iso(),
            "cutoff": CUTOFF_DATE,
            "calendar_asof": str(cal_path),
            "registry_sha256": sha256_file(REG),
            "master_sha256": sha256_file(MASTER),
            "all_pass": all_pass,
            "acceptance": antileak,
            "aligned_root": str(aligned_root),
            "partitions_written": antileak["stats"]["partitions_written"],
            "successor_mode": "FULL_LEGACY",
            "warning": "FULL_HISTORY_REWRITE",
            "completed_bar_probe": ms_detail,
        }
        (staging / "SEAL.json").write_text(
            json.dumps(seal, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
        )
        (staging / "ACCEPTANCE.json").write_text(
            json.dumps(antileak, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
        )

        if args.no_cutover:
            print(
                json.dumps(
                    {"all_pass": True, "release_id": release_id, "staging": str(staging), "cutover": False},
                    ensure_ascii=False,
                )
            )
            return 0

        formal = RELEASES / release_id
        staging.rename(formal)
        pointer = ROOT / "数据/清洗成品/CURRENT_INDEX_MINUTE_ALIGN_RELEASE.json"
        pointer.write_text(
            json.dumps(
                {
                    "release_id": release_id,
                    "release_root": str(formal),
                    "seal_id": seal["seal_id"],
                    "all_pass": all_pass,
                    "set_at": now_iso(),
                    "successor_mode": "FULL_LEGACY",
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        if not args.no_hand_update:
            dec = gc.load_hand_decision() or {}
            dec.update(
                {
                    "index_minute_align_clean_pass": all_pass,
                    "index_minute_align_release_id": release_id,
                    "index_minute_align_seal_id": seal["seal_id"],
                    "next_action": "DONE_INDEX_MINUTE_ALIGN_CLEAN_ANTILEAK" if all_pass else "REVIEW_ACCEPTANCE_FAILURES",
                    "generated_at": gc.now_iso(),
                }
            )
            gc.write_hand_decision(dec)
            gc.write_hand_md(dec)
        print(json.dumps({"all_pass": all_pass, "release_id": release_id, "stats": antileak["stats"]}, ensure_ascii=False))
        return 0 if all_pass else 2
    except Exception as e:
        ctx = incr.BuildContext(
            task_id="INDEX_MINUTE_ALIGN_FULL_LEGACY",
            mode="full",
            previous_release_id="NONE",
            previous_root=staging,
            previous_aligned=aligned_root,
            previous_cutoff=CUTOFF_DATE,
            new_cutoff=CUTOFF_DATE,
            release_id=release_id,
            staging_root=staging,
            aligned_root=aligned_root,
            universe_codes=required,
            publication_generation_id=f"FULL_{stamp}",
            failure_phase="FULL_LEGACY",
            failure_reason=str(e),
        )
        orphan = incr.register_orphan(ctx)
        print(json.dumps({"all_pass": False, "orphan": orphan, "error": str(e)}, ensure_ascii=False))
        return 2


def run_incremental(args: argparse.Namespace) -> int:
    hand_pre = gc.load_hand_decision() or {}
    executor = str(hand_pre.get("allowed_executor") or gc.ALLOWED_EXECUTOR)
    if not args.skip_hand_gate:
        hand = gc.enforce_hand_gate(
            script_path=SCRIPT,
            required_stage="INDEX_MINUTE_ALIGN_CLEAN_ANTILEAK",
            executor=executor,
        )
        print("HAND_OK", hand.get("hand_release_level"), "mode=incremental", flush=True)

    argv = ["--new-cutoff", args.cutoff]
    if args.universe == "required_1m":
        argv += ["--universe", "required_1m"]
    else:
        argv += ["--universe", "from_previous"]
    if args.increment_dates:
        argv += ["--increment-dates", args.increment_dates]
    if args.previous_root:
        argv += ["--previous-root", args.previous_root]
    if args.no_cutover:
        argv.append("--no-cutover")
    if args.no_hand_update:
        argv.append("--no-hand-update")
    if args.plan_only:
        argv.append("--plan-only")
    if args.skip_source_gate:
        argv.append("--skip-source-gate")
    return incr.main(argv)


def enforce_full_mode_hard_gate(args: argparse.Namespace) -> None:
    """Daily/asof bumps MUST NOT use --mode full. Explicit rebuild only."""
    if args.mode != "full":
        return
    ok = bool(getattr(args, "explicit_full_rebuild_authorized", False))
    reason = (getattr(args, "full_rebuild_reason", "") or "").strip()
    capacity = (getattr(args, "full_rebuild_capacity_gb_estimate", "") or "").strip()
    task_class = (getattr(args, "full_rebuild_task_class", "") or "").strip()
    if not ok or not reason or not capacity or task_class != "INDEX_MINUTE_ALIGN_FULL_REBUILD":
        raise SystemExit(
            "HARD_BLOCK_FULL_MODE_FOR_DAILY_ALIGN: "
            "--mode full is forbidden for routine asof/daily increments. "
            "Required for emergency/bootstrap rebuild only: "
            "--explicit-full-rebuild-authorized "
            "--full-rebuild-task-class INDEX_MINUTE_ALIGN_FULL_REBUILD "
            "--full-rebuild-reason <why> "
            "--full-rebuild-capacity-gb-estimate <N>. "
            "Use --mode incremental instead."
        )
    print(
        json.dumps(
            {
                "FULL_REBUILD_AUTHORIZED": True,
                "task_class": task_class,
                "reason": reason,
                "capacity_gb_estimate": capacity,
                "warning": "FULL_HISTORY_REWRITE_EXPECTED",
            },
            ensure_ascii=False,
        ),
        flush=True,
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["incremental", "full"], default="incremental")
    ap.add_argument("--cutoff", type=str, default="", help="YYYY-MM-DD asof cutoff")
    ap.add_argument("--increment-dates", type=str, default="")
    ap.add_argument("--previous-root", type=str, default="")
    ap.add_argument(
        "--universe",
        choices=["required_1m", "jq_downloadable", "jq_all_732"],
        default="jq_all_732",
    )
    ap.add_argument("--no-cutover", action="store_true")
    ap.add_argument("--no-hand-update", action="store_true")
    ap.add_argument("--plan-only", action="store_true")
    ap.add_argument("--skip-hand-gate", action="store_true")
    ap.add_argument("--skip-source-gate", action="store_true")
    # HARD GATE: --mode full requires explicit rebuild authorization (not daily)
    ap.add_argument(
        "--explicit-full-rebuild-authorized",
        action="store_true",
        help="REQUIRED with --mode full; daily increments must NOT set this",
    )
    ap.add_argument(
        "--full-rebuild-task-class",
        type=str,
        default="",
        help="Must be INDEX_MINUTE_ALIGN_FULL_REBUILD when using --mode full",
    )
    ap.add_argument("--full-rebuild-reason", type=str, default="")
    ap.add_argument("--full-rebuild-capacity-gb-estimate", type=str, default="")
    args = ap.parse_args()

    if not args.cutoff:
        cur = incr.load_current_pointer()
        prev_cutoff = incr.read_previous_cutoff(Path(cur["release_root"]))
        raise SystemExit(
            f"--cutoff required. CURRENT={cur['release_id']} previous_cutoff={prev_cutoff}"
        )

    enforce_full_mode_hard_gate(args)
    if args.mode == "full":
        return run_full_legacy(args)
    return run_incremental(args)


if __name__ == "__main__":
    raise SystemExit(main())
