# -*- coding: utf-8 -*-
"""Permanent entry for ADJUST_FACTOR_PIT_R1 backward-dirty incremental refresh."""
from _base import *  # noqa: F401,F403

import sys
from pathlib import Path

TASK_SCRIPT = ROOT / "任务" / "BLACKBOX_ADJUST_FACTOR_PIT_R1_FULL_REBUILD_AND_BACKWARD_REFRESH_R1" / "incremental_backward_refresh_r1.py"
PY = ROOT / ".venv" / "Scripts" / "python.exe"


def main() -> int:
    if not TASK_SCRIPT.is_file():
        print("HARD_BLOCK: incremental engine missing", TASK_SCRIPT)
        return FAIL
    cmd = [str(PY), "-u", str(TASK_SCRIPT), *sys.argv[1:]]
    r = guarded_run(cmd, cwd=str(ROOT))
    return int(r.returncode)


if __name__ == "__main__":
    raise SystemExit(main())
