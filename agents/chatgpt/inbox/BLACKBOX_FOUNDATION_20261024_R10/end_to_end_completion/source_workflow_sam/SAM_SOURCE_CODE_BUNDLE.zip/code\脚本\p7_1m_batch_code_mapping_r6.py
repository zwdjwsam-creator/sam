#!/usr/bin/env python3
"""P7_1M_BATCH_CODE_MAPPING_R6 — PIT batch code mapping + expected_empty (no JQ API)."""
from __future__ import annotations

import csv
import json
import re
from datetime import date, datetime
from pathlib import Path
from typing import Any

import pandas as pd

import p7_gate_common as gc

STOCKS_PER_BATCH = 5
P0 = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P0_meta")
POOL_DIR = gc.REPAIR / "queue_fix" / "1m_matrix_pools"

GET_PRICE_KWARGS_1M: dict[str, Any] = {
    "frequency": "1m",
    "fields": ["open", "close", "high", "low", "volume", "money"],
    "skip_paused": True,
    "fq": "pre",
    "count": None,
    "panel": False,
    "fill_paused": True,
    "round": True,
}


def year_end_for(year: str | int) -> date:
    y = int(year)
    if y >= 2026:
        return min(date(y, 12, 31), date.today())
    return date(y, 12, 31)


def year_start_for(year: str | int) -> date:
    return date(int(year), 1, 1)


def load_securities_df() -> pd.DataFrame:
    sec = sorted(P0.glob("securities_stock__*.parquet"))[-1]
    df = pd.read_parquet(sec)
    df["code"] = df["code"].astype(str)
    return df


def all_stock_codes(sec: pd.DataFrame | None = None) -> list[str]:
    sec = sec if sec is not None else load_securities_df()
    return sorted(
        c
        for c in sec["code"].dropna().unique()
        if isinstance(c, str) and c.endswith(("XSHE", "XSHG"))
    )


def runtime_codes_from_batch(batch_id: str, all_codes: list[str] | None = None) -> list[str]:
    try:
        bi = int(str(batch_id).replace("batch", ""))
    except ValueError:
        return []
    codes = all_codes if all_codes is not None else all_stock_codes()
    return codes[bi * STOCKS_PER_BATCH : bi * STOCKS_PER_BATCH + STOCKS_PER_BATCH]


def parse_codes_field(raw: str | None) -> list[str]:
    if not raw or not str(raw).strip():
        return []
    s = str(raw).strip()
    if s.startswith("["):
        try:
            data = json.loads(s)
            return [str(x) for x in data if x]
        except json.JSONDecodeError:
            pass
    return [c.strip() for c in re.split(r"[|,;]", s) if c.strip()]


def codes_for_queue_row(row: dict[str, str], all_codes: list[str] | None = None) -> tuple[list[str], str]:
    for key in ("eligible_codes", "stock_codes", "fixed_stock_codes"):
        parsed = parse_codes_field(row.get(key))
        if parsed:
            return parsed, f"queue_{key}"
    bid = row.get("batch_id", "")
    return runtime_codes_from_batch(bid, all_codes), "runtime_all_codes_batch_index"


def classify_partition(
    year: str | int,
    batch_id: str,
    *,
    queue_row: dict[str, str] | None = None,
    sec: pd.DataFrame | None = None,
    all_codes: list[str] | None = None,
) -> dict[str, Any]:
    sec = sec if sec is not None else load_securities_df()
    all_codes = all_codes if all_codes is not None else all_stock_codes(sec)
    row = queue_row or {"year": str(year), "batch_id": batch_id}
    old_runtime = runtime_codes_from_batch(batch_id, all_codes)
    codes, code_source = codes_for_queue_row(row, all_codes)
    ys = year_start_for(year)
    ye = year_end_for(year)

    per_code: list[dict[str, Any]] = []
    eligible: list[str] = []
    expected_empty: list[str] = []
    unknown: list[str] = []

    for code in codes:
        sub = sec[sec["code"] == code]
        if sub.empty:
            unknown.append(code)
            per_code.append(
                {
                    "code": code,
                    "start_date": "",
                    "end_date": "",
                    "listed_by_year_end": False,
                    "reason": "unknown_in_p0",
                }
            )
            continue
        sd = pd.Timestamp(sub.iloc[0]["start_date"]).date()
        ed_raw = sub.iloc[0]["end_date"]
        ed = pd.Timestamp(ed_raw).date() if pd.notna(ed_raw) else date(2200, 1, 1)
        listed = sd <= ye and ed >= ys
        if sd > ye:
            reason = "start_after_year_end"
            expected_empty.append(code)
        elif ed < ys:
            reason = "end_before_year_start"
            expected_empty.append(code)
        else:
            reason = "eligible_in_year"
            eligible.append(code)
        per_code.append(
            {
                "code": code,
                "start_date": str(sd),
                "end_date": str(ed),
                "listed_by_year_end": listed,
                "reason": reason,
            }
        )

    all_expected = bool(codes) and len(eligible) == 0 and len(unknown) == 0
    partial = bool(eligible) and bool(expected_empty)
    if not codes:
        mapping_class = "unknown"
    elif all_expected:
        mapping_class = "all_expected_empty"
    elif partial:
        mapping_class = "partial_expected_empty"
    elif unknown:
        mapping_class = "unknown"
    else:
        mapping_class = "still_downloadable"

    return {
        "year": str(year),
        "batch_id": batch_id,
        "partition_key": row.get("partition_key") or f"1m/{year}/{batch_id}",
        "year_end": str(ye),
        "old_runtime_codes": "|".join(old_runtime),
        "resolved_codes": "|".join(codes),
        "code_source": code_source,
        "eligible_codes": "|".join(eligible),
        "expected_empty_codes": "|".join(expected_empty),
        "unknown_codes": "|".join(unknown),
        "per_code_json": json.dumps(per_code, ensure_ascii=False),
        "all_expected_empty": all_expected,
        "partial_expected_empty": partial,
        "mapping_class": mapping_class,
        "queue_status": row.get("status", ""),
    }


def get_price_call_plan(year: str, eligible_codes: list[str]) -> dict[str, Any] | None:
    if not eligible_codes:
        return None
    ys = year_start_for(year)
    ye = year_end_for(year)
    return {
        "security": eligible_codes,
        "start_date": ys.isoformat(),
        "end_date": ye.isoformat(),
        **GET_PRICE_KWARGS_1M,
        "dry_run": True,
        "jqdata_api_called": False,
    }


def load_all_queue_rows() -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for pool in gc.POOLS:
        p = POOL_DIR / f"p7_1m_queue_{pool}.csv"
        if not p.exists():
            continue
        for r in csv.DictReader(p.read_text(encoding="utf-8-sig").splitlines()):
            r = dict(r)
            r["_pool"] = pool
            rows.append(r)
    return rows


def count_completed_on_disk() -> int:
    n = 0
    for f in gc.P7.glob("stock_minute_1m__*.parquet"):
        if ".sidecar" in f.name or ".checksum" in f.name:
            continue
        n += 1
    return n


def load_empty_result_partitions() -> set[str]:
    out: set[str] = set()
    matrix = gc.MATRIX_1M
    for el in matrix.glob("**/execution_log/worker_*_execution_*.csv"):
        try:
            for r in csv.DictReader(el.read_text(encoding="utf-8-sig").splitlines()):
                if r.get("result_status") == "empty_result":
                    pk = r.get("partition_key", "")
                    if pk:
                        out.add(pk)
        except Exception:
            continue
    return out


def repair_queue_row(row: dict[str, str], cls: dict[str, Any], *, apply: bool = False) -> dict[str, str]:
    """Return updated row; apply=False for dry-run only."""
    out = dict(row)
    out["stock_codes"] = cls["resolved_codes"]
    out["eligible_codes"] = cls["eligible_codes"]
    out["expected_empty_codes"] = cls["expected_empty_codes"]
    out["mapping_class_r6"] = cls["mapping_class"]
    out["code_source_r6"] = cls["code_source"]

    mc = cls["mapping_class"]
    if mc == "all_expected_empty":
        out["status"] = "expected_empty_done"
        out["api_call_allowed"] = "false"
        out["reason"] = "mapping_r6_all_expected_empty"
        out["no_redownload"] = "true"
    elif mc == "partial_expected_empty":
        out["status"] = row.get("status", "missing")
        out["api_call_allowed"] = "true" if cls["eligible_codes"] else "false"
        out["reason"] = "mapping_r6_partial_expected_empty"
    elif mc == "still_downloadable":
        out["status"] = row.get("status", "missing")
        out["api_call_allowed"] = "true"
        out["reason"] = row.get("reason", "1m_missing_gap_only")
    else:
        out["reason"] = "mapping_r6_unknown"
    return out
