# -*- coding: utf-8 -*-
"""
BLACKBOX 回测因果信息时钟硬门 R1。

rule_id = BLACKBOX_HAND_BACKTEST_CAUSAL_INFORMATION_STANDARD_R1

唯一正式判断：
  KNOWN_AT <= SIGNAL_TIME < FILL_TIME

用法：
  python -u 脚本/blackbox_backtest_causal_information_gate_r1.py --receipt <receipt.json>
  python -u 脚本/blackbox_backtest_causal_information_gate_r1.py --self-test
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Any

from _base import ROOT, write_text  # noqa: E402

RULE_ID = "BLACKBOX_HAND_BACKTEST_CAUSAL_INFORMATION_STANDARD_R1"
RULE_JSON = ROOT / "规则库/hand_hard_rules" / f"{RULE_ID}.json"

LOOKAHEAD_CLASSES = [
    "FUTURE_DATE_LOOKAHEAD",
    "SAME_DAY_INTRADAY_LOOKAHEAD",
    "PUBLICATION_LOOKAHEAD",
    "REVISION_LOOKAHEAD",
    "UNIVERSE_LOOKAHEAD",
    "CORPORATE_ACTION_LOOKAHEAD",
    "SAME_BAR_LOOKAHEAD",
    "SIGNAL_FILL_LOOKAHEAD",
    "TIMESTAMP_AUTHORITY_UNRESOLVED",
]


def _parse_dt(v: Any) -> datetime | None:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v
    s = str(v).strip()
    if not s or s.upper() in {"NA", "N/A", "NONE", "NULL", "UNRESOLVED"}:
        return None
    # date-only → assume EOD 15:00 local (conservative for daily products)
    if len(s) == 10 and s[4] == "-" and s[7] == "-":
        d = date.fromisoformat(s)
        return datetime.combine(d, time(15, 0, 0))
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return None


def _parse_date(v: Any) -> date | None:
    if v is None or v == "":
        return None
    if isinstance(v, date) and not isinstance(v, datetime):
        return v
    s = str(v).strip()[:10]
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def classify_field(field: dict, signal_time: datetime | None, fill_time: datetime | None) -> list[str]:
    fails: list[str] = []
    known = _parse_dt(field.get("known_at"))
    obs_date = _parse_date(field.get("observation_date") or field.get("observation_timestamp"))
    auth = str(field.get("timestamp_authority") or field.get("authority") or "").upper()
    kind = str(field.get("lookahead_hint") or field.get("class_hint") or "").upper()
    product = str(field.get("source_product") or "").upper()
    name = str(field.get("field_name") or field.get("name") or "")
    bar_start = _parse_dt(field.get("bar_start"))
    bar_end = _parse_dt(field.get("bar_end"))

    if auth in {"UNRESOLVED", "TIMESTAMP_AUTHORITY_UNRESOLVED"} or field.get("timestamp_authority_unresolved") is True:
        fails.append("TIMESTAMP_AUTHORITY_UNRESOLVED")
        return fails

    if known is None and signal_time is not None:
        # missing known_at with no unresolved flag → unresolved stop
        fails.append("TIMESTAMP_AUTHORITY_UNRESOLVED")
        return fails

    if signal_time is None:
        fails.append("TIMESTAMP_AUTHORITY_UNRESOLVED")
        return fails

    if known is not None and known > signal_time:
        # subtype
        if obs_date and signal_time.date() and obs_date > signal_time.date():
            fails.append("FUTURE_DATE_LOOKAHEAD")
        elif kind == "PUBLICATION" or "REPORT" in product or field.get("publication_after_signal"):
            fails.append("PUBLICATION_LOOKAHEAD")
        elif kind == "REVISION" or field.get("revision_lookahead"):
            fails.append("REVISION_LOOKAHEAD")
        elif kind == "UNIVERSE" or "MEMBERSHIP" in product or field.get("universe_lookahead"):
            fails.append("UNIVERSE_LOOKAHEAD")
        elif kind in {"CORP", "CORPORATE"} or field.get("corporate_action_lookahead"):
            fails.append("CORPORATE_ACTION_LOOKAHEAD")
        elif (
            obs_date
            and obs_date == signal_time.date()
            and (
                field.get("eod_daily")
                or "DAILY" in product
                or "INDUSTRY" in name.upper()
                or known.time() >= time(15, 0)
            )
        ):
            fails.append("SAME_DAY_INTRADAY_LOOKAHEAD")
        else:
            fails.append("SAME_DAY_INTRADAY_LOOKAHEAD")

    # same-bar: signal at bar start while consuming full bar ending later
    if bar_start and bar_end and signal_time:
        if signal_time <= bar_start and bar_end > bar_start and field.get("uses_full_bar", True):
            if known and known >= bar_end:
                fails.append("SAME_BAR_LOOKAHEAD")
        # classic: SIGNAL at 09:45:00 using bar 09:45:00-09:45:59
        if bar_start == signal_time and bar_end > signal_time:
            fails.append("SAME_BAR_LOOKAHEAD")

    return list(dict.fromkeys(fails))


def validate_receipt(data: dict) -> tuple[str, list[str], list[str]]:
    """Return (status, fails, classes)."""
    fails: list[str] = []
    classes: list[str] = []

    signal_time = _parse_dt(data.get("signal_time"))
    fill_time = _parse_dt(data.get("fill_time"))
    order_time = _parse_dt(data.get("order_time"))

    if data.get("date_le_signal_date_as_sufficient") is True:
        fails.append("DATE_LE_SIGNAL_DATE_NOT_SUFFICIENT")

    if signal_time is None:
        fails.append("TIMESTAMP_AUTHORITY_UNRESOLVED:missing_signal_time")
        classes.append("TIMESTAMP_AUTHORITY_UNRESOLVED")

    if fill_time is None:
        fails.append("TIMESTAMP_AUTHORITY_UNRESOLVED:missing_fill_time")
        classes.append("TIMESTAMP_AUTHORITY_UNRESOLVED")

    if signal_time and fill_time:
        if not (signal_time < fill_time):
            fails.append("SIGNAL_FILL_LOOKAHEAD")
            classes.append("SIGNAL_FILL_LOOKAHEAD")
        if order_time is not None:
            if not (signal_time < order_time <= fill_time):
                fails.append("SIGNAL_FILL_LOOKAHEAD:order_window")
                classes.append("SIGNAL_FILL_LOOKAHEAD")

    fields = data.get("fields") or data.get("field_lineage") or []
    if isinstance(fields, dict):
        fields = list(fields.values())

    for f in fields:
        if not isinstance(f, dict):
            continue
        fc = classify_field(f, signal_time, fill_time)
        for c in fc:
            fails.append(f"{c}:{f.get('field_name') or f.get('name') or '?'}")
            classes.append(c)

    # mode checks
    mode = str(data.get("information_mode") or "").upper()
    if mode == "PREVIOUS_DAY_CAUSAL":
        # Daily/EOD rows may share calendar date with SIGNAL_TIME (prev EOD),
        # but must not use the FILL/trade calendar day's complete bar.
        fill_d = fill_time.date() if fill_time else None
        for f in fields:
            if not isinstance(f, dict):
                continue
            if f.get("eod_daily") and fill_d:
                od = _parse_date(f.get("observation_date"))
                if od and od >= fill_d:
                    fails.append(f"SAME_DAY_INTRADAY_LOOKAHEAD:{f.get('field_name')}:mode1")
                    classes.append("SAME_DAY_INTRADAY_LOOKAHEAD")

    # HARD trap: EOD / close panel → same-day open (or morning) fill
    # See BLACKBOX_HAND_BACKTEST_MANDATORY_PRECHECK_R1
    if data.get("eod_to_same_day_open") is True or str(data.get("EOD_TO_SAME_DAY_OPEN") or "").upper() in {
        "YES",
        "TRUE",
        "1",
    }:
        fails.append("EOD_ORACLE_SAME_DAY_OPEN:declared")
        classes.append("SAME_DAY_INTRADAY_LOOKAHEAD")

    fill_price = str(data.get("fill_price_source") or data.get("fill_price") or "").upper()
    if signal_time and fill_time and fill_time.date() == signal_time.date():
        morning_fill = fill_time.time() <= time(11, 30, 0)
        openish = fill_price in {"OPEN", "D_OPEN", "AUCTION_OPEN", "MORNING_OPEN"} or (
            fill_time.time() <= time(9, 35, 0)
        )
        if morning_fill or openish:
            for f in fields:
                if not isinstance(f, dict):
                    continue
                known = _parse_dt(f.get("known_at"))
                od = _parse_date(f.get("observation_date"))
                if not known:
                    continue
                same_day_eod = (
                    f.get("eod_daily")
                    or known.time() >= time(15, 0)
                    or str(f.get("source_product") or "").upper().find("DAILY") >= 0
                )
                if same_day_eod and od and od == signal_time.date() and known.date() == signal_time.date():
                    fails.append(
                        f"EOD_ORACLE_SAME_DAY_OPEN:{f.get('field_name') or f.get('name') or '?'}"
                    )
                    classes.append("SAME_DAY_INTRADAY_LOOKAHEAD")

    # mandatory precheck block (optional but if present must not claim illegal)
    mpc = data.get("mandatory_precheck") or data.get("BACKTEST_MANDATORY_PRECHECK") or {}
    if isinstance(mpc, dict) and mpc:
        if str(mpc.get("EOD_TO_SAME_DAY_OPEN") or "").upper() in {"YES", "TRUE", "1"}:
            fails.append("EOD_ORACLE_SAME_DAY_OPEN:precheck")
            classes.append("SAME_DAY_INTRADAY_LOOKAHEAD")
        if str(mpc.get("SIGNAL_LT_FILL") or "").upper() in {"NO", "FALSE", "0"}:
            fails.append("SIGNAL_FILL_LOOKAHEAD:precheck")
            classes.append("SIGNAL_FILL_LOOKAHEAD")

    classes = list(dict.fromkeys(classes))
    status = "PASS" if not fails else "FAIL"
    return status, fails, classes


def regression_cases() -> list[dict]:
    """Fixed CASE_A..CASE_J."""
    d = date(2018, 6, 1)
    d1 = date(2018, 6, 4)  # next trade proxy
    cases = []

    def base(**kw):
        return kw

    # A: D 09:30 uses D close → FAIL
    cases.append(
        {
            "case_id": "CASE_A",
            "expect": "FAIL",
            "expect_class": "SAME_DAY_INTRADAY_LOOKAHEAD",
            "receipt": base(
                signal_time="2018-06-01T09:30:00",
                fill_time="2018-06-01T09:30:00",  # also fill equal - but focus close
                fields=[
                    {
                        "field_name": "close",
                        "source_product": "STOCK_DAILY",
                        "observation_date": "2018-06-01",
                        "known_at": "2018-06-01T15:00:00",
                        "eod_daily": True,
                    }
                ],
            ),
        }
    )
    # fix CASE_A fill > signal for isolated field test? User said D 09:30 use D close MUST FAIL
    # Use fill 09:31 so SIGNAL_FILL doesn't dominate
    cases[0]["receipt"]["fill_time"] = "2018-06-01T09:31:00"

    # B: D 09:30 uses D final industry breadth → FAIL
    cases.append(
        {
            "case_id": "CASE_B",
            "expect": "FAIL",
            "expect_class": "SAME_DAY_INTRADAY_LOOKAHEAD",
            "receipt": base(
                signal_time="2018-06-01T09:30:00",
                fill_time="2018-06-01T09:31:00",
                fields=[
                    {
                        "field_name": "industry_up_ratio",
                        "source_product": "INDUSTRY_EOD",
                        "observation_date": "2018-06-01",
                        "known_at": "2018-06-01T15:00:00",
                        "eod_daily": True,
                    }
                ],
            ),
        }
    )

    # C: D+1 09:30 uses D close → PASS
    cases.append(
        {
            "case_id": "CASE_C",
            "expect": "PASS",
            "expect_class": None,
            "receipt": base(
                signal_time="2018-06-04T09:25:00",
                fill_time="2018-06-04T09:30:00",
                information_mode="PREVIOUS_DAY_CAUSAL",
                fields=[
                    {
                        "field_name": "close",
                        "source_product": "STOCK_DAILY",
                        "observation_date": "2018-06-01",
                        "known_at": "2018-06-01T15:00:00",
                        "eod_daily": True,
                    }
                ],
            ),
        }
    )

    # D: D 09:45 uses <=09:44 completed minutes → PASS
    cases.append(
        {
            "case_id": "CASE_D",
            "expect": "PASS",
            "expect_class": None,
            "receipt": base(
                signal_time="2018-06-01T09:45:00",
                fill_time="2018-06-01T09:46:00",
                information_mode="INTRADAY_ASOF_CAUSAL",
                fields=[
                    {
                        "field_name": "minute_close",
                        "source_product": "STOCK_1M",
                        "observation_date": "2018-06-01",
                        "known_at": "2018-06-01T09:44:00",
                        "bar_start": "2018-06-01T09:44:00",
                        "bar_end": "2018-06-01T09:45:00",
                        "uses_full_bar": True,
                    }
                ],
            ),
        }
    )

    # E: D 09:45 uses 09:45~09:45:59 full bar → FAIL
    cases.append(
        {
            "case_id": "CASE_E",
            "expect": "FAIL",
            "expect_class": "SAME_BAR_LOOKAHEAD",
            "receipt": base(
                signal_time="2018-06-01T09:45:00",
                fill_time="2018-06-01T09:46:00",
                fields=[
                    {
                        "field_name": "minute_bar_0945",
                        "source_product": "STOCK_1M",
                        "observation_date": "2018-06-01",
                        "known_at": "2018-06-01T09:46:00",
                        "bar_start": "2018-06-01T09:45:00",
                        "bar_end": "2018-06-01T09:46:00",
                        "uses_full_bar": True,
                    }
                ],
            ),
        }
    )

    # F: 09:45 signal → 09:45 open fill → FAIL
    cases.append(
        {
            "case_id": "CASE_F",
            "expect": "FAIL",
            "expect_class": "SIGNAL_FILL_LOOKAHEAD",
            "receipt": base(
                signal_time="2018-06-01T09:45:00",
                fill_time="2018-06-01T09:45:00",
                fields=[
                    {
                        "field_name": "asof_price",
                        "source_product": "TICK",
                        "observation_date": "2018-06-01",
                        "known_at": "2018-06-01T09:44:59",
                    }
                ],
            ),
        }
    )

    # G: unpublished report → FAIL
    cases.append(
        {
            "case_id": "CASE_G",
            "expect": "FAIL",
            "expect_class": "PUBLICATION_LOOKAHEAD",
            "receipt": base(
                signal_time="2018-03-31T09:30:00",
                fill_time="2018-03-31T09:31:00",
                fields=[
                    {
                        "field_name": "roe_q1",
                        "source_product": "FINANCE_REPORT",
                        "observation_date": "2018-03-31",
                        "known_at": "2018-04-28T15:00:00",
                        "lookahead_hint": "PUBLICATION",
                        "publication_after_signal": True,
                    }
                ],
            ),
        }
    )

    # H: PIT after publish → PASS
    cases.append(
        {
            "case_id": "CASE_H",
            "expect": "PASS",
            "expect_class": None,
            "receipt": base(
                signal_time="2018-04-30T09:25:00",
                fill_time="2018-04-30T09:30:00",
                fields=[
                    {
                        "field_name": "roe",
                        "source_product": "FINANCIAL_INDICATOR_PIT",
                        "observation_date": "2018-03-31",
                        "known_at": "2018-04-28T15:00:00",
                    }
                ],
            ),
        }
    )

    # I: D daily PB without intraday known_at used at 09:45 → FAIL/UNRESOLVED
    cases.append(
        {
            "case_id": "CASE_I",
            "expect": "FAIL",
            "expect_class": "TIMESTAMP_AUTHORITY_UNRESOLVED",
            "receipt": base(
                signal_time="2018-06-01T09:45:00",
                fill_time="2018-06-01T09:46:00",
                fields=[
                    {
                        "field_name": "pb_ratio",
                        "source_product": "VALUATION_DAILY",
                        "observation_date": "2018-06-01",
                        "known_at": None,
                        "timestamp_authority_unresolved": True,
                    }
                ],
            ),
        }
    )

    # J: D EOD close → D open fill（收盘买开盘）→ FAIL
    cases.append(
        {
            "case_id": "CASE_J",
            "expect": "FAIL",
            "expect_class": "SAME_DAY_INTRADAY_LOOKAHEAD",
            "receipt": base(
                signal_time="2018-06-01T09:25:00",
                fill_time="2018-06-01T09:30:00",
                fill_price_source="OPEN",
                information_mode="INTRADAY_ASOF_CAUSAL",
                fields=[
                    {
                        "field_name": "close",
                        "source_product": "STOCK_DAILY",
                        "observation_date": "2018-06-01",
                        "known_at": "2018-06-01T15:00:00",
                        "eod_daily": True,
                    }
                ],
            ),
        }
    )
    return cases


def run_self_test() -> dict:
    results = []
    all_ok = True
    for case in regression_cases():
        status, fails, classes = validate_receipt(case["receipt"])
        expect = case["expect"]
        ok = status == expect
        if ok and case.get("expect_class"):
            ok = case["expect_class"] in classes or any(case["expect_class"] in f for f in fails)
        if not ok:
            all_ok = False
        results.append(
            {
                "case_id": case["case_id"],
                "expect": expect,
                "got": status,
                "classes": classes,
                "fails": fails,
                "pass": ok,
            }
        )
    return {"all_pass": all_ok, "results": results, "rule_id": RULE_ID}


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Causal information gate R1")
    p.add_argument("--receipt", type=str, default="")
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--write-verdict", type=str, default="")
    p.add_argument("--write-self-test", type=str, default="")
    args = p.parse_args(argv)

    if args.self_test:
        out = run_self_test()
        text = json.dumps(out, ensure_ascii=False, indent=2)
        print(text)
        if args.write_self_test:
            write_text(Path(args.write_self_test), text + "\n")
        return 0 if out["all_pass"] else 2

    if not args.receipt:
        print("need --receipt or --self-test", file=sys.stderr)
        return 2

    data = json.loads(Path(args.receipt).read_text(encoding="utf-8"))
    status, fails, classes = validate_receipt(data)
    verdict = {
        "rule_id": RULE_ID,
        "status": status,
        "LOOKAHEAD_CLASS": classes,
        "fails": fails,
        "BACKTEST_RETURN_VALID": status == "PASS",
        "formula": "KNOWN_AT <= SIGNAL_TIME < FILL_TIME",
    }
    print(json.dumps(verdict, ensure_ascii=False, indent=2))
    if args.write_verdict:
        write_text(Path(args.write_verdict), json.dumps(verdict, ensure_ascii=False, indent=2) + "\n")
    return 0 if status == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
