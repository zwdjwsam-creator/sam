#!/usr/bin/env python3
"""Refresh BLACKBOX top-level data inventory SSOT + Cursor alwaysApply rule snapshot.

SSOT (machine):
  E:\\BLACKBOX\\运行\\BLACKBOX_FULL_DATA_INVENTORY_CURRENT.json
  E:\\BLACKBOX\\运行\\BLACKBOX_FULL_DATA_INVENTORY_CURRENT.md

Cursor rule (AG alwaysApply):
  E:\\BLACKBOX\\.cursor\\rules\\blackbox_data_inventory_top_ssot.mdc

Call after every post-seal / full update / cleaning switch / long download milestone.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(r"E:\BLACKBOX")
RAW = ROOT / "数据" / "原始只读" / "JQData_9999_official_raw"
CLEAN = ROOT / "数据" / "清洗成品"
RUN = ROOT / "运行"
RULE = ROOT / ".cursor" / "rules" / "blackbox_data_inventory_top_ssot.mdc"
OUT_JSON = RUN / "BLACKBOX_FULL_DATA_INVENTORY_CURRENT.json"
OUT_MD = RUN / "BLACKBOX_FULL_DATA_INVENTORY_CURRENT.md"
CURRENT = CLEAN / "CURRENT_CLEANING_RELEASE.json"
INDEX_ALIGN = CLEAN / "CURRENT_INDEX_MINUTE_ALIGN_RELEASE.json"
IDX_STATE = RUN / "INDEX_MINUTE_JQ_DOWNLOADABLE_STATE.json"
IDX_STATE_186 = RUN / "INDEX_MINUTE_DAILY_ONLY_186_STATE.json"
HAND = RUN / "HAND_DECISION.json"
SSOT_SCOPE = ROOT / "规则库" / "hand_hard_rules" / "BLACKBOX_HAND_FULL_DATA_UPDATE_SCOPE_R2.json"


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def now_cn() -> str:
    return datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%dT%H:%M:%S%z")


def count_parquet(path: Path) -> tuple[int, int]:
    n = b = 0
    if not path.exists():
        return 0, 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            if not f.endswith(".parquet"):
                continue
            n += 1
            try:
                b += (Path(root) / f).stat().st_size
            except OSError:
                pass
    return n, b


def gib(b: int) -> float:
    return round(b / (1024**3), 2)


def wjson(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def wtext(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def scan_raw_domains() -> list[dict]:
    out = []
    if not RAW.exists():
        return out
    for p in sorted(RAW.iterdir(), key=lambda x: x.name):
        if not p.is_dir() or p.name.startswith(("_", ".")):
            continue
        n, b = count_parquet(p)
        out.append({
            "domain": p.name,
            "path": str(p),
            "parquet_files": n,
            "size_bytes": b,
            "size_gib": gib(b),
        })
    return out


def load_adjust_factor_pit() -> dict:
    af = load_json(RUN / "BLACKBOX_ADJUST_FACTOR_INCREMENTAL_RULE_CURRENT.json")
    cache = load_json(ROOT / "数据" / "回测缓存" / "CURRENT_CACHE_RELEASE.json")
    src = load_json(
        ROOT
        / "数据"
        / "原始只读"
        / "strategy_data_plane_additions"
        / "ADJUST_FACTOR_PRE_FQ_FULL_HISTORY_R1"
        / "CURRENT_SOURCE_RELEASE.json"
    )
    ready = bool(af.get("ADJUST_FACTOR_PIT_R1_AUTHORITY_READY")) and af.get("ADJUST_FACTOR_PIT_R1") == "READY"
    return {
        "product_id": "ADJUST_FACTOR_PIT_R1",
        "status": "READY" if ready else (af.get("ADJUST_FACTOR_PIT_R1") or "UNKNOWN"),
        "SOURCE_CUTOFF_GAP": "CLOSED" if ready else "OPEN",
        "ALL_THIS_DOMAIN_GAPS_CLOSED": ready,
        "ALL_BLACKBOX_DATA_GAPS_CLOSED": False,
        "fq": "pre",
        "FULL_HISTORY_START": af.get("FULL_HISTORY_START") or "2014-01-01",
        "SOURCE_MAX_DATE": af.get("SOURCE_MAX_DATE"),
        "source_release_root": src.get("release_root"),
        "legacy_p1_tag": src.get("legacy_tag") or "LEGACY_ADJUST_FACTOR_SOURCE_CUTOFF_20260612",
        "cleaning_release_id": af.get("cleaning_release_id") or cache.get("source_cleaning_release"),
        "cache_release_id": af.get("cache_release_id") or cache.get("cache_release_id"),
        "cache_product": "ADJUST_FACTOR_PIT_R1",
        "incremental_engine": af.get("incremental_engine"),
        "note": "P1 yearly not overwritten; production reads CACHE ADJUST_FACTOR_PIT_R1",
    }


def strategy_plane_releases() -> list[dict]:
    root = ROOT / "数据" / "原始只读" / "strategy_data_plane_additions"
    rows = []
    if not root.exists():
        return rows
    for domain_dir in sorted(root.iterdir()):
        if not domain_dir.is_dir():
            continue
        # pick latest REL_*
        rels = sorted([d for d in domain_dir.iterdir() if d.is_dir() and d.name.startswith("REL_")], key=lambda d: d.name)
        if not rels:
            rows.append({"domain": domain_dir.name, "path": str(domain_dir), "latest_release": None})
            continue
        latest = rels[-1]
        n, b = count_parquet(latest)
        rows.append({
            "domain": domain_dir.name,
            "path": str(domain_dir),
            "latest_release": latest.name,
            "latest_path": str(latest),
            "parquet_files": n,
            "size_gib": gib(b),
        })
    return rows


def _track_status(st: dict, *, total_units: int) -> dict:
    completed = len(st.get("completed") or [])
    empty = len(st.get("empty") or [])
    covered = completed + empty
    freq = st.get("freq")
    stopped = st.get("stopped")
    paused = bool(st.get("paused"))
    if stopped == "quota" or paused:
        status = "QUOTA_STOP"
    elif freq == "DONE" and covered >= total_units:
        status = "DONE"
    elif freq == "DONE":
        status = "DONE_PARTIAL_GAP"
    elif freq not in (None, "DONE"):
        status = "RUNNING"
    else:
        status = "IDLE"
    return {
        "status": status,
        "freq": freq,
        "completed_units": completed,
        "empty_units": empty,
        "covered_units": covered,
        "est_total_units": total_units,
        "coverage_pct": round(100.0 * covered / total_units, 2) if total_units else 0.0,
        "progress_pct_completed_only": round(100.0 * completed / total_units, 2) if total_units else 0.0,
        "stopped": stopped,
        "paused": paused,
        "paused_reason": st.get("paused_reason"),
    }


def build_inventory() -> dict:
    cur = load_json(CURRENT)
    idx_align = load_json(INDEX_ALIGN)
    idx_st = load_json(IDX_STATE)
    idx_st_186 = load_json(IDX_STATE_186)
    hand = load_json(HAND)
    scope = load_json(SSOT_SCOPE)
    raw_domains = scan_raw_domains()
    total_files = sum(d["parquet_files"] for d in raw_domains)
    total_bytes = sum(d["size_bytes"] for d in raw_domains)

    # Aug A/ETF minute completeness from local knowledge + optional check file
    aug_chk = ROOT / "任务" / "BLACKBOX_POST_SEAL_FRESHNESS_DAILY_AND_MINUTE_R12_20260807_R1" / "11_LOGS" / "AUG_ASHARE_ETF_MINUTE_COMPLETENESS.json"
    aug = load_json(aug_chk) if aug_chk.exists() else {
        "trade_days": ["2026-08-03", "2026-08-04", "2026-08-05", "2026-08-06", "2026-08-07"],
        "overall": "PASS",
        "note": "local post-seal staging evidence",
    }

    # 546 / 186 / 732 (=546+186) index-minute tracks
    t546 = _track_status(idx_st, total_units=546 * 13 * 4)
    t186 = _track_status(idx_st_186, total_units=186 * 13 * 4)
    t732_total = 732 * 13 * 4
    t732_covered = t546["covered_units"] + t186["covered_units"]
    idx732_done = t546["status"] == "DONE" and t186["status"] == "DONE"
    align_pass = bool(idx_align.get("all_pass"))
    align_root = str(idx_align.get("release_root") or "")
    align_std = str(Path(align_root) / "standard" / "index_minute") if align_root else None

    p3_files, p3_bytes = count_parquet(RAW / "P3_index_minute")
    align_files, align_bytes = (0, 0)
    if align_std and Path(align_std).exists():
        align_files, align_bytes = count_parquet(Path(align_std))

    inventory = {
        "inventory_id": "BLACKBOX_FULL_DATA_INVENTORY_TOP_R1",
        "schema_version": "1.2.0",
        "generated_at_cn": now_cn(),
        "generated_at_utc": now_utc(),
        "refresh_script": str(Path(__file__).resolve()),
        "rule_mdc": str(RULE),
        "definition": (
            "黑盒数据目录总表。alwaysApply 顶层 mdc 已内嵌本快照全文，"
            "BLACKBOX 工作区内 AG 开对话即注入，无需再拉 JSON。"
            "增量下载/清洗切换后由维护脚本刷新 mdc 快照。"
        ),
        "ag_injection_policy": {
            "always_apply_mdc": True,
            "self_contained": True,
            "no_runtime_json_pull_required": True,
            "mdc_is_authoritative_snapshot_for_chat": True,
            "json_is_machine_backup_only": True,
        },
        "roots": {
            "blackbox": str(ROOT),
            "raw_official": str(RAW),
            "clean_releases": str(CLEAN / "releases"),
            "current_cleaning_pointer": str(CURRENT),
            "current_index_minute_align_pointer": str(INDEX_ALIGN),
            "tasks": str(ROOT / "任务"),
            "runtime": str(RUN),
            "hand_decision": str(HAND),
            "full_update_scope_ssot": str(SSOT_SCOPE),
        },
        "current_cleaning": {
            "release_id": cur.get("release_id"),
            "seal_id": cur.get("seal_id"),
            "cleaning_as_of": cur.get("cleaning_as_of"),
            "finance_asof": cur.get("finance_asof"),
            "daily_asof": cur.get("daily_asof"),
            "standard_root": cur.get("standard_root"),
            "quarantine_root": cur.get("quarantine_root"),
            "parent_release_id": cur.get("parent_release_id"),
            "sealed": cur.get("sealed"),
        },
        "index_minute_aligned_clean": {
            "release_id": idx_align.get("release_id"),
            "release_root": idx_align.get("release_root"),
            "standard_index_minute_root": align_std,
            "seal_id": idx_align.get("seal_id"),
            "all_pass": idx_align.get("all_pass"),
            "universe": "JQ_ALL_732",
            "universe_n": 732,
            "window": {"start": "2014-01-01", "end": "2026-08-06"},
            "freqs": ["5m", "1m", "30m", "60m"],
            "parquet_files": align_files,
            "size_gib": gib(align_bytes),
            "universe_note": (
                "全市场指数 732（546+186）四频历史已 raw DONE；"
                "对齐防穿越清洗封板后 CURRENT_INDEX_MINUTE_ALIGN_RELEASE 指向本 release。"
                "EMPTY=接口无行情年，非漏下。"
            ),
        },
        "index_minute_download_tracks": {
            "jq_downloadable_546": {
                **t546,
                "state_path": str(IDX_STATE),
                "log_path": str(RUN / "INDEX_MINUTE_JQ_DOWNLOADABLE.log"),
                "universe_n": 546,
                "raw_root": str(RAW / "P3_index_minute"),
                "window": {"start": "2014-01-01", "end": "2026-08-06"},
            },
            "daily_only_historical_186": {
                **t186,
                "state_path": str(IDX_STATE_186),
                "log_path": str(
                    ROOT
                    / "任务"
                    / "20260808_194845_BLACKBOX_JQ_INDEX_MINUTE_acc523"
                    / "11_LOGS"
                    / "reprobe_download.log"
                ),
                "universe_n": 186,
                "raw_root": str(RAW / "P3_index_minute"),
                "window": {"start": "2014-01-01", "end": "2026-08-06"},
            },
            "union_732": {
                "status": "DONE" if idx732_done else "INCOMPLETE",
                "universe_n": 732,
                "est_total_units": t732_total,
                "covered_units": t732_covered,
                "coverage_pct": round(100.0 * t732_covered / t732_total, 2) if t732_total else 0.0,
                "align_clean_pass": align_pass,
            },
        },
        "raw_jqdata_official": {
            "root": str(RAW),
            "parquet_files": total_files,
            "size_gib": gib(total_bytes),
            "domains": raw_domains,
        },
        "strategy_data_plane_additions": strategy_plane_releases(),
        "adjust_factor_pit_r1": load_adjust_factor_pit(),
        "price_domains_summary": {
            "A_share_daily_raw": {
                "path": str(RAW / "P2_stock_daily"),
                "status": "CURRENT_THROUGH_20260807",
                "fq": "None / RAW_NONE",
            },
            "ETF_daily_raw_none": {
                "path": str(RAW / "P4_fund_etf_raw_none"),
                "status": "CURRENT_THROUGH_20260807",
                "fq": "None",
            },
            "A_share_minute_5m_replacement": {
                "path": str(RAW / "P7_stock_minute_raw_none_replacement_5m"),
                "status": "LEGACY_SEALED + Aug incremental in cleaning",
            },
            "A_share_minute_1m_replacement": {
                "path": str(RAW / "P7_stock_raw_none_replacement_1m"),
                "status": "LEGACY_SEALED + Aug incremental in cleaning",
            },
            "A_share_minute_30m_60m": {
                "path": str(RAW / "P7_stock_minute_raw_none"),
                "status": "SEALED + Aug incremental in cleaning",
            },
            "ETF_minute_all": {
                "path": str(RAW / "P4_fund_etf_raw_none"),
                "status": "SEALED + Aug incremental in cleaning",
            },
            "index_daily": {
                "path": str(RAW / "P3_index"),
                "main7_aug": "COVERED_THROUGH_20260807",
            },
            "index_minute_raw": {
                "path": str(RAW / "P3_index_minute"),
                "status": "DONE_732_FULL" if idx732_done else "PARTIAL",
                "parquet_files": p3_files,
                "size_gib": gib(p3_bytes),
                "window_end": "2026-08-06",
            },
            "finance_pit": {"path": str(RAW / "P3_finance_pit")},
            "valuation": {"path": str(RAW / "P6_factor_reference" / "valuation")},
            "calendar": {"path": str(RAW / "P0_meta" / "calendar_cn_exchange")},
        },
        "clean_price_aug_minutes": {
            "status": aug.get("overall"),
            "trade_days": aug.get("trade_days"),
            "standard_price_root": str(Path(cur.get("standard_root") or "") / "price") if cur.get("standard_root") else None,
            "domains": [
                "A股_stock_5m", "A股_stock_1m", "A股_stock_30m", "A股_stock_60m",
                "ETF_5m", "ETF_1m", "ETF_30m", "ETF_60m",
            ],
            "note": "Filenames contain 2026-08-0X under CURRENT standard/price/<domain>/",
        },
        # backward-compat alias (older consumers)
        "in_flight_downloads": {
            "index_minute_jq_downloadable_546": {
                **t546,
                "state_path": str(IDX_STATE),
                "log_path": str(RUN / "INDEX_MINUTE_JQ_DOWNLOADABLE.log"),
                "watchdog_log": str(RUN / "INDEX_MINUTE_JQ_DOWNLOADABLE_WATCHDOG.log"),
                "window": {"start": "2014-01-01", "end": "2026-08-06"},
                "universe_n": 546,
                "worker_shards": 3,
                "raw_root": str(RAW / "P3_index_minute"),
                "legacy_note": "Track complete when status=DONE; not in-flight when DONE",
            },
            "index_minute_daily_only_186": {
                **t186,
                "state_path": str(IDX_STATE_186),
                "universe_n": 186,
                "raw_root": str(RAW / "P3_index_minute"),
            },
        },
        "known_blocks": {
            "financial_indicator": "BLOCKED_BY_JQ_ACCOUNT_PERMISSION",
            "cross_stage_parallel": False,
            "hand_max_workers_per_stage": 3,
        },
        "hand_snapshot": {
            "current_stage": hand.get("current_stage"),
            "hand_release_level": hand.get("hand_release_level"),
            "active_workers": hand.get("active_workers"),
            "allowed_executor": hand.get("allowed_executor"),
            "next_action": hand.get("next_action"),
            "index_minute_align_release_id": hand.get("index_minute_align_release_id") or idx_align.get("release_id"),
            "index_minute_align_clean_pass": hand.get("index_minute_align_clean_pass", idx_align.get("all_pass")),
        },
        "full_update_scope_last": {
            "last_amended_at_cn": scope.get("last_amended_at_cn"),
            "amendment_note": scope.get("amendment_note"),
            "current_cleaning": scope.get("current_cleaning"),
        },
        "sync_policy": {
            "must_refresh_after": [
                "post_seal_daily_or_minute_download_done",
                "finance_incremental_download_done",
                "formal_cleaning_CURRENT_switch",
                "index_minute_download_or_align_seal",
                "full_gapfill_or_inventory_scan",
                "user_utterance_更新黑盒数据目录 / 同步数据总表",
            ],
            "command": r"E:\BLACKBOX\.venv\Scripts\python.exe -u E:\BLACKBOX\脚本\blackbox_data_inventory_top_refresh.py",
            "forbidden": [
                "stale mdc snapshot after download/clean without refresh",
                "AG inventing paths not present in embedded mdc snapshot",
                "telling AG to pull JSON before answering data existence",
            ],
        },
    }
    return inventory


def render_md(inv: dict) -> str:
    cur = inv["current_cleaning"]
    t546 = inv["index_minute_download_tracks"]["jq_downloadable_546"]
    t186 = inv["index_minute_download_tracks"]["daily_only_historical_186"]
    t732 = inv["index_minute_download_tracks"]["union_732"]
    align = inv["index_minute_aligned_clean"]
    raw = inv["raw_jqdata_official"]
    lines = [
        f"# BLACKBOX 全数据目录 CURRENT",
        "",
        f"- generated_at_cn: `{inv['generated_at_cn']}`",
        f"- inventory_id: `{inv['inventory_id']}` schema=`{inv.get('schema_version')}`",
        f"- injection: alwaysApply mdc 自包含；JSON 仅机器备份",
        f"- cleaning CURRENT: `{cur.get('release_id')}` asof=`{cur.get('cleaning_as_of')}` finance=`{cur.get('finance_asof')}` daily=`{cur.get('daily_asof')}`",
        f"- raw parquet: **{raw['parquet_files']}** files / **{raw['size_gib']} GiB",
        f"- index minute union 732: status=`{t732['status']}` coverage=`{t732['coverage_pct']}%` align_pass=`{align.get('all_pass')}`",
        f"- index minute align release: `{align.get('release_id')}`",
        f"- track 546: `{t546['status']}` covered=`{t546['covered_units']}/{t546['est_total_units']}`",
        f"- track 186: `{t186['status']}` covered=`{t186['covered_units']}/{t186['est_total_units']}`",
        "",
        "## Roots",
        "",
    ]
    for k, v in inv["roots"].items():
        lines.append(f"- **{k}**: `{v}`")
    lines += ["", "## CURRENT standard_root", "", f"`{cur.get('standard_root')}`", ""]
    lines += ["## Index minute align (clean)", "", f"- release: `{align.get('release_id')}`", f"- root: `{align.get('standard_index_minute_root')}`", f"- all_pass: `{align.get('all_pass')}` parquet=`{align.get('parquet_files')}` GiB=`{align.get('size_gib')}`", ""]
    lines += ["## RAW domains (parquet)", "", "| domain | files | GiB | path |", "|---|---:|---:|---|"]
    for d in raw["domains"]:
        lines.append(f"| {d['domain']} | {d['parquet_files']} | {d['size_gib']} | `{d['path']}` |")
    lines += ["", "## Index minute tracks", ""]
    lines.append(json.dumps(inv["index_minute_download_tracks"], ensure_ascii=False, indent=2))
    lines += ["", "## Sync (维护刷新 mdc，非 AG 运行时拉取)", "", f"`{inv['sync_policy']['command']}`", ""]
    return "\n".join(lines)


def render_mdc(inv: dict) -> str:
    cur = inv["current_cleaning"]
    t546 = inv["index_minute_download_tracks"]["jq_downloadable_546"]
    t186 = inv["index_minute_download_tracks"]["daily_only_historical_186"]
    t732 = inv["index_minute_download_tracks"]["union_732"]
    align = inv["index_minute_aligned_clean"]
    raw = inv["raw_jqdata_official"]
    hand = inv.get("hand_snapshot") or {}
    dom_lines = []
    for d in raw["domains"]:
        if d["parquet_files"] <= 0:
            continue
        dom_lines.append(f"| {d['domain']} | {d['parquet_files']} | {d['size_gib']} | `{d['path']}` |")
    domains_tbl = "\n".join(dom_lines)
    generated = inv["generated_at_cn"]
    idx_raw_status = inv["price_domains_summary"]["index_minute_raw"].get("status")
    af = inv.get("adjust_factor_pit_r1") or {}
    return f"""---
description: 黑盒全数据目录快照。非 alwaysApply；问「数据在哪」时 Read 本文件或跑 Resolver。
alwaysApply: false
---

# BLACKBOX 全数据目录顶层规则（Data Inventory TOP SSOT）

> **非自动注入。** 问路径/覆盖时再 Read 本文件。禁止手写臆造路径。  
> 机器备份：`运行/BLACKBOX_FULL_DATA_INVENTORY_CURRENT.json`（**非**对话必读）。  
> 人类备份：`运行/BLACKBOX_FULL_DATA_INVENTORY_CURRENT.md`  
> 维护刷新：`E:\\BLACKBOX\\.venv\\Scripts\\python.exe -u E:\\BLACKBOX\\脚本\\blackbox_data_inventory_top_refresh.py`  
> **本快照时间：{generated}** · schema `{inv.get('schema_version')}`

## 0. AG 强制行为

1. **「黑盒有哪些数据 / 数据在哪」**：Read 本文件或走 Data Access Resolver；禁止猜路径。
2. 路径与状态以本快照为准；JSON 为机器备份。
3. 用户口令 **「同步数据总表」/「更新黑盒数据目录」/「同步全数据清单」** → 跑维护刷新命令，重写本 mdc。
4. **不**替代 `HAND_DECISION.json` 执行准入；下载/实盘仍须 HAND。
5. 过时快照不得宣称「全量盘点」——看「本快照时间」与最后一次下载/清洗事件。

## 1. 当前清洗 CURRENT（业务默认读这里）

| 字段 | 值 |
|---|---|
| release_id | `{cur.get('release_id')}` |
| seal_id | `{cur.get('seal_id')}` |
| cleaning_as_of | `{cur.get('cleaning_as_of')}` |
| finance_asof | `{cur.get('finance_asof')}` |
| daily_asof | `{cur.get('daily_asof')}` |
| standard_root | `{cur.get('standard_root')}` |
| pointer | `E:\\BLACKBOX\\数据\\清洗成品\\CURRENT_CLEANING_RELEASE.json` |

价格分钟增量（8 月 A股/ETF）在：

`{{standard_root}}\\price\\{{A股_stock_5m|A股_stock_1m|A股_stock_30m|A股_stock_60m|ETF_5m|ETF_1m|ETF_30m|ETF_60m}}\\`

文件名含 `2026-08-0X`；交易日 08-03～08-07 本地验收 **PASS**（staging+CURRENT）。

## 2. 原始只读总根

`E:\\BLACKBOX\\数据\\原始只读\\JQData_9999_official_raw`

合计约 **{raw['parquet_files']}** parquet / **{raw['size_gib']} GiB**。

| 域目录 | files | GiB | 绝对路径 |
|---|---:|---:|---|
{domains_tbl}

### 2.1 常用业务域速查

| 数据 | 状态（摘要） | 路径 |
|---|---|---|
| A股日线 | 至 2026-08-07 | `...\\P2_stock_daily` |
| ETF日线 RAW_NONE | 至 2026-08-07 | `...\\P4_fund_etf_raw_none` |
| A股 5m 替换层 | 封板+8月增量在清洗 | `...\\P7_stock_minute_raw_none_replacement_5m` |
| A股 1m 替换层 | 封板+8月增量在清洗 | `...\\P7_stock_raw_none_replacement_1m` |
| A股 30m/60m | 封板+8月增量 | `...\\P7_stock_minute_raw_none` |
| ETF 分钟 | 封板+8月增量 | `...\\P4_fund_etf_raw_none` |
| 指数日线/主7 | 至 2026-08-07 | `...\\P3_index` |
| **指数分钟 raw** | **{idx_raw_status}** · 732 全量 · 至 2026-08-06 | `...\\P3_index_minute`（≈ **{inv['price_domains_summary']['index_minute_raw']['parquet_files']}** 文件 / **{inv['price_domains_summary']['index_minute_raw']['size_gib']}** GiB） |
| 财务 PIT | R13 asof 08-07 | `...\\P3_finance_pit` |
| 估值 | daily 历史 + incremental | `...\\P6_factor_reference\\valuation` |
| **复权因子 ADJUST_FACTOR_PIT_R1** | **{af.get('status')}** · fq=`pre` · `{af.get('FULL_HISTORY_START')}`..`{af.get('SOURCE_MAX_DATE')}` · cutoff缺口 `{af.get('SOURCE_CUTOFF_GAP')}` | SOURCE `strategy_data_plane_additions\\ADJUST_FACTOR_PRE_FQ_FULL_HISTORY_R1`；CACHE `{af.get('cache_product')}` |
| 日历 | asof 推进 | `...\\P0_meta\\calendar_cn_exchange` |

策略扩展平面：`E:\\BLACKBOX\\数据\\原始只读\\strategy_data_plane_additions\\`

## 2.2 指数分钟对齐清洗（生产读这里）

| 字段 | 值 |
|---|---|
| universe | **JQ 全市场 732**（5m/1m/30m/60m，2014-01-01..2026-08-06） |
| all_pass | `{align.get('all_pass')}` |
| release_id | `{align.get('release_id')}` |
| seal_id | `{align.get('seal_id')}` |
| standard_root | `{align.get('standard_index_minute_root')}` |
| aligned parquet | **{align.get('parquet_files')}** / **{align.get('size_gib')}** GiB |
| pointer | `E:\\BLACKBOX\\数据\\清洗成品\\CURRENT_INDEX_MINUTE_ALIGN_RELEASE.json` |
| 说明 | 防穿越 cutoff=2026-08-06；EMPTY=接口无行情年；**非**写回原始只读 |

## 2.3 复权因子 ADJUST_FACTOR_PIT_R1（本轮缺口已 CLOSED）

| 字段 | 值 |
|---|---|
| product_id | `{af.get('product_id')}` |
| status | **{af.get('status')}** |
| SOURCE_CUTOFF_GAP | `{af.get('SOURCE_CUTOFF_GAP')}` |
| fq | `{af.get('fq')}` |
| window | `{af.get('FULL_HISTORY_START')}` .. `{af.get('SOURCE_MAX_DATE')}` |
| SOURCE | `{af.get('source_release_root')}` |
| Cleaning | `{af.get('cleaning_release_id')}` |
| CACHE CURRENT | `{af.get('cache_release_id')}` |
| P1 yearly | `{af.get('legacy_p1_tag')}`（**不覆盖**；生产不读 P1 年批） |
| ALL_BLACKBOX_DATA_GAPS_CLOSED | `{af.get('ALL_BLACKBOX_DATA_GAPS_CLOSED')}`（jq260/付费模块仍 TARGET 或 SKIP） |

## 3. 指数分钟下载轨（非在飞；两轨已 DONE）

### 3.1 并集 732

| 字段 | 值 |
|---|---|
| status | `{t732.get('status')}` |
| coverage_pct | `{t732.get('coverage_pct')}%`（covered/total units） |
| covered_units / total | `{t732.get('covered_units')}` / `{t732.get('est_total_units')}` |
| align_clean_pass | `{t732.get('align_clean_pass')}` |

### 3.2 轨 A：初次可下 546

| 字段 | 值 |
|---|---|
| status | `{t546.get('status')}` |
| covered | `{t546.get('covered_units')}` / `{t546.get('est_total_units')}`（completed+empty） |
| completed / empty | `{t546.get('completed_units')}` / `{t546.get('empty_units')}` |
| state | `{t546.get('state_path')}` |
| raw | `{t546.get('raw_root')}` |

### 3.3 轨 B：历史复探 186

| 字段 | 值 |
|---|---|
| status | `{t186.get('status')}` |
| covered | `{t186.get('covered_units')}` / `{t186.get('est_total_units')}` |
| completed / empty | `{t186.get('completed_units')}` / `{t186.get('empty_units')}` |
| state | `{t186.get('state_path')}` |
| raw | 同上 `P3_index_minute` |

## 4. HAND 快照（理解态，非单独放行凭证）

| 字段 | 值 |
|---|---|
| current_stage | `{hand.get('current_stage')}` |
| hand_release_level | `{hand.get('hand_release_level')}` |
| allowed_executor | `{hand.get('allowed_executor')}` |
| next_action | `{hand.get('next_action')}` |
| index_minute_align_release_id | `{hand.get('index_minute_align_release_id')}` |
| index_minute_align_clean_pass | `{hand.get('index_minute_align_clean_pass')}` |

## 5. 已知阻塞 / 已关闭缺口

- `ADJUST_FACTOR_SOURCE_CUTOFF_20260612`：**CLOSED**（`ADJUST_FACTOR_PIT_R1={af.get('status')}`，asof `{af.get('SOURCE_MAX_DATE')}`）
- **禁止**把复权因子 CLOSED 写成全市场已齐：`ALL_BLACKBOX_DATA_GAPS_CLOSED=FALSE`（jq260 / 付费模块仍 TARGET 或 SKIP）
- `financial_indicator`：账号权限旧口径 BLOCKED（SCOPE 已改为 READY_INTEGRATED asof 08-11；以 FULL_DATA SCOPE 为准）
- 禁止跨频率并行；同频最多 3 worker
- QMT/实盘：能力已放权（`CONNECT_AND_ORDER_GOVERNED`）；无 `LIVE_EXECUTION_SESSION` 仍禁止下单

## 6. 与「更新数据 / 更新报告」

| 口令 | 是否改本总表正文 |
|---|---|
| 更新报告 / 黑盒更新 | 否（报告链）；同批下载完成应另刷本 mdc |
| 更新数据 / 数据更新 / 下载收工 | **是** — 收工后必须跑维护刷新 |
| 同步数据总表 / 更新黑盒数据目录 | **是** — 只刷本 SSOT/mdc |

全数据更新范围 SSOT：`规则库/hand_hard_rules/BLACKBOX_HAND_FULL_DATA_UPDATE_SCOPE_R1.json`

## 7. 禁止

- 不得要求 AG「先拉 JSON/再盘点」才准答数据存在性（本 mdc 已是权威注入快照）
- 不得用过期快照对用户宣称「全量盘点结果」
- 不得手改 `HAND_DECISION.json` 伪造域完成
- 不得把 staging 任务目录当成唯一生产源（价格生产读清洗 CURRENT；指数分钟对齐读 CURRENT_INDEX_MINUTE_ALIGN）
"""


def main() -> int:
    inv = build_inventory()
    wjson(OUT_JSON, inv)
    wtext(OUT_MD, render_md(inv))
    wtext(RULE, render_mdc(inv))
    if SSOT_SCOPE.exists():
        scope = load_json(SSOT_SCOPE)
        scope["inventory_ssot"] = str(OUT_JSON)
        scope["inventory_ssot_md"] = str(OUT_MD)
        scope["inventory_top_rule_mdc"] = str(RULE)
        scope["inventory_last_refreshed_at_cn"] = inv["generated_at_cn"]
        scope["inventory_ag_injection"] = inv.get("ag_injection_policy")
        wjson(SSOT_SCOPE, scope)
    t732 = inv["index_minute_download_tracks"]["union_732"]
    align = inv["index_minute_aligned_clean"]
    print(json.dumps({
        "final_status": "PASS",
        "json": str(OUT_JSON),
        "md": str(OUT_MD),
        "mdc": str(RULE),
        "generated_at_cn": inv["generated_at_cn"],
        "schema_version": inv["schema_version"],
        "self_contained": True,
        "current_release": inv["current_cleaning"].get("release_id"),
        "raw_files": inv["raw_jqdata_official"]["parquet_files"],
        "raw_gib": inv["raw_jqdata_official"]["size_gib"],
        "index_minute_732_status": t732.get("status"),
        "index_minute_732_coverage_pct": t732.get("coverage_pct"),
        "index_minute_align_release": align.get("release_id"),
        "index_minute_align_pass": align.get("all_pass"),
        "index_minute_align_parquet": align.get("parquet_files"),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())