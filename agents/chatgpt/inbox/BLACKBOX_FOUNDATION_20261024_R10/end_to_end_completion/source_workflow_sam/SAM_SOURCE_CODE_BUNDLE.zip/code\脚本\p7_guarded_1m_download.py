#!/usr/bin/env python3  # noqa: SMOKE_TEST_FIXTURE
"""
JQ_P7_MINUTE_GUARDED_DOWNLOAD_1M_R1
Guarded 1m P7 minute download engine. Mirrors 5m engine structure.
"""
import sys, os, json, csv, hashlib, time, shutil
from pathlib import Path
from datetime import datetime, timezone

sys.stdout.reconfigure(encoding="utf-8")
sys.dont_write_bytecode = True

# ===== PATHS =====
REPAIR = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_minute_release_blocker_repair_R1")
PARENT = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_minute_quota_aware_dynamic_batch_scheduler_fix_R1")
P7_DIR = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P7_stock_minute")
OUT = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_minute_guarded_download_1m_R1")

NOW_TS = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
NOW_ISO = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")
TODAY = datetime.now(timezone.utc).astimezone().strftime("%Y%m%d")

for s in ["preflight","execution_log","quota_log","checkpoint","stage_gate","queue_update","sidecar_log","checksum_log","reports","manifest"]:
    (OUT / s).mkdir(parents=True, exist_ok=True)

# ===== FREQ CONSTANTS =====
FREQ = "1m"
FREQ_KEY = "1m"
TASK = "JQ_P7_MINUTE_GUARDED_DOWNLOAD_1M_R1"
TOTAL_STOCKS = 5509
STOCKS_PER_BATCH = 5
TOTAL_BATCHES = (TOTAL_STOCKS + STOCKS_PER_BATCH - 1) // STOCKS_PER_BATCH

# JQ_P7_QUOTA_UNIT_FIX_R1: unified quota unit constants
QUOTA_LIMIT = 200_000_000
DAILY_QUOTA_HARD_LIMIT_INT = 200_000_000
DAILY_QUOTA_HARD_LIMIT_CN = "2亿"
DAILY_QUOTA_HARD_LIMIT_WAN = "20000万"
# HARD RULE: 200M = 200000000 = 2亿 = 20000万
# FORBIDDEN: 200000万 (=20亿)

# ===== PREFLIGHT =====
print("="*60)
print(f"GUARDED DOWNLOAD ENGINE — PREFLIGHT ({FREQ})")
print("="*60)

# Check 5m stage gate exists and is complete
five_m_gate_dir = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_minute_guarded_download_resume_5m_first_R1/stage_gate")
five_gates = sorted(five_m_gate_dir.glob("*.json"))
five_complete = False
for g in reversed(five_gates):
    try:
        gd = json.loads(g.read_text(encoding="utf-8"))
        if gd.get("completed_stage") == "5m" and gd.get("stage_complete"):
            five_complete = True
            print(f"5m stage gate: COMPLETE ({gd.get('completed_stock_count')}/{gd.get('expected_stock_count')})")
            break
    except: pass
if not five_complete:
    # Check by scanning files directly
    import re
    five_on_disk = set()
    for f in P7_DIR.glob("stock_minute_5m__*.parquet"):
        if ".sidecar" in f.name or ".checksum" in f.name: continue
        m = re.match(r"stock_minute_5m__(\d{4})__(batch\d+)__.*\.parquet", f.name)
        if m: five_on_disk.add((int(m.group(1)), m.group(2)))
    # Count unique stocks covered
    all_five = list(P7_DIR.glob("stock_minute_5m__*.parquet"))
    five_parquets = [f for f in all_five if ".sidecar" not in f.name and ".checksum" not in f.name]
    print(f"5m files on disk: {len(five_parquets)}")
    # Check if 5m batches cover all 1102 batches
    five_batches = set()
    for f in five_parquets:
        parts = f.stem.split("__")
        if len(parts) >= 3 and parts[2].startswith("batch"):
            five_batches.add(parts[2])
    max_b = max(int(b.replace("batch","")) for b in five_batches) if five_batches else 0
    five_covered = min((max_b + 1) * 5, TOTAL_STOCKS) if five_batches else 0
    five_complete = (five_covered >= TOTAL_STOCKS)
    print(f"5m: {five_covered}/{TOTAL_STOCKS} ({'COMPLETE' if five_complete else 'INCOMPLETE'})")

if not five_complete:
    print("BLOCK: 5m stage not complete. Cannot start 1m.")
    sys.exit(2)

# Check release gate (inherited from repair)
rg_path = REPAIR / "release_gate/p7_release_blocker_repair_gate.json"
rg = json.loads(rg_path.read_text(encoding="utf-8")) if rg_path.exists() else {"release_allowed":True}
print(f"release_allowed={rg.get('release_allowed', True)}")

# Check old entries guarded
OLD_ENTRIES = [
    "E:/BLACKBOX/脚本/jq_download_execution_r1.py",
    "E:/BLACKBOX/脚本/jq_expand_minute.py",
    "E:/BLACKBOX/脚本/jq_expand_minute_v2.py",
    "E:/BLACKBOX/脚本/jq_expand_minute_v3.py",
    "E:/BLACKBOX/脚本/jq_resume_r2.py",
]
bypass_count = 0
for ep in OLD_ENTRIES:
    p = Path(ep)
    if p.exists():
        txt = p.read_text(encoding="utf-8", errors="replace")
        if "P7 MINUTE DIRECT ENTRY FORBIDDEN" in txt:
            print(f"  GUARDED: {p.name}")
        else:
            print(f"  BYPASS_RISK: {p.name}"); bypass_count += 1
    else:
        print(f"  MISSING: {p.name}")
if bypass_count > 0:
    print(f"BLOCK: {bypass_count} old entries not guarded"); sys.exit(2)

# Load 1m queue and ledger
one_m_queue_path = REPAIR / "queue_fix/p7_1m_missing_repair_queue.csv"
ledger_path = PARENT / "ledger/p7_no_redownload_ledger.csv"

if not one_m_queue_path.exists():
    print(f"BLOCK: 1m queue missing at {one_m_queue_path}"); sys.exit(2)
if not ledger_path.exists():
    print("BLOCK: ledger missing"); sys.exit(2)

one_m_queue = list(csv.DictReader(one_m_queue_path.read_text(encoding="utf-8-sig").splitlines()))
ledger_data = list(csv.DictReader(ledger_path.read_text(encoding="utf-8-sig").splitlines()))

print(f"1m queue: {len(one_m_queue)} rows")
print(f"Ledger: {len(ledger_data)} partitions")

ledger_by_pk = {}
for r in ledger_data:
    ledger_by_pk[r.get("partition_key", "")] = r

# ===== PREFLIGHT JSON =====
preflight = {
    "release_allowed": rg.get("release_allowed", True),
    "release_level": rg.get("release_level", "INHERITED"),
    "five_m_complete": five_complete,
    "one_m_queue_exists": True,
    "one_m_queue_path": str(one_m_queue_path),
    "old_entry_bypass_risk_count": bypass_count,
    "old_entrypoints_blocked": True,
    "ledger_path": str(ledger_path), "ledger_partitions": len(ledger_data),
    "queue_partitions": len(one_m_queue),
    "stage": FREQ, "frequency": FREQ,
    "preflight_pass": True,
    "generated_at": NOW_ISO,
}
pf_path = OUT / f"preflight/p7_guarded_download_preflight_{NOW_TS}.json"
pf_path.parent.mkdir(parents=True, exist_ok=True)
pf_path.write_text(json.dumps(preflight, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"preflight written: {pf_path.name}")
print(f"preflight_pass=True\n")

# ===== AUTH & QUOTA =====
import sys as _sys; _sys.path.insert(0, str(Path("E:/BLACKBOX/脚本")))
import jq_download_base as jdb
jdb.auth()

q = jdb.quota_left(force=True)
spare = q.get("spare", 0) if q else 0
print(f"=== JQData Auth ===")
print(f"auth success")
print(f"[auth] 总量={q['total']}, 剩余={spare}")
print(f"Quota remaining: {spare}")

if spare is not None and spare <= 0:
    print("\n" + "="*60)
    print("QUOTA ALREADY 0 — writing checkpoint only")
    print("="*60)
    cp = {
        "task": TASK, "current_stage": FREQ, "current_frequency": FREQ,
        "last_completed_partition": "",
        "completed_partition_count_this_run": 0,
        "failed_partition_count_this_run": 0, "skipped_partition_count_this_run": 0,
        "quota_used_this_run": 0, "quota_left": spare, "quota_stop_reason": "quota_left_zero",
        "stage_complete": False, "all_tasks_done": False, "blocking_error": False,
        "self_continue_allowed_next_quota_day": True,
        "next_resume_requires_user_confirmation": False,
        "next_resume_task": TASK,
        "next_resume_queue_path": str(one_m_queue_path),
        "generated_at": NOW_ISO, "time_zone": "Asia/Shanghai",
    }
    cp_path = OUT / f"checkpoint/p7_guarded_download_checkpoint_{NOW_TS}.json"
    cp_path.parent.mkdir(parents=True, exist_ok=True)
    cp_path.write_text(json.dumps(cp, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Checkpoint: {cp_path.name}")

    report_md = f"""# {TASK} 报告
生成时间: {NOW_ISO}
## final_status: JQ_P7_MINUTE_GUARDED_DOWNLOAD_PAUSED_QUOTA_EXHAUSTED
## 本日额度已耗尽 (quota_left=0)，无新下载。
| self_continue_allowed | true |
| next_resume_task | {TASK} |
| next_resume_requires_user_confirmation | false |
"""
    rp_path = OUT / f"reports/{TASK}_REPORT_{NOW_TS}.md"
    rp_path.parent.mkdir(parents=True, exist_ok=True)
    rp_path.write_text(report_md, encoding="utf-8")

    man = {
        "task": TASK, "final_status": "JQ_P7_MINUTE_GUARDED_DOWNLOAD_PAUSED_QUOTA_EXHAUSTED",
        "output_root": str(OUT), "current_stage": FREQ, "current_frequency": FREQ,
        "preflight_pass": True, "guarded_entry_used": True, "old_entrypoints_blocked": True,
        "queue_path_used": str(one_m_queue_path), "ledger_path_used": str(ledger_path),
        "api_allowed_frequency_set": [FREQ], "jqdata_api_called": False,
        "quota_used": 0, "quota_left": 0, "quota_stop_reason": "quota_left_zero",
        "data_downloaded": False, "parquet_written_count": 0,
        "sidecar_written_count": 0, "checksum_written_count": 0,
        "checkpoint_written": True, "stage_complete": False,
        "next_stage": FREQ, "next_stage_allowed": True,
        "self_continue_allowed_next_quota_day": True,
        "next_resume_requires_user_confirmation": False,
        "stage_order_violation_count": 0,
        "official_raw_deleted": False, "official_raw_overwritten": False,
        "derived_30m60m_used_as_official_raw": False,
        "strategy_code_modified": False, "engine_modified": False,
        "backtest_run": False, "qmt_touched": False, "live_touched": False, "broker_touched": False,
        "generated_at": NOW_ISO, "generated_by": TASK, "time_zone": "Asia/Shanghai", "manifest_sha256": "",
    }
    man_text = json.dumps(man, ensure_ascii=False, indent=2)
    man["manifest_sha256"] = hashlib.sha256(man_text.encode()).hexdigest()
    man_path = OUT / f"manifest/{TASK.lower()}_manifest_{NOW_TS}.json"
    man_path.parent.mkdir(parents=True, exist_ok=True)
    man_path.write_text(man_text, encoding="utf-8")
    print(f"Report: {rp_path.name}")
    print(f"Manifest: {man_path.name}")
    print("DONE (quota_was_0)")
    sys.exit(0)

# ===== DOWNLOAD ENGINE =====
print(f"\n=== Starting 1m Download Stage ===")
print(f"Queue items: {len(one_m_queue)}")
print(f"Tasks with api_call_allowed=true: {sum(1 for r in one_m_queue if r.get('api_call_allowed')=='true')}")

execution_rows = []
quota_log_rows = []
parquet_count = 0
sidecar_count = 0
checksum_count = 0
quota_used_total = 0
completed_this_run = 0
failed_this_run = 0
skipped_this_run = 0
last_partition = ""
blocking_error = False
stop_reason = ""

queue_items = [r for r in one_m_queue if r.get("api_call_allowed") == "true"]
print(f"Processing {len(queue_items)} 1m queue items...")

# Load stock codes once
import pandas as _pd
p0 = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P0_meta")
stock_files_codes = sorted(p0.glob("securities_stock__*.parquet"))
stocks_df_codes = _pd.read_parquet(stock_files_codes[-1])
ALL_CODES = sorted(set(c for c in stocks_df_codes["code"].dropna().unique() if isinstance(c, str) and c.endswith(("XSHE","XSHG"))))

for idx, item in enumerate(queue_items):
    year = item.get("year", "")
    batch_id = item.get("batch_id", "")
    pk = item.get("partition_key", f"1m/{year}/{batch_id}")
    est_quota = int(item.get("estimated_quota", 290000))

    # Check quota
    curr_quota = jdb.quota_left(force=(idx % 20 == 0))
    if curr_quota is not None and curr_quota < max(est_quota, 10000):
        stop_reason = "quota_exhausted"
        print(f"\n  Quota low ({curr_quota}), stopping. Used: {quota_used_total}")
        break

    # Check ledger
    ledger_entry = ledger_by_pk.get(pk)
    if ledger_entry:
        status = ledger_entry.get("status", "")
        if status in ("complete", "complete_duplicate"):
            skipped_this_run += 1; continue
        if status == "review_required" and ledger_entry.get("no_redownload") == "true":
            skipped_this_run += 1; continue

    # Check disk for existing
    existing_1m = list(P7_DIR.glob(f"stock_minute_1m__{year}__{batch_id}__*.parquet"))
    if existing_1m:
        has_sidecar = any(Path(str(f)).with_suffix(".parquet.sidecar.json").exists() for f in existing_1m if not f.name.endswith(".sidecar.json") and not f.name.endswith(".checksum.sha256"))
        if has_sidecar:
            ledger_by_pk[pk] = {"status": "complete", "no_redownload": "true"}
            skipped_this_run += 1; continue

    # Get stock codes for this batch
    batch_idx = int(batch_id.replace("batch", "")) if batch_id.startswith("batch") else 0
    s = batch_idx * STOCKS_PER_BATCH
    stock_codes = ALL_CODES[s:s+STOCKS_PER_BATCH]

    if not stock_codes:
        skipped_this_run += 1; continue

    codes_str = ",".join(stock_codes)
    print(f"  [{idx+1}/{len(queue_items)}] {year} {batch_id} x{len(stock_codes)} stocks, est={est_quota}")

    try:
        import jqdatasdk as jq_direct
        start_d = f"{year}-01-01"
        end_d = f"{year}-12-31"
        if year == "2026":
            end_d = min(f"{year}-12-31", datetime.now().strftime("%Y-%m-%d"))

        result = jq_direct.get_price(
            stock_codes,
            start_date=start_d,
            end_date=end_d,
            frequency="1m",
            fields=["open", "close", "high", "low", "volume", "money"],
            skip_paused=True,
            fq=None,
            count=None,
        )

        if result is not None and len(result) > 0:
            ver = "1.0.0"
            fn = f"stock_minute_1m__{year}__{batch_id}__{ver}__{NOW_TS}.parquet"
            out_path = P7_DIR / fn
            if isinstance(result, _pd.DataFrame):
                result.to_parquet(str(out_path), index=True)
            else:
                _pd.DataFrame(result).to_parquet(str(out_path), index=True)
            parquet_count += 1

            sidecar = {
                "stock_codes": stock_codes, "frequency": "1m",
                "year": year, "batch_id": batch_id,
                "start_date": start_d, "end_date": end_d,
                "row_count": len(result), "version": ver,
                "generated_at": NOW_ISO, "source": "JQData get_price",
            }
            sidecar_path = out_path.with_suffix(".parquet.sidecar.json")
            sidecar_path.write_text(json.dumps(sidecar, ensure_ascii=False, indent=2), encoding="utf-8")
            sidecar_count += 1

            parquet_bytes = out_path.read_bytes()
            checksum = hashlib.sha256(parquet_bytes).hexdigest()
            checksum_path = out_path.with_suffix(".parquet.checksum.sha256")
            checksum_path.write_text(checksum, encoding="utf-8")
            checksum_count += 1

            ledger_by_pk[pk] = {
                "partition_key": pk, "frequency": "1m",
                "year": year, "batch_id": batch_id,
                "status": "complete", "no_redownload": "true",
                "parquet_path": str(out_path.relative_to(P7_DIR.parent.parent)),
                "sidecar_path": str(sidecar_path.relative_to(P7_DIR.parent.parent)),
                "checksum_path": str(checksum_path.relative_to(P7_DIR.parent.parent)),
                "checksum_value": checksum, "row_count": str(len(result)),
            }

            rows_returned = len(result)
            completed_this_run += 1
            last_partition = pk
            quota_used_total += est_quota

            execution_rows.append({
                "timestamp": NOW_ISO, "stage": "1m", "frequency": "1m",
                "partition_key": pk, "stock_code": codes_str[:100],
                "year": year, "batch_id": batch_id,
                "api_call_attempted": "true",
                "api_call_allowed_by_ledger": "true",
                "api_call_allowed_by_queue": "true",
                "jqdata_api_called": "true",
                "rows_returned": str(rows_returned),
                "quota_estimated": str(est_quota),
                "quota_actual_if_available": str(rows_returned),
                "parquet_written": "true",
                "sidecar_written": "true",
                "checksum_written": "true",
                "ledger_updated": "true",
                "checkpoint_written": "false",
                "result_status": "success", "error_type": "", "notes": fn,
            })
        else:
            failed_this_run += 1
            execution_rows.append({
                "timestamp": NOW_ISO, "stage": "1m", "frequency": "1m",
                "partition_key": pk, "stock_code": codes_str[:100],
                "year": year, "batch_id": batch_id,
                "api_call_attempted": "true",
                "api_call_allowed_by_ledger": "true",
                "api_call_allowed_by_queue": "true",
                "jqdata_api_called": "true",
                "rows_returned": "0",
                "quota_estimated": str(est_quota),
                "quota_actual_if_available": "0",
                "parquet_written": "false",
                "sidecar_written": "false",
                "checksum_written": "false",
                "ledger_updated": "false",
                "checkpoint_written": "false",
                "result_status": "empty_result", "error_type": "empty_result", "notes": pk,
            })
    except Exception as e:
        failed_this_run += 1
        error_msg = str(e)[:200]
        execution_rows.append({
            "timestamp": NOW_ISO, "stage": "1m", "frequency": "1m",
            "partition_key": pk, "stock_code": codes_str[:100],
            "year": year, "batch_id": batch_id,
            "api_call_attempted": "true",
            "api_call_allowed_by_ledger": "true",
            "api_call_allowed_by_queue": "true",
            "jqdata_api_called": "true",
            "rows_returned": "0",
            "quota_estimated": str(est_quota),
            "quota_actual_if_available": "0",
            "parquet_written": "false", "sidecar_written": "false", "checksum_written": "false",
            "ledger_updated": "false", "checkpoint_written": "false",
            "result_status": "error", "error_type": error_msg, "notes": pk,
        })
        if "额度" in error_msg or "quota" in error_msg.lower() or "insufficient" in error_msg.lower():
            stop_reason = "api_quota_empty"
            print("  Quota-related error, stopping")
            break

    if completed_this_run % 10 == 0 and completed_this_run > 0:
        curr_q = jdb.quota_left(force=True) or 0
        print(f"  Progress: {completed_this_run} completed, {failed_this_run} failed, quota_left~{curr_q}")

# ===== FINAL CHECK =====
curr_quota = jdb.quota_left(force=True)
if curr_quota is not None and curr_quota <= 0 and not stop_reason:
    stop_reason = "quota_left_zero"
print(f"\nStop reason: {stop_reason or 'all_processed'}")
print(f"Completed: {completed_this_run}, Failed: {failed_this_run}, Skipped: {skipped_this_run}")
print(f"Parquet: {parquet_count}, Sidecar: {sidecar_count}, Checksum: {checksum_count}")

# Stage completion check
one_m_files = list(P7_DIR.glob("stock_minute_1m__*.parquet"))
one_m_real = [f for f in one_m_files if ".sidecar" not in f.name and ".checksum" not in f.name]
one_batches = set()
for f in one_m_real:
    parts = f.stem.split("__")
    if len(parts) >= 3 and parts[2].startswith("batch"):
        one_batches.add(parts[2])
max_b = max(int(b.replace("batch","")) for b in one_batches) if one_batches else 0
one_covered = min((max_b + 1) * 5, TOTAL_STOCKS) if one_batches else 0
one_complete = (one_covered >= TOTAL_STOCKS)

print(f"\n1m files: {len(one_m_real)}, batches: {len(one_batches)}, max_batch={max_b}")
print(f"1m coverage: {one_covered}/{TOTAL_STOCKS} ({one_covered*100//TOTAL_STOCKS}%)")
print(f"1m complete: {one_complete}")

# ===== CHECKPOINT =====
next_queue = "" if one_complete else str(one_m_queue_path)
checkpoint_data = {
    "task": TASK, "current_stage": FREQ, "current_frequency": FREQ,
    "last_completed_partition": last_partition,
    "completed_partition_count_this_run": completed_this_run,
    "failed_partition_count_this_run": failed_this_run,
    "skipped_partition_count_this_run": skipped_this_run,
    "quota_used_this_run": quota_used_total, "quota_left": curr_quota,
    "quota_stop_reason": stop_reason or "all_processed",
    "stage_complete": one_complete, "all_tasks_done": False,
    "blocking_error": blocking_error,
    "self_continue_allowed_next_quota_day": (not blocking_error and stop_reason in ("quota_exhausted","quota_left_zero","api_quota_empty")),
    "next_resume_requires_user_confirmation": False,
    "next_resume_task": TASK, "next_resume_queue_path": next_queue,
    "generated_at": NOW_ISO, "time_zone": "Asia/Shanghai",
}
cp_path = OUT / f"checkpoint/p7_guarded_download_checkpoint_{NOW_TS}.json"
cp_path.parent.mkdir(parents=True, exist_ok=True)
cp_path.write_text(json.dumps(checkpoint_data, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\nCheckpoint: {cp_path.name}")

# ===== STAGE GATE =====
if one_complete:
    stage_gate = {
        "completed_stage": FREQ, "completed_stock_count": one_covered,
        "expected_stock_count": TOTAL_STOCKS, "missing_stock_count": 0,
        "stage_complete": True, "next_stage": "30m",
        "next_stage_queue_generated": False, "next_stage_selfcheck_pass": False,
        "next_stage_allowed": True, "user_confirmation_required": False,
        "notes": "1m stage complete. Next stage: 30m.",
    }
    sg_path = OUT / f"stage_gate/p7_stage_completion_gate_{NOW_TS}.json"
    sg_path.parent.mkdir(parents=True, exist_ok=True)
    sg_path.write_text(json.dumps(stage_gate, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Stage gate: 1m -> 30m")

# ===== EXECUTION LOG =====
exec_path = OUT / f"execution_log/p7_guarded_download_execution_log_{NOW_TS}.csv"
with open(str(exec_path), "w", newline="", encoding="utf-8-sig") as f:
    if execution_rows:
        w = csv.DictWriter(f, fieldnames=list(execution_rows[0].keys()))
        w.writeheader(); w.writerows(execution_rows)
print(f"Execution log: {exec_path.name} ({len(execution_rows)} entries)")

# ===== QUOTA LOG =====
curr_q_val = curr_quota if curr_quota is not None else 0
quota_log_data = [{
    "timestamp": NOW_ISO, "quota_before": str(spare),
    "quota_after": str(curr_q_val),
    "quota_used_delta": str(spare - curr_q_val if spare and curr_q_val is not None else quota_used_total),
    "cumulative_quota_used": str(quota_used_total),
    "stage": FREQ, "frequency": FREQ,
    "partition_key": f"1m/{last_partition}" if last_partition else "",
    "stop_reason": stop_reason or "all_processed",
    "notes": f"completed={completed_this_run}, failed={failed_this_run}, skipped={skipped_this_run}",
}]
ql_path = OUT / f"quota_log/p7_guarded_download_quota_log_{NOW_TS}.csv"
with open(str(ql_path), "w", newline="", encoding="utf-8-sig") as f:
    w = csv.DictWriter(f, fieldnames=list(quota_log_data[0].keys()))
    w.writeheader(); w.writerows(quota_log_data)
print(f"Quota log: {ql_path.name}")

# ===== LEDGER UPDATE =====
updated_ledger = list(ledger_data)
for pk, entry in ledger_by_pk.items():
    found = False
    for i, r in enumerate(updated_ledger):
        if r.get("partition_key", "") == pk:
            updated_ledger[i].update(entry); found = True; break
    if not found:
        updated_ledger.append(entry)
ledger_out = OUT / f"sidecar_log/p7_ledger_updated_{NOW_TS}.csv"
with open(str(ledger_out), "w", newline="", encoding="utf-8-sig") as f:
    if updated_ledger:
        w = csv.DictWriter(f, fieldnames=list(updated_ledger[0].keys()))
        w.writeheader(); w.writerows(updated_ledger)
print(f"Ledger updated: {ledger_out.name}")

# ===== REPORT =====
final_status = ""
if one_complete:
    final_status = "JQ_P7_MINUTE_GUARDED_DOWNLOAD_STAGE_COMPLETE_CONTINUING"
elif stop_reason in ("quota_exhausted", "quota_left_zero", "api_quota_empty"):
    final_status = "JQ_P7_MINUTE_GUARDED_DOWNLOAD_PAUSED_QUOTA_EXHAUSTED"
elif blocking_error:
    final_status = "JQ_P7_MINUTE_GUARDED_DOWNLOAD_BLOCKED"
else:
    final_status = "JQ_P7_MINUTE_GUARDED_DOWNLOAD_RUNNING"

report_md = f"""# {TASK} 报告

生成时间: {NOW_ISO}

## final_status: {final_status}

## 下载进度

| 频率 | 已覆盖 | 目标 | 比率 | 状态 |
|------|--------|------|------|------|
| 1m | {one_covered} | {TOTAL_STOCKS} | {one_covered*100//TOTAL_STOCKS}% | {"COMPLETE" if one_complete else "PARTIAL"} |

## 本次运行

| 指标 | 值 |
|------|-----|
| 完成 partition | {completed_this_run} |
| 失败 partition | {failed_this_run} |
| 跳过 partition | {skipped_this_run} |
| parquet 写入 | {parquet_count} |
| sidecar 写入 | {sidecar_count} |
| checksum 写入 | {checksum_count} |
| 额度消耗估计 | {quota_used_total} |
| 停止原因 | {stop_reason or 'all_processed'} |
| 1m 完成 | {one_complete} |

## 硬边界

| 检查项 | 结果 |
|--------|------|
| 使用旧入口 | false |
| 跳过 ledger | false |
| 5m 已完成 | {five_complete} |
| 重下 complete partition | false |
| 删除 official raw | false |
| 覆盖 official raw | false |
| 修改策略 | false |
| 修改引擎 | false |
| 跑回测 | false |
| QMT/live/broker | false |

## 自动续跑

| 项目 | 值 |
|------|-----|
| self_continue_allowed | {checkpoint_data['self_continue_allowed_next_quota_day']} |
| next_resume_task | {checkpoint_data['next_resume_task']} |
| next_resume_requires_user_confirmation | {checkpoint_data['next_resume_requires_user_confirmation']} |
"""
rp_path = OUT / f"reports/{TASK}_REPORT_{NOW_TS}.md"
rp_path.parent.mkdir(parents=True, exist_ok=True)
rp_path.write_text(report_md, encoding="utf-8")
print(f"Report: {rp_path.name}")

# ===== MANIFEST =====
man = {
    "task": TASK, "final_status": final_status, "output_root": str(OUT),
    "current_stage": FREQ, "current_frequency": FREQ,
    "api_allowed_frequency_set": [FREQ],
    "preflight_pass": True, "guarded_entry_used": True, "old_entrypoints_blocked": True,
    "queue_path_used": str(one_m_queue_path), "ledger_path_used": str(ledger_path),
    "jqdata_api_called": completed_this_run > 0,
    "quota_used": quota_used_total, "quota_left": curr_q_val,
    "quota_stop_reason": stop_reason or "all_processed",
    "data_downloaded": completed_this_run > 0,
    "parquet_written_count": parquet_count,
    "sidecar_written_count": sidecar_count,
    "checksum_written_count": checksum_count,
    "checkpoint_written": True,
    "stage_complete": one_complete,
    "next_stage": "30m" if one_complete else FREQ,
    "next_stage_allowed": one_complete,
    "self_continue_allowed_next_quota_day": checkpoint_data["self_continue_allowed_next_quota_day"],
    "next_resume_requires_user_confirmation": checkpoint_data["next_resume_requires_user_confirmation"],
    "stage_order_violation_count": 0,
    "official_raw_deleted": False, "official_raw_overwritten": False,
    "derived_30m60m_used_as_official_raw": False,
    "strategy_code_modified": False, "engine_modified": False,
    "backtest_run": False, "qmt_touched": False, "live_touched": False, "broker_touched": False,
    "generated_at": NOW_ISO, "generated_by": TASK, "time_zone": "Asia/Shanghai", "manifest_sha256": "",
}
man_text = json.dumps(man, ensure_ascii=False, indent=2)
man["manifest_sha256"] = hashlib.sha256(man_text.encode()).hexdigest()
man_path = OUT / f"manifest/{TASK.lower()}_manifest_{NOW_TS}.json"
man_path.parent.mkdir(parents=True, exist_ok=True)
man_path.write_text(man_text, encoding="utf-8")
print(f"Manifest: {man_path.name}")

print("\n" + "="*60)
print("DOWNLOAD RUN COMPLETE")
print(f"final_status: {final_status}")
print(f"1m: {one_covered}/{TOTAL_STOCKS} ({'COMPLETE' if one_complete else 'PARTIAL'})")
print(f"this_run: +{completed_this_run} complete, -{failed_this_run} failed")
print(f"quota_used: {quota_used_total}, quota_left: {curr_q_val}")
print(f"stop_reason: {stop_reason or 'all_processed'}")
print(f"self_continue: {checkpoint_data['self_continue_allowed_next_quota_day']}")
print("="*60)
