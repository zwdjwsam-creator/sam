#!/usr/bin/env python3
"""
JQ_P7_1M_MATRIX_LAUNCHER — HAND-gated 3-pool 1m download.
Requires HAND_DECISION + 5m quality gate PASS + one_m_allowed=true.
"""
import sys, json, time, subprocess, hashlib
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path("E:/BLACKBOX/脚本")))
import p7_gate_common as gc

SCRIPT_SELF = Path(__file__).resolve()
NOW_TS = gc.now_ts()
NOW_ISO = gc.now_iso()
TASK = "JQ_P7_1M_MATRIX_DOWNLOAD_R1"
MATRIX = gc.MATRIX_1M
PYTHON = "E:/BLACKBOX/.venv/Scripts/python.exe"
WORKER = str(gc.SCRIPT_1M_WORKER)

for s in ["logs", "reports", "manifest", "gates"]:
    (MATRIX / s).mkdir(parents=True, exist_ok=True)

print("=" * 60)
print(f"{TASK} — 1M MATRIX LAUNCHER (HAND-GATED)")
print("=" * 60)

# ── HAND gate (mandatory) ──
hand = gc.enforce_hand_gate(script_path=SCRIPT_SELF, required_stage="1m", require_one_m=True)
mon = gc.ensure_hand_download_monitor(trigger=TASK, stage="1m")
print(f"HAND monitor: spawned={mon.get('spawned')} reason={mon.get('reason','ok')} pid={mon.get('pid','')}")
gc.clear_global_stop()
POOLS = gc.active_worker_pools(hand)
aw = hand.get("active_workers", len(POOLS))
print(f"HAND level: {hand.get('hand_release_level')} | active_workers={aw}")

# ── 5m quality gate (hard, double-check) ──
g5 = gc.load_5m_quality_gate()
if not g5 or g5.get("quality_gate_pass") is not True:
    print("BLOCK: 5m_quality_gate_pass != true")
    (MATRIX / "gates" / f"1m_blocked_{NOW_TS}.json").write_text(json.dumps({
        "reason": "5m_quality_gate_not_pass", "checked_at": NOW_ISO}, indent=2), encoding="utf-8")
    sys.exit(2)
print(f"5m quality gate: PASS ({g5.get('years_complete')}/{g5.get('years_checked')} years)")

# ── Auth + quota ──
import jq_download_base as jdb
jdb.auth()
ql = jdb.quota_left(force=True) or 0
print(f"Quota: {gc.quota_fmt(ql)}")
if ql <= 0:
    for p in POOLS:
        cp = {"pool": p, "quota": 0, "stop": "quota_left_zero", "self_continue": True, "generated_at": NOW_ISO}
        (MATRIX / p / "checkpoint").mkdir(parents=True, exist_ok=True)
        (MATRIX / p / f"checkpoint/worker_{p}_ckpt_{NOW_TS}.json").write_text(json.dumps(cp, indent=2), encoding="utf-8")
    sys.exit(0)

# ── Launch workers ──
print(f"\nLaunching {len(POOLS)} worker(s)...")
procs = {}
for pool in POOLS:
    lp = MATRIX / "logs" / f"worker_{pool}_{NOW_TS}.log"
    lf = open(str(lp), "w", encoding="utf-8")
    procs[pool] = {"proc": subprocess.Popen([PYTHON, "-u", WORKER, pool], stdout=lf, stderr=subprocess.STDOUT), "log": lf}
    print(f"  {pool}: PID={procs[pool]['proc'].pid}")

try:
    while procs:
        for pool in list(procs):
            if procs[pool]["proc"].poll() is not None:
                procs[pool]["log"].close()
                print(f"\n[{pool}] DONE")
                del procs[pool]
        if procs:
            time.sleep(5)
except KeyboardInterrupt:
    for i in procs.values():
        try: i["proc"].terminate(); i["log"].close()
        except: pass
    sys.exit(1)

# ── Results ──
tc = tf = tp = tq = 0
all_ok = True
for pool in POOLS:
    cks = sorted((MATRIX / pool / "checkpoint").glob("*.json"))
    if cks:
        ck = json.loads(cks[-1].read_text(encoding="utf-8"))
        tc += ck.get("completed", 0); tf += ck.get("failed", 0)
        tp += ck.get("parquet", 0); tq += ck.get("quota_used", 0)
        if not ck.get("pool_complete"): all_ok = False
    else:
        all_ok = False

fs = "ALL_COMPLETE" if all_ok else "PARTIAL"
man = {"task": TASK, "final_status": fs, "done": tc, "fail": tf, "pq": tp,
       "quota_used": tq, "five_m_quality_gate_pass": True, "one_m_allowed": True,
       "returned_to_HAND_for_review": True, "executor": gc.ALLOWED_EXECUTOR,
       "generated_at": NOW_ISO}
mt = json.dumps(man, ensure_ascii=False, indent=2)
man["sha256"] = hashlib.sha256(mt.encode()).hexdigest()
(MATRIX / f"manifest/{TASK.lower()}_manifest_{NOW_TS}.json").write_text(mt, encoding="utf-8")
print(f"\nDONE: {fs} | returned_to_HAND_for_review: true")
