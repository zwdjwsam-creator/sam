#!/usr/bin/env python3
"""Formal Cleaning R9 — parent R8 hardlink + finance incremental ingest; optional CURRENT switch."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")

TASK = "BLACKBOX_POST_SEAL_FINANCE_INCREMENTAL_AND_CLEANING_R9_R1"
ROOT = Path(r"E:\BLACKBOX\任务") / TASK
RELEASES = Path(r"E:\BLACKBOX\数据\清洗成品\releases")
CURRENT = Path(r"E:\BLACKBOX\数据\清洗成品\CURRENT_CLEANING_RELEASE.json")
PARENT_ID = "BLACKBOX_FORMAL_CLEANING_R8_ASOF_20260805_20260806_002532"
PARENT_SEAL = "BLACKBOX_CLEANING_LAYER_SEAL_R8_20260806_002532"
PARENT = RELEASES / PARENT_ID
CLEANING_AS_OF = "2026-08-05"
HAND = Path(r"E:\BLACKBOX\运行\HAND_DECISION.json")
SWITCH_CURRENT = "--switch-current" in sys.argv


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ts_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(1024 * 1024)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def wjson(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def log(msg: str) -> None:
    line = f"[{now_iso()}] {msg}"
    print(line, flush=True)
    p = ROOT / "11_LOGS" / "r9_build.log"
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def hardlink_tree(src: Path, dst: Path) -> tuple[int, int]:
    ok = fail = 0
    for f in src.rglob("*"):
        if not f.is_file():
            continue
        rel = f.relative_to(src)
        out = dst / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists():
            ok += 1
            continue
        try:
            os.link(f, out)
            ok += 1
        except OSError:
            try:
                shutil.copy2(f, out)
                ok += 1
            except Exception:
                fail += 1
    return ok, fail


def load_staging() -> list[dict]:
    man = ROOT / "08_FINANCE_SOURCE_HANDOFF" / "STAGING_MANIFEST.json"
    obj = json.loads(man.read_text(encoding="utf-8"))
    items = list(obj.get("items") or [])
    if not items:
        raise RuntimeError("no_finance_staging_items")
    return items


def ingest_finance(item: dict, release_root: Path) -> dict:
    src = Path(item["raw_path"])
    if not src.exists():
        raise RuntimeError(f"missing_raw:{src}")
    rel = item["clean_rel"].replace("\\", "/")
    out = release_root / "standard" / "fundamentals" / rel
    out.parent.mkdir(parents=True, exist_ok=True)
    # Prefer copy for new finance partitions (avoid cross-volume hardlink surprises)
    if out.exists():
        out.unlink()
    try:
        os.link(src, out)
    except OSError:
        shutil.copy2(src, out)
    # For STK 2026_H1: also drop a stable alias overwriting prior H1 name pattern consumers
    # keep both timestamped incremental and leave old hardlinked parent file intact.
    return {
        "repair_unit_id": item["unit_id"],
        "domain_id": item.get("domain_id"),
        "trade_date": item.get("as_of") or item.get("statDate") or item.get("half") or CLEANING_AS_OF,
        "status": "COMMITTED",
        "source_file": str(src),
        "source_sha256": item.get("file_sha256") or sha256_file(src),
        "active_path": str(out),
        "active_sha256": sha256_file(out),
        "active_row_count": int(item.get("rows") or 0),
        "quarantine_path": None,
        "quarantine_row_count": 0,
    }


def seal_release(release_root: Path, release_id: str, seal_id: str, repair_results: list[dict], finance_asof: str) -> dict:
    inv = []
    for f in release_root.rglob("*.parquet"):
        if not f.is_file():
            continue
        rel = str(f.relative_to(release_root)).replace("\\", "/")
        art = "quarantine" if "/_quarantine/" in ("/" + rel) or rel.startswith("_quarantine/") else "standard"
        inv.append({
            "relative_path": rel,
            "sha256": sha256_file(f),
            "size": f.stat().st_size,
            "artifact_type": art,
            "logical_partition_key": f.name,
        })
    inv_df = pd.DataFrame(inv)
    seal_dir = release_root / "_seal"
    seal_dir.mkdir(parents=True, exist_ok=True)
    inv_df.to_parquet(seal_dir / "SEALED_CONTENT_INVENTORY.parquet", index=False)
    root_sha = hashlib.sha256(
        ("\n".join(sorted(f"{r.relative_path}:{r.sha256}" for r in inv_df.itertuples()))).encode("utf-8")
    ).hexdigest()
    cert = {
        "release_id": release_id,
        "seal_id": seal_id,
        "parent_release_id": PARENT_ID,
        "parent_seal_id": PARENT_SEAL,
        "cleaning_as_of": CLEANING_AS_OF,
        "finance_asof": finance_asof,
        "release_version": "R9",
        "repair_unit_count": len(repair_results),
        "repair_committed": sum(1 for r in repair_results if r["status"] == "COMMITTED"),
        "release_content_root_sha256": root_sha,
        "sealed_at": now_iso(),
        "carry_forward_method": "HARD_LINK_FINGERPRINT_REUSE_FROM_PARENT_R8",
        "scope": "FINANCE_INCREMENTAL_ON_TOP_OF_R4_PRICE",
    }
    wjson(seal_dir / "CLEANING_LAYER_SEAL_CERTIFICATE.json", cert)
    wjson(seal_dir / "RELEASE_ROOT_FINGERPRINTS.json", {
        "release_content_root_sha256": root_sha,
        "file_count": len(inv_df),
        "generated_at": now_iso(),
    })
    (release_root / ".BLACKBOX_SEALED").write_text(seal_id + "\n", encoding="utf-8")
    db = release_root / "_control" / "cleaning_ledger.sqlite"
    db.parent.mkdir(parents=True, exist_ok=True)
    if db.exists():
        db.unlink()
    con = sqlite3.connect(str(db))
    con.execute(
        "CREATE TABLE cleaning_release(release_id TEXT, parent_release_id TEXT, cleaning_as_of TEXT, seal_id TEXT, sealed INTEGER)"
    )
    con.execute(
        "INSERT INTO cleaning_release VALUES (?,?,?,?,1)",
        (release_id, PARENT_ID, CLEANING_AS_OF, seal_id),
    )
    con.execute(
        "CREATE TABLE repair_unit_lineage(repair_unit_id TEXT, domain_id TEXT, trade_date TEXT, active_sha256 TEXT, active_row_count INTEGER, status TEXT)"
    )
    for r in repair_results:
        con.execute(
            "INSERT INTO repair_unit_lineage VALUES (?,?,?,?,?,?)",
            (r["repair_unit_id"], r["domain_id"], r["trade_date"], r["active_sha256"], r["active_row_count"], r["status"]),
        )
    con.commit()
    con.close()
    wjson(release_root / "_control" / "RELEASE_FREEZE.json", {
        "release_id": release_id, "seal_id": seal_id, "frozen_at": now_iso(), "immutable": True,
    })
    return cert


def switch_current(release_id: str, seal_id: str, root_sha: str, release_root: Path, finance_asof: str) -> None:
    daily_asof = CLEANING_AS_OF
    if CURRENT.exists():
        try:
            prev = json.loads(CURRENT.read_text(encoding="utf-8"))
            daily_asof = str(prev.get("daily_asof") or prev.get("cleaning_as_of") or daily_asof)
        except Exception:
            pass
    obj = {
        "release_id": release_id,
        "seal_id": seal_id,
        "sealed": True,
        "cleaning_as_of": CLEANING_AS_OF,
        "finance_asof": finance_asof,
        "daily_asof": daily_asof,
        "standard_root": str(release_root / "standard"),
        "quarantine_root": str(release_root / "_quarantine"),
        "ledger_path": str(release_root / "_control" / "cleaning_ledger.sqlite"),
        "release_content_root_sha256": root_sha,
        "created_at": now_iso(),
        "parent_release_id": PARENT_ID,
        "switch_reason": "POST_SEAL_FINANCE_INCREMENTAL_R9_USER_AUTHORIZED",
    }
    bak = CURRENT.with_suffix(".json.bak_before_r9_" + ts_stamp())
    if CURRENT.exists():
        bak.write_text(CURRENT.read_text(encoding="utf-8"), encoding="utf-8")
    tmp = CURRENT.with_name(CURRENT.name + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, CURRENT)


def patch_hand(release_id: str, seal_id: str, finance_asof: str) -> None:
    if not HAND.exists():
        return
    sys.path.insert(0, r"E:\BLACKBOX\脚本")
    import p7_gate_common as gc
    d = json.loads(HAND.read_text(encoding="utf-8"))
    d.update({
        "cleaning_r9_pending_after_download": False,
        "post_seal_finance_r9_status": "PASS",
        "post_seal_finance_r9_release_id": release_id,
        "post_seal_finance_r9_seal_id": seal_id,
        "finance_asof_current": finance_asof,
        "download_layer_complete": True,
        "next_stage": "POST_SEAL_FINANCE_R9_DONE",
        "next_action": "Finance incremental R9 sealed; awaiting next HAND",
        "updated_at": now_iso(),
    })
    gc.write_hand_decision(d)
    try:
        gc.write_hand_md(d)
    except Exception:
        pass


def main() -> int:
    (ROOT / "11_LOGS").mkdir(parents=True, exist_ok=True)
    dl = json.loads((ROOT / "10_ACCEPTANCE" / "DOWNLOAD_ACCEPTANCE.json").read_text(encoding="utf-8"))
    if dl.get("status") not in ("PASS", "REVIEW_REQUIRED"):
        log(f"download not ready: {dl.get('status')}")
        return 2
    if int(dl.get("unit_fail") or 0) > 0 and int(dl.get("unit_done") or 0) == 0:
        log("download all failed")
        return 2
    if not PARENT.exists() or not (PARENT / ".BLACKBOX_SEALED").exists():
        log("parent R8 missing/unsealed")
        return 2

    items = load_staging()
    finance_asof = str(dl.get("finance_asof") or CLEANING_AS_OF)
    log(f"manifest finance units={len(items)} asof={finance_asof}")

    build_ts = ts_stamp()
    release_id = f"BLACKBOX_FORMAL_CLEANING_R9_ASOF_{CLEANING_AS_OF.replace('-', '')}_{build_ts}"
    seal_id = f"BLACKBOX_CLEANING_LAYER_SEAL_R9_{build_ts}"
    release_root = RELEASES / release_id
    if release_root.exists():
        log("release exists")
        return 2
    release_root.mkdir(parents=True)

    log("CARRY_FORWARD hardlink from R8")
    n_std, f_std = hardlink_tree(PARENT / "standard", release_root / "standard")
    n_q, f_q = hardlink_tree(PARENT / "_quarantine", release_root / "_quarantine")
    log(f"carry std={n_std}/{f_std} q={n_q}/{f_q}")
    if f_std or f_q:
        return 2

    repair_results = []
    for item in items:
        res = ingest_finance(item, release_root)
        repair_results.append(res)
        log(f"ingest {res['repair_unit_id']} rows={res['active_row_count']}")

    cert = seal_release(release_root, release_id, seal_id, repair_results, finance_asof)
    log(f"SEALED {seal_id}")
    if SWITCH_CURRENT:
        switch_current(release_id, seal_id, cert["release_content_root_sha256"], release_root, finance_asof)
        patch_hand(release_id, seal_id, finance_asof)
        log("CURRENT switched to R9")
    out = {
        "final_status": "PASS",
        "release_id": release_id,
        "seal_id": seal_id,
        "parent_release_id": PARENT_ID,
        "repair_committed": len(repair_results),
        "cleaning_as_of": CLEANING_AS_OF,
        "finance_asof": finance_asof,
        "CURRENT_switched": SWITCH_CURRENT,
        "generated_at": now_iso(),
    }
    wjson(ROOT / "12_ACCEPTANCE" / "R9_SEAL_RESULT.json", out)
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
