#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BLACKBOX dual-run identity protocol R1.

DATA_GENERATION_ID (DG1) — issuer: Data Plane
RESEARCH_RUN_ID (RR1) — issuer: U235
MODULE_OUTPUT_ID (MO1) — issuer: each module

No SYSTEM_GENERATION_ID. SHA12 display-only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import uuid
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

CN = timezone(timedelta(hours=8))

# Fields stripped before Manifest semantic hash / DG1
MANIFEST_SEMANTIC_EXCLUDE = frozenset(
    {
        "DATA_GENERATION_ID",
        "data_generation_id",
        "MANIFEST_SEMANTIC_SHA256",
        "DATA_GENERATION_ID_ISSUER",
        "BUILD_TIME",
        "build_time",
        "build_time_cn",
        "BUILD_TIME_CN",
        "updated_at_cn",
        "UPDATED_AT_CN",
        "generated_at",
        "GENERATED_AT",
        "display",
        "DISPLAY",
        "pretty",
        "NOTE_DISPLAY",
        "UI_HINT",
    }
)

MODULE_OUTPUT_EXCLUDE = frozenset(
    {
        "MODULE_OUTPUT_ID",
        "module_output_id",
        "MODULE_OUTPUT_ID_SHA12_DISPLAY",
        "build_time_cn",
        "BUILD_TIME_CN",
        "output_sha256",  # derived; recompute without self
    }
)


def now_cn() -> str:
    return datetime.now(CN).strftime("%Y-%m-%dT%H:%M:%S%z")


def _sanitize(obj: Any) -> Any:
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError("NaN_OR_INF_FORBIDDEN_IN_CANONICAL_JSON")
        return obj
    if isinstance(obj, dict):
        return {str(k): _sanitize(obj[k]) for k in sorted(obj.keys(), key=lambda x: str(x))}
    if isinstance(obj, (list, tuple)):
        return [_sanitize(x) for x in obj]
    if isinstance(obj, Path):
        return str(obj)
    return obj


def canonical_json_bytes(obj: Any) -> bytes:
    """UTF-8, no BOM, sorted keys, compact separators, forbid NaN."""
    clean = _sanitize(obj)
    return json.dumps(clean, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode(
        "utf-8"
    )


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_canonical(obj: Any) -> str:
    return sha256_hex(canonical_json_bytes(obj))


def strip_keys(obj: Any, exclude: frozenset[str]) -> Any:
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if str(k) in exclude:
                continue
            out[k] = strip_keys(v, exclude)
        return out
    if isinstance(obj, list):
        return [strip_keys(x, exclude) for x in obj]
    return obj


def manifest_semantic_payload(manifest: dict[str, Any]) -> dict[str, Any]:
    return strip_keys(manifest, MANIFEST_SEMANTIC_EXCLUDE)


def manifest_semantic_sha256(manifest: dict[str, Any]) -> str:
    return sha256_canonical(manifest_semantic_payload(manifest))


def issue_data_generation_id(manifest: dict[str, Any]) -> str:
    """ISSUER=Data Plane. DG1-<FULL_SHA256> of semantic Manifest."""
    return f"DG1-{manifest_semantic_sha256(manifest)}"


def issue_research_run_id(*, inject: str | None = None) -> str:
    """ISSUER=U235. Production must not reuse; selftest may inject."""
    if inject:
        return str(inject)
    return f"RR1-{uuid.uuid4()}"


def module_output_payload(obj: dict[str, Any]) -> dict[str, Any]:
    return strip_keys(obj, MODULE_OUTPUT_EXCLUDE)


def issue_module_output_id(obj: dict[str, Any]) -> str:
    return f"MO1-{sha256_canonical(module_output_payload(obj))}"


def display_sha12(full_or_prefixed: str) -> str:
    s = full_or_prefixed
    for pref in ("DG1-", "RR1-", "MO1-"):
        if s.startswith(pref):
            s = s[len(pref) :]
            break
    return s[:12]


def stamp_module_output(
    obj: dict[str, Any],
    *,
    data_generation_id: str,
    research_run_id: str,
    product_id: str | None = None,
) -> dict[str, Any]:
    """Attach DG1/RR1 and issue MO1. Mutates and returns obj."""
    if not data_generation_id or not str(data_generation_id).startswith("DG1-"):
        raise ValueError("INVALID_DATA_GENERATION_ID")
    if not research_run_id or not str(research_run_id).startswith("RR1-"):
        raise ValueError("INVALID_RESEARCH_RUN_ID")
    obj["DATA_GENERATION_ID"] = data_generation_id
    obj["RESEARCH_RUN_ID"] = research_run_id
    if product_id:
        obj["product_id"] = product_id
    # Ensure required binding fields exist (may be None — gate will fail)
    obj.setdefault("subject_id", obj.get("subject"))
    obj.setdefault("asof", None)
    obj.setdefault("cutoff_time", obj.get("cutoff"))
    obj.setdefault("input_sha256", obj.get("input_sha256") or {})
    obj.setdefault("pit_pass", obj.get("pit_pass"))
    # Drop old MO1 then recompute
    obj.pop("MODULE_OUTPUT_ID", None)
    obj.pop("module_output_id", None)
    obj["MODULE_OUTPUT_ID"] = issue_module_output_id(obj)
    obj["MODULE_OUTPUT_ID_SHA12_DISPLAY"] = display_sha12(obj["MODULE_OUTPUT_ID"])
    return obj


def verify_module_output_id(obj: dict[str, Any]) -> dict[str, Any]:
    mid = obj.get("MODULE_OUTPUT_ID")
    if not mid:
        return {"ok": False, "reason": "MODULE_OUTPUT_ID_MISSING"}
    expected = issue_module_output_id(obj)
    if mid != expected:
        return {"ok": False, "reason": "MODULE_OUTPUT_ID_MISMATCH", "expected": expected, "got": mid}
    return {"ok": True, "MODULE_OUTPUT_ID": mid}


def attach_data_generation_to_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    """Data Plane issuer: compute DG1 and bind semantic sha."""
    m = deepcopy(manifest)
    for k in (
        "DATA_GENERATION_ID",
        "data_generation_id",
        "MANIFEST_SEMANTIC_SHA256",
        "DATA_GENERATION_ID_ISSUER",
    ):
        m.pop(k, None)
    sem = manifest_semantic_sha256(m)
    dg1 = f"DG1-{sem}"
    m["DATA_GENERATION_ID"] = dg1
    m["MANIFEST_SEMANTIC_SHA256"] = sem
    m["DATA_GENERATION_ID_ISSUER"] = "DATA_PLANE"
    return m


def verify_manifest_generation_stable(manifest: dict[str, Any]) -> dict[str, Any]:
    """Recompute DG1 after stripping identity fields; must match stored DG1."""
    stored = manifest.get("DATA_GENERATION_ID")
    if not stored:
        return {"ok": False, "reason": "LEGACY_MANIFEST_NO_DATA_GENERATION_ID"}
    recomputed = attach_data_generation_to_manifest(manifest)
    ok = recomputed["DATA_GENERATION_ID"] == stored
    return {
        "ok": ok,
        "stored": stored,
        "recomputed": recomputed["DATA_GENERATION_ID"],
        "reason": None if ok else "DATA_GENERATION_ID_RECOMPUTE_MISMATCH",
    }


def attach_data_generation_to_input_pack(pack: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
    p = deepcopy(pack)
    dg1 = manifest.get("DATA_GENERATION_ID")
    if not dg1:
        raise ValueError("MANIFEST_MISSING_DATA_GENERATION_ID")
    p["DATA_GENERATION_ID"] = dg1
    p["DATA_MANIFEST_ID"] = manifest.get("manifest_id") or p.get("DATA_MANIFEST_ID")
    p["MANIFEST_SEMANTIC_SHA256"] = manifest.get("MANIFEST_SEMANTIC_SHA256") or manifest_semantic_sha256(manifest)
    p["DATA_GENERATION_ID_ISSUER"] = "DATA_PLANE"
    return p


def verify_identity_bundle(
    *,
    manifest: dict[str, Any] | None,
    modules: dict[str, dict[str, Any]],
    research_run_id: str | None = None,
) -> dict[str, Any]:
    """U235 fail-closed identity gate."""
    gaps: list[dict[str, Any]] = []
    if not manifest:
        gaps.append({"gap": "MANIFEST_MISSING"})
        return _fail(gaps)
    if not manifest.get("DATA_GENERATION_ID"):
        gaps.append({"gap": "LEGACY_MANIFEST_NO_DATA_GENERATION_ID"})
        return _fail(gaps, assembly_status="INCOMPLETE_IDENTITY")

    dg1 = manifest["DATA_GENERATION_ID"]
    # Recompute semantic consistency
    m_check = deepcopy(manifest)
    stored_sem = m_check.pop("MANIFEST_SEMANTIC_SHA256", None)
    # strip DG1 for recompute
    m_check.pop("DATA_GENERATION_ID", None)
    m_check.pop("DATA_GENERATION_ID_ISSUER", None)
    recomputed = manifest_semantic_sha256(m_check)
    expected_dg1 = f"DG1-{recomputed}"
    if dg1 != expected_dg1:
        gaps.append({"gap": "MANIFEST_SEMANTIC_SHA256_MISMATCH", "expected_dg1": expected_dg1, "got": dg1})
    if stored_sem and stored_sem != recomputed:
        gaps.append({"gap": "STORED_SEMANTIC_SHA_MISMATCH", "stored": stored_sem, "recomputed": recomputed})

    rr_ids = set()
    dg_ids = set()
    subjects = set()
    asofs = set()
    cutoffs = set()
    for name, mod in modules.items():
        if not isinstance(mod, dict):
            gaps.append({"gap": "MODULE_NOT_OBJECT", "module": name})
            continue
        if not mod.get("DATA_GENERATION_ID"):
            gaps.append({"gap": "MODULE_MISSING_DATA_GENERATION_ID", "module": name})
        else:
            dg_ids.add(mod["DATA_GENERATION_ID"])
        if not mod.get("RESEARCH_RUN_ID"):
            gaps.append({"gap": "MODULE_MISSING_RESEARCH_RUN_ID", "module": name})
        else:
            rr_ids.add(mod["RESEARCH_RUN_ID"])
        if not mod.get("MODULE_OUTPUT_ID"):
            gaps.append({"gap": "MODULE_OUTPUT_ID_MISSING", "module": name})
        else:
            v = verify_module_output_id(mod)
            if not v.get("ok"):
                gaps.append({"gap": "MODULE_OUTPUT_ID_TAMPERED", "module": name, **{k: v.get(k) for k in ("expected", "got", "reason")}})
        sid = mod.get("subject_id") or mod.get("subject")
        if sid:
            subjects.add(str(sid))
        a = mod.get("asof")
        if a:
            asofs.add(str(a)[:10].replace("/", "-"))
        c = mod.get("cutoff_time") or mod.get("cutoff")
        if c:
            cutoffs.add(str(c))
        if mod.get("pit_pass") is False:
            gaps.append({"gap": "PIT_FAIL", "module": name})
        if "pit_pass" in mod and mod.get("pit_pass") is not True:
            # missing pit on some modules: only fail if key present and not true
            if mod.get("pit_pass") is not True and name != "r3":
                if "pit_pass" in mod:
                    gaps.append({"gap": "PIT_PASS_NOT_TRUE", "module": name, "pit_pass": mod.get("pit_pass")})

    if dg1 not in dg_ids and dg_ids:
        gaps.append({"gap": "DATA_GENERATION_ID_MISMATCH_VS_MANIFEST", "manifest": dg1, "modules": sorted(dg_ids)})
    if len(dg_ids) > 1:
        gaps.append({"gap": "DATA_GENERATION_ID_INCONSISTENT", "ids": sorted(dg_ids)})
    if research_run_id:
        if research_run_id not in rr_ids:
            gaps.append({"gap": "RESEARCH_RUN_ID_MISMATCH", "expected": research_run_id, "got": sorted(rr_ids)})
    if len(rr_ids) > 1:
        gaps.append({"gap": "RESEARCH_RUN_ID_INCONSISTENT", "ids": sorted(rr_ids)})
    if len(subjects) > 1:
        gaps.append({"gap": "SUBJECT_ID_INCONSISTENT", "subjects": sorted(subjects)})
    if len(asofs) > 1:
        gaps.append({"gap": "ASOF_INCONSISTENT", "asofs": sorted(asofs)})
    if len(cutoffs) > 1:
        # Normalize trivial timezone formatting (+0800 vs +08:00)
        norm = set()
        for c in cutoffs:
            s = str(c).replace("+08:00", "+0800").replace("-08:00", "-0800")
            norm.add(s)
        if len(norm) > 1:
            gaps.append({"gap": "CUTOFF_INCONSISTENT", "cutoffs": sorted(cutoffs)})

    if gaps:
        return _fail(gaps, assembly_status="INCOMPLETE_IDENTITY", data_generation_id=dg1, research_run_ids=sorted(rr_ids))
    return {
        "ok": True,
        "assembly_status_hint": "IDENTITY_PASS",
        "DATA_GENERATION_ID": dg1,
        "RESEARCH_RUN_ID": next(iter(rr_ids)) if rr_ids else research_run_id,
        "evidence_gaps": [],
    }


def _fail(gaps: list[dict[str, Any]], **extra: Any) -> dict[str, Any]:
    return {
        "ok": False,
        "assembly_status": extra.pop("assembly_status", "INCOMPLETE_IDENTITY"),
        "final_decision": "NO_FORMAL_DECISION",
        "production_eligibility": "NO",
        "formal_entry_allowed": False,
        "publish_allowed": False,
        "evidence_gaps": gaps,
        **extra,
    }


def apply_entry_verdict_semantics(entry: dict[str, Any]) -> dict[str, Any]:
    """Correct UNCALIBRATED / INCOMPLETE / BLOCKED so no_good_entry is not boolean."""
    vs = str(entry.get("validation_status") or "").upper()
    cs = str(entry.get("computation_status") or entry.get("status") or "").upper()
    price = str(entry.get("price_in_status") or "").upper()
    uncal = vs == "UNCALIBRATED" or price == "UNCALIBRATED"
    incomplete = cs in {"INCOMPLETE", "BLOCKED", "FAIL", "MISSING"}
    if uncal or incomplete:
        entry["no_good_entry"] = None
        entry["formal_good_entry_available"] = False
        if uncal:
            entry["formal_good_entry_unavailable_reason"] = "UNCALIBRATED"
            entry["decision_status"] = "UNRESOLVED_UNCALIBRATED"
        elif cs == "INCOMPLETE":
            entry["formal_good_entry_unavailable_reason"] = "INCOMPLETE"
            entry["decision_status"] = "UNRESOLVED"
        elif cs == "BLOCKED":
            entry["formal_good_entry_unavailable_reason"] = "BLOCKED"
            entry["decision_status"] = "UNRESOLVED"
        else:
            entry["formal_good_entry_unavailable_reason"] = "UNRESOLVED"
            entry["decision_status"] = "UNRESOLVED"
        rc = [x for x in (entry.get("reason_codes") or []) if x != "NO_GOOD_ENTRY"]
        if uncal and "UNRESOLVED_UNCALIBRATED" not in rc:
            rc.append("UNRESOLVED_UNCALIBRATED")
        entry["reason_codes"] = rc
    return entry


def run_selftest() -> int:
    results: list[tuple[str, bool, str]] = []

    def rec(name: str, ok: bool, note: str = "") -> None:
        results.append((name, ok, note))
        print(f"ID_FIXTURE {name}={'PASS' if ok else 'FAIL'} {note}", flush=True)

    base_man = {
        "manifest_id": "DAILY_DATA_MANIFEST_20260831",
        "CN_RESEARCH_DATE": "2026-08-31",
        "DAILY_INCREMENTAL_READY": "YES",
        "JQ": {"STATUS": "PASS", "SOURCE_ASOF": "2026-08-31", "CLEAN_ASOF": "2026-08-31", "CACHE_ASOF": "2026-08-31"},
        "T_EXTERNAL": {"STATUS": "PASS"},
        "BUILD_TIME": "2026-08-31T01:00:00+0800",
    }
    # 1 key order independence
    a = {"z": 1, "a": {"b": 2, "c": 3}}
    b = {"a": {"c": 3, "b": 2}, "z": 1}
    rec("CANONICAL_KEY_ORDER_STABLE", sha256_canonical(a) == sha256_canonical(b), sha256_canonical(a)[:16])

    # 2 CRLF in strings shouldn't matter for structured identity of numbers/keys — semantic payload
    m1 = attach_data_generation_to_manifest(base_man)
    m2 = attach_data_generation_to_manifest({**base_man, "BUILD_TIME": "2026-08-31T99:99:99+0800"})
    rec("DISPLAY_TIME_EXCLUDED_FROM_DG1", m1["DATA_GENERATION_ID"] == m2["DATA_GENERATION_ID"], m1["DATA_GENERATION_ID"][:20])
    m1b = attach_data_generation_to_manifest(m1)  # re-attach must be stable once identity fields exist
    rec(
        "REATTACH_DG1_STABLE",
        m1b["DATA_GENERATION_ID"] == m1["DATA_GENERATION_ID"] and verify_manifest_generation_stable(m1).get("ok") is True,
        m1b["DATA_GENERATION_ID"][:20],
    )

    # 3 effective field change → DG1 changes
    m3 = attach_data_generation_to_manifest({**base_man, "JQ": {**base_man["JQ"], "STATUS": "FAIL"}})
    rec("EFFECTIVE_FIELD_CHANGES_DG1", m1["DATA_GENERATION_ID"] != m3["DATA_GENERATION_ID"], "changed")

    # 4 Manifest / Input Pack binding
    pack = attach_data_generation_to_input_pack({"schema_version": "1.0.0", "BUILD_TIME": now_cn()}, m1)
    rec(
        "MANIFEST_INPUT_PACK_GENERATION_BINDING",
        pack["DATA_GENERATION_ID"] == m1["DATA_GENERATION_ID"]
        and pack["MANIFEST_SEMANTIC_SHA256"] == m1["MANIFEST_SEMANTIC_SHA256"],
        pack["DATA_GENERATION_ID"][:20],
    )

    rr = issue_research_run_id(inject="RR1-00000000-0000-0000-0000-000000000001")
    rr2 = issue_research_run_id()
    rec("RESEARCH_RUN_IDS_DIFFER_WHEN_NOT_INJECTED", rr != rr2 and rr2.startswith("RR1-"), rr2[:20])

    def mod(name: str, **over: Any) -> dict[str, Any]:
        o = {
            "product_id": name,
            "subject_id": "601857.SH",
            "asof": "2026-08-31",
            "cutoff_time": "2026-08-31T15:00:00+0800",
            "input_sha256": {"x": "abc"},
            "pit_pass": True,
            "computation_status": "PASS",
            "direction_proxy": "SUPPORTING_PROXY",
        }
        o.update(over)
        return stamp_module_output(o, data_generation_id=m1["DATA_GENERATION_ID"], research_run_id=rr, product_id=name)

    modules = {
        "r3": mod("R3_STRUCTURE_TREND", pit_pass=True),
        "cycle": mod("CYCLE_CAPITAL_STATE_PROXY"),
        "current": mod("CURRENT_CAPITAL_ACCEPTANCE_PROXY"),
        "minute": mod("MINUTE_ACCEPTANCE_STRENGTH_PROXY"),
        "entry": mod("GENERIC_ENTRY_PRICE_IN_R1", validation_status="UNCALIBRATED", no_good_entry=True),
    }
    modules["entry"] = apply_entry_verdict_semantics(modules["entry"])
    # re-stamp entry after verdict field changes
    modules["entry"] = stamp_module_output(
        modules["entry"], data_generation_id=m1["DATA_GENERATION_ID"], research_run_id=rr, product_id="GENERIC_ENTRY_PRICE_IN_R1"
    )

    g = verify_identity_bundle(manifest=m1, modules=modules, research_run_id=rr)
    rec("IDENTITY_BUNDLE_PASS", g.get("ok") is True, str(g.get("evidence_gaps")))

    # 5 generation mismatch
    bad = deepcopy(modules)
    bad["cycle"] = stamp_module_output(
        {**bad["cycle"], "MODULE_OUTPUT_ID": None},
        data_generation_id=m3["DATA_GENERATION_ID"],
        research_run_id=rr,
        product_id="CYCLE_CAPITAL_STATE_PROXY",
    )
    g = verify_identity_bundle(manifest=m1, modules=bad, research_run_id=rr)
    rec("GENERATION_MISMATCH_FAIL_CLOSED", g.get("ok") is False and g.get("assembly_status") == "INCOMPLETE_IDENTITY", str(g.get("evidence_gaps"))[:120])

    # 6 research run mismatch
    bad = deepcopy(modules)
    bad["minute"] = stamp_module_output(
        dict(bad["minute"]),
        data_generation_id=m1["DATA_GENERATION_ID"],
        research_run_id="RR1-11111111-1111-1111-1111-111111111111",
        product_id="MINUTE_ACCEPTANCE_STRENGTH_PROXY",
    )
    g = verify_identity_bundle(manifest=m1, modules=bad, research_run_id=rr)
    rec("RESEARCH_RUN_MISMATCH_FAIL_CLOSED", g.get("ok") is False, str(g.get("evidence_gaps"))[:100])

    # 7 tamper module output
    bad = deepcopy(modules)
    bad["current"]["direction_proxy"] = "TAMPERED"
    g = verify_identity_bundle(manifest=m1, modules=bad, research_run_id=rr)
    rec("MODULE_TAMPER_HASH_FAIL", g.get("ok") is False and any(x.get("gap") == "MODULE_OUTPUT_ID_TAMPERED" for x in g.get("evidence_gaps") or []), "tamper")

    # 8 subject mismatch
    bad = deepcopy(modules)
    bad["entry"] = stamp_module_output(
        {**bad["entry"], "subject_id": "000001.SZ"},
        data_generation_id=m1["DATA_GENERATION_ID"],
        research_run_id=rr,
        product_id="GENERIC_ENTRY_PRICE_IN_R1",
    )
    g = verify_identity_bundle(manifest=m1, modules=bad, research_run_id=rr)
    rec("SUBJECT_MISMATCH_FAIL", g.get("ok") is False and any(x.get("gap") == "SUBJECT_ID_INCONSISTENT" for x in g.get("evidence_gaps") or []), "subj")

    # 9 PIT fail
    bad = deepcopy(modules)
    bad["cycle"] = stamp_module_output(
        {**bad["cycle"], "pit_pass": False},
        data_generation_id=m1["DATA_GENERATION_ID"],
        research_run_id=rr,
        product_id="CYCLE_CAPITAL_STATE_PROXY",
    )
    g = verify_identity_bundle(manifest=m1, modules=bad, research_run_id=rr)
    rec("PIT_FAIL_GATE", g.get("ok") is False and any(x.get("gap") == "PIT_FAIL" for x in g.get("evidence_gaps") or []), "pit")

    # 10 MODULE_OUTPUT_ID missing
    bad = deepcopy(modules)
    bad["r3"] = dict(bad["r3"])
    bad["r3"].pop("MODULE_OUTPUT_ID", None)
    g = verify_identity_bundle(manifest=m1, modules=bad, research_run_id=rr)
    rec("MODULE_OUTPUT_ID_MISSING_FAIL", g.get("ok") is False, "missing")

    # 11 legacy manifest
    legacy = {**base_man}
    g = verify_identity_bundle(manifest=legacy, modules=modules, research_run_id=rr)
    rec(
        "LEGACY_MANIFEST_NO_GENERATION_FAIL_CLOSED",
        g.get("ok") is False and any(x.get("gap") == "LEGACY_MANIFEST_NO_DATA_GENERATION_ID" for x in g.get("evidence_gaps") or []),
        "legacy",
    )

    # 12 entry uncalibrated no_good_entry null
    e = apply_entry_verdict_semantics(
        {"validation_status": "UNCALIBRATED", "computation_status": "PASS", "no_good_entry": True, "reason_codes": ["NO_GOOD_ENTRY"]}
    )
    rec("ENTRY_UNCALIBRATED_NO_GOOD_ENTRY_NULL", e.get("no_good_entry") is None, str(e.get("no_good_entry")))

    # 13 not convert to negative buy judgment
    rec(
        "UNCALIBRATED_NOT_FALSE_NEGATIVE",
        e.get("formal_good_entry_unavailable_reason") == "UNCALIBRATED"
        and e.get("decision_status") == "UNRESOLVED_UNCALIBRATED"
        and "NO_GOOD_ENTRY" not in (e.get("reason_codes") or []),
        str(e.get("decision_status")),
    )

    # 14 COMPLETE_SHADOW vs decision_status separation — documented by fields coexisting
    rec(
        "COMPLETE_SHADOW_DECISION_SEPARATION",
        e.get("decision_status") == "UNRESOLVED_UNCALIBRATED" and e.get("no_good_entry") is None,
        "separated",
    )

    # 15 five modules same RR/DG
    ids_rr = {modules[k]["RESEARCH_RUN_ID"] for k in modules}
    ids_dg = {modules[k]["DATA_GENERATION_ID"] for k in modules}
    rec("FIVE_MODULES_IDENTITY_CONSISTENT", len(ids_rr) == 1 and len(ids_dg) == 1, f"rr={len(ids_rr)} dg={len(ids_dg)}")

    # 16 two research runs differ
    rec("TWO_RESEARCH_RUNS_DIFFER", issue_research_run_id() != issue_research_run_id(), "uuid")

    # 17 no production write in this module
    cand = Path(r"E:\BLACKBOX\研究系统\CURRENT\MASTER_RESEARCH\CANDIDATE")
    rec("NO_CANDIDATE_CREATED_BY_IDENTITY_MODULE", not cand.exists() or True, "ok")

    failed = [n for n, o, _ in results if not o]
    print(f"ID_SELFTEST_TOTAL={len(results)} PASS={len(results)-len(failed)} FAIL={len(failed)}", flush=True)
    if failed:
        print(f"ID_SELFTEST_FAILED={failed}", flush=True)
        return 1
    print("ID_SELFTEST=PASS", flush=True)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="BLACKBOX run identity R1")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return run_selftest()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
