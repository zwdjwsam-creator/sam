#!/usr/bin/env python3
"""JQ_P7_60M_MATRIX_WORKER — single-pool 60m missing-only worker."""
import sys
import json
import csv
import time
from pathlib import Path
from datetime import datetime, timezone

if len(sys.argv) < 2:
    print("Usage: p7_60m_matrix_worker.py <POOL_NAME>")
    sys.exit(1)

POOL = sys.argv[1].upper()
TASK = f"JQ_P7_60M_MATRIX_WORKER_{POOL}"

sys.stdout.reconfigure(encoding="utf-8")
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path("E:/BLACKBOX/脚本")))
import p7_gate_common as gc
import p7_60m_batch_code_mapping_r17 as m60

_dec = gc.load_hand_decision()
if not _dec or _dec.get("hand_release_allowed") is not True:
    print(f"[{POOL}] BLOCK: HAND not released")
    sys.exit(3)
if _dec.get("current_stage") != "60m" or _dec.get("sixty_m_allowed") is not True:
    print(f"[{POOL}] BLOCK: 60m not allowed by HAND")
    sys.exit(3)

P7_DIR = m60.P7_DIR
MATRIX = m60.R17_ROOT
OUT = MATRIX / POOL
NOW_TS = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
NOW_ISO = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")

for s in ["preflight", "execution_log", "quota_log", "checkpoint", "reports", "manifest"]:
    (OUT / s).mkdir(parents=True, exist_ok=True)

print(f"=== WORKER {POOL}: PREFLIGHT ===")
pool_queue_path = m60.POOL_DIR / f"p7_60m_queue_{POOL}.csv"
if not pool_queue_path.exists():
    print(f"BLOCK: pool queue missing: {pool_queue_path}")
    sys.exit(2)

queue_data = list(csv.DictReader(pool_queue_path.read_text(encoding="utf-8-sig").splitlines()))
print(f"Pool {POOL}: {len(queue_data)} queue items")

stagger = {"POOL_A": 0.0, "POOL_B": 1.5, "POOL_C": 3.0}
time.sleep(stagger.get(POOL, 0.0))
import jq_download_base as jdb

jdb.auth()
spare = jdb.quota_left(force=True) or 0
print(f"[{POOL}] auth OK, spare={spare}")
if spare <= 0:
    sys.exit(0)

import pandas as pd

_SEC_DF = m60.load_securities_df()
filtered = [r for r in queue_data if str(r.get("api_call_allowed", "")).lower() == "true"]
print(f"[{POOL}] Processing {len(filtered)} items...")

completed = failed = skipped = 0
parquet_count = quota_used = 0
stop_reason = ""

for idx, item in enumerate(filtered):
    if gc.global_stop_active():
        stop_reason = "global_stop"
        break
    year = item.get("year", "")
    batch_id = item.get("batch_id", "")
    pk = item.get("partition_key", m60.partition_key(year, batch_id))
    est = int(item.get("estimated_quota", 1500))

    exists, _ = m60.parquet_exists(year, batch_id)
    if exists or item.get("parquet_exists") == "true":
        skipped += 1
        continue

    curr_q = jdb.quota_left(force=(idx % 15 == 0))
    if curr_q is not None and curr_q < max(est, 500):
        gc.set_global_stop("quota_exhausted")
        stop_reason = "quota_exhausted"
        break

    ok_api, reason = gc.check_partition_before_api(pk, "60m", year, batch_id, worker_id=POOL)
    if not ok_api:
        skipped += 1
        continue

    mapping = m60.classify_partition(year, batch_id, queue_row=item, sec=_SEC_DF)
    eligible = m60.parse_codes_field(mapping["eligible_codes"])
    if mapping["mapping_class"] == "all_expected_empty" or not eligible:
        skipped += 1
        continue

    if idx % 10 == 0:
        print(
            f"  [{POOL}] {idx+1}/{len(filtered)} {year} {batch_id} "
            f"elig={len(eligible)} q~{jdb.quota_left(force=True)}"
        )

    try:
        import jqdatasdk as jq_d

        sd = m60.year_start_for(year).isoformat()
        ed = m60.year_end_for(year).isoformat()
        result = jq_d.get_price(eligible, start_date=sd, end_date=ed, **m60.GET_PRICE_KWARGS_60M)

        if result is not None and len(result) > 0:
            fn = f"stock_minute_60m__{year}__{batch_id}__1.0.0__{NOW_TS}.parquet"
            out_path = P7_DIR / fn
            if out_path.exists():
                skipped += 1
                continue
            if isinstance(result, pd.DataFrame):
                result.to_parquet(str(out_path), index=True)
            else:
                pd.DataFrame(result).to_parquet(str(out_path), index=True)
            parquet_count += 1
            completed += 1
            quota_used += est
            gc.release_partition_claim(pk, worker=POOL)
        else:
            failed += 1
    except Exception as e:
        failed += 1
        if any(kw in str(e).lower() for kw in ("quota", "insufficient", "额度")):
            stop_reason = "api_quota_empty"
            break

curr_q = jdb.quota_left(force=True)
print(f"\n[{POOL}] STOP: {stop_reason or 'pool_done'}")
print(f"[{POOL}] completed={completed} failed={failed} skipped={skipped} parquet={parquet_count}")

cp = {
    "task": TASK,
    "pool": POOL,
    "completed": completed,
    "failed": failed,
    "skipped": skipped,
    "parquet": parquet_count,
    "quota_used": quota_used,
    "quota_left": curr_q,
    "stop_reason": stop_reason or "pool_done",
    "pool_complete": stop_reason in ("", "pool_done"),
    "generated_at": NOW_ISO,
}
(OUT / "checkpoint" / f"worker_{POOL}_checkpoint_{NOW_TS}.json").write_text(
    json.dumps(cp, ensure_ascii=False, indent=2), encoding="utf-8"
)
print(f"[{POOL}] DONE")
sys.exit(0)
