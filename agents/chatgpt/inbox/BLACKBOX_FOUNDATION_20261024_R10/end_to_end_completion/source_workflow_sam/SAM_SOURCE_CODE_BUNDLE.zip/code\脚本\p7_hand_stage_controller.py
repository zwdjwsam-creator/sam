#!/usr/bin/env python3
"""
p7_hand_stage_controller.py — LOCAL HAND scheduler judge.
Reads gates / checkpoints / quota / ledger / queue, writes HAND_DECISION.json.

Usage:
  python p7_hand_stage_controller.py           # live (reads quota)
  python p7_hand_stage_controller.py --dry-run # PRO review (no JQData)
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).resolve().parent))

import p7_gate_common as gc

TASK = "JQ_P7_HAND_AUTO_STAGE_ADVANCE_R1"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="PRO mode: no JQData API")
    args = ap.parse_args()

    print("=" * 60)
    print("HAND STAGE CONTROLLER")
    print("=" * 60)
    print(f"mode: {'DRY_RUN' if args.dry_run else 'LIVE'}")
    print()

    # 1. Old entrypoints
    entry = gc.check_old_entrypoints()
    print(f"Old entrypoints: guarded={entry['guarded_count']} bypass_risk={entry['old_entrypoint_bypass_risk_count']}")

    # 2. All stage quality gates
    for freq in ("5m", "1m"):
        gate = gc.scan_frequency_quality_gate(freq)
        gc.write_quality_gate(freq, gate)
        print(f"{freq} quality gate: {'PASS' if gate['quality_gate_pass'] else 'FAIL'}")
    gc.write_stub_gate_30m_60m()
    print("30m/60m stub gates written")

    # 3. Checkpoints
    ck5 = gc.find_latest_checkpoint(gc.MATRIX_5M)
    ck1 = gc.find_latest_checkpoint(gc.MATRIX_1M)
    print(f"Latest 5m checkpoint: {'yes' if ck5 else 'no'}")
    print(f"Latest 1m checkpoint: {'yes' if ck1 else 'no'}")

    # 4. Build decision (hard gate + auto advance)
    decision = gc.build_hand_decision(dry_run=args.dry_run, task=TASK)
    hand_path = gc.write_hand_decision(decision)
    md_path = gc.write_hand_md(decision)

    print()
    print(f"hard_gate_pass: {decision.get('hard_gate_pass')}")
    print(f"work_stage: {decision.get('work_stage')}")
    print(f"current_stage_complete: {decision.get('current_stage_complete')}")
    print(f"auto_stage_advance_allowed: {decision.get('auto_stage_advance_allowed')}")
    print(f"next_stage_auto_release_allowed: {decision.get('next_stage_auto_release_allowed')}")
    print(f"user_confirmation_required: {decision.get('user_confirmation_required')}")
    print(f"stage_transition_reason: {decision.get('stage_transition_reason')}")
    print(f"hand_release_allowed: {decision['hand_release_allowed']}")
    print(f"hand_release_level: {decision['hand_release_level']}")
    print(f"current_stage: {decision['current_stage']}")
    print(f"allowed_executor: {decision['allowed_executor']}")
    print(f"allowed_script: {decision['allowed_script']}")
    print(f"active_workers: {decision.get('active_workers')}/{decision.get('max_worker_ceiling')}")
    print(f"max_worker: {decision.get('max_worker')}")
    print(f"cross_stage_parallel: {decision.get('cross_stage_parallel')}")
    print(f"concurrency_mode: {decision.get('concurrency_mode')}")
    if decision.get("blocked_reason"):
        print(f"blocked_reason: {decision['blocked_reason']}")
    print(f"next_action: {decision['next_action']}")
    if not args.dry_run and decision.get("quota_left") is not None:
        print(f"quota_left: {gc.quota_fmt(decision['quota_left'])}")
    print()
    print(f"HAND_DECISION: {hand_path}")
    print(f"HAND_MD: {md_path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
