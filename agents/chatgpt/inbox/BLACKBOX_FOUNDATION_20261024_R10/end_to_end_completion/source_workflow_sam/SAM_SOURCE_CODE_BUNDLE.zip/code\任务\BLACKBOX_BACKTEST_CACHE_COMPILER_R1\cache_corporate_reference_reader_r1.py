# -*- coding: utf-8 -*-
"""Readers with separated semantics for corporate reference PIT products."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Optional

import pandas as pd

CACHE_PTR = Path(r"E:\BLACKBOX\数据\回测缓存\CURRENT_CACHE_RELEASE.json")


@lru_cache(maxsize=1)
def _cache_root() -> Path:
    cur = json.loads(CACHE_PTR.read_text(encoding="utf-8"))
    return Path(cur["standard_root"])


def _product_full(product_id: str) -> Path:
    root = _cache_root() / product_id / "data"
    files = list(root.glob("*_FULL.parquet"))
    if not files:
        raise FileNotFoundError(product_id)
    return files[0]


def _timeline(product_id: str, index_name: str) -> pd.DataFrame:
    p = _cache_root() / product_id / "indexes" / index_name
    return pd.read_parquet(p)


def get_shareholder_top10_asof(code: str, trade_date: str) -> pd.DataFrame:
    """Latest known TOP10 snapshot as of trade_date (pit_valid_from <= T)."""
    T = pd.Timestamp(trade_date).normalize()
    tl = _timeline("CORP_SHAREHOLDER_TOP10_PIT_R1", "SHAREHOLDER_TOP10_ASOF_INDEX_R1.parquet")
    sub = tl[(tl["stock_code"] == code) & (pd.to_datetime(tl["pit_valid_from"]) <= T)]
    if sub.empty:
        return pd.DataFrame()
    snap_id = sub.sort_values(["pit_valid_from", "publication_date", "observation_date", "snapshot_version"]).iloc[-1]["snapshot_id"]
    full = pd.read_parquet(_product_full("CORP_SHAREHOLDER_TOP10_PIT_R1"))
    out = full[full["snapshot_id"] == snap_id].copy()
    return out.sort_values("shareholder_rank") if "shareholder_rank" in out.columns else out


def get_floating_shareholder_top10_asof(code: str, trade_date: str) -> pd.DataFrame:
    T = pd.Timestamp(trade_date).normalize()
    tl = _timeline("CORP_SHAREHOLDER_FLOATING_TOP10_PIT_R1", "SHAREHOLDER_FLOATING_TOP10_ASOF_INDEX_R1.parquet")
    sub = tl[(tl["stock_code"] == code) & (pd.to_datetime(tl["pit_valid_from"]) <= T)]
    if sub.empty:
        return pd.DataFrame()
    snap_id = sub.sort_values(["pit_valid_from", "publication_date", "observation_date", "snapshot_version"]).iloc[-1]["snapshot_id"]
    full = pd.read_parquet(_product_full("CORP_SHAREHOLDER_FLOATING_TOP10_PIT_R1"))
    out = full[full["snapshot_id"] == snap_id].copy()
    return out.sort_values("shareholder_rank") if "shareholder_rank" in out.columns else out


def get_xr_xd_known_asof(code: str, trade_date: str) -> pd.DataFrame:
    """Events already publicly known as of trade_date (pit_valid_from <= T)."""
    T = pd.Timestamp(trade_date).normalize()
    idx = pd.read_parquet(_cache_root() / "CORP_XR_XD_EVENT_PIT_R1" / "indexes" / "KNOWN_EVENT_INDEX.parquet")
    sub = idx[(idx["stock_code"] == code) & (pd.to_datetime(idx["pit_valid_from"]) <= T)]
    if sub.empty:
        return pd.DataFrame()
    full = pd.read_parquet(_product_full("CORP_XR_XD_EVENT_PIT_R1"))
    return full[full["event_id"].isin(sub["event_id"])].copy()


def get_xr_xd_effective_on(code: str, trade_date: str) -> pd.DataFrame:
    """Events whose economic effective_date == trade_date (not merely known)."""
    T = pd.Timestamp(trade_date).normalize()
    idx = pd.read_parquet(_cache_root() / "CORP_XR_XD_EVENT_PIT_R1" / "indexes" / "EFFECTIVE_EVENT_INDEX.parquet")
    sub = idx[(idx["stock_code"] == code) & (pd.to_datetime(idx["effective_date"]) == T)]
    if sub.empty:
        return pd.DataFrame()
    full = pd.read_parquet(_product_full("CORP_XR_XD_EVENT_PIT_R1"))
    return full[full["event_id"].isin(sub["event_id"])].copy()
