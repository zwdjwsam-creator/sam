# -*- coding: utf-8 -*-
"""Switch CURRENT only if all gates PASS. Register resolver. No R26. Keep old P2/STOCK_DAILY."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_STOCK_DAILY_RAW_PIT_R1_FULL_REBUILD_R1")
CLEAN_ROOT = Path(r"E:\BLACKBOX\数据\清洗成品")
CLEAN_PTR = CLEAN_ROOT / "CURRENT_CLEANING_RELEASE.json"
CACHE_ROOT = Path(r"E:\BLACKBOX\数据\回测缓存")
CACHE_PTR = CACHE_ROOT / "CURRENT_CACHE_RELEASE.json"
CATALOG = CACHE_ROOT / "registry" / "CACHE_PRODUCT_CATALOG.csv"
SCHEMA = CACHE_ROOT / "registry" / "CACHE_SCHEMA_REGISTRY.csv"
PY = Path(r"E:\BLACKBOX\.venv\Scripts\python.exe")
RESOLVER = Path(r"E:\BLACKBOX\脚本\blackbox_data_access_resolver_r1.py")
STATUS = Path(r"E:\BLACKBOX\运行\BLACKBOX_STOCK_DAILY_RAW_AUTHORITY_CURRENT.json")
HAND = Path(r"E:\BLACKBOX\HAND.txt")
ARCH = Path(r"D:\CURSOR_TASK_ARCHIVE\BLACKBOX_STOCK_DAILY_RAW_PIT_R1_FULL_REBUILD_R1")
PRODUCT = "STOCK_DAILY_RAW_PIT_R1"


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print("[%s] %s" % (now_cn(), msg), flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def load(name: str) -> dict:
    return json.loads((TASK / name).read_text(encoding="utf-8"))


def gates() -> dict:
    cov = load("SOURCE_COVERAGE.json")
    gold = load("RAW_SEMANTICS_GOLDEN.json")
    seal = load("SOURCE_SEAL.json")
    cl = load("CLEANING_CANDIDATE.json")
    ca = load("CACHE_CANDIDATE.json")
    rec = load("PRE_PIT_RECONSTRUCTION_GOLDEN.json")
    nh = load("NH120_POPULATION_RECALIBRATION.json")
    g = {
        "RAW_SOURCE_COMPLETE": bool(cov.get("RAW_SOURCE_COMPLETE")),
        "RAW_SEMANTICS_PASS": bool(gold.get("RAW_SEMANTICS_PASS")),
        "001230_RAW_PASS": bool(gold.get("001230_RAW_PASS")),
        "000001_RAW_PASS": bool(gold.get("000001_RAW_PASS")),
        "PIT_PASS": bool(cl.get("pit", {}).get("PIT_PASS")),
        "ANTI_LOOKAHEAD_PASS": bool(cl.get("pit", {}).get("ANTI_LOOKAHEAD_PASS") and cov.get("ANTI_LOOKAHEAD_PASS")),
        "CLEAN_PASS": bool(ca.get("CLEAN_PASS")),
        "YEAR_SLICE_PASS": bool(ca.get("YEAR_SLICE_PASS")),
        "CACHE_PASS": ca.get("cache_release_id", "").startswith("BLACKBOX_CACHE_R1_STOCK_DAILY_RAW"),
        "NO_RAW_FALLBACK": cov.get("raw_fallback_used") is False and cov.get("p2_reused") is False,
        "PRE_PIT_RECONSTRUCTION_PASS": bool(rec.get("PRE_PIT_RECONSTRUCTION_PASS")),
        "NH120_POPULATION_RECALIBRATED": bool(nh.get("NH120_POPULATION_RECALIBRATED")),
        "SOURCE_SEAL_PASS": bool(seal.get("PASS")),
    }
    g["ALL_GATES"] = all(g.values())
    return g


def append_catalog() -> None:
    txt = CATALOG.read_text(encoding="utf-8")
    line = "STOCK_DAILY_RAW_PIT_R1,L1,STOCK,ACTIVE,year/signal_date,Stock daily RAW PIT fq=none explicit; not P2 none_adj\n"
    if "STOCK_DAILY_RAW_PIT_R1," not in txt:
        CATALOG.write_text(txt.rstrip() + "\n" + line, encoding="utf-8")
    sch = SCHEMA.read_text(encoding="utf-8")
    rows = [
        "STOCK_DAILY_RAW_PIT_R1,signal_date,date,SAME_DAY_KNOWN_EOD,",
        "STOCK_DAILY_RAW_PIT_R1,code,str,STATIC_ASOF,",
        "STOCK_DAILY_RAW_PIT_R1,open,float,SAME_DAY_KNOWN_EOD,RAW_NONE fq=none explicit",
        "STOCK_DAILY_RAW_PIT_R1,high,float,SAME_DAY_KNOWN_EOD,RAW_NONE fq=none explicit",
        "STOCK_DAILY_RAW_PIT_R1,low,float,SAME_DAY_KNOWN_EOD,RAW_NONE fq=none explicit",
        "STOCK_DAILY_RAW_PIT_R1,close,float,SAME_DAY_KNOWN_EOD,RAW_NONE fq=none explicit",
        "STOCK_DAILY_RAW_PIT_R1,volume,float,SAME_DAY_KNOWN_EOD,",
        "STOCK_DAILY_RAW_PIT_R1,money,float,SAME_DAY_KNOWN_EOD,",
        "STOCK_DAILY_RAW_PIT_R1,price_adj_tag,str,STATIC_ASOF,RAW_NONE",
        "STOCK_DAILY_RAW_PIT_R1,pit_status,str,STATIC_ASOF,",
    ]
    if "STOCK_DAILY_RAW_PIT_R1,signal_date" not in sch:
        SCHEMA.write_text(sch.rstrip() + "\n" + "\n".join(rows) + "\n", encoding="utf-8")


def switch_current(g: dict) -> dict:
    cl = load("CLEANING_CANDIDATE.json")
    ca = load("CACHE_CANDIDATE.json")
    clean_rel = CLEAN_ROOT / "releases" / cl["release_id"] / "RELEASE.json"
    cache_rel = Path(ca["release_root"]) / "RELEASE.json"
    clean_ptr = json.loads(clean_rel.read_text(encoding="utf-8"))
    cache_ptr = json.loads(cache_rel.read_text(encoding="utf-8"))
    clean_ptr["sealed"] = True
    clean_ptr["candidate_only"] = False
    clean_ptr["CURRENT_SWITCHED"] = True
    clean_ptr["STOCK_DAILY_RAW_PIT_R1"] = "READY"
    cache_ptr["candidate_only"] = False
    cache_ptr["CURRENT_SWITCHED"] = True
    cache_ptr["STOCK_DAILY_RAW_PIT_R1"] = "READY"
    cache_ptr["mode"] = "stock_daily_raw_pit_full_history_fq_none"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    bak_c = CLEAN_ROOT / ("CURRENT_CLEANING_RELEASE.BACKUP_BEFORE_R27_STOCK_DAILY_RAW_%s.json" % stamp)
    bak_k = CACHE_ROOT / ("CURRENT_CACHE_RELEASE.BACKUP_BEFORE_STOCK_DAILY_RAW_%s.json" % stamp)
    shutil.copy2(CLEAN_PTR, bak_c)
    shutil.copy2(CACHE_PTR, bak_k)
    wjson(clean_rel, clean_ptr)
    wjson(cache_rel, cache_ptr)
    wjson(CLEAN_PTR, clean_ptr)
    wjson(CACHE_PTR, cache_ptr)
    return {"clean_backup": str(bak_c), "cache_backup": str(bak_k), "cleaning": clean_ptr["release_id"], "cache": cache_ptr["cache_release_id"]}


def resolver_check() -> dict:
    cmd = [str(PY), "-u", str(RESOLVER), "--dataset", "STOCK_DAILY_RAW", "--asof", "2026-08-14"]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    try:
        out = json.loads(p.stdout)
    except Exception:
        out = {"raw_stdout": (p.stdout or "")[:2000], "stderr": (p.stderr or "")[:500]}
    ready = out.get("result_status") == "READY" and out.get("product_id") == PRODUCT
    return {"RESOLVER_PASS": ready, "result": out, "returncode": p.returncode}


def main() -> int:
    g = gates()
    wjson(TASK / "AUTHORITY_GATES.json", g)
    log("GATES %s" % g)
    if not g["ALL_GATES"]:
        wjson(TASK / "HARD_BLOCK_STOCK_DAILY_RAW_AUTHORITY.json", g)
        wjson(STATUS, {
            "status": "HARD_BLOCK_STOCK_DAILY_RAW_AUTHORITY",
            "STOCK_DAILY_RAW_PIT_R1_AUTHORITY_READY": False,
            "gates": g,
            "R26_STRATEGY_BACKTEST": "FROZEN_PENDING_STOCK_DAILY_RAW_REPAIR",
            "set_at_cn": now_cn(),
        })
        return 2
    append_catalog()
    switched = switch_current(g)
    idx = subprocess.run([str(PY), "-u", str(RESOLVER), "--build-index"], capture_output=True, text=True, encoding="utf-8")
    log("INDEX %s" % (idx.stdout or idx.stderr)[:400])
    res = resolver_check()
    g["RESOLVER_PASS"] = res["RESOLVER_PASS"]
    g["ALL_GATES"] = g["ALL_GATES"] and res["RESOLVER_PASS"]
    wjson(TASK / "AUTHORITY_GATES.json", g)
    wjson(TASK / "RESOLVER_CHECK.json", res)
    if not res["RESOLVER_PASS"]:
        wjson(TASK / "HARD_BLOCK_STOCK_DAILY_RAW_AUTHORITY.json", {"reason": "RESOLVER_FAIL", "gates": g, "resolver": res})
        return 2
    final = {
        "final_status": "BLACKBOX_STOCK_DAILY_RAW_PIT_R1_FULL_REBUILD_ACCEPTED",
        "STOCK_DAILY_RAW_PIT_R1_AUTHORITY_READY": True,
        "STOCK_DAILY_PIT_R1_RAW_AUTHORITY": "FAIL_LEGACY_EVIDENCE",
        "ADJUST_FACTOR_PIT_R1": "PASS",
        "R26_STRATEGY_BACKTEST": "FROZEN_UNTIL_EXPLICIT_R26d_START",
        "R26b_PRE_PIT_RETURN_23.2753": "INVALID_PENDING_BASE_PRICE_REPAIR",
        "R26d": "NOT_STARTED",
        "switched": switched,
        "gates": g,
        "set_at_cn": now_cn(),
    }
    wjson(TASK / "FINAL_STATUS.json", final)
    wjson(STATUS, final)
    ARCH.mkdir(parents=True, exist_ok=True)
    for name in ("FINAL_STATUS.json", "AUTHORITY_GATES.json", "RAW_SEMANTICS_GOLDEN.json", "SOURCE_COVERAGE.json", "NH120_POPULATION_RECALIBRATION.json", "PRE_PIT_RECONSTRUCTION_GOLDEN.json"):
        src = TASK / name
        if src.exists():
            shutil.copy2(src, ARCH / name)
    log("ACCEPTED %s" % switched)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
