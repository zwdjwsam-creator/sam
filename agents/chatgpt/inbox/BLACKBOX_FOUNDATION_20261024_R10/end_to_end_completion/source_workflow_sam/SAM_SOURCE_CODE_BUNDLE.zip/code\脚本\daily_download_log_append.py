"""Append-only daily download continuity log (每日下载对话框收工写入).

User trigger (daily download dialog): 「下载收工」

SSOT log: 运行/每日下载日志/DAILY_DOWNLOAD_CONTINUITY.jsonl  (append only, never truncate)
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from _base import *  # noqa: F403

ROOT = Path(r"E:\BLACKBOX")
RUN = ROOT / "运行"
LOG_DIR = RUN / "每日下载日志"
JSONL_PATH = LOG_DIR / "DAILY_DOWNLOAD_CONTINUITY.jsonl"
SLICE_PATH = LOG_DIR / "LATEST_SLICE.md"
OUTBOX_POINTER = RUN / "外部大脑信箱/agents/cursor/outbox/DAILY_DOWNLOAD_LATEST.md"
QUOTA_SNAPSHOT = RUN / "P4_main/quota/P4_LIVE_QUOTA_SNAPSHOT.json"
SLICE_TAIL = 30


def _read_jsonl() -> list[dict]:
    if not JSONL_PATH.is_file():
        return []
    rows: list[dict] = []
    for line in read_text(JSONL_PATH).splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def _append_jsonl(entry: dict) -> None:
    existing = read_text(JSONL_PATH) if JSONL_PATH.is_file() else ""
    line = json.dumps(entry, ensure_ascii=False) + "\n"
    write_text(JSONL_PATH, existing + line)


def _quota_hint() -> dict:
    if not QUOTA_SNAPSHOT.is_file():
        return {}
    try:
        doc = json.loads(read_text(QUOTA_SNAPSHOT))
    except json.JSONDecodeError:
        return {}
    return {
        "live_spare": doc.get("live_spare"),
        "block_reason": doc.get("block_reason"),
        "snapshot_at": doc.get("generated_at"),
    }


def _render_slice(rows: list[dict]) -> str:
    tail = rows[-SLICE_TAIL:]
    lines = [
        "# DAILY_DOWNLOAD_LATEST_SLICE",
        "",
        f"- total_entries: {len(rows)}",
        f"- slice_tail: {len(tail)}",
        f"- log_ssot: {JSONL_PATH}",
        "",
        "| # | ts | phase | final_status | message |",
        "|---|---|---|---|---|",
    ]
    for i, row in enumerate(tail, start=max(1, len(rows) - len(tail) + 1)):
        msg = str(row.get("message", "")).replace("|", "/")[:120]
        lines.append(
            f"| {i} | {row.get('ts', '')} | {row.get('phase', '')} | "
            f"{row.get('final_status', '')} | {msg} |"
        )
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description="Append daily download dialog task entry (continuity log)")
    ap.add_argument("--message", required=True, help="本次下载任务摘要（必填）")
    ap.add_argument("--task-slug", default="")
    ap.add_argument("--phase", default="")
    ap.add_argument("--final-status", default="REVIEW_REQUIRED")
    ap.add_argument("--parquet-count", type=int, default=None)
    ap.add_argument("--quota-spare", type=int, default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    set_runtime_context(
        task_dir=LOG_DIR,
        task_slug="DAILY_DOWNLOAD_LOG_APPEND",
        task_type="DATA_PIPELINE",
        exemption_paths=[str(RUN), str(LOG_DIR)],
    )

    ts = datetime.now(timezone.utc).isoformat()
    quota = _quota_hint()
    entry = {
        "entry_id": ts.replace(":", "").replace("+", "_"),
        "ts": ts,
        "source": "daily_download_dialog",
        "task_slug": args.task_slug or None,
        "phase": args.phase or None,
        "final_status": args.final_status,
        "message": args.message.strip(),
        "metrics": {
            "parquet_count": args.parquet_count,
            "quota_spare": args.quota_spare if args.quota_spare is not None else quota.get("live_spare"),
            "quota_block_reason": quota.get("block_reason"),
        },
    }

    if args.dry_run:
        print(json.dumps({"dry_run": True, "entry": entry}, ensure_ascii=False, indent=2))
        return OK

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    _append_jsonl(entry)
    rows = _read_jsonl()
    slice_md = _render_slice(rows)
    write_text(SLICE_PATH, slice_md + "\n")

    pointer = slice_md + "\n\n> 完整延续日志（append-only）: `" + str(JSONL_PATH).replace("\\", "/") + "`\n"
    OUTBOX_POINTER.parent.mkdir(parents=True, exist_ok=True)
    write_text(OUTBOX_POINTER, pointer)

    print(json.dumps({"appended": True, "entry_id": entry["entry_id"], "total_entries": len(rows)}, ensure_ascii=False))
    print(f"log_path={JSONL_PATH}")
    print(f"slice_path={SLICE_PATH}")
    return OK


if __name__ == "__main__":
    raise SystemExit(main())
