#!/usr/bin/env python3
"""After R13 seal: antileak triple-align + amend SSOT."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(r"E:\BLACKBOX\任务\BLACKBOX_POST_SEAL_FINANCE_INDEX_AUG_INCREMENT_R13_R1")
OUT = ROOT / "12_ACCEPTANCE"
CURRENT = Path(r"E:\BLACKBOX\数据\清洗成品\CURRENT_CLEANING_RELEASE.json")
SSOT = Path(r"E:\BLACKBOX\规则库\hand_hard_rules\BLACKBOX_HAND_FULL_DATA_UPDATE_SCOPE_R1.json")
ASOF = "2026-08-07"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def now_cn() -> str:
    return datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%dT%H:%M:%S%z")


def wjson(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def main() -> int:
    seal_path = OUT / "R13_SEAL_RESULT.json"
    if not seal_path.exists():
        print(json.dumps({"final_status": "FAILED", "reason": "missing_seal"}, ensure_ascii=False))
        return 2
    seal = json.loads(seal_path.read_text(encoding="utf-8"))
    cur = json.loads(CURRENT.read_text(encoding="utf-8"))
    asof = str(cur.get("cleaning_as_of") or "")
    finance = str(cur.get("finance_asof") or "")
    daily = str(cur.get("daily_asof") or "")
    aligned = asof == ASOF and finance == ASOF and daily == ASOF
    antileak = {
        "generated_at": now_iso(),
        "cleaning_as_of": asof,
        "finance_asof": finance,
        "daily_asof": daily,
        "asof_aligned": aligned,
        "release_id": cur.get("release_id"),
        "overall_pass": aligned and seal.get("CURRENT_switched") is True,
        "notes": ["R13 finance/valuation ingested; asof triple-align 2026-08-07"],
    }
    wjson(OUT / "ANTI_LEAKAGE_R13.json", antileak)
    if not antileak["overall_pass"]:
        print(json.dumps({"final_status": "REVIEW_REQUIRED", "antileak": antileak}, ensure_ascii=False))
        return 1
    ssot = json.loads(SSOT.read_text(encoding="utf-8"))
    entry = {
        "domain": "post_seal_finance_index_aug_increment_r13",
        "completed_at_cn": now_cn(),
        "status": "CURRENT",
        "cutoff": ASOF,
        "phases": {
            "aug_scan": "PASS",
            "price_aug_already_clean": True,
            "index_daily_main7": "NO_GAP",
            "finance_valuation_download": "PASS",
            "cleaning_r13": seal.get("final_status"),
            "anti_leakage": True,
        },
        "cleaning_release_id": seal.get("release_id"),
        "cleaning_seal_id": seal.get("seal_id"),
        "related_user_utterance": "全量检查8月增量含财务和指数，有则下载清洗对齐防穿越",
    }
    completed = [c for c in (ssot.get("completed_domains") or []) if c.get("domain") != entry["domain"]]
    completed.append(entry)
    ssot["completed_domains"] = completed
    ssot["last_amended_at_cn"] = now_cn()
    ssot["last_amended_utterance"] = entry["related_user_utterance"]
    ssot["amendment_note"] = (
        "R13：8月价格已齐；指数主7无缺口；财务/估值增量 asof=2026-08-07 下载并封板；CURRENT 三元组对齐。"
    )
    ssot["anti_leakage_last"] = {
        "overall_pass": True,
        "asof_aligned": True,
        "cleaning_as_of": ASOF,
        "checked_at": now_iso(),
        "source": "R13_ANTILEAK",
    }
    ssot["current_cleaning"] = {
        "release_id": seal.get("release_id"),
        "seal_id": seal.get("seal_id"),
        "cleaning_as_of": ASOF,
        "status": "CURRENT",
    }
    wjson(SSOT, ssot)
    out = {"final_status": "PASS", "release_id": seal.get("release_id"), "antileak": True, "asof": ASOF}
    wjson(OUT / "R13_FINISH_RESULT.json", out)
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
