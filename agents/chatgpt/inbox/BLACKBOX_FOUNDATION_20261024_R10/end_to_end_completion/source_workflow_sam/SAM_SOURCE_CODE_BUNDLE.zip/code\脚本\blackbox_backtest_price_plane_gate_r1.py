# -*- coding: utf-8 -*-
"""
BLACKBOX 回测价格平面硬门 R1。

历史回测四平面必须同为 PRE_PIT（研究 RAW_NONE 须显式标签）。
LIVE_EXECUTION_PRICE_PLANE 必须是 RAW_REAL_PRICE，且不得当作回测成交平面。
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from _base import FAIL, OK, ROOT, write_text  # noqa: E402
from blackbox_backtest_price_plane_r1 import (  # noqa: E402
    BACKTEST_SUBPLANES,
    FORMAL_BACKTEST_PLANE,
    LIVE_PLANE,
    PRODUCT_ID,
    RESEARCH_RAW,
    RULE_ID,
    planes_identical,
)

RULE_JSON = ROOT / "规则库/hand_hard_rules" / f"{RULE_ID}.json"

REQUIRED = [
    "strategy_id",
    "run_id",
    "BACKTEST_PRICE_PLANE",
    "SIGNAL_PRICE_PLANE",
    "BACKTEST_EXECUTION_PRICE_PLANE",
    "BACKTEST_VALUATION_PRICE_PLANE",
    "BACKTEST_PNL_PRICE_PLANE",
    "LIVE_EXECUTION_PRICE_PLANE",
    "signal_adjustment_method",
    "signal_adjustment_anchor",
    "pit_causal",
    "adjust_factor_product_id",
    "adjust_factor_release",
    "adjust_factor_reader",
    "factor_coverage_ratio",
    "missing_factor_count",
    "missing_factor_codes",
    "raw_fallback_used",
    "future_adjustment_used",
    "execution_uses_adjusted_price",
    "mixed_plane_used",
    "PRICE_PLANE_DEFAULT_APPLIED",
]


def _boolish(v: Any) -> bool | None:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        s = v.strip().lower()
        if s in {"true", "yes", "1", "y"}:
            return True
        if s in {"false", "no", "0", "n"}:
            return False
    return None


def _up(v: Any) -> str:
    return str(v or "").strip().upper()


def _labels(data: dict) -> set[str]:
    lab = data.get("labels") or []
    if isinstance(lab, str):
        lab = [lab]
    return {str(x).strip() for x in lab}


def validate_receipt(data: dict) -> tuple[str, list[str]]:
    fails: list[str] = []
    if not isinstance(data, dict):
        return "FAIL", ["receipt_not_object"]

    labels = _labels(data)
    research_raw = "RESEARCH_RAW_NONE_EXPLICIT" in labels or "LEGACY_RAW_NONE_BASELINE" in labels

    for k in REQUIRED:
        if k not in data or data[k] in (None, ""):
            if k == "missing_factor_codes" and data.get("missing_factor_codes") == []:
                continue
            if k in {"factor_coverage_ratio", "missing_factor_count"} and data.get(k) == 0:
                continue
            fails.append(f"missing_field:{k}")

    bt = _up(data.get("BACKTEST_PRICE_PLANE"))
    live = _up(data.get("LIVE_EXECUTION_PRICE_PLANE"))
    for k in BACKTEST_SUBPLANES:
        if _up(data.get(k)) and _up(data.get(k)) != bt and bt:
            fails.append(f"MIXED_PLANE:{k}={data.get(k)} vs BACKTEST_PRICE_PLANE={bt}")

    if not planes_identical(data) and data.get("mixed_plane_used") is not True:
        fails.append("mixed_plane_used_must_be_true_when_subplanes_differ")
    if data.get("mixed_plane_used") is True:
        fails.append("MIXED_PLANE_USED")

    sig = _up(data.get("SIGNAL_PRICE_PLANE"))
    exe = _up(data.get("BACKTEST_EXECUTION_PRICE_PLANE"))
    if sig == "PRE_PIT" and exe in {"RAW_REAL_PRICE", "RAW_NONE", "RAW"}:
        fails.append("PRE_SIGNAL_PLUS_RAW_BACKTEST_FILL")
    if sig in {"RAW_NONE", "RAW_REAL_PRICE", "RAW"} and exe == "PRE_PIT":
        fails.append("RAW_SIGNAL_PLUS_PRE_FILL")

    if live and live != LIVE_PLANE:
        fails.append(f"LIVE_EXECUTION_PRICE_PLANE_MUST_BE_RAW_REAL_PRICE:{live}")
    if bt == LIVE_PLANE:
        fails.append("BACKTEST_PRICE_PLANE_MUST_NOT_BE_LIVE_RAW")
    if exe == LIVE_PLANE:
        fails.append("REVOKED_BACKTEST_EXECUTION_EQUALS_RAW_REAL_PRICE")

    if research_raw:
        if bt != RESEARCH_RAW:
            fails.append("LEGACY_OR_RESEARCH_RAW_NONE_REQUIRES_BACKTEST_PRICE_PLANE=RAW_NONE")
    else:
        if bt and bt != FORMAL_BACKTEST_PLANE:
            fails.append(f"FORMAL_BACKTEST_REQUIRES_PRE_PIT:{bt}")
        if _boolish(data.get("execution_uses_adjusted_price")) is False:
            fails.append("FORMAL_PRE_PIT_REQUIRES_execution_uses_adjusted_price=true")
        if _up(data.get("adjust_factor_product_id")) not in {"", PRODUCT_ID} and bt == FORMAL_BACKTEST_PLANE:
            if _up(data.get("adjust_factor_product_id")) != PRODUCT_ID:
                fails.append("adjust_factor_product_id_must_be_ADJUST_FACTOR_PIT_R1")

    if _boolish(data.get("pit_causal")) is False:
        fails.append("pit_causal_must_be_true")
    if _boolish(data.get("raw_fallback_used")) is True:
        fails.append("SILENT_OR_EXPLICIT_RAW_FALLBACK_FORBIDDEN")
    if _boolish(data.get("future_adjustment_used")) is True:
        fails.append("FUTURE_ADJUSTMENT_USED")
    if _boolish(data.get("silent_factor_eq_1")) is True:
        fails.append("SILENT_FACTOR_EQ_1_FORBIDDEN")

    miss_n = data.get("missing_factor_count")
    if isinstance(miss_n, (int, float)) and miss_n > 0 and bt == FORMAL_BACKTEST_PLANE:
        fails.append("DATA_COVERAGE_FAILURE:missing_factor_count>0")

    cov = data.get("factor_coverage_ratio")
    if isinstance(cov, (int, float)) and cov < 1 and bt == FORMAL_BACKTEST_PLANE and not research_raw:
        fails.append("DATA_COVERAGE_FAILURE:factor_coverage_ratio<1")

    if _up(data.get("BLACKBOX_PRE_PIT_EQ_JQ_PRE")) in {"TRUE", "YES", "CLAIMED", "EQUIVALENT"}:
        fails.append("JQ_EQUIVALENCE_CLAIM_FORBIDDEN")

    status = "PASS" if not fails else "FAIL"
    return status, fails


def regression_cases() -> list[dict]:
    base = {
        "strategy_id": "R26b_SCORE5050_HOLD3_N1",
        "run_id": "TEST",
        "BACKTEST_PRICE_PLANE": "PRE_PIT",
        "SIGNAL_PRICE_PLANE": "PRE_PIT",
        "BACKTEST_EXECUTION_PRICE_PLANE": "PRE_PIT",
        "BACKTEST_VALUATION_PRICE_PLANE": "PRE_PIT",
        "BACKTEST_PNL_PRICE_PLANE": "PRE_PIT",
        "LIVE_EXECUTION_PRICE_PLANE": "RAW_REAL_PRICE",
        "signal_adjustment_method": "PRE_PIT_FACTOR_D_OVER_FACTOR_T",
        "signal_adjustment_anchor": "EACH_HISTORICAL_TRADE_DAY_T",
        "pit_causal": True,
        "adjust_factor_product_id": PRODUCT_ID,
        "adjust_factor_release": "REL_X",
        "adjust_factor_reader": "CACHE_READER_VIA_RESOLVER",
        "factor_coverage_ratio": 1.0,
        "missing_factor_count": 0,
        "missing_factor_codes": [],
        "raw_fallback_used": False,
        "future_adjustment_used": False,
        "execution_uses_adjusted_price": True,
        "mixed_plane_used": False,
        "PRICE_PLANE_DEFAULT_APPLIED": False,
        "silent_factor_eq_1": False,
        "BLACKBOX_PRE_PIT_EQ_JQ_PRE": "NOT_CLAIMED",
    }
    mixed = dict(base)
    mixed["BACKTEST_EXECUTION_PRICE_PLANE"] = "RAW_REAL_PRICE"
    mixed["mixed_plane_used"] = True
    raw_exec = dict(base)
    raw_exec["BACKTEST_EXECUTION_PRICE_PLANE"] = "RAW_REAL_PRICE"
    silent1 = dict(base)
    silent1["silent_factor_eq_1"] = True
    future = dict(base)
    future["future_adjustment_used"] = True
    fallback = dict(base)
    fallback["raw_fallback_used"] = True
    legacy = dict(base)
    legacy["BACKTEST_PRICE_PLANE"] = "RAW_NONE"
    for k in BACKTEST_SUBPLANES:
        legacy[k] = "RAW_NONE"
    legacy["labels"] = ["LEGACY_RAW_NONE_BASELINE", "RESEARCH_RAW_NONE_EXPLICIT"]
    legacy["execution_uses_adjusted_price"] = False
    legacy["adjust_factor_release"] = "N/A_RAW_NONE"
    return [
        {"case_id": "ALL_PRE_PIT", "receipt": base, "expect": "PASS"},
        {"case_id": "MIXED_PRE_RAW", "receipt": mixed, "expect": "FAIL"},
        {"case_id": "REVOKED_RAW_EXEC", "receipt": raw_exec, "expect": "FAIL"},
        {"case_id": "SILENT_FACTOR_1", "receipt": silent1, "expect": "FAIL"},
        {"case_id": "FUTURE_ADJ", "receipt": future, "expect": "FAIL"},
        {"case_id": "RAW_FALLBACK", "receipt": fallback, "expect": "FAIL"},
        {"case_id": "LEGACY_RAW_NONE", "receipt": legacy, "expect": "PASS"},
    ]


def run_self_test() -> dict:
    results = []
    all_ok = True
    for case in regression_cases():
        status, fails = validate_receipt(case["receipt"])
        ok = status == case["expect"]
        if not ok:
            all_ok = False
        results.append(
            {
                "case_id": case["case_id"],
                "expect": case["expect"],
                "got": status,
                "fails": fails,
                "pass": ok,
            }
        )
    return {"all_pass": all_ok, "results": results, "rule_id": RULE_ID}


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Backtest price plane gate R1")
    p.add_argument("--receipt", type=str, default="")
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--write-verdict", type=str, default="")
    p.add_argument("--write-self-test", type=str, default="")
    args = p.parse_args(argv)

    if args.self_test:
        out = run_self_test()
        text = json.dumps(out, ensure_ascii=False, indent=2)
        print(text)
        if args.write_self_test:
            write_text(Path(args.write_self_test), text + "\n")
        return 0 if out["all_pass"] else FAIL

    if not args.receipt:
        print("need --receipt or --self-test")
        return FAIL
    path = Path(args.receipt)
    if not path.exists():
        print("final_status=FAILED marker=BACKTEST_PRICE_PLANE_FAILED reason=missing_receipt")
        return FAIL
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    status, fails = validate_receipt(data if isinstance(data, dict) else {})
    verdict = {
        "rule_id": RULE_ID,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "receipt_path": str(path),
        "pass": status == "PASS",
        "BACKTEST_VALID": status == "PASS",
        "fails": fails,
        "rule_json_present": RULE_JSON.exists(),
    }
    if args.write_verdict:
        write_text(Path(args.write_verdict), json.dumps(verdict, ensure_ascii=False, indent=2) + "\n")
    if status != "PASS":
        print("final_status=FAILED")
        print("marker=BACKTEST_PRICE_PLANE_FAILED")
        print("BACKTEST_VALID=FALSE")
        print("HARD_BLOCK_NO_BACKTEST")
        for f in fails:
            print(f"fail={f}")
        return FAIL
    print("final_status=PASS")
    print("marker=BACKTEST_PRICE_PLANE_OK")
    print("BACKTEST_VALID=TRUE")
    print(f"BACKTEST_PRICE_PLANE={data.get('BACKTEST_PRICE_PLANE')}")
    print(f"LIVE_EXECUTION_PRICE_PLANE={data.get('LIVE_EXECUTION_PRICE_PLANE')}")
    return OK


if __name__ == "__main__":
    sys.exit(main())
