# -*- coding: utf-8 -*-
"""Download ADJUST_FACTOR SOURCE with explicit fq='pre'. New release only. Do not touch P1."""
from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_ADJUST_FACTOR_PIT_R1_FULL_REBUILD_AND_BACKWARD_REFRESH_R1")
STAGING = TASK / "staging" / "source_batches"
STATE = TASK / "staging" / "DOWNLOAD_STATE.json"
P0 = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P0_meta")
P1_LEGACY = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P1_adjust_factor")
START = "2014-01-01"
END = "2026-08-14"
BATCH = 400
FQ = "pre"
YEARS = list(range(2014, 2027))

sys.path.insert(0, str(Path(r"E:\BLACKBOX\脚本")))
from jq_download_base import auth, quota_left  # noqa: E402


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print(f"[{now_cn()}] {msg}", flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def flatten_factor(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=["date", "code", "factor"])
    x = df.copy()
    if isinstance(x.columns, pd.MultiIndex):
        lvl0 = [str(v) for v in x.columns.get_level_values(0).unique()]
        if "factor" in lvl0:
            x = x.xs("factor", axis=1, level=0)
        x = x.stack(future_stack=True).rename("factor").reset_index()
        x.columns = ["date", "code", "factor"]
    else:
        if "factor" not in x.columns:
            raise SystemExit(f"HARD_BLOCK: no factor column {list(x.columns)}")
        if "code" not in x.columns:
            x = x.reset_index()
        if "security" in x.columns and "code" not in x.columns:
            x = x.rename(columns={"security": "code"})
        if "date" not in x.columns:
            if "time" in x.columns:
                x = x.rename(columns={"time": "date"})
            elif "index" in x.columns:
                x = x.rename(columns={"index": "date"})
            else:
                renamed = False
                for c in list(x.columns):
                    if c in ("factor", "code"):
                        continue
                    x = x.rename(columns={c: "date"})
                    renamed = True
                    break
                if not renamed:
                    raise SystemExit(f"HARD_BLOCK: cannot find date col {list(x.columns)}")
    x["date"] = pd.to_datetime(x["date"], errors="coerce").dt.normalize()
    x["code"] = x["code"].astype(str)
    x["factor"] = pd.to_numeric(x["factor"], errors="coerce")
    x = x.dropna(subset=["date", "code", "factor"])
    x = x.loc[np.isfinite(x["factor"].to_numpy())]
    x = x.loc[x["factor"] > 0]
    x = x.loc[x["date"] >= pd.Timestamp("1990-01-01")]
    return x[["date", "code", "factor"]].copy()


def load_universe() -> list[str]:
    codes: set[str] = set()
    for p in sorted(P0.glob("securities_stock__*.parquet")):
        df = pd.read_parquet(p)
        col = "code" if "code" in df.columns else df.columns[0]
        codes.update(df[col].dropna().astype(str).tolist())
    import jqdatasdk as jq

    live = jq.get_all_securities(types=["stock"], date=END)
    if live is not None and len(live):
        codes.update(live.index.astype(str).tolist())
    out = sorted(c for c in codes if c.endswith((".XSHE", ".XSHG")))
    if len(out) < 4000:
        raise SystemExit(f"HARD_BLOCK: universe too small n={len(out)}")
    return out


def year_end(year: int) -> str:
    if year == 2026:
        return END
    return f"{year}-12-31"


def main() -> int:
    if P1_LEGACY.exists():
        log(f"LEGACY_KEEP {P1_LEGACY} tag=LEGACY_ADJUST_FACTOR_SOURCE_CUTOFF_20260612")
    STAGING.mkdir(parents=True, exist_ok=True)
    auth()
    q = quota_left(force=True)
    log(f"quota_spare={q} FULL_HISTORY={START}..{END} fq={FQ!r}")
    if q is not None and q < 50000:
        log("WARN: quota spare low; continue with resume")
    codes = load_universe()
    batches = [codes[i : i + BATCH] for i in range(0, len(codes), BATCH)]
    log(f"universe={len(codes)} batches={len(batches)} years={YEARS[0]}..{YEARS[-1]}")
    wjson(
        TASK / "staging" / "UNIVERSE.json",
        {"n": len(codes), "start": START, "end": END, "fq": FQ, "batch": BATCH, "codes_head": codes[:20]},
    )
    done = 0
    skip = 0
    fail = 0
    import jqdatasdk as jq

    for year in YEARS:
        sd, ed = f"{year}-01-01", year_end(year)
        for bi, batch in enumerate(batches):
            outp = STAGING / f"year={year}" / f"batch_{bi:03d}.parquet"
            meta = outp.with_suffix(".sidecar.json")
            if outp.exists() and meta.exists():
                skip += 1
                continue
            t0 = time.time()
            try:
                raw = jq.get_price(
                    security=batch,
                    start_date=sd,
                    end_date=ed,
                    frequency="daily",
                    fields=["factor"],
                    fq=FQ,
                )
            except Exception as e:
                fail += 1
                log(f"FAIL year={year} batch={bi} err={type(e).__name__}:{e}")
                wjson(STAGING / f"year={year}" / f"batch_{bi:03d}.fail.json", {"error": str(e)})
                continue
            part = flatten_factor(raw)
            outp.parent.mkdir(parents=True, exist_ok=True)
            part.to_parquet(outp, index=False)
            wjson(
                meta,
                {
                    "year": year,
                    "batch": bi,
                    "n_codes_requested": len(batch),
                    "rows": int(len(part)),
                    "n_codes": int(part["code"].nunique()) if len(part) else 0,
                    "date_min": None if part.empty else str(part["date"].min().date()),
                    "date_max": None if part.empty else str(part["date"].max().date()),
                    "fq": FQ,
                    "elapsed_s": round(time.time() - t0, 2),
                },
            )
            done += 1
            if done % 5 == 0 or bi == 0:
                log(f"OK year={year} batch={bi}/{len(batches)-1} rows={len(part)} done={done} skip={skip} fail={fail}")
    state = {
        "done_new": done,
        "skipped": skip,
        "failed": fail,
        "fq": FQ,
        "start": START,
        "end": END,
        "finished_at_cn": now_cn(),
        "quota_spare_end": quota_left(force=True),
    }
    wjson(STATE, state)
    log(f"DOWNLOAD_LOOP_END {state}")
    if fail:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
