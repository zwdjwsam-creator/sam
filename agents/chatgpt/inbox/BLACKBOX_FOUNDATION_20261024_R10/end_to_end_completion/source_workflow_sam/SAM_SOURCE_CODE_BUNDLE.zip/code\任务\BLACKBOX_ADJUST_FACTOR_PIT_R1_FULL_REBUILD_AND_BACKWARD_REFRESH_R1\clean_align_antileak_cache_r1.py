# -*- coding: utf-8 -*-
"""Ingest already-downloaded ADJUST_FACTOR SOURCE into Cleaning + Cache.

Download is complete (2014-01-01..2026-08-14, 3068/3068 days).
This step: CLEAN → ALIGN → ANTI-LOOKAHEAD → year-slice CACHE.
Does not overwrite P1 legacy. Does not rewrite HAND_DECISION.json.
Does not change R26 parameters.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_ADJUST_FACTOR_PIT_R1_FULL_REBUILD_AND_BACKWARD_REFRESH_R1")
SRC_PTR = Path(r"E:\BLACKBOX\数据\原始只读\strategy_data_plane_additions\ADJUST_FACTOR_PRE_FQ_FULL_HISTORY_R1\CURRENT_SOURCE_RELEASE.json")
CLEAN_ROOT = Path(r"E:\BLACKBOX\数据\清洗成品")
CLEAN_PTR = CLEAN_ROOT / "CURRENT_CLEANING_RELEASE.json"
CACHE_ROOT = Path(r"E:\BLACKBOX\数据\回测缓存")
CACHE_PTR = CACHE_ROOT / "CURRENT_CACHE_RELEASE.json"
CAL = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P0_meta\calendar_cn_exchange\calendar_cn_exchange_v2_asof_20260814\CALENDAR_TRADE_DAYS.parquet")
ASOF = pd.Timestamp("2026-08-14")
START = pd.Timestamp("2014-01-01")
PRODUCT = "ADJUST_FACTOR_PIT_R1"


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print(f"[{now_cn()}] {msg}", flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def inherit_tree(src: Path, dst: Path) -> str:
    if not src.exists():
        return "SKIP_MISSING"
    if dst.exists():
        return "EXISTS"
    if src.is_file():
        shutil.copy2(src, dst)
        return "COPYFILE"
    os.system(f'mklink /J "{dst}" "{src}" >NUL 2>&1')
    if dst.exists() and dst.is_dir():
        return "JUNCTION"
    shutil.copytree(src, dst)
    return "COPYTREE"


def hardlink_file(src: Path, dst: Path) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return "EXISTS"
    try:
        os.link(src, dst)
        return "HARDLINK"
    except OSError:
        shutil.copy2(src, dst)
        return "COPY"


def load_source() -> tuple[Path, list[Path], pd.DataFrame]:
    root = Path(json.loads(SRC_PTR.read_text(encoding="utf-8"))["release_root"])
    files = sorted((root / "data").glob("year=*/part_*.parquet"))
    if not files:
        raise SystemExit("HARD_BLOCK: SOURCE year parts missing — download not complete")
    frames = [pd.read_parquet(f) for f in files]
    df = pd.concat(frames, ignore_index=True)
    df["date"] = pd.to_datetime(df["date"]).dt.normalize()
    df["code"] = df["code"].astype(str)
    df["factor"] = pd.to_numeric(df["factor"], errors="coerce")
    return root, files, df


def antileak_qa(df: pd.DataFrame) -> dict:
    cal = pd.read_parquet(CAL)
    dcol = "trade_date" if "trade_date" in cal.columns else "date"
    days = pd.to_datetime(cal[dcol]).dt.normalize()
    expected = sorted({d for d in days if START <= d <= ASOF})
    actual = sorted(set(df["date"].unique()))
    future = [str(d.date()) for d in actual if d > ASOF]
    missing = [str(d.date()) for d in expected if d not in set(actual)]
    extra = [str(d.date()) for d in actual if d not in set(expected)]
    null_c = int(df["factor"].isna().sum())
    nonfinite = int((~np.isfinite(df["factor"].to_numpy())).sum())
    le0 = int((df["factor"] <= 0).sum())
    dup = int(df.duplicated(["code", "date"]).sum())
    after_asof_rows = int((df["date"] > ASOF).sum())
    qa = {
        "asof": str(ASOF.date()),
        "source_min_date": str(df["date"].min().date()),
        "source_max_date": str(df["date"].max().date()),
        "expected_trade_days": len(expected),
        "actual_trade_days": len(actual),
        "missing_trade_days": missing,
        "calendar_extra_dates": extra[:20],
        "future_dates_gt_asof": future,
        "rows_after_asof": after_asof_rows,
        "total_rows": int(len(df)),
        "actual_codes": int(df["code"].nunique()),
        "duplicate_key_count": dup,
        "null_factor_count": null_c,
        "nonfinite_factor_count": nonfinite,
        "factor_le_zero_count": le0,
        "HAS_20260612_CUTOFF": str(df["date"].max().date()) == "2026-06-12",
        "known_at_rule": "date EOD 15:00",
        "formula": "pre(d|T)=raw(d)*factor(d)/factor(T) for d<=T",
        "fq": "pre",
        "raw_fallback_used": False,
        "silent_factor_one_used": False,
    }
    fails = []
    if qa["source_max_date"] != "2026-08-14":
        fails.append("SOURCE_MAX_DATE")
    if qa["HAS_20260612_CUTOFF"]:
        fails.append("STILL_CUTOFF_0612")
    if missing:
        fails.append("MISSING_TRADE_DAYS")
    if future or after_asof_rows:
        fails.append("FUTURE_DATE_LOOKAHEAD")
    if dup or null_c or nonfinite or le0:
        fails.append("FACTOR_SEMANTICS")
    qa["fails"] = fails
    qa["ANTI_LOOKAHEAD_PASS"] = not fails
    qa["ALIGN_PASS"] = not missing and not extra
    return qa


def publish_cleaning(src_files: list[Path], qa: dict) -> dict:
    parent = json.loads(CLEAN_PTR.read_text(encoding="utf-8"))
    parent_root = Path(parent["standard_root"]).parent
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    rid = f"BLACKBOX_FORMAL_CLEANING_R26_ADJFACTOR_PIT_ASOF_20260814_{stamp}"
    seal = f"BLACKBOX_CLEANING_LAYER_SEAL_R26_ADJFACTOR_{stamp}"
    dst = CLEAN_ROOT / "releases" / rid
    std = dst / "standard"
    std.mkdir(parents=True, exist_ok=True)
    inherited = {}
    for child in (parent_root / "standard").iterdir():
        if child.name == "fundamentals":
            continue
        inherited[child.name] = inherit_tree(child, std / child.name)
    fund_src = parent_root / "standard" / "fundamentals"
    fund_dst = std / "fundamentals"
    fund_dst.mkdir(parents=True, exist_ok=True)
    for sub in fund_src.iterdir():
        if sub.name == "adjust_factor":
            continue
        inherited[f"fundamentals/{sub.name}"] = inherit_tree(sub, fund_dst / sub.name)
    adj = fund_dst / "adjust_factor" / "data"
    links = []
    for f in src_files:
        year = f.parent.name
        mode = hardlink_file(f, adj / year / f.name)
        links.append({"src": str(f), "dst": str(adj / year / f.name), "mode": mode})
    pit = {
        "product_id": PRODUCT,
        "known_at": "date EOD",
        "anchor": "SIGNAL_DATE_T",
        "d_le_T": True,
        "asof_cutoff": str(ASOF.date()),
        "formula": "pre(d|T)=raw(d)*factor(d)/factor(T) for d<=T",
        "fq": "pre",
        "forbid": ["silent_factor_eq_1", "raw_fallback", "future_factor_rewrite", "omit_fq", "fq=none"],
        "anti_lookahead_pass": qa["ANTI_LOOKAHEAD_PASS"],
    }
    wjson(fund_dst / "adjust_factor" / "PIT_CONTRACT.json", pit)
    wjson(fund_dst / "adjust_factor" / "COVERAGE.json", qa)
    wjson(fund_dst / "adjust_factor" / "ANTILEAK_QA.json", qa)
    pointer = {
        **parent,
        "release_id": rid,
        "seal_id": seal,
        "sealed": True,
        "cleaning_as_of": str(ASOF.date()),
        "daily_asof": str(ASOF.date()),
        "standard_root": str(std),
        "parent_release_id": parent["release_id"],
        "switch_reason": "ADJUST_FACTOR_FQ_PRE_FULL_HISTORY_CLEAN_ALIGN_ANTILEAK_AFTER_DOWNLOAD",
        "ADJUST_FACTOR_PIT_R1": "READY",
        "created_at_cn": now_cn(),
        "notes": [
            "Inherit R21; replace fundamentals/adjust_factor with fq=pre full history 2014-01-01..2026-08-14",
            "P1 yearly LEGACY_ADJUST_FACTOR_SOURCE_CUTOFF_20260612 not overwritten",
        ],
    }
    wjson(dst / "RELEASE.json", pointer)
    wjson(dst / "SEAL.json", {"seal_id": seal, "anti_lookahead_pass": qa["ANTI_LOOKAHEAD_PASS"], "qa": qa})
    bak = CLEAN_ROOT / f"CURRENT_CLEANING_RELEASE.BACKUP_BEFORE_R26_ADJFACTOR_{stamp}.json"
    shutil.copy2(CLEAN_PTR, bak)
    wjson(CLEAN_PTR, pointer)
    return {"release_id": rid, "seal_id": seal, "standard_root": str(std), "links": len(links), "backup": str(bak), "inherited": inherited}


def publish_cache(src_files: list[Path], qa: dict, cleaning_id: str) -> dict:
    cur = json.loads(CACHE_PTR.read_text(encoding="utf-8"))
    parent = Path(cur["release_root"])
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    rid = f"BLACKBOX_CACHE_R1_ADJFACTOR_PIT_CLEAN_ASOF_20260814_{stamp}"
    dst = CACHE_ROOT / "releases" / rid
    dst.mkdir(parents=True, exist_ok=True)
    inherited = 0
    for child in parent.iterdir():
        if child.name == PRODUCT:
            continue
        if child.is_file():
            shutil.copy2(child, dst / child.name)
            continue
        if not child.is_dir():
            continue
        mode = inherit_tree(child, dst / child.name)
        if mode in ("JUNCTION", "COPYTREE", "EXISTS"):
            inherited += 1
    prod = dst / PRODUCT / "data"
    for f in src_files:
        hardlink_file(f, prod / f.parent.name / f.name)
    wjson(dst / PRODUCT / "COVERAGE.json", {**qa, "product_id": PRODUCT, "cleaning_release_id": cleaning_id})
    wjson(
        dst / PRODUCT / "PIT_CONTRACT.json",
        {
            "product_id": PRODUCT,
            "known_at": "date EOD",
            "anchor": "SIGNAL_DATE_T",
            "formula": "pre(d|T)=raw(d)*factor(d)/factor(T) for d<=T",
            "fq": "pre",
            "cleaning_release_id": cleaning_id,
            "forbid": ["silent_factor_eq_1", "raw_fallback", "future_factor_rewrite"],
        },
    )
    wjson(
        dst / PRODUCT / "LINEAGE.json",
        {
            "product_id": PRODUCT,
            "source_api": "get_price(fields=['factor'], fq='pre')",
            "cleaning_release_id": cleaning_id,
            "full_history_start": "2014-01-01",
            "end": "2026-08-14",
            "legacy_tag": "LEGACY_ADJUST_FACTOR_SOURCE_CUTOFF_20260612",
            "parent_cache": cur["cache_release_id"],
            "pipeline": "SOURCE → CLEAN → ALIGN → ANTILEAK → CACHE_SLICE",
        },
    )
    pointer = {
        **cur,
        "cache_release_id": rid,
        "release_root": str(dst),
        "published_at_cn": now_cn(),
        "parent_release_id": cur["cache_release_id"],
        "source_cleaning_release": cleaning_id,
        "mode": "adjust_factor_pit_clean_align_antileak_slice",
        "anti_lookahead_pass": qa["ANTI_LOOKAHEAD_PASS"],
        "ADJUST_FACTOR_PIT_R1": "READY",
        "asof": str(ASOF.date()),
    }
    wjson(dst / "RELEASE.json", pointer)
    wjson(CACHE_PTR, pointer)
    return {"cache_release_id": rid, "release_root": str(dst), "inherited_n": inherited}


def main() -> int:
    if "--cache-only" in sys.argv:
        _src_root, files, _df = load_source()
        qa = json.loads((TASK / "CLEAN_ANTILEAK_QA.json").read_text(encoding="utf-8"))
        cleaning_id = json.loads(CLEAN_PTR.read_text(encoding="utf-8"))["release_id"]
        cache = publish_cache(files, qa, cleaning_id)
        wjson(TASK / "CACHE_SLICE_PUBLISH.json", cache)
        log(f"cache {cache['cache_release_id']}")
        return 0
    src_root, files, df = load_source()
    log(f"SOURCE ready root={src_root} files={len(files)} rows={len(df)} codes={df['code'].nunique()}")
    qa = antileak_qa(df)
    wjson(TASK / "CLEAN_ANTILEAK_QA.json", qa)
    log(f"QA anti_lookahead={qa['ANTI_LOOKAHEAD_PASS']} fails={qa['fails']}")
    if not qa["ANTI_LOOKAHEAD_PASS"]:
        wjson(TASK / "HARD_BLOCK_CLEAN.json", qa)
        return 2
    cl = publish_cleaning(files, qa)
    wjson(TASK / "CLEANING_PUBLISH.json", {k: cl[k] for k in cl if k != "inherited"})
    log(f"cleaning {cl['release_id']}")
    cache = publish_cache(files, qa, cl["release_id"])
    wjson(TASK / "CACHE_SLICE_PUBLISH.json", cache)
    log(f"cache {cache['cache_release_id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
