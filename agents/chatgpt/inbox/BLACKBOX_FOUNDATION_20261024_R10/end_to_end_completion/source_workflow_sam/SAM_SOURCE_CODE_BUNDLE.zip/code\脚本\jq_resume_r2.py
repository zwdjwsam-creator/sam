# P7 HARD GUARD — inserted by JQ_P7_MINUTE_RELEASE_BLOCKER_REPAIR_R1
# Date: 2026-06-14T18:59:36+00:00
# This script is BLOCKED as a P7 minute download entry.
# Use: guard/jq_p7_minute_guarded_download_entry_r1.py ONLY
#
if __name__ != "__main__":
    raise SystemExit(0)
print("=" * 60)
print("BLOCKED: P7 MINUTE DIRECT ENTRY FORBIDDEN")
print("Use guarded entry: jq_p7_minute_guarded_download_entry_r1.py")
print("This old entrypoint has been blocked.")
print("=" * 60)
raise SystemExit(1)
# END P7 HARD GUARD

# P7 HARD GUARD — inserted by JQ_P7_MINUTE_RELEASE_BLOCKER_REPAIR_R1
# Date: 2026-06-14T18:59:14+00:00
# This script is BLOCKED as a P7 minute download entry.
# Use: guard/jq_p7_minute_guarded_download_entry_r1.py ONLY
#
if __name__ != "__main__":
    raise SystemExit(0)
print("=" * 60)
print("BLOCKED: P7 MINUTE DIRECT ENTRY FORBIDDEN")
print("Use guarded entry: jq_p7_minute_guarded_download_entry_r1.py")
print("This old entrypoint has been blocked.")
print("=" * 60)
raise SystemExit(1)
# END P7 HARD GUARD

"""
JQData 续跑脚本 V4 - 连接安全版
- 子进程下载 + 超时 kill
- 避免连接超限：主进程仅启动时 auth，出错时才重连
- 跳过已存在文件
- 直到 JQData 额度耗尽
"""
import sys, os, time, json, hashlib
from pathlib import Path
from datetime import datetime
sys.stdout.reconfigure(encoding='utf-8')

import pandas as pd
import jqdatasdk as jq
import subprocess, json

DOWNLOAD_BATCH_PY = Path(__file__).parent / "_download_batch.py"

def _subproc_get_price(stocks, start_date, end_date, frequency, timeout=60):
    """子进程下载，Windows 支持 kill"""
    import tempfile
    tmp_parquet = Path(tempfile.gettempdir()) / f"_jq_batch_{os.getpid()}_{int(time.time())}.parquet"
    stock_json = json.dumps(stocks)
    cmd = [
        sys.executable, "-u", str(DOWNLOAD_BATCH_PY),
        stock_json, start_date, end_date, frequency,
        str(tmp_parquet), str(datetime.now().strftime("%Y%m%d_%H%M%S")), "1.0.0",
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)
        tmp_parquet.unlink(missing_ok=True)
        return None  # timeout
    if proc.returncode != 0:
        tmp_parquet.unlink(missing_ok=True)
        return None
    if tmp_parquet.exists() and tmp_parquet.stat().st_size > 200:
        try:
            df = pd.read_parquet(tmp_parquet)
            tmp_parquet.unlink(missing_ok=True)
            return df
        except Exception:
            tmp_parquet.unlink(missing_ok=True)
            return None
    tmp_parquet.unlink(missing_ok=True)
    return None  # empty result

# ─── 配置 ───────────────────────────────────────────────
CRED_FILE = Path(r"E:/BLACKBOX/配置/secrets/已验证/聚宽账号.txt")
ROOT = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw")
BATCH_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
SCHEMA_VERSION = "1.0.0"
_OUT_DIRS = {
    "minute": ROOT / "P7_stock_minute",
    "etf": ROOT / "P8_etf_fund",
    "derivative": ROOT / "P9_derivative_aux",
}
for d in _OUT_DIRS.values():
    d.mkdir(parents=True, exist_ok=True)

# ─── 认证 — 仅启动时调用, 出错时才重连 ──────────────────
_CRED_U = None
_CRED_P = None
def _load_cred():
    global _CRED_U, _CRED_P
    if _CRED_U and _CRED_P:
        return _CRED_U, _CRED_P
    for line in CRED_FILE.read_text(encoding="utf-8").strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        k, v = (line.split("：", 1) if "：" in line else line.split(":", 1) if ":" in line else (None, None))
        if k and v:
            k, v = k.strip(), v.strip()
            if "账号" in k or "user" in k.lower():
                _CRED_U = v
            if "密码" in k or "pass" in k.lower():
                _CRED_P = v
    return _CRED_U, _CRED_P

def auth():
    """轻量认证, 不查额度"""
    u, p = _load_cred()
    jq.auth(u, p)

def init_auth_and_show_quota():
    """启动时认证并显示额度"""
    auth()
    q = jq.get_query_count()
    print(f"[auth] OK. 总量={q['total']}, 剩余={q['spare']}", flush=True)
    return q

# ─── 额度检查 ───────────────────────────────────────────
_QUOTA_CACHE = {"spare": None, "ts": 0}
def quota_left(force=False):
    global _QUOTA_CACHE
    now = time.time()
    if not force and _QUOTA_CACHE["spare"] is not None and now - _QUOTA_CACHE["ts"] < 5:
        return _QUOTA_CACHE["spare"]
    try:
        q = jq.get_query_count()
        spare = q.get("spare", 0)
        _QUOTA_CACHE["spare"] = spare
        _QUOTA_CACHE["ts"] = now
        return spare
    except Exception:
        if _QUOTA_CACHE["spare"] is not None:
            return _QUOTA_CACHE["spare"]
        return 0

# ─── 工具 ───────────────────────────────────────────────
def now_cn():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def save_with_metadata(df, out_path, domain, source_api):
    df.to_parquet(out_path, index=False)
    meta = {
        "file": out_path.name, "domain": domain, "source_api": source_api,
        "batch_id": BATCH_ID, "schema_version": SCHEMA_VERSION,
        "rows": len(df), "columns": list(df.columns), "created_at": now_cn(),
    }
    out_path.with_suffix(".json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return len(df)

def load_stock_list():
    meta_dir = ROOT / "P0_meta"
    sec_files = sorted(meta_dir.glob("securities_stock__*.parquet")) or sorted(meta_dir.glob("securities_*__*.parquet"))
    codes = []
    for sf in sec_files:
        codes.extend(pd.read_parquet(sf)["code"].dropna().unique().tolist())
    stocks = sorted(set(c.strip() for c in codes if c and isinstance(c, str)))
    return [s for s in stocks if s.endswith(("XSHE", "XSHG"))]

# ═══════════════════════════════════════════════════════════
# T7: 分钟线
# ═══════════════════════════════════════════════════════════
SKIP_STOCKS_FILE = ROOT.parent / "_quota_log" / "skip_stocks.json"

def load_skip_stocks():
    if SKIP_STOCKS_FILE.exists():
        return set(json.loads(SKIP_STOCKS_FILE.read_text(encoding="utf-8")))
    return set()

def save_skip_stock(stock):
    skipped = load_skip_stocks()
    skipped.add(stock)
    SKIP_STOCKS_FILE.parent.mkdir(parents=True, exist_ok=True)
    SKIP_STOCKS_FILE.write_text(json.dumps(sorted(skipped), ensure_ascii=False, indent=2), encoding="utf-8")

def run_t7():
    print(f"\n[{now_cn()}] {'='*50}", flush=True)
    print(f"[{now_cn()}] T7: 分钟线", flush=True)
    print(f"[{now_cn()}] {'='*50}", flush=True)

    all_stocks = load_stock_list()[:200]
    skip_stocks = load_skip_stocks()
    print(f"  股票: {len(all_stocks)}, 已跳过: {len(skip_stocks)}", flush=True)

    out_dir = _OUT_DIRS["minute"]
    total_rows = total_q = 0

    for freq in ["1m", "30m", "60m"]:
        print(f"\n[{now_cn()}] 频率: {freq}", flush=True)
        for year in range(2014, 2027):
            if quota_left() <= 0:
                print(f"  [{now_cn()}] 额度耗尽, 退出 {freq}", flush=True)
                break
            year_str = str(year)
            ye = f"{year_str}-12-31" if year < 2026 else "2026-06-12"

            batches = [all_stocks[i:i+5] for i in range(0, len(all_stocks), 5)]
            for bidx, stock_batch in enumerate(batches):
                if quota_left() <= 0:
                    break

                # 跳过包含已屏蔽股票的批次（改逐只跳过）
                filtered = [s for s in stock_batch if s not in skip_stocks]
                if not filtered:
                    continue
                if len(filtered) < len(stock_batch):
                    # 有屏蔽股票, 逐只下载
                    for singlestock in filtered:
                        if quota_left() <= 0:
                            break
                        sname = f"stock_minute_{freq}__{year_str}__{singlestock}__{SCHEMA_VERSION}__{BATCH_ID}.parquet"
                        s_out = out_dir / sname
                        if list(out_dir.glob(f"stock_minute_{freq}__{year_str}__{singlestock}__{SCHEMA_VERSION}__*.parquet")):
                            continue
                        t1 = time.time()
                        sdf = _subproc_get_price([singlestock], start_date=f"{year_str}-01-01", end_date=ye, frequency=freq, timeout=60)
                        if sdf is not None and len(sdf) > 0:
                            save_with_metadata(sdf, s_out, "P7.stock_minute", f"get_price.{freq}")
                            total_rows += len(sdf)
                            total_q += 1
                            if total_q % 10 == 0:
                                print(f"  {freq} {year_str} {singlestock}: {len(sdf)}行 (逐只, 累计{total_q}, 剩余额={quota_left()})", flush=True)
                        elif sdf is None:
                            print(f"  [跳过] {freq} {year_str} {singlestock}: 超时", flush=True)
                            save_skip_stock(singlestock)
                            skip_stocks.add(singlestock)
                    continue

                batch_label = f"batch{bidx:04d}"
                if list(out_dir.glob(f"stock_minute_{freq}__{year_str}__{batch_label}__{SCHEMA_VERSION}__*.parquet")):
                    continue  # already exists

                t0 = time.time()
                df = _subproc_get_price(filtered, start_date=f"{year_str}-01-01", end_date=ye, frequency=freq)
                elapsed = time.time() - t0
                if df is not None and len(df) > 0:
                    fname = f"stock_minute_{freq}__{year_str}__{batch_label}__{SCHEMA_VERSION}__{BATCH_ID}.parquet"
                    save_with_metadata(df, out_dir / fname, "P7.stock_minute", f"get_price.{freq}")
                    total_rows += len(df)
                    total_q += 1
                    print(f"  {freq} {year_str} {batch_label}: {len(df)}行, {elapsed:.1f}s (剩余额={quota_left(force=True)})", flush=True)
                elif df is None:
                    # 批次超时, 重试一次
                    print(f"  {freq} {year_str} {batch_label}: 超时, 重试...", flush=True)
                    t0 = time.time()
                    df2 = _subproc_get_price(filtered, start_date=f"{year_str}-01-01", end_date=ye, frequency=freq, timeout=60)
                    elapsed = time.time() - t0
                    if df2 is not None and len(df2) > 0:
                        fname = f"stock_minute_{freq}__{year_str}__{batch_label}__{SCHEMA_VERSION}__{BATCH_ID}.parquet"
                        save_with_metadata(df2, out_dir / fname, "P7.stock_minute", f"get_price.{freq}")
                        total_rows += len(df2)
                        total_q += 1
                        print(f"  {freq} {year_str} {batch_label}: {len(df2)}行 (重试), {elapsed:.1f}s", flush=True)
                    else:
                        # 批次仍失败, 逐只尝试并屏蔽挂起股票
                        print(f"  {freq} {year_str} {batch_label}: 批次失败, 逐只...", flush=True)
                        for singlestock in filtered:
                            if quota_left() <= 0:
                                break
                            sname = f"stock_minute_{freq}__{year_str}__{singlestock}__{SCHEMA_VERSION}__{BATCH_ID}.parquet"
                            s_out = out_dir / sname
                            if list(out_dir.glob(f"stock_minute_{freq}__{year_str}__{singlestock}__{SCHEMA_VERSION}__*.parquet")):
                                continue
                            t1 = time.time()
                            sdf = _subproc_get_price([singlestock], start_date=f"{year_str}-01-01", end_date=ye, frequency=freq, timeout=60)
                            if sdf is not None and len(sdf) > 0:
                                save_with_metadata(sdf, s_out, "P7.stock_minute", f"get_price.{freq}")
                                total_rows += len(sdf)
                                total_q += 1
                                print(f"    {freq} {year_str} {singlestock}: {len(sdf)}行, {time.time()-t1:.1f}s", flush=True)
                            elif sdf is None:
                                print(f"    [跳过] {freq} {year_str} {singlestock}: 超时", flush=True)
                                save_skip_stock(singlestock)
                                skip_stocks.add(singlestock)

        if quota_left() <= 0:
            break

    skip_stocks = load_skip_stocks()
    print(f"\n[{now_cn()}] T7 完成. 新增 {total_q} 文件, {total_rows} 行", flush=True)
    print(f"  跳过股票 ({len(skip_stocks)}): {sorted(skip_stocks)[:20]}...", flush=True)
    return total_q, total_rows


# ═══════════════════════════════════════════════════════════
# T8: ETF / 基金
# ═══════════════════════════════════════════════════════════
def run_t8():
    print(f"\n[{now_cn()}] {'='*50}", flush=True)
    print(f"[{now_cn()}] T8: ETF / 基金", flush=True)
    print(f"[{now_cn()}] {'='*50}", flush=True)
    out_dir = _OUT_DIRS["etf"]
    total_rows = total_q = 0

    # ETF 日线
    if quota_left() > 0:
        print(f"\n[{now_cn()}] T8a: ETF 日线", flush=True)
        df_etf_list = _subproc_get_price(["000001.XSHE"], "2014-01-01", "2014-01-02", "daily", timeout=30)
        # Use direct API via subprocess for ETF list
        from subprocess import check_output
        list_script = (
            "import sys,json; sys.stdout.reconfigure(encoding='utf-8'); "
            "import jqdatasdk as jq; "
            "jq.auth('" + _CRED_U + "','" + _CRED_P + "'); "
            "df=jq.get_all_securities('etf'); "
            "codes=list(df.index); "
            "codes=[c for c in codes if c.endswith(('XSHE','XSHG'))]; "
            "print(json.dumps(codes[:500]))"
        )
        try:
            result = check_output([sys.executable, "-c", list_script], timeout=30, text=True)
            etf_codes = json.loads(result.strip().split("\n")[-1])
            print(f"  ETF 数量: {len(etf_codes)}", flush=True)
            etf_batches = [etf_codes[i:i+50] for i in range(0, len(etf_codes), 50)]
            for bidx, batch in enumerate(etf_batches):
                if quota_left() <= 0:
                    break
                batch_label = f"batch{bidx:04d}"
                pattern = f"etf_daily__full__{batch_label}__{SCHEMA_VERSION}__*.parquet"
                if list(out_dir.glob(pattern)):
                    continue
                # Use subproc for ETF daily data
                df = _subproc_get_price(batch, "2014-01-01", "2026-06-12", "daily", timeout=60)
                if df is not None and len(df) > 0:
                    fname = f"etf_daily__full__{batch_label}__{SCHEMA_VERSION}__{BATCH_ID}.parquet"
                    save_with_metadata(df, out_dir / fname, "P8.etf", "get_price.etf")
                    total_rows += len(df); total_q += 1
                    print(f"  ETF {batch_label}: {len(df)}行 (剩余额={quota_left(force=True)})", flush=True)
        except Exception as e:
            print(f"  ETF list error: {str(e)[:80]}", flush=True)

    print(f"\n[{now_cn()}] T8 完成. 新增 {total_q} 文件, {total_rows} 行", flush=True)
    return total_q, total_rows


# ═══════════════════════════════════════════════════════════
# T9: 衍生辅助 (指数分钟线 + MTSS 融资融券)
# ═══════════════════════════════════════════════════════════
def run_t9():
    print(f"\n[{now_cn()}] {'='*50}", flush=True)
    print(f"[{now_cn()}] T9: 衍生辅助", flush=True)
    print(f"[{now_cn()}] {'='*50}", flush=True)
    out_dir = _OUT_DIRS["derivative"]
    total_rows = total_q = 0

    # 指数分钟线
    indices = ["000001.XSHG", "000300.XSHG", "000016.XSHG", "000905.XSHG", "000688.XSHG"]
    for freq in ["5m", "1m", "30m", "60m"]:
        if quota_left() <= 0:
            break
        pattern = f"index_minute_{freq}__full__{SCHEMA_VERSION}__*.parquet"
        existing = list(out_dir.glob(pattern))
        if existing:
            print(f"  指数 {freq} 已存在, 跳过", flush=True)
            total_rows += pd.read_parquet(existing[0]).shape[0] if existing[0].stat().st_size > 100 else 0
            continue
        t0 = time.time()
        df = _subproc_get_price(indices, "2014-01-01", "2026-06-12", freq, timeout=120)
        if df is not None and len(df) > 0:
            fname = f"index_minute_{freq}__full__{SCHEMA_VERSION}__{BATCH_ID}.parquet"
            save_with_metadata(df, out_dir / fname, "P9.index_minute", f"get_price.index.{freq}")
            total_rows += len(df); total_q += 1
            print(f"  指数 {freq}: {len(df)}行, {time.time()-t0:.1f}s (剩余额={quota_left(force=True)})", flush=True)

    # MTSS 融资融券 (样本50只)
    if quota_left() > 0:
        print(f"\n[{now_cn()}] T9b: 融资融券 (样本50只)", flush=True)
        stock_sample = load_stock_list()[:50]
        try:
            all_mtss = []
            for stock in stock_sample:
                if quota_left() <= 0:
                    break
                # 用子进程下载单只股票 MTSS
                mtss_script = (
                    "import sys,json; sys.stdout.reconfigure(encoding='utf-8'); "
                    "import jqdatasdk as jq; "
                    "jq.auth('" + _CRED_U + "','" + _CRED_P + "'); "
                    "df=jq.get_mtss('" + stock + "','2014-01-01','2026-06-12'); "
                    "if df is not None and len(df)>0: print(df.to_json(orient='records',force_ascii=False))"
                )
                try:
                    result = subprocess.check_output([sys.executable, "-c", mtss_script], timeout=60, text=True)
                    lines = result.strip().split("\n")
                    for line in lines:
                        if line.startswith("["):
                            import json as _j
                            data = _j.loads(line)
                            if data:
                                import pandas as _pd
                                all_mtss.append(_pd.DataFrame(data))
                            break
                except Exception:
                    pass
            if all_mtss:
                df = pd.concat(all_mtss)
                fname = f"mtss__sample50__full__{SCHEMA_VERSION}__{BATCH_ID}.parquet"
                save_with_metadata(df, out_dir / fname, "P9.mtss", "get_mtss")
                total_rows += len(df); total_q += 1
                print(f"  MTSS: {len(df)}行", flush=True)
        except Exception as e:
            print(f"  MTSS error: {str(e)[:80]}", flush=True)

    print(f"\n[{now_cn()}] T9 完成. 新增 {total_q} 文件, {total_rows} 行", flush=True)
    return total_q, total_rows


# ═══════════════════════════════════════════════════════════
# 主流程
# ═══════════════════════════════════════════════════════════
def main():
    print(f"{'#'*60}", flush=True)
    print(f"# JQData 续跑 V4 - 全量模式 (T7+T8+T9)", flush=True)
    print(f"# 开始: {now_cn()}", flush=True)
    print(f"{'#'*60}\n", flush=True)

    q0 = init_auth_and_show_quota()
    total_q_all = total_rows_all = 0

    for stage_name, stage_fn in [("T7", run_t7), ("T8", run_t8), ("T9", run_t9)]:
        if quota_left() <= 0:
            print(f"\n[{now_cn()}] 额度耗尽, 跳过 {stage_name}", flush=True)
            break
        try:
            q, r = stage_fn()
            total_q_all += q; total_rows_all += r
        except Exception as e:
            print(f"\n[错误] {stage_name}: {str(e)[:200]}", flush=True)

    # 最终额度
    try:
        auth()
        qf = jq.get_query_count()
    except:
        qf = {"spare": "?"}
    print(f"\n{'='*60}", flush=True)
    print(f"# 完成. 新增 {total_q_all} 文件, {total_rows_all} 行", flush=True)
    print(f"# 初始={q0['spare']}, 最终={qf.get('spare','?')}", flush=True)
    print(f"{'='*60}", flush=True)

if __name__ == "__main__":
    main()
