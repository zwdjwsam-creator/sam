# -*- coding: utf-8 -*-
"""Seal SOURCE, validate coverage/golden, publish ADJUST_FACTOR_PIT_R1. Do not overwrite P1."""
from __future__ import annotations

import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_ADJUST_FACTOR_PIT_R1_FULL_REBUILD_AND_BACKWARD_REFRESH_R1")
STAGING = TASK / "staging" / "source_batches"
CAL = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P0_meta\calendar_cn_exchange\calendar_cn_exchange_v2_asof_20260814\CALENDAR_TRADE_DAYS.parquet")
CACHE_ROOT = Path(r"E:\BLACKBOX\数据\回测缓存")
POINTER = CACHE_ROOT / "CURRENT_CACHE_RELEASE.json"
CATALOG = CACHE_ROOT / "registry" / "CACHE_PRODUCT_CATALOG.csv"
ADDITIONS = Path(r"E:\BLACKBOX\数据\原始只读\strategy_data_plane_additions\ADJUST_FACTOR_PRE_FQ_FULL_HISTORY_R1")
START = pd.Timestamp("2014-01-01")
END = pd.Timestamp("2026-08-14")
PRODUCT = "ADJUST_FACTOR_PIT_R1"
sys.path.insert(0, r"E:\BLACKBOX\脚本")
from jq_download_base import auth  # noqa: E402


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print(f"[{now_cn()}] {msg}", flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def inherit_tree(src: Path, dst: Path) -> str:
    if not src.exists():
        return "SKIP_MISSING"
    if dst.exists():
        return "EXISTS"
    if src.is_file():
        shutil.copy2(src, dst)
        return "COPYFILE"
    os.system(f'mklink /J "{dst}" "{src}" >NUL 2>&1')
    if dst.exists() and dst.is_dir():
        return "JUNCTION"
    shutil.copytree(src, dst)
    return "COPYTREE"


def concat_source() -> pd.DataFrame:
    files = sorted(STAGING.glob("year=*/batch_*.parquet"))
    if not files:
        raise SystemExit("HARD_BLOCK: no staging batches")
    frames = []
    for f in files:
        df = pd.read_parquet(f)
        if df.empty:
            continue
        frames.append(df)
    out = pd.concat(frames, ignore_index=True)
    out["date"] = pd.to_datetime(out["date"]).dt.normalize()
    out["code"] = out["code"].astype(str)
    out["factor"] = pd.to_numeric(out["factor"], errors="coerce")
    out = out.dropna(subset=["date", "code", "factor"])
    out = out.loc[np.isfinite(out["factor"].to_numpy())]
    out = out.loc[out["factor"] > 0]
    out = out.sort_values(["code", "date"]).drop_duplicates(["code", "date"], keep="last")
    log(f"concat rows={len(out)} codes={out['code'].nunique()} files={len(files)}")
    return out


def coverage(df: pd.DataFrame) -> dict:
    cal = pd.read_parquet(CAL)
    dcol = "trade_date" if "trade_date" in cal.columns else ("date" if "date" in cal.columns else cal.columns[0])
    days = pd.to_datetime(cal[dcol]).dt.normalize()
    expected = sorted({d for d in days if START <= d <= END})
    actual = sorted(set(df["date"].unique()))
    missing = [str(d.date()) for d in expected if d not in set(actual)]
    per_date = df.groupby("date")["code"].nunique()
    null_c = int(df["factor"].isna().sum())
    nonfinite = int((~np.isfinite(df["factor"].to_numpy())).sum())
    le0 = int((df["factor"] <= 0).sum())
    dup = int(df.duplicated(["code", "date"]).sum())
    cutoff_0612 = str(df["date"].max().date()) == "2026-06-12"
    return {
        "source_min_date": str(df["date"].min().date()),
        "source_max_date": str(df["date"].max().date()),
        "SOURCE_MAX_DATE": str(df["date"].max().date()),
        "expected_trade_days": len(expected),
        "actual_trade_days": len(actual),
        "missing_trade_days": missing,
        "n_missing_trade_days": len(missing),
        "expected_codes": "UNIVERSE_LISTED_VARIABLE",
        "actual_codes": int(df["code"].nunique()),
        "total_rows": int(len(df)),
        "per_date_code_count_min": int(per_date.min()),
        "per_date_code_count_max": int(per_date.max()),
        "per_date_code_count_on_end": int(per_date.get(END, 0)),
        "per_code_date_count_min": int(df.groupby("code")["date"].nunique().min()),
        "per_code_date_count_max": int(df.groupby("code")["date"].nunique().max()),
        "duplicate_key_count": dup,
        "null_factor_count": null_c,
        "nonfinite_factor_count": nonfinite,
        "factor_le_zero_count": le0,
        "HAS_20260612_CUTOFF": cutoff_0612,
        "HAS_20260814": bool(END in set(actual)),
        "HAS_20260617": bool(pd.Timestamp("2026-06-17") in set(actual)),
    }


def golden_live(df: pd.DataFrame) -> dict:
    import jqdatasdk as jq

    auth()
    cases = [
        {"code": "001230.XSHE", "T": "2026-08-11", "d": "2026-05-12", "expect_raw": 28.70, "expect_pre": 20.21},
        {"code": "600351.XSHG", "T": "2026-08-13", "d": "2026-04-30", "expect_raw": 7.08, "expect_pre": 6.91},
        {"code": "000001.XSHE", "T": "2026-08-11", "d": "2026-05-12", "expect_raw": 11.25, "expect_pre": 10.89},
    ]
    out = []
    for c in cases:
        code, T, d = c["code"], c["T"], c["d"]
        raw = jq.get_price(security=code, start_date=d, end_date=T, frequency="daily", fields=["open", "close"], fq="none")
        pre = jq.get_price(security=code, start_date=d, end_date=T, frequency="daily", fields=["open", "close", "factor"], fq="pre")

        def _norm(frame: pd.DataFrame) -> pd.DataFrame:
            x = frame.copy()
            if "time" in x.columns:
                x = x.rename(columns={"time": "date"})
            if "date" not in x.columns:
                x = x.reset_index()
                x = x.rename(columns={x.columns[0]: "date"})
            x["date"] = pd.to_datetime(x["date"]).dt.normalize()
            return x

        raw = _norm(raw)
        pre = _norm(pre)
        loc = df.loc[df["code"] == code, ["date", "factor"]]
        def row(frame, ds, col):
            sub = frame.loc[pd.to_datetime(frame["date"]).dt.normalize() == pd.Timestamp(ds)]
            return None if sub.empty else float(sub.iloc[-1][col])
        rec = {
            "code": code,
            "T": T,
            "d": d,
            "jq_raw_close_d": row(raw, d, "close"),
            "jq_pre_close_d": row(pre, d, "close"),
            "jq_pre_factor_d": row(pre, d, "factor"),
            "jq_pre_factor_T": row(pre, T, "factor"),
            "local_factor_d": row(loc, d, "factor"),
            "local_factor_T": row(loc, T, "factor"),
        }
        if rec["jq_raw_close_d"] is not None and rec["local_factor_d"] and rec["local_factor_T"]:
            rec["reconstructed_pre"] = rec["jq_raw_close_d"] * rec["local_factor_d"] / rec["local_factor_T"]
            rec["abs_err"] = abs(rec["reconstructed_pre"] - rec["jq_pre_close_d"]) if rec["jq_pre_close_d"] is not None else None
            rec["match_1fen"] = rec["abs_err"] is not None and rec["abs_err"] < 0.01
        else:
            rec["reconstructed_pre"] = None
            rec["match_1fen"] = False
        rec["factor_matches_jq"] = (
            rec["local_factor_d"] is not None
            and rec["jq_pre_factor_d"] is not None
            and abs(rec["local_factor_d"] - rec["jq_pre_factor_d"]) < 1e-8
        )
        out.append(rec)
    return {"cases": out, "all_pass": all(x.get("match_1fen") and x.get("factor_matches_jq") for x in out)}


def write_year_parts(df: pd.DataFrame, dest: Path) -> list[str]:
    dest.mkdir(parents=True, exist_ok=True)
    paths = []
    df = df.copy()
    df["year"] = df["date"].dt.year
    for y, g in df.groupby("year"):
        p = dest / f"year={int(y)}" / f"part_{int(y)}.parquet"
        p.parent.mkdir(parents=True, exist_ok=True)
        gg = g.drop(columns=["year"]).sort_values(["code", "date"])
        gg.to_parquet(p, index=False)
        paths.append(str(p))
        log(f"write {p.name} rows={len(gg)}")
    return paths


def publish_cache(df: pd.DataFrame, cov: dict) -> dict:
    cur = json.loads(POINTER.read_text(encoding="utf-8"))
    parent = Path(cur["release_root"])
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    rid = f"BLACKBOX_CACHE_R1_ADJFACTOR_PIT_ASOF_20260814_{ts}"
    rel = CACHE_ROOT / "releases" / rid
    rel.mkdir(parents=True, exist_ok=True)
    inherited = {}
    for child in parent.iterdir():
        if child.name.startswith("."):
            continue
        if child.is_dir():
            inherited[child.name] = inherit_tree(child, rel / child.name)
        elif child.suffix in (".json", ".md", ".txt"):
            shutil.copy2(child, rel / child.name)
    prod = rel / PRODUCT
    if prod.exists():
        shutil.rmtree(prod)
    write_year_parts(df, prod / "data")
    wjson(
        prod / "COVERAGE.json",
        {
            "product_id": PRODUCT,
            "min_date": cov["source_min_date"],
            "max_date": cov["source_max_date"],
            "row_count": cov["total_rows"],
            "formal_freshness": "2026-08-14",
            "coverage_mode": "DATA_READY_FULL_HISTORY",
            "fq": "pre",
            "formula": "pre(d|T)=raw(d)*factor(d)/factor(T)",
            **{k: cov[k] for k in ("expected_trade_days", "actual_trade_days", "n_missing_trade_days", "actual_codes")},
        },
    )
    wjson(
        prod / "PIT_CONTRACT.json",
        {
            "product_id": PRODUCT,
            "known_at": "date EOD",
            "anchor": "SIGNAL_DATE_T",
            "formula": "pre(d|T)=raw(d)*factor(d)/factor(T) for d<=T",
            "fq": "pre",
            "forbid": ["silent_factor_eq_1", "raw_fallback", "future_factor_rewrite", "omit_fq"],
        },
    )
    wjson(
        prod / "LINEAGE.json",
        {
            "product_id": PRODUCT,
            "source_api": "get_price(fields=['factor'], fq='pre')",
            "full_history_start": "2014-01-01",
            "end": "2026-08-14",
            "legacy_not_overwritten": str(Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P1_adjust_factor")),
            "legacy_tag": "LEGACY_ADJUST_FACTOR_SOURCE_CUTOFF_20260612",
            "parent_cache": cur["cache_release_id"],
        },
    )
    cat = CATALOG.read_text(encoding="utf-8")
    line = "ADJUST_FACTOR_PIT_R1,L1,STOCK,ACTIVE,year/asof_date,PIT adjust factor fq=pre for PRE_PIT reconstruction\n"
    if "ADJUST_FACTOR_PIT_R1" not in cat:
        CATALOG.write_text(cat.rstrip() + "\n" + line, encoding="utf-8")
    pointer = {
        **cur,
        "cache_release_id": rid,
        "release_root": str(rel),
        "published_at_cn": now_cn(),
        "parent_release_id": cur["cache_release_id"],
        "mode": "adjust_factor_pit_full_rebuild",
        "ADJUST_FACTOR_PIT_R1": "READY",
        "asof": "2026-08-14",
        "notes": list(cur.get("notes") or []) + ["ADD ADJUST_FACTOR_PIT_R1 fq=pre full history 2014-01-01..2026-08-14; P1 yearly not overwritten"],
    }
    wjson(POINTER, pointer)
    wjson(rel / "RELEASE.json", pointer)
    return {"cache_release_id": rid, "release_root": str(rel), "inherited_n": len(inherited)}


def load_or_concat() -> pd.DataFrame:
    ptr = ADDITIONS / "CURRENT_SOURCE_RELEASE.json"
    if ptr.exists():
        root = Path(json.loads(ptr.read_text(encoding="utf-8"))["release_root"])
        files = sorted((root / "data").glob("year=*/part_*.parquet"))
        if files:
            frames = [pd.read_parquet(f) for f in files]
            out = pd.concat(frames, ignore_index=True)
            out["date"] = pd.to_datetime(out["date"]).dt.normalize()
            log(f"reload source rows={len(out)} from {root}")
            return out
    return concat_source()


def main() -> int:
    df = load_or_concat()
    cov = coverage(df)
    wjson(TASK / "SOURCE_COVERAGE.json", cov)
    log(f"coverage max={cov['SOURCE_MAX_DATE']} missing={cov['n_missing_trade_days']} cutoff0612={cov['HAS_20260612_CUTOFF']}")
    hard = []
    if cov["SOURCE_MAX_DATE"] != "2026-08-14":
        hard.append("SOURCE_MAX_DATE")
    if cov["HAS_20260612_CUTOFF"]:
        hard.append("STILL_CUTOFF_0612")
    if cov["n_missing_trade_days"]:
        hard.append("MISSING_TRADE_DAYS")
    if cov["duplicate_key_count"] or cov["null_factor_count"] or cov["factor_le_zero_count"]:
        hard.append("FACTOR_SEMANTICS")
    if not cov["HAS_20260617"]:
        hard.append("MISSING_20260617")
    src_ptr = ADDITIONS / "CURRENT_SOURCE_RELEASE.json"
    if src_ptr.exists():
        src_rel = Path(json.loads(src_ptr.read_text(encoding="utf-8"))["release_root"])
        log(f"reuse source release {src_rel}")
    else:
        src_rel = ADDITIONS / f"REL_ASOF_20260814_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        write_year_parts(df, src_rel / "data")
        wjson(src_rel / "COVERAGE.json", cov)
        wjson(src_ptr, {"release_root": str(src_rel), "legacy_tag": "LEGACY_ADJUST_FACTOR_SOURCE_CUTOFF_20260612"})
    gold = golden_live(df)
    wjson(TASK / "GOLDEN_RECONSTRUCTION.json", gold)
    log(f"golden all_pass={gold['all_pass']}")
    if not gold["all_pass"]:
        hard.append("GOLDEN_RECONSTRUCTION")
    if hard:
        wjson(TASK / "HARD_BLOCK.json", {"hard": hard, "coverage": cov, "golden": gold})
        log(f"HARD_BLOCK {hard}")
        return 2
    pub = publish_cache(df, cov)
    wjson(TASK / "CACHE_PUBLISH.json", pub)
    log(f"published {pub['cache_release_id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
