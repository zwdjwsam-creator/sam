#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BLACKBOX Master Research Autorun Charter R1.

TRIGGER(研究策略) → WAIT_TERMINAL → DATA/AUTHORITY/PIT GATE → RESEARCH → DRIFT_AUDIT
ORDER_ALLOWED=FALSE
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
CN = timezone(timedelta(hours=8))
TASK = ROOT / "任务" / "BLACKBOX_MASTER_RESEARCH_AUTORUN_CHARTER_R1"
OUT_CUR = ROOT / "研究系统" / "CURRENT" / "MASTER_RESEARCH"
OUT_DAILY = ROOT / "研究系统" / "DAILY" / "MASTER_RESEARCH"
CURRENT = ROOT / "运行" / "BLACKBOX_MASTER_RESEARCH_AUTORUN_CHARTER_CURRENT.json"
CANONICAL_MANIFEST_PATH = ROOT / "研究系统" / "数据平面" / "CURRENT" / "DAILY_DATA_MANIFEST_CURRENT.json"
# Canonical JSONPaths (Data Plane publish_current / build_manifest — no aliases):
#   $.manifest_id
#   $.DAILY_INCREMENTAL_READY
#   $.JQ.STATUS
#   $.JQ.SOURCE_ASOF
#   $.JQ.CLEAN_ASOF
#   $.JQ.CACHE_ASOF
# BATCH2 — Shadow Candidate reserved paths (do not write unless --publish-candidate)
CANDIDATE_DIR = OUT_CUR / "CANDIDATE"
CANDIDATE_JSON_PATH = CANDIDATE_DIR / "U235_SHADOW_MAIN_RESEARCH_CURRENT.json"
CANDIDATE_TXT_PATH = CANDIDATE_DIR / "U235_SHADOW_MAIN_RESEARCH_CURRENT.txt"
# BATCH7 — append-only run layout (U235 sole writer)
CANDIDATE_RUNS_DIR = CANDIDATE_DIR / "RUNS"
CANDIDATE_CURRENT_POINTER = CANDIDATE_DIR / "CURRENT.json"
CANDIDATE_STAGING_DIR = CANDIDATE_DIR / ".staging"
FREEZE_R2_CANONICAL_PATH = ROOT / "研究系统" / "BLACKBOX_MASTER_RESEARCH_OS_FREEZE_R2.md"
R3_STRUCTURED_ARTIFACT_PATH = ROOT / "运行" / "BLACKBOX_GLOBAL_LEADERSHIP_FIRST_MAPPING_R3_CURRENT.json"
# Consumer-side optional capital product CURRENT pointers (absent → INCOMPLETE)
CAPITAL_PRODUCT_CANDIDATE_PATHS: dict[str, list[Path]] = {
    "CYCLE_CAPITAL_STATE": [
        ROOT / "运行" / "BLACKBOX_CYCLE_CAPITAL_STATE_CURRENT.json",
        ROOT / "研究系统" / "CURRENT" / "CYCLE_CAPITAL_STATE_CURRENT.json",
        OUT_CUR / "CANDIDATE" / "INPUTS" / "CYCLE_CAPITAL_STATE_PROXY_CURRENT.json",
    ],
    "CURRENT_CAPITAL_ACCEPTANCE": [
        ROOT / "运行" / "BLACKBOX_CURRENT_CAPITAL_ACCEPTANCE_CURRENT.json",
        ROOT / "研究系统" / "CURRENT" / "CURRENT_CAPITAL_ACCEPTANCE_CURRENT.json",
        OUT_CUR / "CANDIDATE" / "INPUTS" / "CURRENT_CAPITAL_ACCEPTANCE_PROXY_CURRENT.json",
    ],
    "MINUTE_ACCEPTANCE_STRENGTH": [
        ROOT / "运行" / "BLACKBOX_MINUTE_ACCEPTANCE_STRENGTH_CURRENT.json",
        ROOT / "研究系统" / "CURRENT" / "MINUTE_ACCEPTANCE_STRENGTH_CURRENT.json",
        OUT_CUR / "CANDIDATE" / "INPUTS" / "MINUTE_ACCEPTANCE_STRENGTH_PROXY_CURRENT.json",
    ],
}
ENTRY_GENERAL_CANDIDATE_PATHS: list[Path] = [
    ROOT / "运行" / "BLACKBOX_ENTRY_PRICE_IN_GENERAL_CURRENT.json",
    ROOT / "研究系统" / "CURRENT" / "ENTRY_PRICE_IN_GENERAL_CURRENT.json",
    OUT_CUR / "CANDIDATE" / "INPUTS" / "GENERIC_ENTRY_PRICE_IN_CURRENT.json",
]
REFINING_SAMPLE_MARKERS = (
    "ENERGY_REFINING_20260828",
    "ENERGY_REFINING",
    "炼化行业",
    "炼化专用",
    "case_sample",
    "regression_fixture",
    "CASE_SAMPLE",
    "REGRESSION_FIXTURE",
    "MECHANISM_RESEARCH_SAMPLE",
)
FORBIDDEN_REAL_FLOW_CLAIMS = (
    "主力进场",
    "资金确认流入",
    "真实资金承接",
    "大资金持续买入",
    "大资金确认承接",
    "真实资金持续买入",
    "flow confirmed",
    "real money confirmed",
    "资金确认流入",
)
ALLOWED_EVIDENCE_TYPES = {
    "DIRECT_MEASURED_FLOW",
    "DECLARED_FLOW",
    "PRICE_VOLUME_ACCEPTANCE_PROXY",
    "MODEL_DERIVED_PROXY",
    "ABSENT",
}
SHADOW_SCHEMA_VERSION = "U235_SHADOW_MAIN_RESEARCH_R1"
SHENGYI = (
    ROOT
    / "任务"
    / "BLACKBOX_UNIFIED_DATA_RESEARCH_ORCHESTRATOR_R2"
    / "案例库"
    / "SHENGYI_ELECTRONICS_DYNAMIC_DISCOVERY_20260826.json"
)

TERMINAL_OK = {
    "COMPLETE",
    "NO_NEW_DATA",
    "KNOWN_AUTH_BLOCKED",
    "KNOWN_SOURCE_UNAVAILABLE",
    "NOT_APPLICABLE",
    "PASS",
    "READY",
    "PARTIAL",  # materialization partial + tip done may still be usable with EVIDENCE_GAP
}
FORBIDDEN = {
    "RUNNING",
    "PENDING",
    "QUEUED",
    "UNKNOWN",
    "FAILED_UNCLASSIFIED",
    "UNVALIDATED",
    "WAIT",
    "WAIT_JQ",
}

# CN prior expressions by US pool (PRIOR only — not live winners)
CN_BRANCH_PRIORS: dict[str, list[dict[str, str]]] = {
    "SW_OBSERVABILITY": [
        {"code": "688023.SH", "name": "安恒信息", "role": "WATCH", "why": "安全/运维监控邻近表达（PRIOR）"},
        {"code": "300454.SZ", "name": "深信服", "role": "WATCH", "why": "云安全/安全运营邻近（PRIOR）"},
        {"code": "002212.SZ", "name": "天融信", "role": "WATCH", "why": "网络安全邻近（PRIOR）"},
    ],
    "SW_ENTERPRISE_SAAS": [
        {"code": "600570.SH", "name": "恒生电子", "role": "WATCH", "why": "企业软件/金融IT（PRIOR）"},
        {"code": "300033.SZ", "name": "同花顺", "role": "WATCH", "why": "软件订阅邻近（PRIOR，非同池）"},
        {"code": "688111.SH", "name": "金山办公", "role": "SECOND_IN_BRANCH", "why": "企业办公SaaS/变现路径近（PRIOR）"},
    ],
    "SW_AI_NATIVE": [
        {"code": "002230.SZ", "name": "科大讯飞", "role": "WATCH", "why": "AI应用变现（PRIOR）"},
        {"code": "300418.SZ", "name": "昆仑万维", "role": "WATCH", "why": "AI应用（PRIOR）"},
        {"code": "688787.SH", "name": "海天瑞声", "role": "WATCH", "why": "AI数据（PRIOR）"},
    ],
    "EN_UPSTREAM": [
        {"code": "600028.SH", "name": "中国石化", "role": "WATCH", "why": "油气上游邻近（PRIOR）"},
        {"code": "601857.SH", "name": "中国石油", "role": "WATCH", "why": "油气上游（PRIOR）"},
    ],
    "EN_GRID": [
        {"code": "600406.SH", "name": "国电南瑞", "role": "BEST_IN_BRANCH", "why": "电网自动化核心表达（PRIOR）"},
        {"code": "601126.SH", "name": "四方股份", "role": "SECOND_IN_BRANCH", "why": "继电保护/电力自动化（PRIOR）"},
        {"code": "603606.SH", "name": "东方电缆", "role": "WATCH", "why": "电缆/电力基建邻近（PRIOR）"},
    ],
    "SEMI_OPTICAL": [
        {"code": "300308.SZ", "name": "中际旭创", "role": "BEST_IN_BRANCH", "why": "光模块CPO邻近（PRIOR）"},
        {"code": "300502.SZ", "name": "新易盛", "role": "SECOND_IN_BRANCH", "why": "光模块（PRIOR）"},
    ],
}


def now_cn() -> str:
    return datetime.now(CN).strftime("%Y-%m-%dT%H:%M:%S%z")


def today_cn() -> str:
    return datetime.now(CN).strftime("%Y-%m-%d")


def load_json(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def atomic_write_json(p: Path, obj: Any) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(p)


def write_md(p: Path, text: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + "\n", encoding="utf-8")


def normalize_manifest_asof(value: Any) -> str | None:
    """Strict YYYY-MM-DD or YYYYMMDD only. No invent / no alias / no DD-MM-YYYY scrape."""
    if value is None:
        return None
    s = str(value).strip()
    if not s or s.lower() in {"none", "null", "nan"}:
        return None
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        y, m, d = (int(s[0:4]), int(s[5:7]), int(s[8:10]))
    elif re.fullmatch(r"\d{8}", s):
        y, m, d = (int(s[0:4]), int(s[4:6]), int(s[6:8]))
        s = f"{y:04d}-{m:02d}-{d:02d}"
    else:
        return None
    if not (1 <= m <= 12 and 1 <= d <= 31):
        return None
    return f"{y:04d}-{m:02d}-{d:02d}"


def load_and_evaluate_canonical_manifest_gate(manifest_path: Path | None = None) -> dict[str, Any]:
    """Hard gate on Data Plane canonical Manifest. No READY aliases, no soft defaults."""
    path = Path(manifest_path) if manifest_path is not None else CANONICAL_MANIFEST_PATH
    out: dict[str, Any] = {
        "STATUS": "FAIL",
        "reason_code": None,
        "manifest_id": None,
        "source_asof": None,
        "clean_asof": None,
        "cache_asof": None,
        "manifest_path": str(path),
        "evidence_gaps": [],
        "DAILY_INCREMENTAL_READY": None,
        "JQ_STATUS": None,
    }

    def fail(code: str, *, gaps: list[Any] | None = None) -> dict[str, Any]:
        out["STATUS"] = "FAIL"
        out["reason_code"] = code
        out["evidence_gaps"] = gaps if gaps is not None else [{"id": "CANONICAL_MANIFEST", "gap": code}]
        return out

    if not path.exists():
        return fail("MANIFEST_MISSING")
    try:
        raw = path.read_text(encoding="utf-8")
        obj = json.loads(raw)
    except (OSError, UnicodeError, json.JSONDecodeError):
        return fail("MANIFEST_INVALID_JSON")
    if not isinstance(obj, dict):
        return fail("MANIFEST_NOT_OBJECT")

    mid = obj.get("manifest_id")
    if mid is None or (isinstance(mid, str) and not mid.strip()):
        return fail("MANIFEST_ID_MISSING")
    out["manifest_id"] = str(mid).strip()

    if "DAILY_INCREMENTAL_READY" not in obj:
        return fail("MANIFEST_READY_MISSING")
    ready = obj.get("DAILY_INCREMENTAL_READY")
    out["DAILY_INCREMENTAL_READY"] = ready
    # Strict string YES only — reject True/PASS/DEGRADED/NO/null
    if ready != "YES":
        return fail("MANIFEST_NOT_READY")

    jq = obj.get("JQ")
    if not isinstance(jq, dict):
        return fail("JQ_LANE_MISSING")
    jq_st = jq.get("STATUS")
    out["JQ_STATUS"] = jq_st
    if jq_st != "PASS":
        return fail("JQ_STATUS_NOT_PASS" if jq_st is not None else "JQ_STATUS_MISSING")

    if "SOURCE_ASOF" not in jq or jq.get("SOURCE_ASOF") is None:
        return fail("SOURCE_ASOF_NULL")
    if "CLEAN_ASOF" not in jq or jq.get("CLEAN_ASOF") is None:
        return fail("CLEAN_ASOF_NULL")
    if "CACHE_ASOF" not in jq or jq.get("CACHE_ASOF") is None:
        return fail("CACHE_ASOF_NULL")

    src_raw, cln_raw, cac_raw = jq.get("SOURCE_ASOF"), jq.get("CLEAN_ASOF"), jq.get("CACHE_ASOF")
    src, cln, cac = normalize_manifest_asof(src_raw), normalize_manifest_asof(cln_raw), normalize_manifest_asof(cac_raw)
    out["source_asof"], out["clean_asof"], out["cache_asof"] = src, cln, cac
    if src is None or cln is None or cac is None:
        return fail("INVALID_ASOF_FORMAT")

    # Distinguish pairwise mismatch for diagnostics (fixtures encode one pair off).
    if src != cln and cln == cac:
        return fail("SOURCE_CLEAN_MISMATCH")
    if src != cac and src == cln:
        return fail("SOURCE_CACHE_MISMATCH")
    if cln != cac and src == cac:
        return fail("CLEAN_CACHE_MISMATCH")
    if src != cln:
        return fail("SOURCE_CLEAN_MISMATCH")
    if src != cac:
        return fail("SOURCE_CACHE_MISMATCH")
    if cln != cac:
        return fail("CLEAN_CACHE_MISMATCH")

    out["STATUS"] = "PASS"
    out["reason_code"] = "MANIFEST_GATE_PASS"
    out["evidence_gaps"] = []
    return out


def formal_research_allowed(
    *,
    data_gate: str,
    manifest_gate: str,
    authority_gate: str,
    pit_gate: str,
) -> bool:
    return (
        data_gate == "PASS"
        and manifest_gate == "PASS"
        and authority_gate == "PASS"
        and pit_gate == "PASS"
    )


def resolve_wait_tick(
    *,
    body: dict[str, Any],
    elapsed_sec: float,
    max_hours: float,
) -> dict[str, Any]:
    """Pure wait policy. No R29 timeout→PASS. Returns action CONTINUE|RETURN_PASS|RETURN_FAIL."""
    out = dict(body)
    waiting_ids = {w.get("id") for w in (out.get("waiting") or [])}
    if formal_research_allowed(
        data_gate=str(out.get("DATA_GATE")),
        manifest_gate=str(out.get("MANIFEST_GATE")),
        authority_gate=str(out.get("AUTHORITY_GATE")),
        pit_gate=str(out.get("PIT_GATE")),
    ):
        out["_wait_action"] = "RETURN_PASS"
        return out
    if waiting_ids == {"R29_FULL_CHAIN"} or (
        waiting_ids and waiting_ids <= {"R29_FULL_CHAIN"}
    ):
        out["reason_code"] = "R29_WAITING"
    if elapsed_sec > max_hours * 3600:
        out["DATA_GATE"] = "FAIL"
        if "R29_FULL_CHAIN" in waiting_ids or waiting_ids <= {"R29_FULL_CHAIN"}:
            out["reason_code"] = "R29_WAIT_TIMEOUT"
        else:
            out["reason_code"] = out.get("reason_code") or "WAIT_TIMEOUT"
        out["FORMAL_RESEARCH_ALLOWED"] = False
        out["R3_SUBPROCESS_ALLOWED"] = False
        out["ENTRY_SUBPROCESS_ALLOWED"] = False
        out["FINAL_SUMMARY_ALLOWED"] = False
        out["RESEARCH_COMPLETE_CURRENT_ALLOWED"] = False
        out["_wait_action"] = "RETURN_FAIL"
        return out
    out["_wait_action"] = "CONTINUE"
    return out


def norm_status(s: Any) -> str:
    return str(s or "UNKNOWN").upper()


def classify_terminal(status: str, *, running_hint: bool = False) -> str:
    st = norm_status(status)
    if running_hint or st in FORBIDDEN or st.endswith("_RUNNING"):
        if st in TERMINAL_OK and not running_hint:
            return st
        return "RUNNING" if running_hint or st in {"RUNNING", "PENDING", "QUEUED", "WAIT", "WAIT_JQ"} else st
    if st in TERMINAL_OK:
        return st
    if "BLOCK" in st or "PERMISSION" in st or "NO_PERMISSION" in st:
        return "KNOWN_AUTH_BLOCKED"
    return st


def collector_snapshot() -> list[dict[str, Any]]:
    plane_state = ROOT / "研究系统" / "数据平面" / "STATE"
    scope = load_json(ROOT / "运行" / "BLACKBOX_FULL_DATA_UPDATE_SCOPE_CURRENT.json")
    clean = load_json(ROOT / "数据" / "清洗成品" / "CURRENT_CLEANING_RELEASE.json")
    cache = load_json(ROOT / "数据" / "回测缓存" / "CURRENT_CACHE_RELEASE.json")
    ext_align = load_json(ROOT / "运行" / "BLACKBOX_EXTERNAL_EVIDENCE_ASOF_ALIGN_CURRENT.json")
    sell = load_json(ROOT / "数据" / "研究报告" / "CURRENT" / "SELLSIDE_DAILY_INCREMENTAL_CURRENT.json")
    us_fine = load_json(ROOT / "运行" / "BLACKBOX_US_MARKET_FINE_GRAINED_FLOW_PROFIT_POOL_CURRENT.json")
    us_mkt = load_json(ROOT / "数据" / "美国市场" / "市场状态" / "CURRENT" / "US_MARKET_STATE_CURRENT.json")
    us_news = load_json(ROOT / "数据" / "美国市场" / "新闻" / "CURRENT" / "US_NEWS_CURRENT.json")
    domestic = load_json(plane_state / "DOMESTIC_RESEARCH_INCREMENTAL_STATE.json")
    r29_path = Path(r"D:\CURSOR_TASK_ARCHIVE\BLACKBOX_FULL_DATA_INCREMENT_R29_ASOF_20260828\out\R29_CHAIN_STATE.json")
    r29 = load_json(r29_path)
    r29_final = norm_status(r29.get("final_status"))
    r29_running = r29_final == "RUNNING"
    r29_process_status = None
    r29_hint = None
    r29_step_codes: list[Any] = []
    # Observe stale RUNNING / dead PID for diagnostics ONLY — never write D:\ R29 state, never promote to PASS.
    if r29_running:
        steps = r29.get("steps") or []
        r29_step_codes = [s.get("exit") for s in steps]
        all_ok = bool(steps) and all(int(s.get("exit", 1)) == 0 for s in steps)
        pid_alive = False
        try:
            pid_path = r29_path.parent / "R29_CHAIN_PID.json"
            pid_obj = load_json(pid_path)
            pid = int(pid_obj.get("pid") or 0)
            if pid > 0:
                import subprocess as _sp

                chk = _sp.run(
                    ["powershell", "-NoProfile", "-Command", f"Get-Process -Id {pid} -ErrorAction SilentlyContinue"],
                    capture_output=True,
                    timeout=15,
                )
                pid_alive = chk.returncode == 0
        except Exception:
            pid_alive = False
        if all_ok and not pid_alive:
            r29_process_status = "PID_DEAD"
            r29_hint = "STALE_PID_DEAD_STEPS_ZERO"
            # Keep RUNNING / UNVERIFIED — do NOT set r29_final=PASS; do NOT write r29_path.

    # process hint for external tip
    ext_running = False
    try:
        import subprocess

        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
             "Where-Object { $_.CommandLine -match 'external_evidence_materialization' } | "
             "Measure-Object | Select-Object -ExpandProperty Count"],
            text=True,
            timeout=30,
        )
        ext_running = int((out or "0").strip() or "0") > 0
    except Exception:
        ext_running = False

    jq_asof = scope.get("data_asof")
    collectors = [
        {
            "COLLECTOR_ID": "JQ_SCOPE",
            "DATA_PRODUCT": "FULL_DATA_UPDATE_SCOPE",
            "STATUS": classify_terminal("PASS" if jq_asof else "PENDING"),
            "EVENT_DATE": jq_asof,
            "OUTPUT_PATH": str(ROOT / "运行" / "BLACKBOX_FULL_DATA_UPDATE_SCOPE_CURRENT.json"),
            "PIT_ELIGIBLE": True,
            "ERROR_CLASS": None,
        },
        {
            "COLLECTOR_ID": "JQ_CLEANING",
            "DATA_PRODUCT": "CURRENT_CLEANING_RELEASE",
            "STATUS": classify_terminal("PASS" if clean.get("cleaning_as_of") else "PENDING"),
            "EVENT_DATE": clean.get("cleaning_as_of"),
            "OUTPUT_PATH": str(ROOT / "数据" / "清洗成品" / "CURRENT_CLEANING_RELEASE.json"),
            "PIT_ELIGIBLE": True,
            "NOTE": clean.get("release_id"),
        },
        {
            "COLLECTOR_ID": "JQ_CACHE",
            "DATA_PRODUCT": "CURRENT_CACHE_RELEASE",
            "STATUS": classify_terminal("PASS" if cache.get("asof") else "PENDING"),
            "EVENT_DATE": cache.get("asof"),
            "OUTPUT_PATH": str(ROOT / "数据" / "回测缓存" / "CURRENT_CACHE_RELEASE.json"),
            "PIT_ELIGIBLE": bool(cache.get("anti_lookahead_pass", True)),
            "NOTE": cache.get("cache_release_id"),
        },
        {
            "COLLECTOR_ID": "R29_FULL_CHAIN",
            "DATA_PRODUCT": "FULL_DATA_INCREMENT_R29",
            "STATUS": classify_terminal(r29_final, running_hint=r29_running),
            "EVENT_DATE": r29.get("asof"),
            "OUTPUT_PATH": str(Path(r"D:\CURSOR_TASK_ARCHIVE\BLACKBOX_FULL_DATA_INCREMENT_R29_ASOF_20260828\out\R29_CHAIN_STATE.json")),
            "PIT_ELIGIBLE": not r29_running,
            "NOTE": f"steps={len(r29.get('steps') or [])}",
            "R29_PROCESS_STATUS": r29_process_status,
            "R29_STEP_RETURN_CODES": r29_step_codes,
            "R29_HINT": r29_hint,
            "R29_AUTHORITY_STATUS": "UNVERIFIED" if r29_hint else None,
        },
        {
            "COLLECTOR_ID": "T_EXTERNAL_ASOF_ALIGN",
            "DATA_PRODUCT": "EXTERNAL_EVIDENCE_ASOF_ALIGN",
            "STATUS": classify_terminal(
                (
                    "RUNNING"
                    if ext_running
                    else (
                        "WAIT"
                        if str(ext_align.get("aligned_to_jq_asof") or "") != str(jq_asof or "")
                        else ext_align.get("status", "UNKNOWN")
                    )
                ),
                running_hint=ext_running,
            ),
            "EVENT_DATE": ext_align.get("aligned_to_jq_asof"),
            "OUTPUT_PATH": str(ROOT / "运行" / "BLACKBOX_EXTERNAL_EVIDENCE_ASOF_ALIGN_CURRENT.json"),
            "PIT_ELIGIBLE": (not ext_running)
            and ext_align.get("status") == "PASS"
            and str(ext_align.get("aligned_to_jq_asof") or "") == str(jq_asof or ""),
            "NOTE": f"aligned={ext_align.get('aligned_to_jq_asof')} jq={jq_asof}",
            "EVIDENCE_GAP": (
                None
                if (not ext_running and str(ext_align.get("aligned_to_jq_asof")) == str(jq_asof))
                else "EXTERNAL_TIP_LAG_OR_RUNNING"
            ),
        },
        {
            "COLLECTOR_ID": "SELLSIDE_INCREMENTAL",
            "DATA_PRODUCT": "SELLSIDE_DAILY_INCREMENTAL",
            "STATUS": classify_terminal(sell.get("TASK_STATUS", "UNKNOWN")),
            "EVENT_DATE": sell.get("asof"),
            "OUTPUT_PATH": str(ROOT / "数据" / "研究报告" / "CURRENT" / "SELLSIDE_DAILY_INCREMENTAL_CURRENT.json"),
            "PIT_ELIGIBLE": True,
        },
        {
            "COLLECTOR_ID": "US_FINE_GRAINED",
            "DATA_PRODUCT": "US_FINE_GRAINED_SNAPSHOT",
            "STATUS": classify_terminal(us_fine.get("STATUS", "UNKNOWN")),
            "EVENT_DATE": us_fine.get("US_MARKET_DATE"),
            "OUTPUT_PATH": str(ROOT / "运行" / "BLACKBOX_US_MARKET_FINE_GRAINED_FLOW_PROFIT_POOL_CURRENT.json"),
            "PIT_ELIGIBLE": True,
        },
        {
            "COLLECTOR_ID": "US_MARKET_STATE",
            "DATA_PRODUCT": "US_MARKET_STATE",
            "STATUS": classify_terminal(us_mkt.get("STATUS", "UNKNOWN")),
            "EVENT_DATE": us_mkt.get("US_MARKET_DATE"),
            "OUTPUT_PATH": str(ROOT / "数据" / "美国市场" / "市场状态" / "CURRENT" / "US_MARKET_STATE_CURRENT.json"),
            "PIT_ELIGIBLE": True,
        },
        {
            "COLLECTOR_ID": "US_NEWS",
            "DATA_PRODUCT": "US_L1_IMPORTANT_NEWS",
            "STATUS": classify_terminal(us_news.get("STATUS", "UNKNOWN")),
            "EVENT_DATE": us_news.get("US_MARKET_DATE"),
            "OUTPUT_PATH": str(ROOT / "数据" / "美国市场" / "新闻" / "CURRENT" / "US_NEWS_CURRENT.json"),
            "PIT_ELIGIBLE": True,
        },
        {
            "COLLECTOR_ID": "DOMESTIC_RESEARCH_NEWS",
            "DATA_PRODUCT": "DOMESTIC_RESEARCH_INCREMENTAL",
            "STATUS": classify_terminal(domestic.get("STATUS", "UNKNOWN")),
            "EVENT_DATE": domestic.get("DISCOVERY_ASOF"),
            "OUTPUT_PATH": str(plane_state / "DOMESTIC_RESEARCH_INCREMENTAL_STATE.json"),
            "PIT_ELIGIBLE": True,
        },
        {
            "COLLECTOR_ID": "CN_MINUTE_ACCEPTANCE_PLANE",
            "DATA_PRODUCT": "CN_PREVIOUS_DAY_MINUTE_ACCEPTANCE",
            "STATUS": "KNOWN_SOURCE_UNAVAILABLE",
            "EVENT_DATE": None,
            "OUTPUT_PATH": None,
            "PIT_ELIGIBLE": False,
            "EVIDENCE_GAP": "NO_FORMAL_MINUTE_ACCEPTANCE_PRODUCT_YET",
            "ERROR_CLASS": "KNOWN_SOURCE_GAP",
        },
        {
            "COLLECTOR_ID": "QMT_REQUIRED_INCREMENTAL",
            "DATA_PRODUCT": "QMT_LIVE_INTRADAY",
            "STATUS": "NOT_APPLICABLE",
            "EVENT_DATE": None,
            "NOTE": "Night research uses JQ clean/cache; QMT for next-session live only",
            "PIT_ELIGIBLE": False,
        },
    ]
    return collectors


def data_gate(
    collectors: list[dict[str, Any]],
    *,
    manifest_gate: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Pass only if canonical Manifest Gate PASS and required collectors are terminal."""
    mg = manifest_gate if manifest_gate is not None else load_and_evaluate_canonical_manifest_gate()
    required = [c for c in collectors if c["COLLECTOR_ID"] not in {"QMT_REQUIRED_INCREMENTAL"}]
    waiting = []
    gaps = []
    for c in required:
        st = classify_terminal(c.get("STATUS"), running_hint=c.get("STATUS") == "RUNNING")
        c["STATUS_NORM"] = st
        if st in FORBIDDEN or st == "RUNNING":
            if st == "KNOWN_SOURCE_UNAVAILABLE" or c.get("ERROR_CLASS") == "KNOWN_SOURCE_GAP":
                gaps.append(c)
                continue
            waiting.append(c)
        elif c.get("EVIDENCE_GAP"):
            gaps.append(c)
    collector_gate = "WAIT" if waiting else "PASS"
    if waiting:
        only_chain = all(c["COLLECTOR_ID"] in {"R29_FULL_CHAIN", "T_EXTERNAL_ASOF_ALIGN"} for c in waiting)
        if only_chain:
            collector_gate = "WAIT"

    gaps_out = [
        {"id": c["COLLECTOR_ID"], "gap": c.get("EVIDENCE_GAP"), "status": c.get("STATUS")} for c in gaps
    ]
    if mg.get("STATUS") != "PASS":
        gate = "FAIL"
        reason = mg.get("reason_code") or "MANIFEST_GATE_FAIL"
        gaps_out.append({"id": "CANONICAL_MANIFEST", "gap": reason, "status": mg.get("STATUS")})
    else:
        gate = collector_gate
        reason = "MANIFEST_GATE_PASS" if gate == "PASS" else (
            "R29_WAITING"
            if waiting and all(c["COLLECTOR_ID"] == "R29_FULL_CHAIN" for c in waiting)
            else "COLLECTORS_WAITING"
        )

    return {
        "DATA_GATE": gate,
        "MANIFEST_GATE": mg.get("STATUS"),
        "reason_code": reason,
        "manifest_gate": mg,
        "waiting": [{"id": c["COLLECTOR_ID"], "status": c.get("STATUS"), "note": c.get("NOTE")} for c in waiting],
        "evidence_gaps": gaps_out,
        "collectors": collectors,
        "BUILD_TIME_CN": now_cn(),
    }


def authority_pit_gate() -> dict[str, Any]:
    us_close = ROOT / "数据" / "美国市场" / "市场状态" / "CURRENT" / "US_CLOSE_STATE_CURRENT.json"
    us_open = ROOT / "数据" / "美国市场" / "市场状态" / "CURRENT" / "US_OPEN_STATE_CURRENT.json"
    us_fine_snap = ROOT / "数据" / "美国市场" / "细粒度利润池" / "CURRENT" / "US_FINE_GRAINED_SNAPSHOT_CURRENT.json"
    sell = ROOT / "数据" / "研究报告" / "CURRENT" / "SELLSIDE_DAILY_INCREMENTAL_CURRENT.json"
    checks = []
    for name, p in [
        ("US_CLOSE_STATE_CURRENT", us_close),
        ("US_OPEN_STATE_CURRENT", us_open),
        ("US_FINE_GRAINED_SNAPSHOT", us_fine_snap),
        ("SELLSIDE_DAILY_INCREMENTAL_CURRENT", sell),
        ("SHENGYI_METHOD_CASE", SHENGYI),
    ]:
        obj = load_json(p) if p.suffix == ".json" else {}
        ok = p.exists()
        checks.append(
            {
                "name": name,
                "path": str(p),
                "exists": ok,
                "US_MARKET_DATE": obj.get("US_MARKET_DATE") or obj.get("asof"),
                "PIT_ELIGIBLE": ok,
            }
        )
    auth_pass = all(c["exists"] for c in checks)
    # PIT: discovery dates must not invent future
    pit_pass = True
    for c in checks:
        d = c.get("US_MARKET_DATE")
        if d and str(d) > today_cn():
            pit_pass = False
    return {
        "AUTHORITY_GATE": "PASS" if auth_pass else "FAIL",
        "PIT_GATE": "PASS" if pit_pass else "FAIL",
        "checks": checks,
        "BUILD_TIME_CN": now_cn(),
        "NOTE": "US authority prefers E:\\BLACKBOX\\数据\\美国市场\\ CURRENT only",
    }


def load_research_inputs() -> dict[str, Any]:
    fine_root = ROOT / "数据" / "美国市场" / "细粒度利润池" / "CURRENT"
    return {
        "price": load_json(fine_root / "TOP_PRICE_ACCEPTANCE_SECTORS_CURRENT.json"),
        "flow": load_json(fine_root / "TOP_REAL_FLOW_SECTORS_CURRENT.json"),
        "leadership": load_json(fine_root / "FINE_GRAINED_LEADERSHIP_TABLE_CURRENT.json"),
        "mapping": load_json(fine_root / "A_SHARE_MAPPING_PRIOR_CURRENT.json"),
        "one_line": load_json(fine_root / "ONE_LINE_CONCLUSION_CURRENT.json"),
        "snap": load_json(fine_root / "US_FINE_GRAINED_SNAPSHOT_CURRENT.json"),
        "sellside": load_json(ROOT / "数据" / "研究报告" / "CURRENT" / "SELLSIDE_DAILY_INCREMENTAL_CURRENT.json"),
        "us_close": load_json(ROOT / "数据" / "美国市场" / "市场状态" / "CURRENT" / "US_CLOSE_STATE_CURRENT.json"),
        "shengyi": load_json(SHENGYI),
    }


def pick_top_pools(inp: dict[str, Any], n: int = 5) -> list[dict[str, Any]]:
    rows = list((inp.get("price") or {}).get("rows") or [])
    # prefer positive acceptance / strength
    rows = sorted(rows, key=lambda r: (r.get("avg_return_pct") or -999), reverse=True)
    picked = []
    for r in rows:
        if len(picked) >= n:
            break
        if (r.get("avg_return_pct") or -999) < -0.5 and len(picked) >= 3:
            continue
        picked.append(r)
    if len(picked) < 3:
        picked = rows[: max(3, n)]
    return picked[:n]


def build_focus_panel(pools: list[dict[str, Any]], inp: dict[str, Any]) -> tuple[str, list[dict[str, Any]], dict[str, Any]]:
    lead_by = {r.get("pool_id"): r for r in ((inp.get("leadership") or {}).get("rows") or [])}
    map_by = {r.get("US_POOL_ID"): r for r in ((inp.get("mapping") or {}).get("rows") or [])}
    focus_names: list[dict[str, Any]] = []
    blocks = [
        "================================================",
        "NEXT DAY FOCUS",
        f"BUILD_TIME_CN: {now_cn()}",
        f"US_MARKET_DATE: {(inp.get('snap') or {}).get('US_MARKET_DATE')}",
        "PRIOR_ONLY = TRUE",
        "ORDER_ALLOWED = FALSE",
        "STATIC_PRIOR_NE_LIVE_WINNER = TRUE",
        "================================================",
        "",
    ]
    for i, p in enumerate(pools, 1):
        pid = p.get("pool_id")
        lead = lead_by.get(pid, {})
        mp = map_by.get(pid, {})
        cn_hints = mp.get("CN_SAME_PROFIT_POOL") or []
        priors = CN_BRANCH_PRIORS.get(pid, [])[:3]
        for pr in priors:
            focus_names.append(
                {
                    **pr,
                    "pool_id": pid,
                    "l4": p.get("l4_profit_pool"),
                    "source": "US_MAPPING+STATIC_PRIOR_BOOK",
                    "kind": "HYPOTHESIS" if pr["role"] == "WATCH" else "SUPPORTED_INFERENCE",
                }
            )
        blocks += [
            f"PROFIT_POOL_{i}: {p.get('l3')}/{p.get('l4_profit_pool')}",
            f"为什么美国在交易: labels={p.get('price_acceptance_labels')} ret={p.get('avg_return_pct')}% RS={p.get('relative_strength_vs_bench')} FLOW={p.get('FLOW_STATUS')}",
            f"谁付钱: {lead.get('PAYER')}",
            f"谁变现: {lead.get('MONETIZATION')}",
            f"Leadership: {lead.get('LEADERSHIP_STATE')} cores={lead.get('CORE_CONFIRMATION')}",
            f"A股映射利润池: {cn_hints}",
            "A股昨天Price-in程度: UNCLEAR (CN日线横截面未在本轮完整计算 → EVIDENCE_GAP)",
            "A股分钟苗头: EVIDENCE_GAP=NO_FORMAL_MINUTE_ACCEPTANCE_PRODUCT_YET",
            f"Best-in-Branch(A股PRIOR表达): {[x['name']+x['code']+':'+x['role'] for x in priors] or 'NONE_IN_BOOK'}",
            "Intersection: 待盘中 DYNAMIC + 业务身份确认（MORE_CONCEPTS!=BETTER）",
            f"明早Focus: {[x['name'] for x in priors[:2]]}",
            "开盘验证条件: THEME_SYNC + CORE_DIRECTION + 非孤立高开 + 非过热；否则 NO_TRADE",
            "",
        ]
    # compress unique focus 3-8
    uniq: list[dict[str, Any]] = []
    seen = set()
    for x in focus_names:
        if x["code"] in seen:
            continue
        seen.add(x["code"])
        uniq.append(x)
        if len(uniq) >= 8:
            break
    if len(uniq) > 8:
        uniq = uniq[:8]
    if len(uniq) < 3:
        # legal NO_CLEAR_FOCUS
        pass
    blocks += [
        "------------------------------------------------------------",
        f"TOP_FOCUS_3_TO_8 = {[u['code']+':'+u['name'] for u in uniq]}",
        "NOTE: 以上为 PRIOR_ONLY 表达资产，不是买入指令；盘中须 DYNAMIC_DISCOVERY + Best-in-Branch 再压缩。",
        "生益案例提醒: 保存 FINDING_METHOD，禁止硬编码永久优先股。",
        "",
    ]
    meta = {
        "TOP_FOCUS": uniq,
        "POOLS": pools,
        "PRIOR_ONLY": True,
        "ORDER_ALLOWED": False,
    }
    return "\n".join(blocks), uniq, meta


def drift_audit(meta: dict[str, Any], inp: dict[str, Any], out_files: list[str]) -> str:
    text_blob = " ".join(Path(p).read_text(encoding="utf-8") if Path(p).exists() else "" for p in out_files)
    checks = {
        "A_degraded_to_news_summary_only": not bool(re.search(r"PROFIT_POOL|L4|利润池", text_blob)),
        "B_degraded_to_sector_rank_list": bool(re.search(r"\bSOFTWARE STRONG\b|\bENERGY STRONG\b", text_blob)),
        "C_static_prior_equals_live_winner": "PERMANENT_PRIORITY" in text_blob or "优先生益" in text_blob,
        "D_ignored_dynamic_discovery": "DYNAMIC_DISCOVERY" not in text_blob,
        "E_ignored_theme_intersection": "Intersection" not in text_blob and "THEME_INTERSECTION" not in text_blob,
        "F_ignored_cn_minute": "分钟" not in text_blob and "MINUTE" not in text_blob,
        "G_us_up_implies_cn_must_up": bool(re.search(r"A股必涨|必须跟涨", text_blob)),
        "H_thesis_as_position_obligation": bool(re.search(r"必须持仓|强制持有", text_blob)),
    }
    # Positive method markers
    positives = {
        "has_l3_l4_pools": len(meta.get("POOLS") or []) >= 3,
        "flow_ne_price": (inp.get("flow") or {}).get("PRODUCT") == "TOP_REAL_FLOW_SECTORS",
        "mapping_prior_only": (inp.get("mapping") or {}).get("ORDER_ALLOWED") is False,
        "shengyi_method_present": bool(inp.get("shengyi")),
        "focus_compressed": 0 < len(meta.get("TOP_FOCUS") or []) <= 8,
        "no_trade_legal_stated": "NO_TRADE" in text_blob,
        "static_prior_ne_live_winner_stated": "STATIC_PRIOR_NE_LIVE_WINNER" in text_blob,
    }
    fail_flags = [k for k, v in checks.items() if v]
    # D/E/F: if we mentioned method but gap — F should be False if we documented EVIDENCE_GAP for minute
    if "EVIDENCE_GAP=NO_FORMAL_MINUTE_ACCEPTANCE" in text_blob or "MINUTE_ACCEPTANCE" in text_blob:
        checks["F_ignored_cn_minute"] = False
        fail_flags = [k for k, v in checks.items() if v]
    if "DYNAMIC_DISCOVERY" in text_blob or "动态发现" in text_blob:
        checks["D_ignored_dynamic_discovery"] = False
        fail_flags = [k for k, v in checks.items() if v]
    if "Intersection" in text_blob or "交叉" in text_blob:
        checks["E_ignored_theme_intersection"] = False
        fail_flags = [k for k, v in checks.items() if v]

    status = "PASS" if not fail_flags and positives["has_l3_l4_pools"] else ("FAIL" if fail_flags else "PARTIAL")
    lines = [
        "# 12_RESEARCH_METHOD_DRIFT_AUDIT",
        f"BUILD_TIME_CN: {now_cn()}",
        f"DRIFT_AUDIT_STATUS: {status}",
        "",
        "## Failure-mode checks (True = bad)",
        "",
    ]
    for k, v in checks.items():
        lines.append(f"- {k}: {v}")
    lines += ["", "## Positive method markers", ""]
    for k, v in positives.items():
        lines.append(f"- {k}: {v}")
    lines += [
        "",
        "## Method alignment (Tao-abstracted)",
        "",
        "- INFORMATION_SELECTS_DIRECTION: YES (sellside+US fine)",
        "- MONEY_SELECTS_STOCK: PARTIAL (CN minute plane EVIDENCE_GAP; live path deferred)",
        "- POSITION_STATE_FOLLOWS_MARKET_VALIDATION: YES (PRIOR_ONLY, ORDER_ALLOWED=FALSE, NO_TRADE legal)",
        "",
        "## Shengyi case",
        "",
        f"- case_present: {bool(inp.get('shengyi'))}",
        "- preserve: FINDING_METHOD (not stock hardcode)",
        "",
        f"FAIL_FLAGS: {fail_flags}",
        "",
    ]
    return "\n".join(lines), status


def run_research(cn_date: str, gate: dict[str, Any], auth: dict[str, Any]) -> dict[str, Any]:
    out = OUT_CUR
    day = OUT_DAILY / cn_date
    out.mkdir(parents=True, exist_ok=True)
    day.mkdir(parents=True, exist_ok=True)
    inp = load_research_inputs()
    pools = pick_top_pools(inp, 5)
    files: list[Path] = []

    def emit(name: str, body: str) -> None:
        p1, p2 = out / name, day / name
        write_md(p1, body)
        write_md(p2, body)
        files.append(p1)

    emit(
        "00_DATA_COMPLETION_GATE.md",
        "# 00_DATA_COMPLETION_GATE\n\n"
        + f"DATA_GATE = {gate['DATA_GATE']}\n\n"
        + "```json\n"
        + json.dumps({k: gate[k] for k in ('DATA_GATE', 'waiting', 'evidence_gaps', 'BUILD_TIME_CN')}, ensure_ascii=False, indent=2)
        + "\n```\n",
    )
    emit(
        "01_DATA_AUTHORITY_AND_PIT_GATE.md",
        "# 01_DATA_AUTHORITY_AND_PIT_GATE\n\n```json\n" + json.dumps(auth, ensure_ascii=False, indent=2) + "\n```\n",
    )

    sell = inp.get("sellside") or {}
    emit(
        "02_BIG_THESIS_UPDATE.md",
        "\n".join(
            [
                "# 02_BIG_THESIS_UPDATE",
                f"asof={sell.get('asof')} status={sell.get('TASK_STATUS')}",
                "BIG_THESIS role = WHAT MAY MATTER (not buy list)",
                f"NEW_REPORT_COUNT={sell.get('NEW_REPORT_COUNT')} EXTERNAL_SUMMARY={sell.get('NEW_METADATA_OR_EXTERNAL_SUMMARY_COUNT')}",
                "Candidates (titles only):",
                *[f"- [{c.get('institution')}] {c.get('title')} ({c.get('ingest_status')})" for c in (sell.get('candidates') or [])[:12]],
                "",
                "STATE: UNCHANGED/STRENGTHENED mixed AI infra + financing narratives; not converted to tomorrow stock picks.",
                "",
            ]
        ),
    )

    emit(
        "03_US_FINE_GRAINED_PROFIT_POOLS.md",
        "# 03_US_FINE_GRAINED_PROFIT_POOLS\n\n"
        + f"ONE_LINE: {(inp.get('one_line') or {}).get('text')}\n\n"
        + "TOP_PRICE_ACCEPTANCE (FLOW_STATUS must stay UNKNOWN without verified flow):\n\n"
        + "```json\n"
        + json.dumps((inp.get("price") or {}).get("rows", [])[:8], ensure_ascii=False, indent=2)
        + "\n```\n\nTOP_REAL_FLOW:\n\n```json\n"
        + json.dumps(inp.get("flow") or {}, ensure_ascii=False, indent=2)
        + "\n```\n",
    )

    emit(
        "04_US_LEADERSHIP_MIGRATION.md",
        "# 04_US_LEADERSHIP_MIGRATION\n\n"
        + "```json\n"
        + json.dumps([
            {
                "pool_id": r.get("pool_id"),
                "L3": r.get("L3"),
                "L4": r.get("L4_PROFIT_POOL"),
                "LEADERSHIP_STATE": r.get("LEADERSHIP_STATE"),
                "PRICE_RETURN_PCT": r.get("PRICE_RETURN_PCT"),
            }
            for r in ((inp.get("leadership") or {}).get("rows") or [])[:12]
        ], ensure_ascii=False, indent=2)
        + "\n```\n\nNOTE: Software sub-pools leading vs semi weakness may be INTRA_AI_PROFIT_POOL_MIGRATION, not AI_OUTFLOW.\n",
    )

    emit(
        "05_CN_PREVIOUS_CLOSE_AND_MINUTE.md",
        "# 05_CN_PREVIOUS_CLOSE_AND_MINUTE\n\n"
        "CN_PRICE_IN_STATE: UNCLEAR for mapped branches (full cross-section not sealed this run).\n"
        "MINUTE_ACCEPTANCE: EVIDENCE_GAP = NO_FORMAL_MINUTE_ACCEPTANCE_PRODUCT_YET\n"
        "NEXT_COLLECTION: formalize CN previous-day minute acceptance plane (VWAP/RS/recovery/afternoon_hold/BEST_IN_BRANCH).\n"
        "METHOD REQUIRED: do not rank by return only.\n",
    )

    emit(
        "06_US_CN_PROFIT_POOL_MAPPING.md",
        "# 06_US_CN_PROFIT_POOL_MAPPING\n\nSAME_PROFIT_POOL_MAPPING only.\n\n```json\n"
        + json.dumps((inp.get("mapping") or {}).get("rows", []), ensure_ascii=False, indent=2)
        + "\n```\n",
    )

    emit(
        "07_THEME_INTERSECTION.md",
        "# 07_THEME_INTERSECTION\n\n"
        "Candidates to validate live (REAL_BUSINESS + BOTH_THEMES_LIVE + MONEY_ACCEPTANCE):\n"
        "- ENTERPRISE_SOFTWARE ∩ AI_APPLICATION\n"
        "- CYBERSECURITY/OBS ∩ AI_SECURITY_SPENDING\n"
        "- POWER/GRID ∩ AI_DATA_CENTER\n"
        "MORE_CONCEPTS != BETTER_STOCK\n",
    )

    emit(
        "08_DYNAMIC_DISCOVERY.md",
        "# 08_DYNAMIC_DISCOVERY\n\n"
        "STATIC_PRIOR != LIVE_WINNER\n"
        f"CASE: {((inp.get('shengyi') or {}).get('CASE_ID'))}\n"
        "PATH: ALL_MARKET_DYNAMIC_DISCOVERY → THEME_BRANCH → MINUTE_ACCEPTANCE → CROSS_SECTION → BEST_IN_BRANCH\n"
        "Tonight: seeds = top US profit pools; A-share live dynamic scan deferred to next session / minute plane.\n"
        "FORBIDDEN: hardcode 生益电子 as permanent priority.\n",
    )

    focus_md, focus_list, meta = build_focus_panel(pools, inp)
    emit(
        "09_BEST_IN_BRANCH.md",
        "# 09_BEST_IN_BRANCH\n\nPRIOR book expressions (not live winners):\n\n```json\n"
        + json.dumps(focus_list, ensure_ascii=False, indent=2)
        + "\n```\n\nLive Best-in-Branch requires CN minute + cross-section competition at open.\n",
    )

    emit(
        "10_NEXT_DAY_THEME_PRIOR.md",
        "# 10_NEXT_DAY_THEME_PRIOR\n\n"
        + "\n".join(
            [
                f"- {p.get('l3')}/{p.get('l4_profit_pool')}: ret={p.get('avg_return_pct')} labels={p.get('price_acceptance_labels')} FLOW={p.get('FLOW_STATUS')}"
                for p in pools
            ]
        )
        + "\n\nBIG_THESIS_SUPPORT: sellside AI/financing/memory narratives (structural)\n"
        "US_SHORT_CYCLE_SUPPORT: observability / enterprise SaaS / AI native price-acceptance\n"
        "CN_MINUTE_MOJO: EVIDENCE_GAP\n",
    )

    emit("11_NEXT_DAY_FOCUS_PANEL.md", focus_md)

    drift_text, drift_status = drift_audit(meta, inp, [str(f) for f in files] + [str(out / "11_NEXT_DAY_FOCUS_PANEL.md")])
    emit("12_RESEARCH_METHOD_DRIFT_AUDIT.md", drift_text)

    # USER-FACING: single TXT = focus panel + drift audit (HAND: no dual-MD deliverable)
    asof = cn_date
    summary_name = f"MASTER_RESEARCH_SUMMARY_{asof.replace('-', '')}.txt"
    sep = "=" * 72
    # fold EXTERNAL_EVENTS into user TXT when present
    ext_ev = ""
    try:
        ev_cur = load_json(ROOT / "研究系统" / "CURRENT" / "EXTERNAL_EVENTS" / "EXTERNAL_EVENTS_CURRENT.json")
        if ev_cur:
            ext_ev = (
                f"\n{sep}\nSECTION C — EXTERNAL_EVENTS (asof-aligned research context)\n{sep}\n\n"
                + json.dumps(ev_cur, ensure_ascii=False, indent=2)
                + "\n"
            )
            for e in ev_cur.get("events") or []:
                p = Path(e.get("path") or "")
                if p.exists():
                    ext_ev += f"\n--- {e.get('event_id')} ---\n"
                    ext_ev += p.read_text(encoding="utf-8")[:4000] + "\n"
    except Exception:
        ext_ev = ""
    summary_txt = (
        "BLACKBOX MASTER RESEARCH SUMMARY\n"
        f"ASOF={asof}\n"
        f"BUILD_TIME_CN={now_cn()}\n"
        "ORDER_ALLOWED=FALSE\n"
        f"DRIFT_AUDIT_STATUS={drift_status}\n"
        f"DATA_GATE={gate.get('DATA_GATE')}\n"
        f"AUTHORITY_GATE={auth.get('AUTHORITY_GATE')}\n"
        f"PIT_GATE={auth.get('PIT_GATE')}\n"
        f"\n{sep}\nSECTION A — NEXT_DAY_FOCUS_PANEL\n{sep}\n\n"
        f"{focus_md.strip()}\n\n"
        f"{sep}\nSECTION B — RESEARCH_METHOD_DRIFT_AUDIT\n{sep}\n\n"
        f"{drift_text.strip()}\n"
        f"{ext_ev}"
    )
    write_md(out / summary_name, summary_txt)
    write_md(day / summary_name, summary_txt)
    write_md(OUT_CUR / "MASTER_RESEARCH_SUMMARY.txt", summary_txt)
    write_md(day / "MASTER_RESEARCH_SUMMARY.txt", summary_txt)

    emit(
        "13_DATA_GAPS_NEXT_COLLECTION.md",
        "# 13_DATA_GAPS_NEXT_COLLECTION\n\n"
        "RESEARCH → DATA_REQUIREMENT → NEXT_COLLECTION\n\n"
        "1. CN_PREVIOUS_DAY_MINUTE_ACCEPTANCE formal product (VWAP/RS/recovery/afternoon_hold/branch_rank)\n"
        "2. CN branch membership for Observability / Enterprise SaaS / AI Native profit pools (not sector label)\n"
        "3. Paid ETF/fund TRUE_NET_FLOW if available; else keep FLOW_STATUS=UNKNOWN\n"
        "4. Keep Cybersecurity split: Identity/Endpoint/Cloud/SOC when US leadership migrates\n"
        f"\nevidence_gaps={json.dumps(gate.get('evidence_gaps'), ensure_ascii=False)}\n",
    )

    result = {
        "STATUS": "RESEARCH_COMPLETE",
        "DRIFT_AUDIT_STATUS": drift_status,
        "DATA_GATE": gate.get("DATA_GATE"),
        "AUTHORITY_GATE": auth.get("AUTHORITY_GATE"),
        "PIT_GATE": auth.get("PIT_GATE"),
        "TOP_FOCUS": focus_list,
        "POOLS": [{"l3": p.get("l3"), "l4": p.get("l4_profit_pool"), "ret": p.get("avg_return_pct")} for p in pools],
        "OUTPUT_DIR": str(out),
        "USER_DELIVERABLE_TXT": str(OUT_CUR / "MASTER_RESEARCH_SUMMARY.txt"),
        "USER_DELIVERABLE_TXT_DATED": str(out / summary_name),
        "PRIOR_ONLY": True,
        "ORDER_ALLOWED": False,
        "BUILD_TIME_CN": now_cn(),
    }
    atomic_write_json(out / "14_TOMORROW_CANDIDATE_BOOK.json", result)
    atomic_write_json(day / "14_TOMORROW_CANDIDATE_BOOK.json", result)
    return result


def publish_current(body: dict[str, Any]) -> None:
    atomic_write_json(CURRENT, body)


def mode_gate(*, write_outputs: bool = True) -> dict[str, Any]:
    cols = collector_snapshot()
    mg = load_and_evaluate_canonical_manifest_gate()
    dg = data_gate(cols, manifest_gate=mg)
    ag = authority_pit_gate()
    formal = formal_research_allowed(
        data_gate=str(dg["DATA_GATE"]),
        manifest_gate=str(dg.get("MANIFEST_GATE") or mg.get("STATUS")),
        authority_gate=str(ag["AUTHORITY_GATE"]),
        pit_gate=str(ag["PIT_GATE"]),
    )
    body = {
        "task_id": "BLACKBOX_MASTER_RESEARCH_AUTORUN_CHARTER_R1",
        "canonical_command": "RUN_MASTER_RESEARCH_STRATEGY",
        "MODE": "GATE",
        "ORDER_ALLOWED": False,
        "DATA_GATE": dg["DATA_GATE"],
        "MANIFEST_GATE": dg.get("MANIFEST_GATE") or mg.get("STATUS"),
        "AUTHORITY_GATE": ag["AUTHORITY_GATE"],
        "PIT_GATE": ag["PIT_GATE"],
        "reason_code": dg.get("reason_code") or mg.get("reason_code"),
        "manifest_id": mg.get("manifest_id"),
        "source_asof": mg.get("source_asof"),
        "clean_asof": mg.get("clean_asof"),
        "cache_asof": mg.get("cache_asof"),
        "waiting": dg["waiting"],
        "evidence_gaps": dg["evidence_gaps"],
        "FORMAL_RESEARCH_ALLOWED": formal,
        "R3_SUBPROCESS_ALLOWED": formal,
        "ENTRY_SUBPROCESS_ALLOWED": formal,
        "FINAL_SUMMARY_ALLOWED": formal,
        "RESEARCH_COMPLETE_CURRENT_ALLOWED": formal,
        "BUILD_TIME_CN": now_cn(),
    }
    if write_outputs:
        OUT_CUR.mkdir(parents=True, exist_ok=True)
        write_md(
            OUT_CUR / "00_DATA_COMPLETION_GATE.md",
            "# 00_DATA_COMPLETION_GATE\n\n"
            + f"DATA_GATE = {dg['DATA_GATE']}\n"
            + f"MANIFEST_GATE = {body['MANIFEST_GATE']}\n"
            + f"reason_code = {body.get('reason_code')}\n"
            + f"FORMAL_RESEARCH_ALLOWED = {formal}\n\n"
            + "WAITING (no full research conclusion yet):\n"
            + json.dumps(dg["waiting"], ensure_ascii=False, indent=2)
            + "\n",
        )
        # Diagnostic GATE CURRENT only — never RESEARCH_COMPLETE here
        publish_current(body)
    return body


def mode_wait(*, poll_sec: int = 120, max_hours: float = 6.0, allow_degraded_external: bool = False) -> dict[str, Any]:
    del allow_degraded_external  # retained for CLI compat; R29 timeout→PASS removed
    t0 = time.time()
    while True:
        body = mode_gate()
        tick = resolve_wait_tick(body=body, elapsed_sec=time.time() - t0, max_hours=max_hours)
        print(
            json.dumps(
                {
                    "wait_check": tick["DATA_GATE"],
                    "MANIFEST_GATE": tick.get("MANIFEST_GATE"),
                    "waiting": tick.get("waiting"),
                    "reason_code": tick.get("reason_code"),
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        action = tick.get("_wait_action")
        if action == "RETURN_PASS":
            return tick
        if action == "RETURN_FAIL":
            publish_current({k: v for k, v in tick.items() if not str(k).startswith("_")})
            return tick
        time.sleep(poll_sec)


def mode_run(*, delay_hours: float = 0.0, today_first: bool = False, poll_sec: int = 120) -> int:
    if delay_hours > 0:
        print(f"[TRIGGER] delay {delay_hours}h then recheck terminal", flush=True)
        time.sleep(delay_hours * 3600)
    print("[TRIGGER] RUN_MASTER_RESEARCH_STRATEGY", flush=True)
    gate_body = mode_wait(poll_sec=poll_sec, max_hours=8.0, allow_degraded_external=True)
    # Explicit re-assert before any research subprocess (do not trust wait alone)
    mg = load_and_evaluate_canonical_manifest_gate()
    formal = formal_research_allowed(
        data_gate=str(gate_body.get("DATA_GATE")),
        manifest_gate=str(mg.get("STATUS")),
        authority_gate=str(gate_body.get("AUTHORITY_GATE")),
        pit_gate=str(gate_body.get("PIT_GATE")),
    )
    if not formal or gate_body.get("DATA_GATE") != "PASS" or mg.get("STATUS") != "PASS":
        diag = {
            "task_id": "BLACKBOX_MASTER_RESEARCH_AUTORUN_CHARTER_R1",
            "MODE": "GATE",
            "ORDER_ALLOWED": False,
            "FORMAL_RESEARCH_ALLOWED": False,
            "R3_SUBPROCESS_ALLOWED": False,
            "ENTRY_SUBPROCESS_ALLOWED": False,
            "FINAL_SUMMARY_ALLOWED": False,
            "RESEARCH_COMPLETE_CURRENT_ALLOWED": False,
            "DATA_GATE": gate_body.get("DATA_GATE"),
            "MANIFEST_GATE": mg.get("STATUS"),
            "AUTHORITY_GATE": gate_body.get("AUTHORITY_GATE"),
            "PIT_GATE": gate_body.get("PIT_GATE"),
            "reason_code": gate_body.get("reason_code") or mg.get("reason_code"),
            "manifest_id": mg.get("manifest_id"),
            "source_asof": mg.get("source_asof"),
            "clean_asof": mg.get("clean_asof"),
            "cache_asof": mg.get("cache_asof"),
            "evidence_gaps": gate_body.get("evidence_gaps") or mg.get("evidence_gaps"),
            "BUILD_TIME_CN": now_cn(),
        }
        publish_current(diag)
        print(f"[STOP] FORMAL_RESEARCH_ALLOWED=NO reason={diag.get('reason_code')}", flush=True)
        return 2
    print("[AUTO] COLLECTION_MODE → RESEARCH_MODE (R3 GLOBAL_LEADERSHIP_FIRST)", flush=True)
    import subprocess

    rc = subprocess.call(
        [
            str(ROOT / ".venv" / "Scripts" / "python.exe"),
            "-u",
            str(ROOT / "脚本" / "run_blackbox_global_leadership_first_mapping_r3.py"),
            "--mode",
            "run",
        ]
    )
    result = load_json(ROOT / "运行" / "BLACKBOX_GLOBAL_LEADERSHIP_FIRST_MAPPING_R3_CURRENT.json")
    result["TODAY_FIRST_RUN"] = today_first
    result["DEGRADED"] = gate_body.get("DEGRADED")
    publish_current(
        {
            "task_id": "BLACKBOX_MASTER_RESEARCH_AUTORUN_CHARTER_R1",
            "MODE": "RESEARCH_COMPLETE_R3",
            "ORDER_ALLOWED": False,
            "result": result,
            "BUILD_TIME_CN": now_cn(),
            "USER_DELIVERABLE_TXT": str(OUT_CUR / "MASTER_RESEARCH_SUMMARY.txt"),
            "patch": ["R3_GLOBAL_LEADERSHIP_FIRST", "R4_STOCK_DISCOVERY_HEAD"],
            "MANIFEST_GATE": mg.get("STATUS"),
            "manifest_id": mg.get("manifest_id"),
        }
    )
    print(f"SUMMARY_TXT={OUT_CUR / 'MASTER_RESEARCH_SUMMARY.txt'}", flush=True)
    print(f"DRIFT_STATUS={result.get('DRIFT_AUDIT_STATUS')}", flush=True)
    print(f"PRIMARY={result.get('PRIMARY_THEME')}", flush=True)
    print(f"TOP_FOCUS={result.get('TOP_FOCUS')}", flush=True)
    return 0 if rc == 0 and result.get("DRIFT_AUDIT_STATUS") in {"PASS", "PARTIAL"} else 1



# ---------------------------------------------------------------------------
# BATCH_2 — U235 Shadow Main Research Assembly (consumer-side; production_eligibility=NO)
# ---------------------------------------------------------------------------


def _sha256_file(path: Path) -> str | None:
    try:
        if not path.exists() or not path.is_file():
            return None
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _absent_capital(product_id: str, *, gaps: list[Any] | None = None) -> dict[str, Any]:
    return {
        "product_id": product_id,
        "schema_version": None,
        "role": product_id,
        "status": "INCOMPLETE",
        "asof": None,
        "subject": None,
        "universe": None,
        "evidence_type": "ABSENT",
        "quality": "INSUFFICIENT",
        "direction": None,
        "strength": None,
        "real_flow_status": "UNAVAILABLE",
        "source_paths": [],
        "input_sha256": None,
        "evidence_gaps": gaps or [{"gap": f"{product_id}_ARTIFACT_ABSENT"}],
        "artifact_rejected": None,
    }


def is_refining_or_case_sample_artifact(obj: Any, path: Path | None = None) -> bool:
    blob = (json.dumps(obj, ensure_ascii=False, default=str) if obj is not None else "") + "|" + str(path or "")
    low = blob.lower()
    for m in REFINING_SAMPLE_MARKERS:
        if m.lower() in low:
            return True
    if isinstance(obj, dict):
        role = str(obj.get("artifact_role") or obj.get("role") or "").upper()
        if role in {
            "REFERENCE_SAMPLE",
            "REGRESSION_FIXTURE",
            "MECHANISM_RESEARCH_SAMPLE",
            "CASE_SAMPLE",
        }:
            return True
        scope = str(obj.get("scope") or "").upper()
        if "REFINING" in scope or "ENERGY_REFINING" in scope:
            return True
        if obj.get("case_sample") is True or obj.get("regression_fixture") is True:
            return True
    return False


def load_structured_artifact(path: Path | None, *, expect_json: bool = True) -> dict[str, Any]:
    out: dict[str, Any] = {
        "exists": False,
        "path": str(path) if path else None,
        "sha256": None,
        "obj": None,
        "status": "MISSING",
        "error": None,
        "is_json": False,
        "is_text_only": False,
    }
    if path is None:
        out["error"] = "PATH_NONE"
        return out
    p = Path(path)
    out["path"] = str(p)
    if not p.exists():
        out["error"] = "FILE_MISSING"
        return out
    out["exists"] = True
    out["sha256"] = _sha256_file(p)
    try:
        raw = p.read_text(encoding="utf-8")
    except OSError as e:
        out["error"] = f"READ_ERROR:{e}"
        return out
    if expect_json or p.suffix.lower() == ".json":
        try:
            obj = json.loads(raw)
            if not isinstance(obj, dict):
                out["status"] = "NOT_OBJECT"
                out["error"] = "JSON_NOT_OBJECT"
                out["is_json"] = True
                out["obj"] = obj
                return out
            out["obj"] = obj
            out["is_json"] = True
            out["status"] = "LOADED"
            return out
        except json.JSONDecodeError:
            out["is_text_only"] = True
            out["status"] = "UNSTRUCTURED_TEXT"
            out["error"] = "JSON_DECODE_FAIL"
            out["obj"] = {"_raw_text_preview": raw[:2000]}
            return out
    out["is_text_only"] = True
    out["status"] = "TEXT"
    out["obj"] = {"_raw_text_preview": raw[:2000]}
    return out


def normalize_module_input(kind: str, loaded: dict[str, Any], *, product_id: str | None = None) -> dict[str, Any]:
    del product_id
    kind_u = str(kind).upper()
    if kind_u == "R3_STRUCTURE_TREND":
        return _normalize_r3_input(loaded)
    if kind_u in {"CYCLE_CAPITAL_STATE", "CURRENT_CAPITAL_ACCEPTANCE", "MINUTE_ACCEPTANCE_STRENGTH"}:
        return _normalize_capital_input(kind_u, loaded)
    if kind_u == "ENTRY_PRICE_IN":
        return _normalize_entry_input(loaded)
    if kind_u == "FREEZE_R2":
        return _normalize_freeze_input(loaded)
    raise ValueError(f"unknown module kind={kind}")


def _normalize_freeze_input(loaded: dict[str, Any]) -> dict[str, Any]:
    p = loaded.get("path")
    exists = bool(loaded.get("exists"))
    version = None
    status = None
    canonical = False
    if exists and p:
        try:
            raw = Path(p).read_text(encoding="utf-8")
            if "BLACKBOX_MASTER_RESEARCH_OPERATING_SYSTEM_FREEZE_R2" in raw:
                version = "R2"
                canonical = True
            if "FROZEN_CORE" in raw:
                status = "FROZEN_CORE"
            if "R2 SUPERSEDES R1" in raw or "SUPERSEDES R1" in raw:
                canonical = True
            if "FREEZE R2" not in raw and "freeze_id" not in raw and not canonical:
                canonical = False
        except OSError:
            exists = False
    ok = bool(exists and canonical and version == "R2")
    return {
        "path": p,
        "version": version,
        "status": status if ok else ("MISSING" if not exists else "INVALID_OR_NON_CANONICAL"),
        "sha256": loaded.get("sha256"),
        "canonical_loaded": ok,
        "evidence_gaps": [] if ok else [{"gap": "FREEZE_R2_NOT_CANONICAL_OR_MISSING"}],
    }


def _normalize_r3_input(loaded: dict[str, Any]) -> dict[str, Any]:
    base: dict[str, Any] = {
        "role": "STRUCTURE_AND_TREND_PRODUCER",
        "artifact_path": loaded.get("path"),
        "artifact_sha256": loaded.get("sha256"),
        "build_time": None,
        "asof": None,
        "status": "INCOMPLETE",
        "R3_INPUT_STATUS": "INCOMPLETE",
        "structural_direction": None,
        "trend_status": None,
        "themes": [],
        "stock_mapping": [],
        "evidence_gaps": [],
        "not_promoted_to_final_decision": True,
    }
    if not loaded.get("exists"):
        base["evidence_gaps"] = [{"gap": "R3_STRUCTURED_ARTIFACT_MISSING"}]
        return base
    if loaded.get("is_text_only") or loaded.get("status") == "UNSTRUCTURED_TEXT":
        base["evidence_gaps"] = [{"gap": "R3_UNSTRUCTURED_TEXT_ONLY"}]
        return base
    obj = loaded.get("obj") or {}
    if not isinstance(obj, dict):
        base["evidence_gaps"] = [{"gap": "R3_NOT_OBJECT"}]
        return base
    theme = obj.get("PRIMARY_THEME") or obj.get("structural_direction") or obj.get("STRUCTURE_DIRECTION")
    trend = obj.get("trend_status") or obj.get("TREND_STATUS") or obj.get("DRIFT_AUDIT_STATUS")
    focus = obj.get("TOP_FOCUS") if isinstance(obj.get("TOP_FOCUS"), list) else []
    stock_mapping = []
    for row in focus:
        if isinstance(row, dict) and row.get("code"):
            stock_mapping.append(
                {
                    "code": row.get("code"),
                    "name": row.get("name"),
                    "theme": row.get("SOURCE_THEME") or theme,
                    "focus_status": row.get("FOCUS_STATUS"),
                    "note": "R3_MAPPING_INPUT_ONLY",
                }
            )
    themes = [t for t in [obj.get("PRIMARY_THEME"), obj.get("SECONDARY_THEME")] if t]
    gaps = list(obj.get("evidence_gaps") or [])
    incomplete = theme is None and not themes and not stock_mapping
    if incomplete:
        gaps.append({"gap": "R3_STRUCTURE_FIELDS_INSUFFICIENT"})
    st = "LOADED" if not incomplete else "INCOMPLETE"
    base.update(
        {
            "build_time": obj.get("BUILD_TIME_CN") or obj.get("build_time"),
            "asof": obj.get("asof") or obj.get("ASOF") or obj.get("CN_RESEARCH_DATE"),
            "status": st,
            "R3_INPUT_STATUS": "LOADED" if st == "LOADED" else "INCOMPLETE",
            "structural_direction": theme,
            "trend_status": trend,
            "themes": themes,
            "stock_mapping": stock_mapping,
            "evidence_gaps": gaps,
            "r3_status_field": obj.get("STATUS"),
            "drift_audit_status": obj.get("DRIFT_AUDIT_STATUS"),
        }
    )
    return base


def _normalize_capital_input(product_id: str, loaded: dict[str, Any]) -> dict[str, Any]:
    if not loaded.get("exists"):
        return _absent_capital(product_id)
    if loaded.get("is_text_only") or not isinstance(loaded.get("obj"), dict):
        out = _absent_capital(product_id, gaps=[{"gap": f"{product_id}_NOT_STRUCTURED_JSON"}])
        out["source_paths"] = [loaded.get("path")]
        return out
    obj = loaded["obj"]
    path = Path(loaded["path"]) if loaded.get("path") else None
    if is_refining_or_case_sample_artifact(obj, path):
        out = _absent_capital(
            product_id,
            gaps=[{"gap": "CASE_SPECIFIC_ARTIFACT_REJECTED", "path": loaded.get("path")}],
        )
        out["artifact_rejected"] = "CASE_SPECIFIC_ARTIFACT_REJECTED"
        out["source_paths"] = [loaded.get("path")]
        out["input_sha256"] = loaded.get("sha256")
        return out
    declared = str(obj.get("product_id") or obj.get("PRODUCT_ID") or "")
    declared_base = declared[:-6] if declared.endswith("_PROXY") else declared
    expected_proxy = f"{product_id}_PROXY"
    if declared and declared not in {product_id, expected_proxy} and declared_base != product_id:
        out = _absent_capital(
            product_id,
            gaps=[{"gap": "PRODUCT_ID_MISMATCH", "declared": declared, "expected": product_id}],
        )
        out["source_paths"] = [loaded.get("path")]
        return out

    computation_status = str(obj.get("computation_status") or obj.get("COMPUTATION_STATUS") or "").upper() or None
    pit_pass = obj.get("pit_pass")
    if pit_pass is None:
        pit_pass = obj.get("PIT_PASS")
    validation_status = obj.get("validation_status") or obj.get("VALIDATION_STATUS")

    # Batch3 proxy products: computation/PIT gates
    if computation_status in {
        "FAIL",
        "INCOMPLETE",
        "BLOCKED_NO_FORMAL_DATA_ROUTE",
        "MISSING",
    }:
        out = _absent_capital(
            product_id,
            gaps=[{"gap": f"COMPUTATION_{computation_status}", "path": loaded.get("path")}],
        )
        out["source_paths"] = [loaded.get("path")]
        out["input_sha256"] = loaded.get("sha256")
        out["computation_status"] = computation_status
        out["pit_pass"] = pit_pass
        out["validation_status"] = validation_status
        return out
    if pit_pass is False:
        out = _absent_capital(
            product_id,
            gaps=[{"gap": "PRODUCT_PIT_FAIL", "path": loaded.get("path")}],
        )
        out["source_paths"] = [loaded.get("path")]
        out["input_sha256"] = loaded.get("sha256")
        out["computation_status"] = computation_status
        out["pit_pass"] = False
        out["validation_status"] = validation_status
        return out

    et = obj.get("evidence_type") or obj.get("EVIDENCE_TYPE")
    if et is None:
        if any(k in obj for k in ("vwap", "VWAP", "price_volume", "PRICE_VOLUME", "volume_proxy", "direction_proxy")):
            et = "PRICE_VOLUME_ACCEPTANCE_PROXY"
        else:
            et = "ABSENT"
    # Batch3 producers must not elevate to DIRECT/DECLARED without formal contract —
    # if artifact self-declares DIRECT without FORMAL marker, coerce to PROXY.
    if et in {"DIRECT_MEASURED_FLOW", "DECLARED_FLOW"} and not obj.get("FORMAL_FLOW_CONTRACT"):
        et = "PRICE_VOLUME_ACCEPTANCE_PROXY"
    if et not in ALLOWED_EVIDENCE_TYPES:
        et = "ABSENT"
    real_flow = obj.get("real_flow_status") or obj.get("REAL_FLOW_STATUS")
    if et in {"PRICE_VOLUME_ACCEPTANCE_PROXY", "MODEL_DERIVED_PROXY", "ABSENT"}:
        real_flow = "UNAVAILABLE"
    elif et == "DIRECT_MEASURED_FLOW":
        real_flow = real_flow or "AVAILABLE_DIRECT"
    elif et == "DECLARED_FLOW":
        real_flow = real_flow or "DECLARED_ONLY"
    else:
        real_flow = real_flow or "UNAVAILABLE"

    # Prefer explicit LOADED when computation PASS
    if computation_status == "PASS" and pit_pass is not False:
        status = "LOADED"
    else:
        status = obj.get("status") or obj.get("STATUS") or "INCOMPLETE"
    quality = obj.get("quality") or obj.get("QUALITY") or (
        "INSUFFICIENT" if status == "INCOMPLETE" else "UNKNOWN"
    )
    gaps = list(obj.get("evidence_gaps") or [])
    if status == "INCOMPLETE" or et == "ABSENT":
        if not gaps:
            gaps = [{"gap": f"{product_id}_INCOMPLETE"}]
    direction = (
        obj.get("direction_proxy")
        or obj.get("direction")
        or obj.get("DIRECTION")
    )
    return {
        "product_id": product_id,
        "schema_version": obj.get("schema_version"),
        "role": product_id,
        "status": status,
        "asof": obj.get("asof") or obj.get("ASOF"),
        "subject": obj.get("subject") or obj.get("subject_id"),
        "universe": obj.get("universe"),
        "evidence_type": et,
        "quality": quality,
        "direction": direction,
        "strength": obj.get("strength") or obj.get("STRENGTH"),
        "real_flow_status": real_flow,
        "source_paths": [loaded.get("path")],
        "input_sha256": loaded.get("sha256"),
        "evidence_gaps": gaps,
        "artifact_rejected": None,
        "computation_status": computation_status,
        "pit_pass": pit_pass,
        "validation_status": validation_status,
        "measurements": obj.get("measurements"),
        "DATA_GENERATION_ID": obj.get("DATA_GENERATION_ID"),
        "RESEARCH_RUN_ID": obj.get("RESEARCH_RUN_ID"),
        "MODULE_OUTPUT_ID": obj.get("MODULE_OUTPUT_ID"),
        "pit_pass": pit_pass,
        "subject_id": obj.get("subject_id") or obj.get("subject"),
        "cutoff_time": obj.get("cutoff_time") or obj.get("cutoff"),
        "input_sha256": obj.get("input_sha256") or loaded.get("sha256"),
        "allowed_proxy_claims": (
            ["价量承接代理增强/减弱", "VWAP 承接代理", "成交量与价格恢复代理", "真实资金流证据不可用"]
            if et == "PRICE_VOLUME_ACCEPTANCE_PROXY"
            else []
        ),
    }


def _normalize_entry_input(loaded: dict[str, Any]) -> dict[str, Any]:
    base: dict[str, Any] = {
        "role": "PRICE_IN_AND_BUY_POINT_PRODUCER",
        "ENTRY_STATUS": "INCOMPLETE",
        "status": "INCOMPLETE",
        "scope": None,
        "price_in_status": None,
        "entry_ladder": None,
        "confirmation_condition": None,
        "invalidation_condition": None,
        "no_good_entry": None,
        "asof": None,
        "subject": None,
        "universe": None,
        "sha256": loaded.get("sha256"),
        "artifact_path": loaded.get("path"),
        "evidence_gaps": [],
        "artifact_rejected": None,
    }
    if not loaded.get("exists"):
        base["evidence_gaps"] = [{"gap": "GENERIC_ENTRY_ARTIFACT_MISSING"}]
        return base
    if loaded.get("is_text_only") or not isinstance(loaded.get("obj"), dict):
        base["evidence_gaps"] = [{"gap": "ENTRY_NOT_STRUCTURED_JSON"}]
        return base
    obj = loaded["obj"]
    path = Path(loaded["path"]) if loaded.get("path") else None
    if is_refining_or_case_sample_artifact(obj, path):
        base["evidence_gaps"] = [{"gap": "CASE_SPECIFIC_ARTIFACT_REJECTED"}]
        base["artifact_rejected"] = "CASE_SPECIFIC_ARTIFACT_REJECTED"
        return base
    # Accept universe=GENERAL as scope when scope omitted (GENERIC_ENTRY_PRICE_IN_R1 contract).
    scope = str(obj.get("scope") or obj.get("SCOPE") or obj.get("universe") or obj.get("UNIVERSE") or "").upper()
    if scope not in {"GENERAL", "UNIVERSAL", "MARKET_GENERAL"}:
        base["evidence_gaps"] = [{"gap": "ENTRY_SCOPE_NOT_GENERAL", "scope": scope or None}]
        return base
    conf = obj.get("confirmation_condition")
    if conf is None and isinstance(obj.get("confirmation_conditions"), list) and obj.get("confirmation_conditions"):
        conf = obj["confirmation_conditions"][0]
    inv = obj.get("invalidation_condition")
    if inv is None and isinstance(obj.get("invalidation_conditions"), list) and obj.get("invalidation_conditions"):
        inv = obj["invalidation_conditions"][0]
    base.update(
        {
            "ENTRY_STATUS": "LOADED",
            "status": obj.get("status") or "LOADED",
            "scope": scope,
            "product_id": obj.get("product_id"),
            "price_in_status": obj.get("price_in_status"),
            "entry_ladder": obj.get("entry_ladder"),
            "confirmation_condition": conf,
            "invalidation_condition": inv,
            "no_good_entry": obj.get("no_good_entry"),
            "asof": obj.get("asof"),
            "subject": obj.get("subject") or obj.get("subject_id"),
            "universe": obj.get("universe") or scope,
            "validation_status": obj.get("validation_status"),
            "formal_entry_allowed": obj.get("formal_entry_allowed"),
            "decision_status": obj.get("decision_status"),
            "formal_good_entry_available": obj.get("formal_good_entry_available"),
            "formal_good_entry_unavailable_reason": obj.get("formal_good_entry_unavailable_reason"),
            "DATA_GENERATION_ID": obj.get("DATA_GENERATION_ID"),
            "RESEARCH_RUN_ID": obj.get("RESEARCH_RUN_ID"),
            "MODULE_OUTPUT_ID": obj.get("MODULE_OUTPUT_ID"),
            "evidence_gaps": list(obj.get("evidence_gaps") or []),
        }
    )
    for req in (
        "price_in_status",
        "entry_ladder",
        "confirmation_condition",
        "invalidation_condition",
        "asof",
    ):
        if base.get(req) is None:
            base["evidence_gaps"].append({"gap": f"ENTRY_FIELD_MISSING:{req}"})
    # no_good_entry may be null when UNCALIBRATED / INCOMPLETE / BLOCKED — not a missing field
    if base.get("no_good_entry") is None and str(base.get("validation_status") or "").upper() not in {
        "UNCALIBRATED",
        "",
    }:
        # still allow None for incomplete entry artifacts
        pass
    if any(str(g.get("gap", "")).startswith("ENTRY_FIELD_MISSING") for g in base["evidence_gaps"]):
        base["ENTRY_STATUS"] = "INCOMPLETE"
        base["status"] = "INCOMPLETE"
    return base


def _find_first_existing(paths: list[Path]) -> Path | None:
    for p in paths:
        if p.exists():
            return p
    return None


def _direction_alignment(r3: dict[str, Any], capitals: dict[str, dict[str, Any]]) -> dict[str, Any]:
    reasons: list[str] = []
    caps = [
        capitals[k]
        for k in ("CYCLE_CAPITAL_STATE", "CURRENT_CAPITAL_ACCEPTANCE", "MINUTE_ACCEPTANCE_STRENGTH")
    ]
    if any(c.get("status") == "INCOMPLETE" or c.get("evidence_type") == "ABSENT" for c in caps):
        reasons.append("CAPITAL_PRODUCT_INCOMPLETE")
    dirs: list[Any] = []
    r3_dir = r3.get("structural_direction")
    for c in caps:
        d = c.get("direction")
        if d is not None:
            dirs.append(d)
    if "CAPITAL_PRODUCT_INCOMPLETE" in reasons:
        return {
            "status": "UNKNOWN",
            "structural_direction": r3_dir,
            "capital_direction": None,
            "reason_codes": reasons,
            "evidence_quality": "INSUFFICIENT",
        }
    if r3_dir is None or not dirs:
        reasons.append("DIRECTION_SCHEMA_NOT_COMPARABLE")
        return {
            "status": "UNKNOWN",
            "structural_direction": r3_dir,
            "capital_direction": dirs[0] if len(set(str(x) for x in dirs)) == 1 else (dirs or None),
            "reason_codes": reasons,
            "evidence_quality": "INSUFFICIENT",
        }
    cap_set = set(str(x) for x in dirs)
    if len(cap_set) == 1 and str(r3_dir) == next(iter(cap_set)):
        align = "ALIGNED"
    elif len(cap_set) == 1:
        align = "DIVERGENT"
    else:
        align = "MIXED_OR_UNKNOWN"
        reasons.append("CAPITAL_DIRECTIONS_NOT_UNIFORM")
    return {
        "status": align,
        "structural_direction": r3_dir,
        "capital_direction": next(iter(cap_set)) if len(cap_set) == 1 else sorted(cap_set),
        "reason_codes": reasons,
        "evidence_quality": "DECLARED_ENUM_ONLY",
    }


def validate_shadow_claims(candidate: dict[str, Any], txt: str) -> dict[str, Any]:
    forbidden_hits: list[str] = []
    # Do not treat meta enumerations (forbidden_claims list) as narrative claims.
    scan_obj = json.loads(json.dumps(candidate, ensure_ascii=False, default=str))
    if isinstance(scan_obj.get("claim_boundary"), dict):
        scan_obj["claim_boundary"]["forbidden_claims"] = []
    blob_json = json.dumps(scan_obj, ensure_ascii=False, default=str)
    txt_scan_lines = []
    for line in (txt or "").splitlines():
        if line.startswith("forbidden_claims="):
            continue
        txt_scan_lines.append(line)
    blob = blob_json + "\n" + "\n".join(txt_scan_lines)
    caps = candidate.get("inputs") or {}
    real_statuses = []
    for key in ("cycle_capital_state", "current_capital_acceptance", "minute_acceptance_strength"):
        c = caps.get(key) or {}
        real_statuses.append(c.get("real_flow_status"))
    claim_boundary = candidate.get("claim_boundary") or {}
    real_ok = any(s == "AVAILABLE_DIRECT" for s in real_statuses) or (
        claim_boundary.get("real_flow_status") == "AVAILABLE_DIRECT"
    )
    if not real_ok:
        low = blob.lower()
        for phrase in FORBIDDEN_REAL_FLOW_CLAIMS:
            if phrase.lower() in low:
                forbidden_hits.append(phrase)
    # de-dup while preserving order
    seen: set[str] = set()
    dedup: list[str] = []
    for p in forbidden_hits:
        if p not in seen:
            seen.add(p)
            dedup.append(p)
    forbidden_hits = dedup
    proxy_only = False
    cur = caps.get("current_capital_acceptance") or {}
    if cur.get("evidence_type") == "PRICE_VOLUME_ACCEPTANCE_PROXY":
        proxy_only = True
    proxy_disclaimer = "本结论基于价量承接代理，不代表已测得真实资金流。"
    proxy_ok = (not proxy_only) or (proxy_disclaimer in (txt or ""))
    status = "PASS"
    reasons: list[str] = []
    if forbidden_hits:
        status = "FAIL"
        reasons.append("FORBIDDEN_REAL_FLOW_CLAIM")
    if proxy_only and not proxy_ok:
        status = "FAIL"
        reasons.append("PROXY_DISCLAIMER_MISSING")
    return {
        "CLAIM_GATE": status,
        "forbidden_hits": forbidden_hits,
        "proxy_disclaimer_required": proxy_only,
        "proxy_disclaimer_present": proxy_disclaimer in (txt or ""),
        "reason_codes": reasons,
    }


def render_u235_shadow_txt(candidate: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("U235 SHADOW MAIN RESEARCH CANDIDATE")
    lines.append(f"schema_version={candidate.get('schema_version')}")
    lines.append(f"mode={candidate.get('mode')}")
    lines.append(f"assembly_status={candidate.get('assembly_status')}")
    lines.append(f"production_eligibility={candidate.get('production_eligibility')}")
    lines.append(f"build_time_cn={candidate.get('build_time_cn')}")
    lines.append("ORDER_ALLOWED=FALSE")
    dm = candidate.get("data_manifest") or {}
    lines.append("")
    lines.append("== DATA_MANIFEST ==")
    lines.append(f"gate_status={dm.get('gate_status')} manifest_id={dm.get('manifest_id')}")
    lines.append(
        f"source_asof={dm.get('source_asof')} clean_asof={dm.get('clean_asof')} cache_asof={dm.get('cache_asof')}"
    )
    fr = candidate.get("freeze_r2") or {}
    lines.append("")
    lines.append("== FREEZE_R2 ==")
    lines.append(
        f"path={fr.get('path')} version={fr.get('version')} status={fr.get('status')} "
        f"canonical_loaded={fr.get('canonical_loaded')}"
    )
    inp = candidate.get("inputs") or {}
    r3 = inp.get("r3_structure_trend") or {}
    lines.append("")
    lines.append("== R3_STRUCTURE_AND_TREND_INPUT ==")
    lines.append(
        f"R3_INPUT_STATUS={r3.get('R3_INPUT_STATUS')} structural_direction={r3.get('structural_direction')} "
        f"trend_status={r3.get('trend_status')}"
    )
    lines.append("NOTE: R3 is STRUCTURE_AND_TREND_PRODUCER only; not U235 final decision.")
    for key, label in (
        ("cycle_capital_state", "CYCLE_CAPITAL_STATE"),
        ("current_capital_acceptance", "CURRENT_CAPITAL_ACCEPTANCE"),
        ("minute_acceptance_strength", "MINUTE_ACCEPTANCE_STRENGTH"),
    ):
        c = inp.get(key) or {}
        lines.append("")
        lines.append(f"== {label} ==")
        lines.append(
            f"status={c.get('status')} evidence_type={c.get('evidence_type')} "
            f"real_flow_status={c.get('real_flow_status')} quality={c.get('quality')}"
        )
        if c.get("evidence_type") == "PRICE_VOLUME_ACCEPTANCE_PROXY":
            lines.append("价量承接代理：可描述增强/减弱 / VWAP 承接代理 / 成交量与价格恢复代理")
            lines.append("真实资金流证据不可用")
            lines.append("本结论基于价量承接代理，不代表已测得真实资金流。")
        if c.get("artifact_rejected"):
            lines.append(f"artifact_rejected={c.get('artifact_rejected')}")
    ent = inp.get("entry_price_in") or {}
    lines.append("")
    lines.append("== ENTRY_PRICE_IN ==")
    lines.append(
        f"ENTRY_STATUS={ent.get('ENTRY_STATUS')} scope={ent.get('scope')} no_good_entry={ent.get('no_good_entry')}"
    )
    da = candidate.get("direction_alignment") or {}
    lines.append("")
    lines.append("== DIRECTION_ALIGNMENT ==")
    lines.append(f"status={da.get('status')} reason_codes={da.get('reason_codes')}")
    fd = candidate.get("final_decision") or {}
    lines.append("")
    lines.append("== FINAL_DECISION (Freeze R2 mapped; shadow only) ==")
    lines.append(f"status={fd.get('status')} formal_decision_allowed={fd.get('formal_decision_allowed')}")
    lines.append(f"reason_codes={fd.get('reason_codes')}")
    frf = fd.get("freeze_r2_fields") or {}
    for k in (
        "THEME_VALID",
        "LEADERSHIP_CONFIRMED",
        "TIER1_ENTRY_AVAILABLE",
        "TIER2_ENTRY_AVAILABLE",
        "NO_GOOD_ENTRY",
    ):
        lines.append(f"{k}={frf.get(k)}")
    cb = candidate.get("claim_boundary") or {}
    lines.append("")
    lines.append("== CLAIM_BOUNDARY ==")
    lines.append(
        f"real_flow_status={cb.get('real_flow_status')} capital_evidence_type={cb.get('capital_evidence_type')}"
    )
    lines.append(f"allowed_claims={cb.get('allowed_claims')}")
    lines.append(f"forbidden_claims={cb.get('forbidden_claims')}")
    lines.append("")
    lines.append("== EVIDENCE_GAPS ==")
    lines.append(json.dumps(candidate.get("evidence_gaps") or [], ensure_ascii=False, indent=2))
    lines.append("")
    lines.append("== WARNINGS ==")
    lines.append(json.dumps(candidate.get("warnings") or [], ensure_ascii=False, indent=2))
    lines.append("")
    lines.append("PRODUCTION_ELIGIBILITY=NO")
    lines.append("SHADOW_CANDIDATE_ONLY=YES")
    return "\n".join(lines) + "\n"


def assemble_u235_shadow_candidate(
    *,
    manifest_path: Path | None = None,
    freeze_path: Path | None = None,
    r3_path: Path | None = None,
    capital_paths: dict[str, Path | None] | None = None,
    entry_path: Path | None = None,
    force_claims: dict[str, Any] | None = None,
    entry_explicit_missing: bool = False,
    research_run_id: str | None = None,
    skip_identity_gate: bool = False,
) -> dict[str, Any]:
    """Assemble Shadow Candidate. production_eligibility always NO.

    ISSUES RESEARCH_RUN_ID (unless injected for selftest).
    Identity gate fail-closed → assembly_status=INCOMPLETE_IDENTITY.
    """
    from blackbox_run_identity_r1 import issue_research_run_id, verify_identity_bundle

    rr1 = issue_research_run_id(inject=research_run_id)
    warnings: list[Any] = []
    evidence_gaps: list[Any] = []
    provenance: dict[str, Any] = {}
    sha_map: dict[str, Any] = {}

    mg = load_and_evaluate_canonical_manifest_gate(manifest_path)
    man_path = Path(manifest_path) if manifest_path is not None else CANONICAL_MANIFEST_PATH
    man_sha = _sha256_file(man_path) if man_path.exists() else None
    data_manifest = {
        "path": str(man_path),
        "manifest_id": mg.get("manifest_id"),
        "source_asof": mg.get("source_asof"),
        "clean_asof": mg.get("clean_asof"),
        "cache_asof": mg.get("cache_asof"),
        "gate_status": mg.get("STATUS"),
        "sha256": man_sha,
        "reason_code": mg.get("reason_code"),
    }
    provenance["data_manifest"] = data_manifest["path"]
    sha_map["data_manifest"] = man_sha

    if mg.get("STATUS") != "PASS":
        cand = {
            "schema_version": SHADOW_SCHEMA_VERSION,
            "mode": "SHADOW_CANDIDATE",
            "assembly_status": "BLOCKED_BY_DATA_GATE",
            "production_eligibility": "NO",
            "build_time_cn": now_cn(),
            "data_manifest": data_manifest,
            "freeze_r2": None,
            "inputs": None,
            "direction_alignment": None,
            "final_decision": {
                "status": "NO_FORMAL_DECISION",
                "freeze_r2_fields": {},
                "formal_decision_allowed": False,
                "reason_codes": ["BLOCKED_BY_DATA_GATE", mg.get("reason_code")],
            },
            "claim_boundary": {
                "real_flow_status": "UNAVAILABLE",
                "capital_evidence_type": "ABSENT",
                "allowed_claims": [],
                "forbidden_claims": list(FORBIDDEN_REAL_FLOW_CLAIMS),
            },
            "evidence_gaps": mg.get("evidence_gaps") or [{"gap": mg.get("reason_code")}],
            "input_provenance": provenance,
            "input_sha256": sha_map,
            "warnings": ["NO_MODULE_LOAD_WHEN_MANIFEST_FAIL"],
            "ORDER_ALLOWED": False,
        }
        return cand

    fp = Path(freeze_path) if freeze_path is not None else FREEZE_R2_CANONICAL_PATH
    freeze_loaded: dict[str, Any] = {
        "exists": fp.exists(),
        "path": str(fp),
        "sha256": _sha256_file(fp) if fp.exists() else None,
        "obj": None,
        "status": "LOADED" if fp.exists() else "MISSING",
        "is_json": False,
        "is_text_only": True,
    }
    freeze = normalize_module_input("FREEZE_R2", freeze_loaded)
    provenance["freeze_r2"] = freeze.get("path")
    sha_map["freeze_r2"] = freeze.get("sha256")
    if not freeze.get("canonical_loaded"):
        return {
            "schema_version": SHADOW_SCHEMA_VERSION,
            "mode": "SHADOW_CANDIDATE",
            "assembly_status": "BLOCKED_BY_FREEZE",
            "production_eligibility": "NO",
            "build_time_cn": now_cn(),
            "data_manifest": data_manifest,
            "freeze_r2": freeze,
            "inputs": None,
            "direction_alignment": None,
            "final_decision": {
                "status": "NO_FORMAL_DECISION",
                "freeze_r2_fields": {},
                "formal_decision_allowed": False,
                "reason_codes": ["BLOCKED_BY_FREEZE"],
            },
            "claim_boundary": {
                "real_flow_status": "UNAVAILABLE",
                "capital_evidence_type": "ABSENT",
                "allowed_claims": [],
                "forbidden_claims": list(FORBIDDEN_REAL_FLOW_CLAIMS),
            },
            "evidence_gaps": freeze.get("evidence_gaps") or [{"gap": "FREEZE_R2_MISSING"}],
            "input_provenance": provenance,
            "input_sha256": sha_map,
            "warnings": ["NO_MODULE_LOAD_WHEN_FREEZE_BLOCK"],
            "ORDER_ALLOWED": False,
        }

    rp = Path(r3_path) if r3_path is not None else R3_STRUCTURED_ARTIFACT_PATH
    r3_loaded = load_structured_artifact(rp, expect_json=True)
    r3 = normalize_module_input("R3_STRUCTURE_TREND", r3_loaded)
    provenance["r3_structure_trend"] = r3.get("artifact_path")
    sha_map["r3_structure_trend"] = r3.get("artifact_sha256")
    if r3.get("R3_INPUT_STATUS") != "LOADED":
        evidence_gaps.extend(r3.get("evidence_gaps") or [{"gap": "R3_INCOMPLETE"}])

    capital_paths = dict(capital_paths or {})
    capitals: dict[str, dict[str, Any]] = {}
    for pid in ("CYCLE_CAPITAL_STATE", "CURRENT_CAPITAL_ACCEPTANCE", "MINUTE_ACCEPTANCE_STRENGTH"):
        if pid in capital_paths:
            cp = capital_paths[pid]
        else:
            cp = _find_first_existing(CAPITAL_PRODUCT_CANDIDATE_PATHS.get(pid) or [])
        if cp is None:
            loaded = {
                "exists": False,
                "path": None,
                "sha256": None,
                "obj": None,
                "status": "MISSING",
                "is_json": False,
                "is_text_only": False,
            }
        else:
            loaded = load_structured_artifact(Path(cp), expect_json=True)
        capitals[pid] = normalize_module_input(pid, loaded)
        provenance[pid] = capitals[pid].get("source_paths")
        sha_map[pid] = capitals[pid].get("input_sha256")
        if capitals[pid].get("status") == "INCOMPLETE" or capitals[pid].get("evidence_type") == "ABSENT":
            evidence_gaps.extend(capitals[pid].get("evidence_gaps") or [{"gap": f"{pid}_INCOMPLETE"}])
        cap_asof = normalize_manifest_asof(capitals[pid].get("asof")) if capitals[pid].get("asof") else None
        man_asof = mg.get("source_asof")
        if cap_asof and man_asof and cap_asof != man_asof:
            evidence_gaps.append(
                {
                    "gap": "ASOF_MISMATCH",
                    "product": pid,
                    "product_asof": cap_asof,
                    "manifest_asof": man_asof,
                }
            )
            warnings.append(f"ASOF_MISMATCH:{pid}")
            capitals[pid]["status"] = "INCOMPLETE"
            capitals[pid].setdefault("evidence_gaps", []).append({"gap": "ASOF_MISMATCH"})

    if entry_explicit_missing:
        ep = None
    elif entry_path is not None:
        ep = entry_path
    else:
        ep = _find_first_existing(ENTRY_GENERAL_CANDIDATE_PATHS)
    if ep is None:
        entry_loaded = {
            "exists": False,
            "path": None,
            "sha256": None,
            "obj": None,
            "status": "MISSING",
            "is_json": False,
            "is_text_only": False,
        }
    else:
        entry_loaded = load_structured_artifact(Path(ep), expect_json=True)
    entry = normalize_module_input("ENTRY_PRICE_IN", entry_loaded)
    provenance["entry_price_in"] = entry.get("artifact_path")
    sha_map["entry_price_in"] = entry.get("sha256")
    if entry.get("ENTRY_STATUS") != "LOADED":
        evidence_gaps.extend(entry.get("evidence_gaps") or [{"gap": "ENTRY_INCOMPLETE"}])

    direction = _direction_alignment(r3, capitals)

    # --- Dual identity gate (Batch 6) ---
    man_obj = None
    if man_path.exists():
        try:
            man_obj = json.loads(man_path.read_text(encoding="utf-8"))
        except Exception:
            man_obj = None
    data_manifest["DATA_GENERATION_ID"] = (man_obj or {}).get("DATA_GENERATION_ID")
    data_manifest["MANIFEST_SEMANTIC_SHA256"] = (man_obj or {}).get("MANIFEST_SEMANTIC_SHA256")

    identity_modules: dict[str, dict[str, Any]] = {}
    # Prefer raw loaded objs when present on disk paths
    def _raw_from_path(p: Path | None) -> dict[str, Any] | None:
        if p is None or not Path(p).is_file():
            return None
        try:
            o = json.loads(Path(p).read_text(encoding="utf-8"))
            return o if isinstance(o, dict) else None
        except Exception:
            return None

    r3_raw = _raw_from_path(Path(r3_path) if r3_path else R3_STRUCTURED_ARTIFACT_PATH)
    if r3_raw:
        identity_modules["r3"] = r3_raw
    for pid, key in (
        ("CYCLE_CAPITAL_STATE", "cycle"),
        ("CURRENT_CAPITAL_ACCEPTANCE", "current"),
        ("MINUTE_ACCEPTANCE_STRENGTH", "minute"),
    ):
        cp = (capital_paths or {}).get(pid) if capital_paths else None
        if cp is None:
            cp = _find_first_existing(CAPITAL_PRODUCT_CANDIDATE_PATHS.get(pid) or [])
        raw = _raw_from_path(Path(cp) if cp else None)
        if raw:
            identity_modules[key] = raw
    if not entry_explicit_missing:
        ep_raw = entry_path if entry_path is not None else _find_first_existing(ENTRY_GENERAL_CANDIDATE_PATHS)
        raw_e = _raw_from_path(Path(ep_raw) if ep_raw else None)
        if raw_e:
            identity_modules["entry"] = raw_e

    identity_gate = {"ok": True, "skipped": True}
    if not skip_identity_gate:
        identity_gate = verify_identity_bundle(
            manifest=man_obj,
            modules=identity_modules,
            research_run_id=rr1,
        )
        if not identity_gate.get("ok"):
            return {
                "schema_version": SHADOW_SCHEMA_VERSION,
                "mode": "SHADOW_CANDIDATE",
                "assembly_status": "INCOMPLETE_IDENTITY",
                "production_eligibility": "NO",
                "build_time_cn": now_cn(),
                "RESEARCH_RUN_ID": rr1,
                "DATA_GENERATION_ID": (man_obj or {}).get("DATA_GENERATION_ID"),
                "data_manifest": data_manifest,
                "freeze_r2": freeze,
                "inputs": {
                    "r3_structure_trend": r3,
                    "cycle_capital_state": capitals["CYCLE_CAPITAL_STATE"],
                    "current_capital_acceptance": capitals["CURRENT_CAPITAL_ACCEPTANCE"],
                    "minute_acceptance_strength": capitals["MINUTE_ACCEPTANCE_STRENGTH"],
                    "entry_price_in": entry,
                },
                "direction_alignment": direction,
                "decision_status": "UNRESOLVED",
                "final_decision": {
                    "status": "NO_FORMAL_DECISION",
                    "freeze_r2_fields": {},
                    "formal_decision_allowed": False,
                    "reason_codes": ["INCOMPLETE_IDENTITY"]
                    + [g.get("gap") for g in (identity_gate.get("evidence_gaps") or [])],
                },
                "identity_gate": identity_gate,
                "claim_boundary": {
                    "real_flow_status": "UNAVAILABLE",
                    "capital_evidence_type": "ABSENT",
                    "allowed_claims": [],
                    "forbidden_claims": list(FORBIDDEN_REAL_FLOW_CLAIMS),
                },
                "evidence_gaps": list(identity_gate.get("evidence_gaps") or []),
                "input_provenance": provenance,
                "input_sha256": sha_map,
                "warnings": ["IDENTITY_GATE_FAIL_CLOSED"],
                "ORDER_ALLOWED": False,
                "formal_entry_allowed": False,
                "publish_allowed": False,
            }

    incomplete_reasons: list[str] = []
    if r3.get("R3_INPUT_STATUS") != "LOADED":
        incomplete_reasons.append("R3_INCOMPLETE")

    def _cap_complete(c: dict[str, Any]) -> bool:
        return c.get("status") in {"LOADED", "PASS", "COMPLETE"} and c.get("evidence_type") not in {
            None,
            "ABSENT",
        }

    for pid, c in capitals.items():
        if not _cap_complete(c):
            incomplete_reasons.append(f"{pid}_INCOMPLETE")
    if entry.get("ENTRY_STATUS") != "LOADED":
        incomplete_reasons.append("ENTRY_INCOMPLETE")
    if any(str(w).startswith("ASOF_MISMATCH") for w in warnings):
        incomplete_reasons.append("ASOF_MISMATCH")

    entry_uncal = str(entry.get("validation_status") or entry.get("decision_status") or "").upper() in {
        "UNCALIBRATED",
        "UNRESOLVED_UNCALIBRATED",
    } or entry.get("decision_status") == "UNRESOLVED_UNCALIBRATED"

    assembly_status = "INCOMPLETE" if incomplete_reasons else "COMPLETE_SHADOW"
    # COMPLETE_SHADOW ≠ calibrated buy; uncalibrated → NO_FORMAL_DECISION
    if incomplete_reasons:
        fd_status = "NO_FORMAL_DECISION"
        fd_reasons = list(incomplete_reasons)
        decision_status = "UNRESOLVED"
    elif entry_uncal:
        fd_status = "NO_FORMAL_DECISION"
        fd_reasons = ["UNRESOLVED_UNCALIBRATED", "SHADOW_ONLY_NOT_PRODUCTION"]
        decision_status = "UNRESOLVED_UNCALIBRATED"
    else:
        fd_status = "SHADOW_CANDIDATE_ONLY"
        fd_reasons = ["SHADOW_ONLY_NOT_PRODUCTION"]
        decision_status = "SHADOW_ONLY"

    frf = {
        "THEME_VALID": "UNKNOWN"
        if incomplete_reasons
        else ("TRUE" if r3.get("structural_direction") else "UNKNOWN"),
        "LEADERSHIP_CONFIRMED": "UNKNOWN",
        "TIER1_ENTRY_AVAILABLE": "UNKNOWN"
        if entry.get("ENTRY_STATUS") != "LOADED"
        else ("FALSE" if entry.get("no_good_entry") is True else "UNKNOWN"),
        "TIER2_ENTRY_AVAILABLE": "UNKNOWN",
        "NO_GOOD_ENTRY": (
            "UNKNOWN"
            if entry.get("no_good_entry") is None
            else entry.get("no_good_entry")
            if entry.get("ENTRY_STATUS") == "LOADED"
            else "UNKNOWN"
        ),
    }

    ets = [capitals[k].get("evidence_type") for k in capitals]
    if "DIRECT_MEASURED_FLOW" in ets and any(
        capitals[k].get("real_flow_status") == "AVAILABLE_DIRECT" for k in capitals
    ):
        real_flow_status = "AVAILABLE_DIRECT"
        cap_et = "DIRECT_MEASURED_FLOW"
    elif any(x == "PRICE_VOLUME_ACCEPTANCE_PROXY" for x in ets):
        real_flow_status = "UNAVAILABLE"
        cap_et = "PRICE_VOLUME_ACCEPTANCE_PROXY"
    else:
        real_flow_status = "UNAVAILABLE"
        cap_et = "ABSENT"
    allowed_claims = []
    if cap_et == "PRICE_VOLUME_ACCEPTANCE_PROXY":
        allowed_claims = [
            "价量承接代理增强/减弱",
            "VWAP 承接代理",
            "成交量与价格恢复代理",
            "真实资金流证据不可用",
        ]
    claim_boundary = {
        "real_flow_status": real_flow_status,
        "capital_evidence_type": cap_et,
        "allowed_claims": allowed_claims,
        "forbidden_claims": list(FORBIDDEN_REAL_FLOW_CLAIMS),
    }

    cand: dict[str, Any] = {
        "schema_version": SHADOW_SCHEMA_VERSION,
        "mode": "SHADOW_CANDIDATE",
        "assembly_status": assembly_status,
        "decision_status": decision_status,
        "production_eligibility": "NO",
        "RESEARCH_RUN_ID": rr1,
        "DATA_GENERATION_ID": (man_obj or {}).get("DATA_GENERATION_ID"),
        "build_time_cn": now_cn(),
        "data_manifest": data_manifest,
        "freeze_r2": freeze,
        "inputs": {
            "r3_structure_trend": r3,
            "cycle_capital_state": capitals["CYCLE_CAPITAL_STATE"],
            "current_capital_acceptance": capitals["CURRENT_CAPITAL_ACCEPTANCE"],
            "minute_acceptance_strength": capitals["MINUTE_ACCEPTANCE_STRENGTH"],
            "entry_price_in": entry,
        },
        "direction_alignment": direction,
        "final_decision": {
            "status": fd_status,
            "freeze_r2_fields": frf,
            "formal_decision_allowed": False,
            "reason_codes": fd_reasons,
        },
        "identity_gate": identity_gate,
        "claim_boundary": claim_boundary,
        "evidence_gaps": evidence_gaps,
        "input_provenance": provenance,
        "input_sha256": sha_map,
        "warnings": warnings,
        "ORDER_ALLOWED": False,
        "formal_entry_allowed": False,
        "publish_allowed": False,
    }
    if force_claims and force_claims.get("inject_json_claim"):
        cand["warnings"] = list(cand.get("warnings") or []) + [force_claims["inject_json_claim"]]
    return cand


def atomic_publish_candidate(
    candidate: dict[str, Any],
    txt: str,
    *,
    json_path: Path | None = None,
    txt_path: Path | None = None,
) -> None:
    """Write Candidate JSON then TXT. Caller must require --publish-candidate."""
    jp = Path(json_path) if json_path is not None else CANDIDATE_JSON_PATH
    tp = Path(txt_path) if txt_path is not None else CANDIDATE_TXT_PATH
    if jp.name == "MASTER_RESEARCH_SUMMARY.txt" or tp.name == "MASTER_RESEARCH_SUMMARY.txt":
        raise RuntimeError("REFUSE_OVERWRITE_FORMAL_SUMMARY")
    if jp.name == "BLACKBOX_MASTER_RESEARCH_AUTORUN_CHARTER_CURRENT.json":
        raise RuntimeError("REFUSE_OVERWRITE_AUTORUN_CURRENT")
    jp.parent.mkdir(parents=True, exist_ok=True)
    tmp_j = jp.with_suffix(jp.suffix + ".tmp")
    tmp_j.write_text(json.dumps(candidate, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp_j.replace(jp)
    tmp_t = tp.with_suffix(tp.suffix + ".tmp")
    tmp_t.write_text(txt if txt.endswith("\n") else txt + "\n", encoding="utf-8")
    tmp_t.replace(tp)


def _write_json_atomic(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def _refuse_formal_paths(path: Path) -> None:
    name = path.name
    if name == "MASTER_RESEARCH_SUMMARY.txt":
        raise RuntimeError("REFUSE_OVERWRITE_FORMAL_SUMMARY")
    if name == "BLACKBOX_MASTER_RESEARCH_AUTORUN_CHARTER_CURRENT.json":
        raise RuntimeError("REFUSE_OVERWRITE_AUTORUN_CURRENT")
    try:
        path.resolve().relative_to(CANDIDATE_DIR.resolve())
    except ValueError as e:
        raise RuntimeError(f"REFUSE_WRITE_OUTSIDE_CANDIDATE:{path}") from e


def enumerate_r3_coded_candidates(r3: dict[str, Any]) -> list[dict[str, Any]]:
    """Mechanical R3 universe: TOP_FOCUS order then DEMOTED.codes. No cherry-pick."""
    out: list[dict[str, Any]] = []
    rank = 0
    for item in r3.get("TOP_FOCUS") or []:
        if not isinstance(item, dict):
            continue
        code = item.get("code") or item.get("subject_id")
        if not code:
            out.append(
                {
                    "selection_source": "R3_TOP_FOCUS",
                    "selection_group": "TOP_FOCUS",
                    "original_rank": None,
                    "calibration_eligible": False,
                    "evidence_gap": "THEME_OR_ITEM_WITHOUT_SECURITY_CODE",
                    "raw": item,
                }
            )
            continue
        rank += 1
        out.append(
            {
                "subject_id": str(code),
                "selection_source": "R3_STRUCTURED_OUTPUT",
                "selection_group": "TOP_FOCUS",
                "original_rank": rank,
                "calibration_eligible": True,
                "tier": item.get("TIER"),
                "focus_status": item.get("FOCUS_STATUS"),
                "source_theme": item.get("SOURCE_THEME"),
                "raw": item,
            }
        )
    demoted = r3.get("DEMOTED") or {}
    codes = demoted.get("codes") or []
    for i, code in enumerate(codes):
        if not code:
            continue
        rank += 1
        out.append(
            {
                "subject_id": str(code),
                "selection_source": "R3_STRUCTURED_OUTPUT",
                "selection_group": "DEMOTED",
                "original_rank": rank,
                "calibration_eligible": True,
                "demoted_label": demoted.get("label"),
                "demoted_status": demoted.get("status"),
                "raw": {"code": code},
            }
        )
    # Theme-only strings (not securities)
    for key in ("PRIMARY_THEME", "SECONDARY_THEME"):
        if r3.get(key) and not any(c.get("subject_id") == r3.get(key) for c in out):
            out.append(
                {
                    "selection_source": "R3_THEME_STRING",
                    "selection_group": key,
                    "original_rank": None,
                    "calibration_eligible": False,
                    "evidence_gap": "THEME_WITHOUT_SECURITY_CODE",
                    "theme": r3.get(key),
                }
            )
    return out


_FORBIDDEN_REAL_FLOW_PHRASES = (
    "主力已经进场",
    "主力已进场",
    "真实资金流入确认",
    "真实资金流已确认",
    "正式买入",
    "允许下单",
)


def _scan_forbidden_claims(text: str) -> list[str]:
    hits = []
    for p in _FORBIDDEN_REAL_FLOW_PHRASES:
        if p in text:
            hits.append(p)
    return hits


def build_shadow_research_report_cn(
    *,
    dg1: str,
    rr1: str,
    manifest_reference: dict[str, Any],
    assembly: dict[str, Any],
    subjects: dict[str, dict[str, Any]],
    selection_meta: list[dict[str, Any]] | None = None,
) -> tuple[str, dict[str, Any]]:
    """Nine-section Chinese report + structured twin. COMPLETE_SHADOW ≠ buy."""
    jq = (manifest_reference.get("JQ") or {}) if isinstance(manifest_reference, dict) else {}
    lines: list[str] = []
    lines.append("BLACKBOX Shadow Candidate 研究报告（中文）")
    lines.append("=" * 48)
    lines.append("")
    lines.append("一、数据身份")
    lines.append(f"- DATA_GENERATION_ID: {dg1}")
    lines.append(f"- RESEARCH_RUN_ID: {rr1}")
    lines.append(f"- manifest_id: {manifest_reference.get('manifest_id')}")
    lines.append(f"- CN_RESEARCH_DATE/asof: {manifest_reference.get('CN_RESEARCH_DATE') or jq.get('SOURCE_ASOF')}")
    lines.append(
        f"- JQ asof: SOURCE={jq.get('SOURCE_ASOF')} CLEAN={jq.get('CLEAN_ASOF')} CACHE={jq.get('CACHE_ASOF')}"
    )
    lines.append(f"- PIT/JQ.STATUS: {jq.get('STATUS')} reason={jq.get('reason_code')} PIT_PASS={jq.get('PIT_PASS')}")
    lines.append("")
    lines.append("二、大方向与趋势（仅引用 R3，U235 不重算）")
    # Prefer first subject R3
    first_r3 = None
    for sid, mods in subjects.items():
        first_r3 = mods.get("r3") or mods.get("R3_OUTPUT")
        if first_r3:
            break
    r3 = first_r3 or {}
    lines.append(f"- PRIMARY_THEME: {r3.get('PRIMARY_THEME')}")
    lines.append(f"- SECONDARY_THEME: {r3.get('SECONDARY_THEME')}")
    lines.append(f"- R3.STATUS: {r3.get('STATUS')}")
    lines.append(f"- structural/product fields as-of: {r3.get('asof')} cutoff={r3.get('cutoff_time')}")
    lines.append("- 走势是否与结构方向一致：以各标的 cycle/current direction_proxy 对照，见第三节/四节；此处不另算趋势。")
    lines.append("")
    lines.append("三、周期资金状态（价格量代理，非真实资金流）")
    for sid, mods in subjects.items():
        cyc = mods.get("cycle") or mods.get("CYCLE_CAPITAL_STATE") or {}
        lines.append(
            f"- {sid}: direction_proxy={cyc.get('direction_proxy')} "
            f"evidence_type={cyc.get('evidence_type')} real_flow_status={cyc.get('real_flow_status')} "
            f"status={cyc.get('computation_status')}"
        )
    lines.append("- 声明：以上均为价格/成交量代理，不得解读为真实资金流入。")
    lines.append("")
    lines.append("四、当前资金承接（承接/分歧/缺口；禁止宣称主力进场类措辞）")
    for sid, mods in subjects.items():
        cur = mods.get("current") or mods.get("CURRENT_CAPITAL_ACCEPTANCE") or {}
        gaps = cur.get("evidence_gaps") or []
        lines.append(
            f"- {sid}: direction_proxy={cur.get('direction_proxy')} "
            f"evidence_type={cur.get('evidence_type')} gaps={len(gaps) if isinstance(gaps, list) else gaps}"
        )
    lines.append("")
    lines.append("五、分钟承接（VWAP/分钟量价代理；不得单独升格为结构方向）")
    for sid, mods in subjects.items():
        mn = mods.get("minute") or mods.get("MINUTE_ACCEPTANCE_STRENGTH") or {}
        meas = mn.get("measurements") or {}
        lines.append(
            f"- {sid}: direction_proxy={mn.get('direction_proxy')} "
            f"vwap_related={bool(meas)} status={mn.get('computation_status')}"
        )
    lines.append("")
    lines.append("六、Price-in / Entry（当前 UNCALIBRATED）")
    for sid, mods in subjects.items():
        en = mods.get("entry") or mods.get("GENERIC_ENTRY_PRICE_IN") or {}
        lines.append(
            f"- {sid}: price_in_status={en.get('price_in_status')} "
            f"validation_status={en.get('validation_status')} "
            f"decision_status={en.get('decision_status')} "
            f"no_good_entry={en.get('no_good_entry')!r} "
            f"ladder={en.get('entry_ladder')}"
        )
    lines.append("- 统一裁决字段：NO_FORMAL_DECISION；no_good_entry 在未校准时为 null（非假阴性无买点）。")
    lines.append("")
    lines.append("七、Freeze R2 最终裁决（分层，禁止把 COMPLETE_SHADOW 写成买入）")
    lines.append(f"- assembly_status: {assembly.get('assembly_status')}")
    lines.append(f"- evidence_status: {assembly.get('evidence_status') or 'SEE_MODULE_GAPS'}")
    lines.append(f"- decision_status: {assembly.get('decision_status')}")
    fd = assembly.get("final_decision")
    fd_s = fd.get("status") if isinstance(fd, dict) else fd
    lines.append(f"- final_decision: {fd_s}")
    lines.append("- COMPLETE_SHADOW 仅表示装配完整，不表示买点成立或经验有效。")
    lines.append("")
    lines.append("八、反例与证伪条件")
    lines.append("- 若后续 R3 主主题切换或 TOP_FOCUS 编码集合系统性替换，则当前结构方向判断失效。")
    lines.append("- 若周期/当前/分钟 direction_proxy 连续转为分歧且 evidence_gaps 扩大，则候选失效。")
    lines.append("- 若 Entry 仍 UNCALIBRATED，任何“可交易买点”陈述均为越权。")
    lines.append("")
    lines.append("九、最终边界")
    lines.append("- FORMAL_ENTRY_ALLOWED=NO")
    lines.append("- ORDER_ALLOWED=NO")
    lines.append("- PRODUCTION_ELIGIBILITY=NO")
    lines.append("- EMPIRICAL_VALIDITY=NOT_PROVEN")
    if selection_meta:
        lines.append("")
        lines.append("附：样本选择元数据（机械枚举，非人工挑选）")
        for m in selection_meta:
            if m.get("subject_id"):
                lines.append(
                    f"- {m.get('subject_id')}: group={m.get('selection_group')} "
                    f"rank={m.get('original_rank')} calibration_eligible={m.get('calibration_eligible')}"
                )
            elif m.get("evidence_gap"):
                lines.append(f"- THEME_GAP: {m.get('selection_group')} gap={m.get('evidence_gap')} theme={m.get('theme')}")

    text = "\n".join(lines) + "\n"
    hits = _scan_forbidden_claims(text)
    structured = {
        "schema_version": "SHADOW_RESEARCH_REPORT_STRUCTURED_R1",
        "DATA_GENERATION_ID": dg1,
        "RESEARCH_RUN_ID": rr1,
        "sections": [
            "数据身份",
            "大方向与趋势",
            "周期资金状态",
            "当前资金承接",
            "分钟承接",
            "Price-in_Entry",
            "Freeze_R2_裁决",
            "反例与证伪",
            "最终边界",
        ],
        "assembly_status": assembly.get("assembly_status"),
        "decision_status": assembly.get("decision_status"),
        "final_decision": fd_s,
        "formal_entry_allowed": False,
        "order_allowed": False,
        "production_eligibility": "NO",
        "empirical_validity": "NOT_PROVEN",
        "no_good_entry_policy": "NULL_WHEN_UNCALIBRATED",
        "forbidden_claim_hits": hits,
        "selection_meta": selection_meta or [],
        "subjects": list(subjects.keys()),
    }
    if hits:
        raise RuntimeError(f"FORBIDDEN_CLAIM_IN_REPORT:{hits}")
    return text, structured


def update_candidate_current_pointer(
    *,
    research_run_id: str,
    data_generation_id: str,
    subjects: list[str],
    run_path: Path | str,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Advance CANDIDATE/CURRENT.json only after memory handoff success."""
    run_path = Path(run_path)
    pointer = {
        "schema_version": "CANDIDATE_CURRENT_POINTER_R1",
        "RESEARCH_RUN_ID": research_run_id,
        "DATA_GENERATION_ID": data_generation_id,
        "run_path": str(run_path),
        "subjects": list(subjects),
        "assembly_status": "COMPLETE_SHADOW",
        "decision_status": "UNRESOLVED_UNCALIBRATED",
        "final_decision": "NO_FORMAL_DECISION",
        "formal_entry_allowed": False,
        "order_allowed": False,
        "production_eligibility": "NO",
        "empirical_validity": "NOT_PROVEN",
        "updated_at_cn": now_cn(),
        "writer": "U235",
    }
    if extra:
        pointer.update(extra)
    _refuse_formal_paths(CANDIDATE_CURRENT_POINTER)
    _write_json_atomic(CANDIDATE_CURRENT_POINTER, pointer)
    return pointer


def atomic_publish_shadow_candidate_run(
    payload: dict[str, Any],
    *,
    update_current_pointer: bool = True,
) -> dict[str, Any]:
    """U235-only append-only Candidate publish under RUNS/<RESEARCH_RUN_ID>/.

    Staging → identity/hash verify → atomic rename into RUNS.
    Batch8: set update_current_pointer=False until Shadow Memory handoff succeeds.
    Failed runs must not update CURRENT pointer. Never overwrite an existing RUNS/<RR>.
    """
    import shutil
    import uuid as _uuid

    from blackbox_run_identity_r1 import verify_identity_bundle, verify_module_output_id

    rr1 = str(payload.get("RESEARCH_RUN_ID") or "")
    dg1 = str(payload.get("DATA_GENERATION_ID") or "")
    if not rr1.startswith("RR1-"):
        return {"ok": False, "published": False, "reason": "INVALID_RESEARCH_RUN_ID", "publish_allowed": False}
    if not dg1.startswith("DG1-"):
        return {"ok": False, "published": False, "reason": "INVALID_DATA_GENERATION_ID", "publish_allowed": False}

    run_dir = CANDIDATE_RUNS_DIR / rr1
    if run_dir.exists():
        return {
            "ok": False,
            "published": False,
            "reason": "RUN_ALREADY_EXISTS",
            "path": str(run_dir),
            "publish_allowed": False,
        }

    subjects = payload.get("subjects") or {}
    if not isinstance(subjects, dict) or not subjects:
        return {"ok": False, "published": False, "reason": "SUBJECTS_REQUIRED", "publish_allowed": False}

    manifest_reference = payload.get("MANIFEST_REFERENCE") or {}
    assembly = payload.get("CANDIDATE_ASSEMBLY") or {}
    selection_meta = payload.get("selection_meta")
    identity_results: dict[str, Any] = {}
    all_ok = True
    for sid, mods in subjects.items():
        if not isinstance(mods, dict):
            all_ok = False
            identity_results[sid] = {"ok": False, "reason": "SUBJECT_MODULES_NOT_DICT"}
            continue
        modules = {
            "r3": mods.get("r3") or mods.get("R3_OUTPUT"),
            "cycle": mods.get("cycle") or mods.get("CYCLE_CAPITAL_STATE"),
            "current": mods.get("current") or mods.get("CURRENT_CAPITAL_ACCEPTANCE"),
            "minute": mods.get("minute") or mods.get("MINUTE_ACCEPTANCE_STRENGTH"),
            "entry": mods.get("entry") or mods.get("GENERIC_ENTRY_PRICE_IN"),
        }
        if any(v is None or not isinstance(v, dict) for v in modules.values()):
            all_ok = False
            identity_results[sid] = {"ok": False, "reason": "MODULE_MISSING"}
            continue
        mo_ok = True
        for mk, mv in modules.items():
            vr = verify_module_output_id(mv)
            if not vr.get("ok"):
                mo_ok = False
                identity_results[sid] = {"ok": False, "reason": "MODULE_OUTPUT_ID_MISMATCH", "module": mk, "detail": vr}
                break
            if mv.get("DATA_GENERATION_ID") != dg1 or mv.get("RESEARCH_RUN_ID") != rr1:
                mo_ok = False
                identity_results[sid] = {"ok": False, "reason": "DG1_OR_RR1_MISMATCH", "module": mk}
                break
            subj = mv.get("subject_id") or mv.get("subject")
            if subj and str(subj) != str(sid):
                mo_ok = False
                identity_results[sid] = {"ok": False, "reason": "SUBJECT_ID_MISMATCH", "module": mk, "got": subj}
                break
        if not mo_ok:
            all_ok = False
            continue
        gate = verify_identity_bundle(
            manifest=manifest_reference if manifest_reference.get("DATA_GENERATION_ID") else payload.get("manifest"),
            modules=modules,
            research_run_id=rr1,
        )
        identity_results[sid] = gate
        if not gate.get("ok"):
            all_ok = False

    fd = assembly.get("final_decision")
    fd_status = fd.get("status") if isinstance(fd, dict) else fd
    req_checks = {
        "assembly_status": assembly.get("assembly_status") == "COMPLETE_SHADOW",
        "decision_status": assembly.get("decision_status") == "UNRESOLVED_UNCALIBRATED",
        "final_decision": fd_status == "NO_FORMAL_DECISION",
        "formal_entry_allowed": assembly.get("formal_entry_allowed") in (False, "NO", None),
        "order_allowed": assembly.get("ORDER_ALLOWED") in (False, "NO", None)
        or assembly.get("order_allowed") in (False, "NO", None),
        "production_eligibility": assembly.get("production_eligibility") == "NO",
        "empirical_validity": assembly.get("empirical_validity") in (None, "NOT_PROVEN"),
    }
    if not all(req_checks.values()):
        all_ok = False

    if not all_ok:
        return {
            "ok": False,
            "published": False,
            "publish_allowed": False,
            "assembly_status": "INCOMPLETE_IDENTITY",
            "identity_results": identity_results,
            "semantic_checks": req_checks,
            "CURRENT_updated": False,
        }

    # Build report before staging so forbidden claims fail closed pre-publish
    try:
        report_cn, report_struct = build_shadow_research_report_cn(
            dg1=dg1,
            rr1=rr1,
            manifest_reference=manifest_reference,
            assembly=assembly,
            subjects=subjects,
            selection_meta=selection_meta if isinstance(selection_meta, list) else None,
        )
    except Exception as e:
        return {
            "ok": False,
            "published": False,
            "publish_allowed": False,
            "reason": f"REPORT_BUILD_FAIL:{e}",
            "CURRENT_updated": False,
            "identity_results": identity_results,
        }

    staging_root = CANDIDATE_STAGING_DIR / f"{rr1}_{_uuid.uuid4().hex[:8]}"
    if staging_root.exists():
        shutil.rmtree(staging_root)
    staging_root.mkdir(parents=True, exist_ok=False)
    try:
        _refuse_formal_paths(staging_root / "probe.json")
        man_ref = dict(manifest_reference)
        man_ref.setdefault("DATA_GENERATION_ID", dg1)
        man_ref.setdefault("RESEARCH_RUN_ID", rr1)
        _write_json_atomic(staging_root / "MANIFEST_REFERENCE.json", man_ref)

        for sid, mods in subjects.items():
            sdir = staging_root / "SUBJECTS" / str(sid)
            sdir.mkdir(parents=True, exist_ok=True)
            mapping = {
                "R3_OUTPUT.json": mods.get("r3") or mods.get("R3_OUTPUT"),
                "CYCLE_CAPITAL_STATE.json": mods.get("cycle") or mods.get("CYCLE_CAPITAL_STATE"),
                "CURRENT_CAPITAL_ACCEPTANCE.json": mods.get("current") or mods.get("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH.json": mods.get("minute") or mods.get("MINUTE_ACCEPTANCE_STRENGTH"),
                "GENERIC_ENTRY_PRICE_IN.json": mods.get("entry") or mods.get("GENERIC_ENTRY_PRICE_IN"),
            }
            for fname, obj in mapping.items():
                _write_json_atomic(sdir / fname, obj)
            sub_asm = mods.get("assembly") or mods.get("CANDIDATE_ASSEMBLY")
            if isinstance(sub_asm, dict):
                _write_json_atomic(sdir / "CANDIDATE_ASSEMBLY.json", sub_asm)

        run_asm = dict(assembly)
        run_asm["RESEARCH_RUN_ID"] = rr1
        run_asm["DATA_GENERATION_ID"] = dg1
        run_asm["publish_allowed"] = True
        run_asm["published_by"] = "U235"
        run_asm["layout"] = "CANDIDATE/RUNS/<RESEARCH_RUN_ID>"
        run_asm["subjects"] = list(subjects.keys())
        run_asm["empirical_validity"] = "NOT_PROVEN"
        run_asm["real_flow_status"] = run_asm.get("real_flow_status") or (
            (run_asm.get("claim_boundary") or {}).get("real_flow_status") or "UNAVAILABLE"
        )
        run_asm["selection_meta"] = selection_meta
        _write_json_atomic(staging_root / "CANDIDATE_ASSEMBLY.json", run_asm)

        first_sid = next(iter(subjects.keys()))
        first = subjects[first_sid]
        flat_map = {
            "R3_OUTPUT.json": first.get("r3") or first.get("R3_OUTPUT"),
            "CYCLE_CAPITAL_STATE.json": first.get("cycle") or first.get("CYCLE_CAPITAL_STATE"),
            "CURRENT_CAPITAL_ACCEPTANCE.json": first.get("current") or first.get("CURRENT_CAPITAL_ACCEPTANCE"),
            "MINUTE_ACCEPTANCE_STRENGTH.json": first.get("minute") or first.get("MINUTE_ACCEPTANCE_STRENGTH"),
            "GENERIC_ENTRY_PRICE_IN.json": first.get("entry") or first.get("GENERIC_ENTRY_PRICE_IN"),
        }
        for fname, obj in flat_map.items():
            note = dict(obj)
            note["_NOTE"] = "FLAT_ALIAS_FIRST_SUBJECT_ONLY; authoritative under SUBJECTS/"
            note["_FLAT_ALIAS_SUBJECT"] = first_sid
            _write_json_atomic(staging_root / fname, note)

        # Batch8 report artifacts inside run
        (staging_root / "RESEARCH_REPORT_CN.txt").write_text(
            report_cn if report_cn.endswith("\n") else report_cn + "\n", encoding="utf-8"
        )
        _write_json_atomic(staging_root / "RESEARCH_REPORT_STRUCTURED.json", report_struct)
        pending_receipt = {
            "status": "PENDING_MEMORY_HANDOFF",
            "RESEARCH_RUN_ID": rr1,
            "DATA_GENERATION_ID": dg1,
            "candidate_current_advanced": False,
            "updated_at_cn": now_cn(),
        }
        _write_json_atomic(staging_root / "MEMORY_HANDOFF_RECEIPT.json", pending_receipt)

        CANDIDATE_RUNS_DIR.mkdir(parents=True, exist_ok=True)
        if run_dir.exists():
            raise RuntimeError("RUN_ALREADY_EXISTS_RACE")
        staging_root.rename(run_dir)

        current_updated = False
        if update_current_pointer:
            update_candidate_current_pointer(
                research_run_id=rr1,
                data_generation_id=dg1,
                subjects=list(subjects.keys()),
                run_path=run_dir,
            )
            current_updated = True

        return {
            "ok": True,
            "published": True,
            "publish_allowed": True,
            "RESEARCH_RUN_ID": rr1,
            "DATA_GENERATION_ID": dg1,
            "run_path": str(run_dir),
            "CURRENT_pointer": str(CANDIDATE_CURRENT_POINTER),
            "identity_results": identity_results,
            "CURRENT_updated": current_updated,
            "report_cn_path": str(run_dir / "RESEARCH_REPORT_CN.txt"),
            "orphan_recoverable": (not current_updated),
            "report_structured": report_struct,
            "report_cn": report_cn,
        }
    except Exception as e:
        if staging_root.exists():
            shutil.rmtree(staging_root, ignore_errors=True)
        return {
            "ok": False,
            "published": False,
            "publish_allowed": False,
            "reason": str(e),
            "CURRENT_updated": False,
            "identity_results": identity_results,
        }


def run_shadow_candidate(
    *,
    publish: bool = False,
    paths: dict[str, Any] | None = None,
    force_claims: dict[str, Any] | None = None,
    publish_json_path: Path | None = None,
    publish_txt_path: Path | None = None,
) -> dict[str, Any]:
    paths = paths or {}
    cand = assemble_u235_shadow_candidate(
        manifest_path=paths.get("manifest_path"),
        freeze_path=paths.get("freeze_path"),
        r3_path=paths.get("r3_path"),
        capital_paths=paths.get("capital_paths"),
        entry_path=paths.get("entry_path"),
        force_claims=force_claims,
        entry_explicit_missing=bool(paths.get("entry_explicit_missing")),
        research_run_id=paths.get("research_run_id"),
        skip_identity_gate=bool(paths.get("skip_identity_gate")),
    )
    txt = render_u235_shadow_txt(cand)
    if force_claims and force_claims.get("inject_txt_claim"):
        txt = txt + "\n" + str(force_claims["inject_txt_claim"]) + "\n"
    gate = validate_shadow_claims(cand, txt)
    cand["claim_gate"] = gate
    if gate.get("CLAIM_GATE") != "PASS":
        cand["warnings"] = list(cand.get("warnings") or []) + ["CLAIM_GATE_FAIL_NO_PUBLISH"]
        publish = False
    result = {
        "candidate": cand,
        "txt": txt,
        "claim_gate": gate,
        "published": False,
        "publish_paths": {"json": str(CANDIDATE_JSON_PATH), "txt": str(CANDIDATE_TXT_PATH)},
    }
    if publish:
        atomic_publish_candidate(
            cand,
            txt,
            json_path=publish_json_path,
            txt_path=publish_txt_path,
        )
        result["published"] = True
    print(
        json.dumps(
            {
                "assembly_status": cand.get("assembly_status"),
                "production_eligibility": cand.get("production_eligibility"),
                "final_decision": cand.get("final_decision"),
                "claim_gate": gate,
                "published": result["published"],
            },
            ensure_ascii=False,
            indent=2,
        ),
        flush=True,
    )
    return result



def run_batch2_selftest() -> int:
    """Isolated BATCH_2 shadow assembly tests. Tempfile only. No production writes."""
    import inspect
    import tempfile
    from unittest import mock

    # Batch2 fixtures predate dual-identity; skip identity gate here only.
    _assemble_real = assemble_u235_shadow_candidate

    def assemble_u235_shadow_candidate(**kwargs):  # noqa: F811
        kwargs.setdefault("skip_identity_gate", True)
        return _assemble_real(**kwargs)

    results: list[tuple[str, bool, str]] = []

    def rec(name: str, ok: bool, note: str) -> None:
        results.append((name, ok, note))
        print(f"B2_FIXTURE {name} = {'PASS' if ok else 'FAIL'}  {note}", flush=True)

    def write_json(p: Path, obj: Any) -> None:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def write_text(p: Path, text: str) -> None:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")

    def ok_manifest() -> dict[str, Any]:
        return {
            "manifest_id": "DAILY_DATA_MANIFEST_B2TEST",
            "DAILY_INCREMENTAL_READY": "YES",
            "JQ": {
                "STATUS": "PASS",
                "SOURCE_ASOF": "2026-08-31",
                "CLEAN_ASOF": "2026-08-31",
                "CACHE_ASOF": "2026-08-31",
            },
        }

    def ok_r3() -> dict[str, Any]:
        return {
            "STATUS": "RESEARCH_COMPLETE_R3",
            "DRIFT_AUDIT_STATUS": "PASS",
            "PRIMARY_THEME": "ENERGY",
            "SECONDARY_THEME": "BIOTECH",
            "TOP_FOCUS": [{"code": "601857.SH", "name": "中国石油", "SOURCE_THEME": "ENERGY"}],
            "BUILD_TIME_CN": "2026-08-31T12:00:00+0800",
            "asof": "2026-08-31",
        }

    def ok_cap(pid: str, *, direction: str = "ENERGY", et: str = "DECLARED_FLOW", asof: str = "2026-08-31") -> dict[str, Any]:
        return {
            "product_id": pid,
            "schema_version": "1.0.0",
            "status": "LOADED",
            "asof": asof,
            "subject": "CN_A",
            "universe": "GENERAL",
            "evidence_type": et,
            "quality": "DECLARED",
            "direction": direction,
            "strength": "MED",
            "real_flow_status": "AVAILABLE_DIRECT" if et == "DIRECT_MEASURED_FLOW" else "DECLARED_ONLY",
            "evidence_gaps": [],
        }

    def proxy_cap(pid: str) -> dict[str, Any]:
        return {
            "product_id": pid,
            "schema_version": "1.0.0",
            "status": "LOADED",
            "asof": "2026-08-31",
            "universe": "GENERAL",
            "evidence_type": "PRICE_VOLUME_ACCEPTANCE_PROXY",
            "quality": "PROXY",
            "direction": "ENERGY",
            "strength": "MED",
            "vwap": 10.0,
            "evidence_gaps": [],
        }

    def ok_entry() -> dict[str, Any]:
        return {
            "scope": "GENERAL",
            "status": "LOADED",
            "price_in_status": "WATCH",
            "entry_ladder": {"TIER1": [], "TIER2": []},
            "confirmation_condition": "NONE",
            "invalidation_condition": "NONE",
            "no_good_entry": True,
            "asof": "2026-08-31",
            "universe": "GENERAL",
        }

    freeze_src = FREEZE_R2_CANONICAL_PATH
    summary_path = OUT_CUR / "MASTER_RESEARCH_SUMMARY.txt"
    autorun_path = CURRENT
    summary_before = _sha256_file(summary_path) if summary_path.exists() else None
    autorun_before = _sha256_file(autorun_path) if autorun_path.exists() else None
    cand_json_before = CANDIDATE_JSON_PATH.exists()
    cand_txt_before = CANDIDATE_TXT_PATH.exists()

    # Snapshot mode_run source for dispatch unchanged
    mode_run_src = inspect.getsource(mode_run)
    main_src = inspect.getsource(main)

    with tempfile.TemporaryDirectory(prefix="b2_u235_") as td0:
        td = Path(td0)
        man = td / "manifest.json"
        write_json(man, ok_manifest())
        freeze = td / "freeze_r2.md"
        freeze.write_text(freeze_src.read_text(encoding="utf-8"), encoding="utf-8")
        r3p = td / "r3.json"
        write_json(r3p, ok_r3())

        # 1 MANIFEST_FAIL
        bad_man = td / "bad_man.json"
        write_json(bad_man, {**ok_manifest(), "DAILY_INCREMENTAL_READY": "NO"})
        c = assemble_u235_shadow_candidate(
            manifest_path=bad_man,
            freeze_path=freeze,
            r3_path=r3p,
            capital_paths={
                "CYCLE_CAPITAL_STATE": None,
                "CURRENT_CAPITAL_ACCEPTANCE": None,
                "MINUTE_ACCEPTANCE_STRENGTH": None,
            },
            entry_explicit_missing=True,
        )
        rec(
            "MANIFEST_FAIL",
            c.get("assembly_status") == "BLOCKED_BY_DATA_GATE"
            and c.get("production_eligibility") == "NO"
            and c.get("inputs") is None,
            f"status={c.get('assembly_status')}",
        )

        # 2 FREEZE_MISSING
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=td / "missing_freeze.md",
            r3_path=r3p,
            capital_paths={
                "CYCLE_CAPITAL_STATE": None,
                "CURRENT_CAPITAL_ACCEPTANCE": None,
                "MINUTE_ACCEPTANCE_STRENGTH": None,
            },
            entry_explicit_missing=True,
        )
        rec("FREEZE_MISSING", c.get("assembly_status") == "BLOCKED_BY_FREEZE", f"status={c.get('assembly_status')}")

        # 3 R3_MISSING
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=td / "no_r3.json",
            capital_paths={
                "CYCLE_CAPITAL_STATE": None,
                "CURRENT_CAPITAL_ACCEPTANCE": None,
                "MINUTE_ACCEPTANCE_STRENGTH": None,
            },
            entry_explicit_missing=True,
        )
        rec(
            "R3_MISSING",
            c.get("assembly_status") == "INCOMPLETE"
            and (c.get("inputs") or {}).get("r3_structure_trend", {}).get("R3_INPUT_STATUS") == "INCOMPLETE",
            f"status={c.get('assembly_status')}",
        )

        # 4 R3_UNSTRUCTURED_TEXT_ONLY
        r3txt = td / "r3.txt"
        write_text(r3txt, "PRIMARY_THEME=ENERGY but free text only\n")
        # force json path with invalid json content via .json suffix
        r3bad = td / "r3_unstructured.json"
        write_text(r3bad, "not json theme ENERGY")
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=r3bad,
            capital_paths={
                "CYCLE_CAPITAL_STATE": None,
                "CURRENT_CAPITAL_ACCEPTANCE": None,
                "MINUTE_ACCEPTANCE_STRENGTH": None,
            },
            entry_explicit_missing=True,
        )
        gaps = json.dumps(c.get("evidence_gaps") or [], ensure_ascii=False)
        rec(
            "R3_UNSTRUCTURED_TEXT_ONLY",
            c.get("assembly_status") == "INCOMPLETE" and "R3_UNSTRUCTURED_TEXT_ONLY" in gaps,
            f"gaps_has={('R3_UNSTRUCTURED_TEXT_ONLY' in gaps)}",
        )

        def caps_paths(mapping: dict[str, dict[str, Any] | None]) -> dict[str, Path | None]:
            out: dict[str, Path | None] = {}
            for k, v in mapping.items():
                if v is None:
                    out[k] = None
                else:
                    pp = td / f"{k}.json"
                    write_json(pp, v)
                    out[k] = pp
            return out

        # 5 ALL_CAPITAL_PRODUCTS_MISSING
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=r3p,
            capital_paths=caps_paths(
                {
                    "CYCLE_CAPITAL_STATE": None,
                    "CURRENT_CAPITAL_ACCEPTANCE": None,
                    "MINUTE_ACCEPTANCE_STRENGTH": None,
                }
            ),
            entry_path=(td / "entry.json"),
        )
        write_json(td / "entry.json", ok_entry())
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=r3p,
            capital_paths={
                "CYCLE_CAPITAL_STATE": None,
                "CURRENT_CAPITAL_ACCEPTANCE": None,
                "MINUTE_ACCEPTANCE_STRENGTH": None,
            },
            entry_path=td / "entry.json",
        )
        rec(
            "ALL_CAPITAL_PRODUCTS_MISSING",
            c.get("assembly_status") == "INCOMPLETE"
            and (c.get("direction_alignment") or {}).get("status") == "UNKNOWN",
            f"status={c.get('assembly_status')} dir={(c.get('direction_alignment') or {}).get('status')}",
        )

        # 6 CYCLE_MISSING
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": None,
                "CURRENT_CAPITAL_ACCEPTANCE": ok_cap("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": ok_cap("MINUTE_ACCEPTANCE_STRENGTH"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=td / "entry.json"
        )
        rec("CYCLE_MISSING", c.get("assembly_status") == "INCOMPLETE", f"status={c.get('assembly_status')}")

        # 7 CURRENT_PROXY_ONLY
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": ok_cap("CYCLE_CAPITAL_STATE"),
                "CURRENT_CAPITAL_ACCEPTANCE": proxy_cap("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": ok_cap("MINUTE_ACCEPTANCE_STRENGTH"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=td / "entry.json"
        )
        cur = (c.get("inputs") or {}).get("current_capital_acceptance") or {}
        txt = render_u235_shadow_txt(c)
        gate = validate_shadow_claims(c, txt)
        rec(
            "CURRENT_PROXY_ONLY",
            cur.get("evidence_type") == "PRICE_VOLUME_ACCEPTANCE_PROXY"
            and cur.get("real_flow_status") == "UNAVAILABLE"
            and "本结论基于价量承接代理" in txt
            and gate.get("CLAIM_GATE") == "PASS",
            f"et={cur.get('evidence_type')} claim={gate.get('CLAIM_GATE')}",
        )

        # 8 CURRENT_PROXY_WITH_REAL_FLOW_CLAIM
        c2 = dict(c)
        c2["warnings"] = list(c.get("warnings") or []) + ["资金确认流入"]
        gate2 = validate_shadow_claims(c2, txt)
        rec(
            "CURRENT_PROXY_WITH_REAL_FLOW_CLAIM",
            gate2.get("CLAIM_GATE") == "FAIL",
            f"claim={gate2.get('CLAIM_GATE')} hits={gate2.get('forbidden_hits')}",
        )

        # 9 MINUTE_MISSING
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": ok_cap("CYCLE_CAPITAL_STATE"),
                "CURRENT_CAPITAL_ACCEPTANCE": ok_cap("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": None,
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=td / "entry.json"
        )
        rec("MINUTE_MISSING", c.get("assembly_status") == "INCOMPLETE", f"status={c.get('assembly_status')}")

        # 10 REFINING_SAMPLE_REJECTED
        refining = ok_cap("CYCLE_CAPITAL_STATE")
        refining["case_sample"] = True
        refining["universe"] = "ENERGY_REFINING_20260828"
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": refining,
                "CURRENT_CAPITAL_ACCEPTANCE": ok_cap("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": ok_cap("MINUTE_ACCEPTANCE_STRENGTH"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=td / "entry.json"
        )
        cy = (c.get("inputs") or {}).get("cycle_capital_state") or {}
        rec(
            "REFINING_SAMPLE_REJECTED",
            cy.get("status") == "INCOMPLETE"
            and cy.get("artifact_rejected") == "CASE_SPECIFIC_ARTIFACT_REJECTED",
            f"rejected={cy.get('artifact_rejected')} status={cy.get('status')}",
        )

        # 11 GENERIC_ENTRY_MISSING
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": ok_cap("CYCLE_CAPITAL_STATE"),
                "CURRENT_CAPITAL_ACCEPTANCE": ok_cap("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": ok_cap("MINUTE_ACCEPTANCE_STRENGTH"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=r3p,
            capital_paths=cp,
            entry_explicit_missing=True,
        )
        rec(
            "GENERIC_ENTRY_MISSING",
            c.get("assembly_status") == "INCOMPLETE"
            and (c.get("inputs") or {}).get("entry_price_in", {}).get("ENTRY_STATUS") == "INCOMPLETE",
            f"status={c.get('assembly_status')}",
        )

        # 12 REFINING_ENTRY_REJECTED
        ent_ref = ok_entry()
        ent_ref["scope"] = "ENERGY_REFINING"
        ent_ref["case_sample"] = True
        ep = td / "entry_refining.json"
        write_json(ep, ent_ref)
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=ep
        )
        ent = (c.get("inputs") or {}).get("entry_price_in") or {}
        rec(
            "REFINING_ENTRY_REJECTED",
            ent.get("ENTRY_STATUS") == "INCOMPLETE"
            and ent.get("artifact_rejected") == "CASE_SPECIFIC_ARTIFACT_REJECTED",
            f"rejected={ent.get('artifact_rejected')}",
        )

        # 13 DIRECTION_SCHEMA_NOT_COMPARABLE — capitals loaded but no direction fields
        nodir = ok_cap("CYCLE_CAPITAL_STATE")
        nodir.pop("direction", None)
        nodir["direction"] = None
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": {**ok_cap("CYCLE_CAPITAL_STATE"), "direction": None},
                "CURRENT_CAPITAL_ACCEPTANCE": {**ok_cap("CURRENT_CAPITAL_ACCEPTANCE"), "direction": None},
                "MINUTE_ACCEPTANCE_STRENGTH": {**ok_cap("MINUTE_ACCEPTANCE_STRENGTH"), "direction": None},
            }
        )
        # force status LOADED with null directions
        for k, pth in cp.items():
            if pth:
                obj = json.loads(pth.read_text(encoding="utf-8"))
                obj["direction"] = None
                write_json(pth, obj)
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=td / "entry.json"
        )
        da = c.get("direction_alignment") or {}
        rec(
            "DIRECTION_SCHEMA_NOT_COMPARABLE",
            da.get("status") == "UNKNOWN"
            and "DIRECTION_SCHEMA_NOT_COMPARABLE" in (da.get("reason_codes") or []),
            f"da={da.get('status')} reasons={da.get('reason_codes')}",
        )

        # 14 ASOF_MISMATCH
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": ok_cap("CYCLE_CAPITAL_STATE", asof="2026-08-30"),
                "CURRENT_CAPITAL_ACCEPTANCE": ok_cap("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": ok_cap("MINUTE_ACCEPTANCE_STRENGTH"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=td / "entry.json"
        )
        rec(
            "ASOF_MISMATCH",
            c.get("assembly_status") == "INCOMPLETE"
            and any("ASOF_MISMATCH" in str(x) for x in (c.get("warnings") or [])),
            f"status={c.get('assembly_status')} warnings={c.get('warnings')}",
        )

        # 15 FORBIDDEN_CLAIM_IN_JSON
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": ok_cap("CYCLE_CAPITAL_STATE"),
                "CURRENT_CAPITAL_ACCEPTANCE": proxy_cap("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": ok_cap("MINUTE_ACCEPTANCE_STRENGTH"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=r3p,
            capital_paths=cp,
            entry_path=td / "entry.json",
            force_claims={"inject_json_claim": "主力进场"},
        )
        txt = render_u235_shadow_txt(c)
        gate = validate_shadow_claims(c, txt)
        rec("FORBIDDEN_CLAIM_IN_JSON", gate.get("CLAIM_GATE") == "FAIL", f"hits={gate.get('forbidden_hits')}")

        # 16 FORBIDDEN_CLAIM_IN_TXT
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=td / "entry.json"
        )
        txt = render_u235_shadow_txt(c) + "\n真实资金承接\n"
        gate = validate_shadow_claims(c, txt)
        rec("FORBIDDEN_CLAIM_IN_TXT", gate.get("CLAIM_GATE") == "FAIL", f"hits={gate.get('forbidden_hits')}")

        # 17 ALL_SYNTHETIC_INPUTS_COMPLETE
        cp = caps_paths(
            {
                "CYCLE_CAPITAL_STATE": ok_cap("CYCLE_CAPITAL_STATE", et="DIRECT_MEASURED_FLOW"),
                "CURRENT_CAPITAL_ACCEPTANCE": ok_cap("CURRENT_CAPITAL_ACCEPTANCE", et="DIRECT_MEASURED_FLOW"),
                "MINUTE_ACCEPTANCE_STRENGTH": ok_cap("MINUTE_ACCEPTANCE_STRENGTH", et="DIRECT_MEASURED_FLOW"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=td / "entry.json"
        )
        rec(
            "ALL_SYNTHETIC_INPUTS_COMPLETE",
            c.get("assembly_status") == "COMPLETE_SHADOW"
            and c.get("production_eligibility") == "NO"
            and (c.get("final_decision") or {}).get("status") == "SHADOW_CANDIDATE_ONLY",
            f"status={c.get('assembly_status')} fd={(c.get('final_decision') or {}).get('status')}",
        )

        # Hard: only this fixture may be COMPLETE_SHADOW among prior fixtures — checked at end

        # 18 SHADOW_DEFAULT_NO_WRITE
        out_json = td / "pub" / "cand.json"
        out_txt = td / "pub" / "cand.txt"
        res = run_shadow_candidate(
            publish=False,
            paths={
                "manifest_path": man,
                "freeze_path": freeze,
                "r3_path": r3p,
                "capital_paths": cp,
                "entry_path": td / "entry.json",
            },
        )
        rec(
            "SHADOW_DEFAULT_NO_WRITE",
            res.get("published") is False and not out_json.exists() and not CANDIDATE_JSON_PATH.exists(),
            f"published={res.get('published')} cand_exists={CANDIDATE_JSON_PATH.exists()}",
        )

        # 19 LIVE_SUMMARY_UNCHANGED
        summary_after = _sha256_file(summary_path) if summary_path.exists() else None
        rec("LIVE_SUMMARY_UNCHANGED", summary_before == summary_after, f"before={summary_before} after={summary_after}")

        # 20 AUTORUN_CURRENT_UNCHANGED
        autorun_after = _sha256_file(autorun_path) if autorun_path.exists() else None
        rec(
            "AUTORUN_CURRENT_UNCHANGED",
            autorun_before == autorun_after,
            f"before={autorun_before} after={autorun_after}",
        )

        # 21 EXISTING_MODE_RUN_DISPATCH_UNCHANGED
        ok_dispatch = (
            "if args.mode == \"run\":" in main_src
            and "return mode_run(" in main_src
            and "run_blackbox_global_leadership_first_mapping_r3.py" in mode_run_src
            and "subprocess.call" in mode_run_src
            and "shadow_candidate" not in mode_run_src
        )
        rec("EXISTING_MODE_RUN_DISPATCH_UNCHANGED", ok_dispatch, "mode_run body still R3 path; shadow not inside mode_run")

        # 22 BATCH1_MANIFEST_GATE_REUSED
        # Same function object used by assemble
        g1 = load_and_evaluate_canonical_manifest_gate(bad_man)
        # assemble used same function — prove by identity of reason
        c_block = assemble_u235_shadow_candidate(manifest_path=bad_man, freeze_path=freeze, r3_path=r3p)
        rec(
            "BATCH1_MANIFEST_GATE_REUSED",
            g1.get("reason_code") == "MANIFEST_NOT_READY"
            and c_block.get("assembly_status") == "BLOCKED_BY_DATA_GATE"
            and (c_block.get("data_manifest") or {}).get("reason_code") == g1.get("reason_code"),
            f"gate={g1.get('reason_code')}",
        )

        # Ensure no COMPLETE_SHADOW except ALL_SYNTHETIC
        complete_names = [n for n, o, note in results if o and "COMPLETE_SHADOW" in note and n != "ALL_SYNTHETIC_INPUTS_COMPLETE"]
        # stronger: re-check failed fixtures didn't claim complete — scan PASS notes for wrong complete
        illegal = []
        for n, o, note in results:
            if n == "ALL_SYNTHETIC_INPUTS_COMPLETE":
                continue
            if o and "status=COMPLETE_SHADOW" in note:
                illegal.append(n)
        rec("NO_FALSE_COMPLETE_SHADOW", len(illegal) == 0, f"illegal={illegal}")

        # Candidate paths still absent / unchanged existence
        rec(
            "CANDIDATE_PATHS_UNTOUCHED",
            CANDIDATE_JSON_PATH.exists() == cand_json_before and CANDIDATE_TXT_PATH.exists() == cand_txt_before,
            f"json={CANDIDATE_JSON_PATH.exists()} txt={CANDIDATE_TXT_PATH.exists()}",
        )

    failed = [n for n, o, _ in results if not o]
    print(f"B2_SELFTEST_TOTAL={len(results)} PASS={len(results)-len(failed)} FAIL={len(failed)}", flush=True)
    if failed:
        print(f"B2_SELFTEST_FAILED={failed}", flush=True)
        return 1
    print("B2_BATCH2_SELFTEST=PASS", flush=True)
    print("REAL_SUBPROCESSES_LAUNCHED=0", flush=True)
    print("PRODUCTION_FILES_WRITTEN=0", flush=True)
    return 0



def run_batch3_selftest() -> int:
    """BATCH_3: U235 consumes capital proxy products. Tempfile only."""
    import inspect
    import tempfile
    from copy import deepcopy

    results: list[tuple[str, bool, str]] = []

    def rec(name: str, ok: bool, note: str) -> None:
        results.append((name, ok, note))
        print(f"B3_FIXTURE {name} = {'PASS' if ok else 'FAIL'}  {note}", flush=True)

    def write_json(p: Path, obj: Any) -> None:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def ok_manifest() -> dict[str, Any]:
        return {
            "manifest_id": "DAILY_DATA_MANIFEST_B3",
            "DAILY_INCREMENTAL_READY": "YES",
            "JQ": {
                "STATUS": "PASS",
                "SOURCE_ASOF": "2026-08-31",
                "CLEAN_ASOF": "2026-08-31",
                "CACHE_ASOF": "2026-08-31",
            },
        }

    def ok_r3() -> dict[str, Any]:
        return {
            "STATUS": "RESEARCH_COMPLETE_R3",
            "DRIFT_AUDIT_STATUS": "PASS",
            "PRIMARY_THEME": "ENERGY",
            "TOP_FOCUS": [{"code": "601857.SH", "name": "中国石油", "SOURCE_THEME": "ENERGY"}],
            "BUILD_TIME_CN": "2026-08-31T12:00:00+0800",
            "asof": "2026-08-31",
        }

    def ok_entry() -> dict[str, Any]:
        return {
            "scope": "GENERAL",
            "status": "LOADED",
            "price_in_status": "WATCH",
            "entry_ladder": {"TIER1": [], "TIER2": []},
            "confirmation_condition": "NONE",
            "invalidation_condition": "NONE",
            "no_good_entry": True,
            "asof": "2026-08-31",
            "universe": "GENERAL",
        }

    def proxy_product(pid: str, *, computation_status: str = "PASS", pit_pass: bool = True, direction: str = "SUPPORTING_PROXY") -> dict[str, Any]:
        return {
            "schema_version": "U235_CAPITAL_PROXY_R1",
            "product_id": f"{pid}_PROXY" if not pid.endswith("_PROXY") else pid,
            "subject_type": "INSTRUMENT",
            "subject_id": "TEST",
            "universe": "GENERAL",
            "asof": "2026-08-31",
            "cutoff_time": "2026-08-31T15:00:00+0800",
            "computation_status": computation_status,
            "validation_status": "UNCALIBRATED",
            "evidence_type": "PRICE_VOLUME_ACCEPTANCE_PROXY",
            "real_flow_status": "UNAVAILABLE",
            "FORMAL_FLOW_CONFIRMATION_ALLOWED": False,
            "quality": "PROXY_UNCALIBRATED",
            "direction_proxy": direction,
            "measurements": {"note": "synthetic"},
            "source_paths": [],
            "source_sha256": {},
            "max_input_timestamp": "2026-08-31T15:00:00+0800",
            "pit_pass": pit_pass,
            "evidence_gaps": [],
            "warnings": ["UNCALIBRATED"],
            "proxy_disclaimer": "本产品只测量价量承接代理，不代表已测得真实资金流。",
            "ORDER_ALLOWED": False,
        }

    summary_path = OUT_CUR / "MASTER_RESEARCH_SUMMARY.txt"
    autorun_path = CURRENT
    summary_before = _sha256_file(summary_path) if summary_path.exists() else None
    autorun_before = _sha256_file(autorun_path) if autorun_path.exists() else None
    mode_run_src = inspect.getsource(mode_run)
    gate_fn = load_and_evaluate_canonical_manifest_gate
    schema_ver = SHADOW_SCHEMA_VERSION

    with tempfile.TemporaryDirectory(prefix="b3_u235_") as td0:
        td = Path(td0)
        man = td / "manifest.json"
        write_json(man, ok_manifest())
        freeze = td / "freeze_r2.md"
        freeze.write_text(FREEZE_R2_CANONICAL_PATH.read_text(encoding="utf-8"), encoding="utf-8")
        r3p = td / "r3.json"
        write_json(r3p, ok_r3())
        entry_p = td / "entry.json"
        write_json(entry_p, ok_entry())

        def caps(mapping: dict[str, dict[str, Any] | None]) -> dict[str, Path | None]:
            out: dict[str, Path | None] = {}
            for k, v in mapping.items():
                if v is None:
                    out[k] = None
                else:
                    pp = td / f"{k}.json"
                    write_json(pp, v)
                    out[k] = pp
            return out

        # 25 THREE_PRODUCTS_MISSING
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=r3p,
            capital_paths={
                "CYCLE_CAPITAL_STATE": None,
                "CURRENT_CAPITAL_ACCEPTANCE": None,
                "MINUTE_ACCEPTANCE_STRENGTH": None,
            },
            entry_path=entry_p,
        )
        rec(
            "THREE_PRODUCTS_MISSING",
            c.get("assembly_status") == "INCOMPLETE"
            and (c.get("final_decision") or {}).get("status") == "NO_FORMAL_DECISION",
            f"status={c.get('assembly_status')}",
        )

        # 26 ONE_PRODUCT_MISSING
        cp = caps(
            {
                "CYCLE_CAPITAL_STATE": proxy_product("CYCLE_CAPITAL_STATE"),
                "CURRENT_CAPITAL_ACCEPTANCE": proxy_product("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": None,
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=entry_p
        )
        rec("ONE_PRODUCT_MISSING", c.get("assembly_status") == "INCOMPLETE", c.get("assembly_status"))

        # 27 THREE_PRODUCTS_PASS_UNCALIBRATED (+ entry) → COMPLETE_SHADOW still production NO
        cp = caps(
            {
                "CYCLE_CAPITAL_STATE": proxy_product("CYCLE_CAPITAL_STATE"),
                "CURRENT_CAPITAL_ACCEPTANCE": proxy_product("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": proxy_product("MINUTE_ACCEPTANCE_STRENGTH"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp, entry_path=entry_p
        )
        vals = [
            ((c.get("inputs") or {}).get(k) or {}).get("validation_status")
            for k in (
                "cycle_capital_state",
                "current_capital_acceptance",
                "minute_acceptance_strength",
            )
        ]
        rec(
            "THREE_PRODUCTS_PASS_UNCALIBRATED",
            c.get("assembly_status") == "COMPLETE_SHADOW"
            and c.get("production_eligibility") == "NO"
            and (c.get("final_decision") or {}).get("formal_decision_allowed") is False
            and all(v == "UNCALIBRATED" for v in vals),
            f"status={c.get('assembly_status')} vals={vals}",
        )

        # 28 THREE_PRODUCTS_PASS_ENTRY_MISSING
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=r3p,
            capital_paths=cp,
            entry_explicit_missing=True,
        )
        rec(
            "THREE_PRODUCTS_PASS_ENTRY_MISSING",
            c.get("assembly_status") == "INCOMPLETE"
            and (c.get("final_decision") or {}).get("status") == "NO_FORMAL_DECISION",
            f"status={c.get('assembly_status')} fd={(c.get('final_decision') or {}).get('status')}",
        )

        # 29 PRODUCT_PIT_FAIL
        bad_pit = proxy_product("CYCLE_CAPITAL_STATE", pit_pass=False)
        cp2 = caps(
            {
                "CYCLE_CAPITAL_STATE": bad_pit,
                "CURRENT_CAPITAL_ACCEPTANCE": proxy_product("CURRENT_CAPITAL_ACCEPTANCE"),
                "MINUTE_ACCEPTANCE_STRENGTH": proxy_product("MINUTE_ACCEPTANCE_STRENGTH"),
            }
        )
        c = assemble_u235_shadow_candidate(
            manifest_path=man, freeze_path=freeze, r3_path=r3p, capital_paths=cp2, entry_path=entry_p
        )
        cy = (c.get("inputs") or {}).get("cycle_capital_state") or {}
        rec(
            "PRODUCT_PIT_FAIL",
            c.get("assembly_status") == "INCOMPLETE"
            and cy.get("status") == "INCOMPLETE"
            and (c.get("direction_alignment") or {}).get("status") == "UNKNOWN",
            f"cy={cy.get('status')} dir={(c.get('direction_alignment') or {}).get('status')}",
        )

        # 30 CLAIM_GATE_FAIL
        c = assemble_u235_shadow_candidate(
            manifest_path=man,
            freeze_path=freeze,
            r3_path=r3p,
            capital_paths=cp,
            entry_path=entry_p,
            force_claims={"inject_json_claim": "主力进场"},
        )
        txt = render_u235_shadow_txt(c)
        gate = validate_shadow_claims(c, txt)
        rec("CLAIM_GATE_FAIL", gate.get("CLAIM_GATE") == "FAIL", str(gate.get("forbidden_hits")))

        # 31 EXISTING_MODE_RUN_UNCHANGED
        rec(
            "EXISTING_MODE_RUN_UNCHANGED",
            "run_blackbox_global_leadership_first_mapping_r3.py" in mode_run_src
            and "subprocess.call" in mode_run_src
            and "shadow_candidate" not in mode_run_src,
            "mode_run intact",
        )

        # 32 LIVE_SUMMARY_UNCHANGED
        summary_after = _sha256_file(summary_path) if summary_path.exists() else None
        rec("LIVE_SUMMARY_UNCHANGED", summary_before == summary_after, "sha")

        # 33 AUTORUN_CURRENT_UNCHANGED
        autorun_after = _sha256_file(autorun_path) if autorun_path.exists() else None
        rec("AUTORUN_CURRENT_UNCHANGED", autorun_before == autorun_after, "sha")

        # 34 BATCH1_GATE_UNCHANGED
        bad_man = td / "bad.json"
        write_json(bad_man, {**ok_manifest(), "DAILY_INCREMENTAL_READY": "DEGRADED"})
        g = gate_fn(bad_man)
        rec(
            "BATCH1_GATE_UNCHANGED",
            g.get("reason_code") == "MANIFEST_NOT_READY" and g.get("STATUS") == "FAIL",
            g.get("reason_code"),
        )

        # 35 BATCH2_SHADOW_SCHEMA_UNCHANGED
        rec(
            "BATCH2_SHADOW_SCHEMA_UNCHANGED",
            schema_ver == "U235_SHADOW_MAIN_RESEARCH_R1",
            schema_ver,
        )

    failed = [n for n, o, _ in results if not o]
    print(f"B3_U235_SELFTEST_TOTAL={len(results)} PASS={len(results)-len(failed)} FAIL={len(failed)}", flush=True)
    if failed:
        print(f"B3_U235_SELFTEST_FAILED={failed}", flush=True)
        return 1
    print("B3_U235_SELFTEST=PASS", flush=True)
    print("REAL_SUBPROCESSES_LAUNCHED=0", flush=True)
    print("PRODUCTION_FILES_WRITTEN=0", flush=True)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="MASTER RESEARCH AUTORUN CHARTER R1 — 研究策略")
    ap.add_argument("--mode", default="status", choices=["status", "gate", "wait", "research", "run", "shadow_candidate"])
    ap.add_argument("--delay-hours", type=float, default=0.0)
    ap.add_argument("--today-first-run", action="store_true")
    ap.add_argument("--poll-sec", type=int, default=120)
    ap.add_argument(
        "--batch1-selftest",
        action="store_true",
        help="BATCH_1 isolated gates selftest; no production CURRENT/R3/Summary writes",
    )
    ap.add_argument(
        "--batch2-selftest",
        action="store_true",
        help="BATCH_2 isolated shadow assembly selftest; tempfile only; no production writes",
    )
    ap.add_argument(
        "--batch3-selftest",
        action="store_true",
        help="BATCH_3 capital proxy consumption selftest; tempfile only; no production writes",
    )
    ap.add_argument(
        "--publish-candidate",
        action="store_true",
        help="Only with --mode shadow_candidate: write Candidate JSON/TXT (forbidden in this batch runtime)",
    )
    args = ap.parse_args()
    if args.batch1_selftest:
        return batch1_u235_selftest()
    if args.batch2_selftest:
        return run_batch2_selftest()
    if args.batch3_selftest:
        return run_batch3_selftest()
    if args.mode == "status":
        body = mode_gate()
        print(json.dumps(body, ensure_ascii=False, indent=2))
        return 0
    if args.mode == "gate":
        body = mode_gate()
        print(json.dumps(body, ensure_ascii=False, indent=2))
        return 0 if body.get("FORMAL_RESEARCH_ALLOWED") else 2
    if args.mode == "wait":
        body = mode_wait(poll_sec=args.poll_sec)
        print(json.dumps(body, ensure_ascii=False, indent=2))
        return 0 if body.get("FORMAL_RESEARCH_ALLOWED") else 2
    if args.mode == "research":
        body = mode_gate()
        if not body.get("FORMAL_RESEARCH_ALLOWED"):
            print("FORMAL_RESEARCH_ALLOWED=NO — refusing premature research", flush=True)
            return 2
        cols = collector_snapshot()
        mg = load_and_evaluate_canonical_manifest_gate()
        result = run_research(today_cn(), data_gate(cols, manifest_gate=mg), authority_pit_gate())
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.mode == "run":
        return mode_run(delay_hours=args.delay_hours, today_first=args.today_first_run, poll_sec=args.poll_sec)
    if args.mode == "shadow_candidate":
        # Default: assemble+print only. --publish-candidate required to write Candidate paths.
        run_shadow_candidate(publish=bool(args.publish_candidate))
        return 0
    return 2


def batch1_u235_selftest() -> int:
    """Isolated BATCH_1 tests. Reuses production gate functions. No real R3 / CURRENT / Summary."""
    import tempfile
    from unittest import mock

    results: list[tuple[str, bool, str]] = []

    def rec(name: str, ok: bool, note: str) -> None:
        results.append((name, ok, note))
        print(f"U235_FIXTURE {name} = {'PASS' if ok else 'FAIL'}  {note}", flush=True)

    def write_man(p: Path, obj: Any) -> None:
        p.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(obj, str):
            p.write_text(obj, encoding="utf-8")
        else:
            p.write_text(json.dumps(obj, ensure_ascii=False) + "\n", encoding="utf-8")

    def base_ok() -> dict[str, Any]:
        return {
            "manifest_id": "DAILY_DATA_MANIFEST_TEST",
            "DAILY_INCREMENTAL_READY": "YES",
            "JQ": {
                "STATUS": "PASS",
                "SOURCE_ASOF": "2026-08-31",
                "CLEAN_ASOF": "2026-08-31",
                "CACHE_ASOF": "2026-08-31",
            },
        }

    # --- Manifest gate cases ---
    cases = [
        ("MANIFEST_MISSING", None, "MANIFEST_MISSING", True),
        ("MANIFEST_INVALID_JSON", "{bad", "MANIFEST_INVALID_JSON", False),
        ("MANIFEST_NOT_OBJECT", ["x"], "MANIFEST_NOT_OBJECT", False),
        ("MANIFEST_ID_MISSING", {**base_ok(), "manifest_id": ""}, "MANIFEST_ID_MISSING", False),
        ("READY_MISSING", {k: v for k, v in base_ok().items() if k != "DAILY_INCREMENTAL_READY"}, "MANIFEST_READY_MISSING", False),
        ("READY_NO", {**base_ok(), "DAILY_INCREMENTAL_READY": "NO"}, "MANIFEST_NOT_READY", False),
        ("READY_DEGRADED", {**base_ok(), "DAILY_INCREMENTAL_READY": "DEGRADED"}, "MANIFEST_NOT_READY", False),
        ("JQ_STATUS_MISSING", {**base_ok(), "JQ": {**base_ok()["JQ"], "STATUS": None}}, "JQ_STATUS_MISSING", False),
        ("JQ_STATUS_NO", {**base_ok(), "JQ": {**base_ok()["JQ"], "STATUS": "NO"}}, "JQ_STATUS_NOT_PASS", False),
        ("SOURCE_NULL", {**base_ok(), "JQ": {**base_ok()["JQ"], "SOURCE_ASOF": None}}, "SOURCE_ASOF_NULL", False),
        ("CLEAN_NULL", {**base_ok(), "JQ": {**base_ok()["JQ"], "CLEAN_ASOF": None}}, "CLEAN_ASOF_NULL", False),
        ("CACHE_NULL", {**base_ok(), "JQ": {**base_ok()["JQ"], "CACHE_ASOF": None}}, "CACHE_ASOF_NULL", False),
        ("INVALID_ASOF_FORMAT", {**base_ok(), "JQ": {**base_ok()["JQ"], "SOURCE_ASOF": "31-08-2026"}}, "INVALID_ASOF_FORMAT", False),
        (
            "SOURCE_CLEAN_MISMATCH",
            {**base_ok(), "JQ": {**base_ok()["JQ"], "SOURCE_ASOF": "2026-08-31", "CLEAN_ASOF": "2026-08-30", "CACHE_ASOF": "2026-08-30"}},
            "SOURCE_CLEAN_MISMATCH",
            False,
        ),
        (
            "SOURCE_CACHE_MISMATCH",
            {**base_ok(), "JQ": {**base_ok()["JQ"], "CACHE_ASOF": "2026-08-30"}},
            "SOURCE_CACHE_MISMATCH",
            False,
        ),
        (
            "CLEAN_CACHE_MISMATCH",
            {**base_ok(), "JQ": {**base_ok()["JQ"], "CLEAN_ASOF": "2026-08-30"}},
            "CLEAN_CACHE_MISMATCH",
            False,
        ),
    ]
    for name, payload, expect_reason, missing_file in cases:
        with tempfile.TemporaryDirectory(prefix="b1_u235_") as td:
            mp = Path(td) / "m.json"
            if not missing_file:
                write_man(mp, payload)
            g = load_and_evaluate_canonical_manifest_gate(mp if not missing_file else mp)
            ok = g["STATUS"] == "FAIL" and g["reason_code"] == expect_reason
            rec(name, ok, f"reason={g.get('reason_code')} status={g.get('STATUS')}")

    # AUTHORITY / PIT composition
    ok = formal_research_allowed(data_gate="PASS", manifest_gate="PASS", authority_gate="FAIL", pit_gate="PASS") is False
    rec("AUTHORITY_FAIL", ok, "formal=False")
    ok = formal_research_allowed(data_gate="PASS", manifest_gate="PASS", authority_gate="PASS", pit_gate="FAIL") is False
    rec("PIT_FAIL", ok, "formal=False")

    # R29 wait policy — no PASS after 1800
    body_wait = {
        "DATA_GATE": "WAIT",
        "MANIFEST_GATE": "PASS",
        "AUTHORITY_GATE": "PASS",
        "PIT_GATE": "PASS",
        "waiting": [{"id": "R29_FULL_CHAIN"}],
    }
    t1 = resolve_wait_tick(body=body_wait, elapsed_sec=100.0, max_hours=8.0)
    ok = t1.get("_wait_action") == "CONTINUE" and t1.get("reason_code") == "R29_WAITING" and t1.get("DATA_GATE") != "PASS"
    rec("R29_RUNNING_BELOW_TIMEOUT", ok, f"action={t1.get('_wait_action')} reason={t1.get('reason_code')}")
    t2 = resolve_wait_tick(body=body_wait, elapsed_sec=1801.0, max_hours=8.0)
    ok = t2.get("DATA_GATE") != "PASS" and t2.get("_wait_action") == "CONTINUE" and "R29_STALE_RUNNING_SEAL_ALLOWED" not in str(t2)
    rec("R29_RUNNING_ABOVE_1800", ok, f"gate={t2.get('DATA_GATE')} action={t2.get('_wait_action')}")
    t3 = resolve_wait_tick(body=body_wait, elapsed_sec=8.0 * 3600 + 1, max_hours=8.0)
    ok = t3.get("DATA_GATE") == "FAIL" and t3.get("reason_code") == "R29_WAIT_TIMEOUT" and t3.get("R3_SUBPROCESS_ALLOWED") is False
    rec("R29_REACHES_TOTAL_WAIT_LIMIT", ok, f"gate={t3.get('DATA_GATE')} reason={t3.get('reason_code')}")

    # Dead PID: classification must not be PASS
    r29_col_status = classify_terminal("RUNNING", running_hint=True)
    ok = r29_col_status != "PASS" and r29_col_status == "RUNNING"
    rec("R29_DEAD_PID", ok, f"status_norm={r29_col_status} (writeback removed; stays RUNNING/UNVERIFIED)")

    # ALL_GATES_PASS — mock wait + subprocess
    r3_calls: list[Any] = []
    published: list[Any] = []

    def fake_wait(**kwargs: Any) -> dict[str, Any]:
        return {
            "DATA_GATE": "PASS",
            "MANIFEST_GATE": "PASS",
            "AUTHORITY_GATE": "PASS",
            "PIT_GATE": "PASS",
            "FORMAL_RESEARCH_ALLOWED": True,
            "waiting": [],
            "evidence_gaps": [],
            "reason_code": "MANIFEST_GATE_PASS",
        }

    def fake_subcall(cmd: list[str], *a: Any, **k: Any) -> int:
        r3_calls.append(list(cmd))
        return 0

    def fake_publish(body: dict[str, Any]) -> None:
        published.append(body)

    import sys

    mod = sys.modules[__name__]
    with (
        mock.patch.object(mod, "mode_wait", side_effect=fake_wait),
        mock.patch.object(
            mod,
            "load_and_evaluate_canonical_manifest_gate",
            return_value={
                "STATUS": "PASS",
                "reason_code": "MANIFEST_GATE_PASS",
                "manifest_id": "DAILY_DATA_MANIFEST_TEST",
                "source_asof": "2026-08-31",
                "clean_asof": "2026-08-31",
                "cache_asof": "2026-08-31",
                "evidence_gaps": [],
            },
        ),
        mock.patch.object(mod, "publish_current", side_effect=fake_publish),
        mock.patch("subprocess.call", side_effect=fake_subcall),
        mock.patch.object(
            mod,
            "load_json",
            return_value={"DRIFT_AUDIT_STATUS": "PASS", "PRIMARY_THEME": "T", "TOP_FOCUS": []},
        ),
    ):
        rc = mode_run(delay_hours=0.0, today_first=False, poll_sec=1)
    ok = (
        rc == 0
        and len(r3_calls) == 1
        and "run_blackbox_global_leadership_first_mapping_r3.py" in " ".join(r3_calls[0])
        and any(p.get("MODE") == "RESEARCH_COMPLETE_R3" for p in published)
    )
    rec("ALL_GATES_PASS", ok, f"rc={rc} r3_calls={len(r3_calls)} published_modes={[p.get('MODE') for p in published]}")

    # Negative: manifest fail → R3 not called
    r3_calls.clear()
    published.clear()
    with (
        mock.patch.object(
            mod,
            "mode_wait",
            return_value={
                "DATA_GATE": "FAIL",
                "MANIFEST_GATE": "FAIL",
                "AUTHORITY_GATE": "PASS",
                "PIT_GATE": "PASS",
                "reason_code": "MANIFEST_NOT_READY",
                "waiting": [],
                "evidence_gaps": [],
            },
        ),
        mock.patch.object(
            mod,
            "load_and_evaluate_canonical_manifest_gate",
            return_value={
                "STATUS": "FAIL",
                "reason_code": "MANIFEST_NOT_READY",
                "manifest_id": None,
                "evidence_gaps": [],
            },
        ),
        mock.patch.object(mod, "publish_current", side_effect=fake_publish),
        mock.patch("subprocess.call", side_effect=fake_subcall),
    ):
        rc = mode_run(delay_hours=0.0)
    ok = rc != 0 and len(r3_calls) == 0 and all(p.get("MODE") == "GATE" for p in published)
    rec("MANIFEST_FAIL_R3_UNREACHABLE", ok, f"rc={rc} r3={len(r3_calls)}")

    failed = [n for n, o, _ in results if not o]
    print(f"U235_SELFTEST_TOTAL={len(results)} PASS={len(results)-len(failed)} FAIL={len(failed)}", flush=True)
    if failed:
        print(f"U235_SELFTEST_FAILED={failed}", flush=True)
        return 1
    print("U235_BATCH1_SELFTEST=PASS", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
