#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""yyb凌波双低 — R2 PIT 严格版：T 收盘信号 / T+1 开盘成交.

TASK_CLASS = BACKTEST
SOURCE = TUSHARE_CBOND_DAILY_MARKET_R1
       + TUSHARE_CBOND_RATING_PIT_R1
       + TUSHARE_CBOND_CALL_PIT_R1
       + TUSHARE_CBOND_REMAIN_SIZE_PIT_R1
       + TUSHARE_CBOND_BASIC_R1 (list/delist/maturity/cb_type only)
NOT Jisilu / NOT cookie / NOT QMT / NOT R26d / NOT top10 / NOT convert-price rebuild
JQ_EQUIVALENCE = NOT_CLAIMED
FULL_PIT_READY = FALSE  (convert-price PIT still NOT_READY)
CBOND_EVENT_PIT_READY = YES
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path
from typing import Any

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _base import ROOT, FAIL, OK, guarded_write_path, set_runtime_context  # noqa: E402
import blackbox_cbond_dual_low_eod_tplus1_backtest_r1 as loose  # noqa: E402

TASK_CLASS = "BACKTEST"
TASK_SLUG = "可转债双低日频回测_PIT严格_五年_R1"
TASK_DIR = ROOT / "任务" / TASK_SLUG
START_FULL = "20210816"
START_YTD = "20260101"
END = "20260814"
RUN_ID = "CBOND_DUAL_LOW_PIT_STRICT_5Y_EOD_TPLUS1_R1"
STRATEGY_ID = "YYB_LINGBO_DUAL_LOW_PIT_STRICT_EOD_TPLUS1_R1"
CBOND_PTR = ROOT / "数据" / "回测缓存" / "可转债指针" / "CURRENT_CBOND_CACHE_RELEASE.json"
LOOSE_SUMMARY = ROOT / "任务" / "可转债双低日频回测_2026YTD_R1" / "SUMMARY.json"

# 途施 is_call 为中文状态，不是 Y/N。仅「已公告」的强赎才排雷。
REDEEM_ANNOUNCED_TOKENS = ("实施强赎", "提示强赎")


def wjson(path: Path, obj: Any) -> None:
    guarded_write_path(path, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def product_path(ptr: dict[str, Any], product_id: str) -> Path:
    mp = ptr.get("product_path_map") or {}
    if product_id in mp:
        return Path(mp[product_id])
    raise FileNotFoundError(f"product_path_map missing {product_id}")


def read_product_parquet(root: Path) -> pd.DataFrame:
    files = sorted(root.rglob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"no parquet under {root}")
    frames = [pd.read_parquet(p) for p in files]
    return pd.concat(frames, ignore_index=True) if len(frames) > 1 else frames[0]


def rating_passes_pit(rating: Any) -> bool:
    if rating is None or (isinstance(rating, float) and math.isnan(rating)):
        return False
    s = str(rating).strip().upper()
    if s in {"AAA-"}:
        return True
    return loose.rating_passes(s)


def redeem_announced_row(is_call: Any, call_type: Any) -> bool:
    text = f"{'' if is_call is None else is_call} {'' if call_type is None else call_type}"
    return any(tok in text for tok in REDEEM_ANNOUNCED_TOKENS)


def size_to_yi(val: Any, source: Any) -> float:
    try:
        x = float(val)
    except (TypeError, ValueError):
        return float("nan")
    if not math.isfinite(x) or x <= 0:
        return float("nan")
    src = str(source or "")
    if src == "ISSUE_SIZE_INITIAL" and x < 10000:
        return x
    if x > 1e6:
        return x / 1e8
    if x > 200:
        return x / 1e4
    return x


def merge_asof_interval(panel: pd.DataFrame, pit: pd.DataFrame, cols: list[str], code_col: str = "bond_code_ts") -> pd.DataFrame:
    left = panel.copy()
    left[code_col] = left[code_col].astype(str)
    left["_on"] = left["trade_date"].map(loose.ymd).astype("int64")
    left = left.sort_values(["_on", code_col], kind="mergesort")
    right = pit.copy()
    right[code_col] = right[code_col].astype(str)
    right["_vf"] = right["pit_valid_from"].map(loose.ymd)
    if "pit_valid_to" in right.columns:
        right["_vt"] = right["pit_valid_to"].map(loose.ymd)
    else:
        right["_vt"] = "99991231"
    right = right[right["_vf"].notna()].copy()
    right["_on"] = right["_vf"].astype("int64")
    right = right.sort_values(["_on", code_col], kind="mergesort")
    keep = [code_col, "_on", "_vf", "_vt"] + [c for c in cols if c in right.columns]
    merged = pd.merge_asof(
        left,
        right[keep],
        on="_on",
        by=code_col,
        direction="backward",
        suffixes=("", "_pit"),
    )
    invalid = merged["_vf"].isna() | (merged["_vt"].notna() & (merged["_vt"] <= merged["trade_date"]))
    for c in cols:
        if c in merged.columns:
            merged.loc[invalid, c] = pd.NA
    return merged.drop(columns=[c for c in ("_on", "_vf", "_vt") if c in merged.columns])


def merge_asof_latest(panel: pd.DataFrame, pit: pd.DataFrame, cols: list[str], code_col: str = "bond_code_ts") -> pd.DataFrame:
    left = panel.copy()
    left[code_col] = left[code_col].astype(str)
    left["_on"] = left["trade_date"].map(loose.ymd).astype("int64")
    left = left.sort_values(["_on", code_col], kind="mergesort")
    right = pit.copy()
    right[code_col] = right[code_col].astype(str)
    right["_vf"] = right["pit_valid_from"].map(loose.ymd)
    right = right[right["_vf"].notna()].copy()
    right["_on"] = right["_vf"].astype("int64")
    right = right.sort_values(["_on", code_col], kind="mergesort")
    keep = [code_col, "_on"] + [c for c in cols if c in right.columns]
    merged = pd.merge_asof(
        left,
        right[keep],
        on="_on",
        by=code_col,
        direction="backward",
        suffixes=("", "_pit"),
    )
    return merged.drop(columns=[c for c in ("_on",) if c in merged.columns])


def survivors_of_strict(day: pd.DataFrame) -> pd.DataFrame:
    ok = day[
        day["close"].map(loose.valid_px)
        & day["cb_over_rate"].notna()
        & day["dl"].notna()
        & (day["rating_ok"] == True)  # noqa: E712
        & (day["redeem_announced"] != True)  # noqa: E712
        & (day["close"] <= 145)
        & ((day["remain"].isna()) | (day["remain"] >= 0.5))
    ].copy()
    return ok


def survivors_of_loose(day: pd.DataFrame) -> pd.DataFrame:
    ok = day[
        day["close"].map(loose.valid_px)
        & day["cb_over_rate"].notna()
        & day["dl"].notna()
        & (day["rating_ok_loose"] == True)  # noqa: E712
        & (day["close"] <= 145)
        & ((day["remain"].isna()) | (day["remain"] >= 0.5))
    ].copy()
    return ok


def resolve_paths() -> dict[str, Any]:
    if not CBOND_PTR.is_file():
        raise FileNotFoundError(f"CBOND CURRENT missing: {CBOND_PTR}")
    ptr = json.loads(CBOND_PTR.read_text(encoding="utf-8"))
    needed = [
        "TUSHARE_CBOND_DAILY_MARKET_R1",
        "TUSHARE_CBOND_BASIC_R1",
        "TUSHARE_CBOND_RATING_PIT_R1",
        "TUSHARE_CBOND_CALL_PIT_R1",
        "TUSHARE_CBOND_REMAIN_SIZE_PIT_R1",
    ]
    paths = {k: str(product_path(ptr, k)) for k in needed}
    return {
        "cache_release_id": ptr.get("cache_release_id"),
        "parent_release_id": ptr.get("parent_release_id"),
        "release_root": ptr.get("release_root"),
        "asof": ptr.get("asof"),
        "source_vendor": ptr.get("source_vendor"),
        "jq_native_data": ptr.get("jq_native_data"),
        "CBOND_CONVERT_PRICE_PIT": ptr.get("CBOND_CONVERT_PRICE_PIT"),
        "CBOND_RATING_PIT": ptr.get("CBOND_RATING_PIT"),
        "CBOND_CALL_PIT": ptr.get("CBOND_CALL_PIT"),
        "CBOND_REMAIN_SIZE_PIT": ptr.get("CBOND_REMAIN_SIZE_PIT"),
        "CBOND_TOP10_HOLDERS": ptr.get("CBOND_TOP10_HOLDERS"),
        "product_paths": paths,
        "daily_path": paths["TUSHARE_CBOND_DAILY_MARKET_R1"],
        "basic_path": paths["TUSHARE_CBOND_BASIC_R1"],
        "rating_pit_path": paths["TUSHARE_CBOND_RATING_PIT_R1"],
        "call_pit_path": paths["TUSHARE_CBOND_CALL_PIT_R1"],
        "remain_pit_path": paths["TUSHARE_CBOND_REMAIN_SIZE_PIT_R1"],
    }


def write_receipts(paths: dict[str, Any], signal_day: str, fill_day: str) -> dict[str, Path]:
    sig = f"{loose.ymd_dash(signal_day)}T15:00:00"
    fill = f"{loose.ymd_dash(fill_day)}T09:30:00"
    labels = [
        "RESEARCH_RAW_NONE_EXPLICIT",
        "CBOND_VENDOR_QUOTE_NO_STOCK_ADJ",
        "NOT_LIVE_OR_JQ_MATCH_EXECUTION",
        "RATING_USES_PIT_ASOF_NOT_ISSUE_OR_NEWEST",
        "CALL_USES_PIT_ASOF_KNOWN_REDEEM_ANNOUNCED",
        "SIZE_USES_REMAIN_PIT_ASOF",
        "TOP10_HOLDERS_NOT_USED",
        "CONVERT_PRICE_PIT_NOT_USED",
    ]
    causal = {
        "strategy_id": STRATEGY_ID,
        "run_id": RUN_ID,
        "information_mode": "EOD_CAUSAL_NEXT_DAY",
        "signal_time": sig,
        "fill_time": fill,
        "order_time": fill,
        "fill_price_source": "OPEN",
        "eod_to_same_day_open": False,
        "EOD_TO_SAME_DAY_OPEN": "NO",
        "date_le_signal_date_as_sufficient": False,
        "mandatory_precheck": {
            "HAND_CAUSAL_READ": "YES",
            "INFORMATION_MODE": "EOD_CAUSAL_NEXT_DAY",
            "EOD_TO_SAME_DAY_OPEN": "NO",
            "MINUTE_POLICY": "UNUSED",
            "SIGNAL_TIME": sig,
            "FILL_TIME": fill,
            "SIGNAL_LT_FILL": "YES",
            "UNIFIED_MINUTE_PLANE_IF_NEEDED": "NOT_APPLICABLE",
        },
        "fields": [
            {
                "field_name": "close",
                "source_product": "TUSHARE_CBOND_DAILY_MARKET_R1",
                "observation_date": loose.ymd_dash(signal_day),
                "known_at": sig,
                "eod_daily": True,
                "timestamp_authority": "VENDOR_EOD_AFTER_CLOSE",
            },
            {
                "field_name": "cb_over_rate",
                "source_product": "TUSHARE_CBOND_DAILY_MARKET_R1",
                "observation_date": loose.ymd_dash(signal_day),
                "known_at": sig,
                "eod_daily": True,
                "timestamp_authority": "VENDOR_EOD_AFTER_CLOSE",
            },
            {
                "field_name": "rating",
                "source_product": "TUSHARE_CBOND_RATING_PIT_R1",
                "observation_date": loose.ymd_dash(signal_day),
                "known_at": sig,
                "eod_daily": False,
                "timestamp_authority": "PIT_VALID_FROM_NEXT_TRADE_DAY_AFTER_ANN",
                "note": "only intervals with pit_valid_from <= T < pit_valid_to; missing as-of rating fail-closed",
            },
            {
                "field_name": "is_call",
                "source_product": "TUSHARE_CBOND_CALL_PIT_R1",
                "observation_date": loose.ymd_dash(signal_day),
                "known_at": sig,
                "eod_daily": False,
                "timestamp_authority": "PIT_VALID_FROM_NEXT_TRADE_DAY_AFTER_ANN",
                "note": "latest event with pit_valid_from <= T; exclude 实施强赎/提示强赎; call_date is NOT known_at",
            },
            {
                "field_name": "known_remain_size",
                "source_product": "TUSHARE_CBOND_REMAIN_SIZE_PIT_R1",
                "observation_date": loose.ymd_dash(signal_day),
                "known_at": sig,
                "eod_daily": False,
                "timestamp_authority": "PIT_VALID_FROM_NEXT_TRADE_DAY_AFTER_PUBLISH",
                "note": "only intervals with pit_valid_from <= T < pit_valid_to",
            },
            {
                "field_name": "maturity_date",
                "source_product": "TUSHARE_CBOND_BASIC_R1",
                "observation_date": "1970-01-01",
                "known_at": "1970-01-01T15:00:00",
                "eod_daily": False,
                "timestamp_authority": "CONTRACTUAL_DICTIONARY",
            },
            {
                "field_name": "cb_type",
                "source_product": "TUSHARE_CBOND_BASIC_R1",
                "observation_date": "1970-01-01",
                "known_at": "1970-01-01T15:00:00",
                "eod_daily": False,
                "timestamp_authority": "DICTIONARY",
            },
        ],
    }
    preflight = {
        "strategy_id": STRATEGY_ID,
        "run_id": RUN_ID,
        "empty_rank_policy": "EMPTY_KEEP_HOLDING",
        "price_adj_tag": "TUSHARE_CBOND_VENDOR_QUOTE_RAW_NONE",
        "price_source": paths["daily_path"],
        "claim_jq_or_live_match": False,
        "rebalance_clock_rule": f"EOD_SIGNAL_T_THEN_TPLUS1_OPEN_FILL; rebalance every {loose.REBALANCE_EVERY_N} sessions; pulse may fire any EOD",
        "bridge_method": "none",
        "BACKTEST_PRICE_PLANE": "RAW_NONE",
        "SIGNAL_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_EXECUTION_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_VALUATION_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_PNL_PRICE_PLANE": "RAW_NONE",
        "LIVE_EXECUTION_PRICE_PLANE": "RAW_REAL_PRICE",
        "labels": labels,
        "JQ_EQUIVALENCE": "NOT_CLAIMED",
        "FULL_PIT_READY": False,
        "CBOND_EVENT_PIT_READY": True,
        "CBOND_CONVERT_PRICE_PIT_READY": False,
        "CBOND_TOP10_HOLDERS_USED": False,
    }
    plane = {
        "strategy_id": STRATEGY_ID,
        "run_id": RUN_ID,
        "BACKTEST_PRICE_PLANE": "RAW_NONE",
        "SIGNAL_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_EXECUTION_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_VALUATION_PRICE_PLANE": "RAW_NONE",
        "BACKTEST_PNL_PRICE_PLANE": "RAW_NONE",
        "LIVE_EXECUTION_PRICE_PLANE": "RAW_REAL_PRICE",
        "signal_adjustment_method": "NONE_CBOND_VENDOR_QUOTE",
        "signal_adjustment_anchor": "EACH_HISTORICAL_TRADE_DAY_T",
        "pit_causal": True,
        "adjust_factor_product_id": "N/A_CBOND_VENDOR_QUOTE_NO_STOCK_ADJ",
        "adjust_factor_release": "N/A_RAW_NONE",
        "adjust_factor_reader": "N/A_CBOND_VENDOR_QUOTE",
        "factor_coverage_ratio": 1.0,
        "missing_factor_count": 0,
        "missing_factor_codes": [],
        "raw_fallback_used": False,
        "future_adjustment_used": False,
        "execution_uses_adjusted_price": False,
        "mixed_plane_used": False,
        "PRICE_PLANE_DEFAULT_APPLIED": False,
        "silent_factor_eq_1": False,
        "BLACKBOX_PRE_PIT_EQ_JQ_PRE": "NOT_CLAIMED",
        "labels": labels,
        "note": "Convertible-bond quotes have no A-share PRE_PIT adjust-factor chain; explicit RESEARCH_RAW_NONE.",
    }
    out = {
        "causal": TASK_DIR / "CAUSAL_RECEIPT.json",
        "preflight": TASK_DIR / "BACKTEST_PREFLIGHT_RECEIPT.json",
        "plane": TASK_DIR / "BACKTEST_PRICE_PLANE_RECEIPT.json",
    }
    wjson(out["causal"], causal)
    wjson(out["preflight"], preflight)
    wjson(out["plane"], plane)
    return out


def load_panel(paths: dict[str, Any], start: str, end: str) -> tuple[pd.DataFrame, dict[str, Any]]:
    daily = read_product_parquet(Path(paths["daily_path"]))
    basic = read_product_parquet(Path(paths["basic_path"]))
    rating_pit = read_product_parquet(Path(paths["rating_pit_path"]))
    call_pit = read_product_parquet(Path(paths["call_pit_path"]))
    remain_pit = read_product_parquet(Path(paths["remain_pit_path"]))

    daily["trade_date"] = daily["trade_date"].map(loose.ymd)
    daily = daily[(daily["trade_date"] >= start) & (daily["trade_date"] <= end)].copy()
    if "cb_type" not in basic.columns:
        raise RuntimeError("cb_type missing in BASIC")
    keep_basic = basic[basic["cb_type"].astype(str).str.upper() == "CB"].copy()
    size_col = "issue_size" if "issue_size" in keep_basic.columns else "remain_size"
    unit_name, div = loose.detect_size_to_yi(keep_basic[size_col])
    keep_basic["size_yi_loose"] = pd.to_numeric(keep_basic[size_col], errors="coerce") / div
    keep_basic["rating_ok_loose"] = keep_basic.get("issue_rating", pd.Series(index=keep_basic.index)).map(loose.rating_passes)
    meta_cols = [
        "bond_code_ts",
        "bond_short_name",
        "cb_type",
        "list_date",
        "delist_date",
        "maturity_date",
        "issue_rating",
        "size_yi_loose",
        "rating_ok_loose",
    ]
    for c in meta_cols:
        if c not in keep_basic.columns:
            keep_basic[c] = None
    meta = keep_basic[meta_cols].drop_duplicates("bond_code_ts")
    panel = daily.merge(meta, on="bond_code_ts", how="inner")
    panel["_ld"] = panel["list_date"].map(loose.ymd)
    panel["_dd"] = panel["delist_date"].map(loose.ymd)
    panel = panel[panel["_ld"].notna() & (panel["_ld"] <= panel["trade_date"])]
    panel = panel[panel["_dd"].isna() | (panel["_dd"] > panel["trade_date"])]
    panel["close"] = pd.to_numeric(panel["close"], errors="coerce")
    panel["open"] = pd.to_numeric(panel["open"], errors="coerce")
    panel["cb_over_rate"] = pd.to_numeric(panel["cb_over_rate"], errors="coerce")
    panel["dl"] = panel["close"] + panel["cb_over_rate"]
    panel["remain"] = [loose.remain_years(m, t) for m, t in zip(panel["maturity_date"], panel["trade_date"])]

    panel = merge_asof_interval(panel, rating_pit, ["rating"])
    panel["rating_ok"] = panel["rating"].map(rating_passes_pit)
    panel = merge_asof_latest(panel, call_pit, ["is_call", "call_type", "ann_date"])
    panel["redeem_announced"] = [
        redeem_announced_row(a, b) for a, b in zip(panel.get("is_call"), panel.get("call_type"))
    ]
    panel = merge_asof_interval(panel, remain_pit, ["known_remain_size", "known_remain_size_source"])
    panel["size_yi"] = [
        size_to_yi(v, s) for v, s in zip(panel.get("known_remain_size"), panel.get("known_remain_size_source"))
    ]

    info = {
        "daily_rows": int(len(daily)),
        "panel_rows": int(len(panel)),
        "cb_basic_rows": int(len(meta)),
        "size_unit_detected_loose_issue": unit_name,
        "size_divisor_loose_issue": div,
        "size_col_loose": size_col,
        "unique_dates": int(panel["trade_date"].nunique()),
        "unique_bonds": int(panel["bond_code_ts"].nunique()),
        "rating_asof_hit_ratio": float(panel["rating"].notna().mean()) if len(panel) else None,
        "remain_asof_hit_ratio": float(panel["known_remain_size"].notna().mean()) if len(panel) else None,
        "redeem_announced_row_ratio": float(panel["redeem_announced"].mean()) if len(panel) else None,
        "window": f"{loose.ymd_dash(start)} .. {loose.ymd_dash(end)}",
    }
    return panel, info


def overlay_last_day(panel: pd.DataFrame) -> dict[str, Any]:
    if panel.empty:
        return {"reason": "EMPTY_PANEL"}
    last = sorted(panel["trade_date"].unique())[-1]
    day = panel[panel["trade_date"] == last].copy()
    mkt = day[day["close"].map(loose.valid_px) & day["cb_over_rate"].notna()]
    dls = [float(x) for x in mkt["dl"] if pd.notna(x)]
    dl_mean = sum(dls) / len(dls) if dls else None
    frac, pos_txt = loose.position_frac(dl_mean)
    loose_s = survivors_of_loose(day)
    strict_s = survivors_of_strict(day)
    loose_codes = set(loose_s["bond_code_ts"].astype(str))
    strict_codes = set(strict_s["bond_code_ts"].astype(str))
    only_loose = sorted(loose_codes - strict_codes)
    only_strict = sorted(strict_codes - loose_codes)
    n_rating_fail = int((~day["rating_ok"].fillna(False) & day["rating_ok_loose"].fillna(False)).sum())
    n_redeem = int(day["redeem_announced"].fillna(False).sum())
    return {
        "date": last,
        "dl_mean": None if dl_mean is None else round(dl_mean, 4),
        "pos_text": pos_txt,
        "pos_frac": frac,
        "n_universe": int(len(mkt)),
        "n_survivors_loose_issue_rating_no_call": int(len(loose_s)),
        "n_survivors_strict_pit": int(len(strict_s)),
        "n_only_in_loose": len(only_loose),
        "n_only_in_strict": len(only_strict),
        "n_listed_with_redeem_announced_known": n_redeem,
        "n_loose_ok_but_pit_rating_fail": n_rating_fail,
        "only_in_loose_sample": only_loose[:20],
        "only_in_strict_sample": only_strict[:20],
        "note": "overlay is research comparison of 排雷; cash rule still uses market dl_mean",
    }


def perf_block(sim: dict[str, Any]) -> dict[str, Any]:
    tr = sim.get("total_return")
    return {
        "window": f"{loose.ymd_dash(sim.get('start'))} .. {loose.ymd_dash(sim.get('end'))}",
        "total_return": tr,
        "total_return_pct": None if tr is None else round(tr * 100, 2),
        "ann_return_242": sim.get("ann_return_242"),
        "max_drawdown": sim.get("max_drawdown"),
        "max_drawdown_pct": None if sim.get("max_drawdown") is None else round(float(sim["max_drawdown"]) * 100, 2),
        "n_trades": sim.get("n_trades"),
        "n_buy": sim.get("n_buy"),
        "n_sell": sim.get("n_sell"),
        "final_nav": sim.get("final_nav"),
        "n_sessions": sim.get("n_sessions"),
        "final_holdings": sim.get("final_holdings"),
        "last_snapshot": sim.get("last_snapshot"),
    }


def invested_days(sim: dict[str, Any]) -> dict[str, Any]:
    eq = sim.get("equity") or []
    n_pos = sum(1 for r in eq if float(r.get("pos_frac") or 0) > 0)
    n_hold = sum(1 for r in eq if int(r.get("n_hold_actual") or 0) > 0)
    dls = [float(r["dl_mean"]) for r in eq if r.get("dl_mean") is not None]
    return {
        "n_sessions_pos_frac_gt_0": n_pos,
        "n_sessions_actual_holding_gt_0": n_hold,
        "dl_mean_min": None if not dls else round(min(dls), 4),
        "dl_mean_median": None if not dls else round(sorted(dls)[len(dls) // 2], 4),
        "dl_mean_max": None if not dls else round(max(dls), 4),
    }


def main() -> int:
    TASK_DIR.mkdir(parents=True, exist_ok=True)
    set_runtime_context(task_dir=TASK_DIR, task_slug=TASK_SLUG, task_type="BACKTEST")
    loose.survivors_of = survivors_of_strict
    paths = resolve_paths()
    panel_full, info_full = load_panel(paths, START_FULL, END)
    dates = sorted(panel_full["trade_date"].unique())
    if len(dates) < 2:
        wjson(TASK_DIR / "FAIL.json", {"reason": "NOT_ENOUGH_DATES", "info": info_full})
        print("BACKTEST_RETURN_VALID=FALSE reason=NOT_ENOUGH_DATES")
        return FAIL
    receipts = write_receipts(paths, dates[0], dates[1])
    gates = loose.run_gates(receipts)
    wjson(
        TASK_DIR / "GATE_RESULTS.json",
        {k: ({kk: vv for kk, vv in v.items() if kk != "cmd"} if isinstance(v, dict) else v) for k, v in gates.items()},
    )
    if not gates.get("all_pass"):
        wjson(
            TASK_DIR / "SUMMARY.json",
            {
                "BACKTEST_RETURN_VALID": False,
                "reason": "GATE_FAIL",
                "gates": {k: v.get("returncode") if isinstance(v, dict) else v for k, v in gates.items()},
            },
        )
        print("BACKTEST_RETURN_VALID=FALSE reason=GATE_FAIL")
        for k, v in gates.items():
            if isinstance(v, dict) and v.get("returncode") not in (0, None):
                print(f"gate_fail={k} code={v.get('returncode')} fails={v.get('fails')}")
        return FAIL

    sim_full = loose.simulate(panel_full)
    panel_ytd = panel_full[panel_full["trade_date"] >= START_YTD].copy()
    sim_ytd = loose.simulate(panel_ytd) if panel_ytd["trade_date"].nunique() >= 2 else {}
    overlay = overlay_last_day(panel_full)
    loose_prev = None
    if LOOSE_SUMMARY.is_file():
        loose_prev = json.loads(LOOSE_SUMMARY.read_text(encoding="utf-8"))

    summary = {
        "TASK_CLASS": TASK_CLASS,
        "MUST_READ_BOOTSTRAP": "YES",
        "MUST_READ_DATA_ACCESS": "YES",
        "MUST_READ_BACKTEST": "YES",
        "HAND_READ": "YES",
        "AUTHORITY_READY": "YES" if gates.get("all_pass") else "NO",
        "BACKTEST_RETURN_VALID": bool(gates.get("all_pass")),
        "JQ_EQUIVALENCE": "NOT_CLAIMED",
        "FULL_PIT_READY": False,
        "CBOND_EVENT_PIT_READY": True,
        "CBOND_CONVERT_PRICE_PIT_READY": False,
        "CBOND_TOP10_HOLDERS_USED": False,
        "INFORMATION_MODE": "EOD_CAUSAL_NEXT_DAY",
        "EOD_TO_SAME_DAY_OPEN": "NO",
        "SIGNAL_LT_FILL": "YES",
        "BACKTEST_RERUN_R26D": "NO",
        "source": paths,
        "panel_full": info_full,
        "deviations_from_live_jisilu_script": [
            "数据源=本地 Tushare CBOND，不是集思录实时 API",
            "评级=R2 rating PIT as-of（pit_valid_from<=T<pit_valid_to）；缺评级 fail-closed；不用 newest_rating 快照",
            "强赎=R2 call PIT 最新已知事件；仅排除 is_call 含「实施强赎」或「提示强赎」；不用 call_date 当天",
            "规模=R2 remain_size PIT as-of；发行初始区间可能是亿元、后续 cb_share 为元，已分行换算",
            "十大持有人未用（PIT_SAFE=NO）",
            "转股价 PIT 未用（NOT_READY）",
            "轮动每 10 个交易日；脉冲可每日 EOD、次日开盘成交",
            "成交=T+1 开盘；停牌/开盘无效则跳过该笔",
            "单边成本 1bp，无滑点",
        ],
        "stricter_vs_loose_2026ytd_r1": [
            "宽松版用 issue_rating + issue_size，且 EVENT_PIT_NOT_READY 故未滤强赎",
            "本版用 rating/call/remain PIT；仓位规则仍按全市场 dl_mean，未改阈值",
        ],
        "reader_call_asof_note": "blackbox_tushare_cbond_reader_r2.get_cbond_call_state_asof 仍按 Y/N 识别 is_call；途施实际为中文状态。本回测未走该 Y/N 分支，直接按中文「实施强赎/提示强赎」判定。",
        "performance_full_5y": perf_block(sim_full),
        "invested_full_5y": invested_days(sim_full),
        "performance_2026ytd_fresh_start": perf_block(sim_ytd) if sim_ytd else None,
        "invested_2026ytd": invested_days(sim_ytd) if sim_ytd else None,
        "overlay_last_day_loose_vs_strict": overlay,
        "loose_2026ytd_r1_performance": None if loose_prev is None else loose_prev.get("performance"),
        "loose_2026ytd_r1_last_snapshot": None if loose_prev is None else loose_prev.get("last_snapshot"),
        "generated_at_cn": loose.now_cn(),
    }
    wjson(TASK_DIR / "SUMMARY.json", summary)
    wjson(TASK_DIR / "EQUITY.json", sim_full["equity"])
    wjson(TASK_DIR / "TRADES.json", sim_full["trades"])
    wjson(TASK_DIR / "SNAPSHOTS.json", sim_full["snapshots"])
    if sim_ytd:
        wjson(TASK_DIR / "EQUITY_2026YTD.json", sim_ytd["equity"])
        wjson(TASK_DIR / "TRADES_2026YTD.json", sim_ytd["trades"])
    wjson(TASK_DIR / "OVERLAY_LAST_DAY.json", overlay)

    pf = summary["performance_full_5y"]
    py = summary["performance_2026ytd_fresh_start"] or {}
    print("BACKTEST_RETURN_VALID=TRUE")
    print(f"window_full={pf.get('window')}")
    print(f"full_total_return_pct={pf.get('total_return_pct')}")
    print(f"full_max_drawdown_pct={pf.get('max_drawdown_pct')}")
    print(f"full_n_trades={pf.get('n_trades')}")
    print(f"full_n_sessions={pf.get('n_sessions')}")
    print(f"ytd_total_return_pct={py.get('total_return_pct')}")
    print(f"ytd_n_trades={py.get('n_trades')}")
    print(f"overlay_strict_survivors={overlay.get('n_survivors_strict_pit')}")
    print(f"overlay_loose_survivors={overlay.get('n_survivors_loose_issue_rating_no_call')}")
    print(f"task_dir={TASK_DIR}")
    return OK


if __name__ == "__main__":
    raise SystemExit(main())
