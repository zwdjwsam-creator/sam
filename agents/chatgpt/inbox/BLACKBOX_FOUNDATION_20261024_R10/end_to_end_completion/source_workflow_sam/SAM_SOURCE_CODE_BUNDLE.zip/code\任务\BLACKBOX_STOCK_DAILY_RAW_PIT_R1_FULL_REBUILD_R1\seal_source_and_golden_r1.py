# -*- coding: utf-8 -*-
"""Seal SOURCE year parts + coverage + RAW golden. No CURRENT switch. No R26."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_STOCK_DAILY_RAW_PIT_R1_FULL_REBUILD_R1")
STAGING = TASK / "staging" / "source_batches"
STATE = TASK / "staging" / "DOWNLOAD_STATE.json"
CAL = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P0_meta\calendar_cn_exchange\calendar_cn_exchange_v2_asof_20260814\CALENDAR_TRADE_DAYS.parquet")
ADDITIONS = Path(r"E:\BLACKBOX\数据\原始只读\strategy_data_plane_additions\STOCK_DAILY_RAW_NONE_FULL_HISTORY_R1")
START = pd.Timestamp("2014-01-01")
END = pd.Timestamp("2026-08-14")
OHLC = ["open", "high", "low", "close"]
TOL = 0.015
GOLDEN = [
    ("001230.XSHE", "2026-05-12"),
    ("000001.XSHE", "2026-05-12"),
    ("600351.XSHG", "2026-04-30"),
    ("002870.XSHE", "2026-05-12"),
    ("301336.XSHE", "2026-02-12"),
    ("300143.XSHE", "2026-03-13"),
    ("300406.XSHE", "2026-05-12"),
    ("603236.XSHG", "2026-05-12"),
    ("688767.XSHG", "2026-05-12"),
    ("002870.XSHE", "2026-08-11"),
    ("301336.XSHE", "2026-08-11"),
    ("300143.XSHE", "2026-08-13"),
    ("300406.XSHE", "2026-08-13"),
    ("603236.XSHG", "2026-08-13"),
    ("688767.XSHG", "2026-08-13"),
    ("001230.XSHE", "2026-08-11"),
    ("000001.XSHE", "2026-08-11"),
]
MUST_MATCH_RAW = {("001230.XSHE", "2026-05-12"), ("000001.XSHE", "2026-05-12")}

sys.path.insert(0, r"E:\BLACKBOX\脚本")
from jq_download_base import auth  # noqa: E402


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print("[%s] %s" % (now_cn(), msg), flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def drop_invalid(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    x["date"] = pd.to_datetime(x["date"]).dt.normalize()
    x["code"] = x["code"].astype(str)
    for c in OHLC + ["volume", "money"]:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    ok = np.ones(len(x), dtype=bool)
    for c in OHLC:
        v = x[c].to_numpy()
        ok &= np.isfinite(v) & (v > 0)
    ok &= np.isfinite(x["volume"].to_numpy()) & (x["volume"].to_numpy() >= 0)
    ok &= np.isfinite(x["money"].to_numpy()) & (x["money"].to_numpy() >= 0)
    ok &= x["high"].to_numpy() >= x["low"].to_numpy()
    x = x.loc[ok].copy()
    x = x.loc[(x["date"] >= START) & (x["date"] <= END)]
    x = x.sort_values(["code", "date"]).drop_duplicates(["code", "date"], keep="last")
    return x


def write_source_years() -> tuple[Path, list[Path], dict]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    rel_id = "REL_ASOF_20260814_%s" % stamp
    root = ADDITIONS / rel_id
    data = root / "data"
    files = []
    per_year = {}
    for year in range(2014, 2027):
        parts = sorted((STAGING / ("year=%s" % year)).glob("batch_*.parquet"))
        if not parts:
            raise SystemExit("HARD_BLOCK: missing staging year=%s" % year)
        frames = [pd.read_parquet(p) for p in parts]
        df = drop_invalid(pd.concat(frames, ignore_index=True))
        outp = data / ("year=%s" % year) / ("part_%s.parquet" % year)
        outp.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(outp, index=False)
        files.append(outp)
        per_year[str(year)] = {
            "rows": int(len(df)),
            "codes": int(df["code"].nunique()),
            "date_min": None if df.empty else str(df["date"].min().date()),
            "date_max": None if df.empty else str(df["date"].max().date()),
            "n_batches": len(parts),
        }
        log("SOURCE year=%s rows=%s codes=%s" % (year, len(df), df["code"].nunique()))
    ptr = {
        "release_id": rel_id,
        "release_root": str(root),
        "product_id": "STOCK_DAILY_RAW_PIT_R1",
        "fq": "none",
        "fq_explicit": True,
        "jq_api": "get_price(frequency='daily', fq='none')",
        "start": "2014-01-01",
        "end": "2026-08-14",
        "created_at_cn": now_cn(),
        "legacy_p2_not_used": True,
    }
    wjson(root / "RELEASE.json", ptr)
    wjson(ADDITIONS / "CURRENT_SOURCE_RELEASE.json", ptr)
    return root, files, per_year


def coverage(files: list[Path], per_year: dict) -> dict:
    frames = [pd.read_parquet(f, columns=["date", "code"] + OHLC + ["volume", "money"]) for f in files]
    df = pd.concat(frames, ignore_index=True)
    df["date"] = pd.to_datetime(df["date"]).dt.normalize()
    cal = pd.read_parquet(CAL)
    days = pd.to_datetime(cal["trade_date"]).dt.normalize()
    expected = sorted({d for d in days if START <= d <= END})
    actual = sorted(set(df["date"].unique()))
    missing = [str(d.date()) for d in expected if d not in set(actual)]
    extra = [str(d.date()) for d in actual if d not in set(expected)]
    future = [str(d.date()) for d in actual if d > END]
    per_date = df.groupby("date")["code"].nunique()
    per_code = df.groupby("code")["date"].nunique()
    null_c = int(df[OHLC].isna().any(axis=1).sum())
    arr = df[OHLC].to_numpy(dtype=float)
    nonfinite = int((~np.isfinite(arr)).any(axis=1).sum())
    le0 = int((arr <= 0).any(axis=1).sum())
    dup = int(df.duplicated(["code", "date"]).sum())
    uni = json.loads((TASK / "staging" / "UNIVERSE.json").read_text(encoding="utf-8"))
    qa = {
        "source_min_date": str(df["date"].min().date()),
        "source_max_date": str(df["date"].max().date()),
        "SOURCE_MAX_DATE": str(df["date"].max().date()),
        "expected_trade_days": len(expected),
        "actual_trade_days": len(actual),
        "missing_trade_days": missing,
        "n_missing_trade_days": len(missing),
        "calendar_extra_dates": extra[:20],
        "future_dates_gt_asof": future,
        "expected_codes": int(uni["n"]),
        "actual_codes": int(df["code"].nunique()),
        "total_rows": int(len(df)),
        "duplicate_key_count": dup,
        "null_ohlc_count": null_c,
        "nonfinite_ohlc_count": nonfinite,
        "ohlc_le_zero_count": le0,
        "per_year_row_count": per_year,
        "per_date_code_count_min": int(per_date.min()),
        "per_date_code_count_max": int(per_date.max()),
        "per_date_code_count_on_end": int(per_date.get(END, 0)),
        "per_code_date_count_min": int(per_code.min()),
        "per_code_date_count_max": int(per_code.max()),
        "HAS_20260814": bool(END in set(actual)),
        "fq": "none",
        "raw_fallback_used": False,
        "p2_reused": False,
    }
    fails = []
    if qa["SOURCE_MAX_DATE"] != "2026-08-14":
        fails.append("SOURCE_MAX_DATE")
    if missing:
        fails.append("MISSING_TRADE_DAYS")
    if future:
        fails.append("FUTURE_DATE")
    if dup or null_c or nonfinite or le0:
        fails.append("OHLC_SEMANTICS")
    if extra:
        fails.append("CALENDAR_EXTRA")
    qa["fails"] = fails
    qa["RAW_SOURCE_COMPLETE"] = not fails
    qa["ANTI_LOOKAHEAD_PASS"] = not future
    return qa, df


def classify(bb, jq_none, jq_pre) -> str:
    if bb is None or jq_none is None or jq_pre is None:
        return "INCOMPLETE"
    if abs(jq_none - jq_pre) < TOL:
        if abs(bb - jq_none) < TOL:
            return "NONE_PRE_IDENTICAL_ON_DATE"
        return "MATCH_NEITHER"
    if abs(bb - jq_none) < TOL and abs(bb - jq_pre) >= TOL:
        return "MATCH_RAW"
    if abs(bb - jq_pre) < TOL:
        return "MATCH_PRE"
    return "MATCH_NEITHER"


def golden(df: pd.DataFrame) -> dict:
    import jqdatasdk as jq

    auth()
    rows = []
    for code, d in GOLDEN:
        sub = df.loc[(df["code"] == code) & (df["date"] == pd.Timestamp(d))]
        bb = None if sub.empty else float(sub.iloc[-1]["close"])
        none = jq.get_price(security=code, start_date=d, end_date=d, frequency="daily", fields=["close"], fq="none")
        pre = jq.get_price(security=code, start_date=d, end_date=d, frequency="daily", fields=["close"], fq="pre")
        jq_none = float(none.iloc[-1]["close"]) if none is not None and len(none) else None
        jq_pre = float(pre.iloc[-1]["close"]) if pre is not None and len(pre) else None
        cls = classify(bb, jq_none, jq_pre)
        rec = {
            "code": code,
            "date": d,
            "bb_raw_close": bb,
            "jq_none": jq_none,
            "jq_pre": jq_pre,
            "class": cls,
            "must_match_raw": (code, d) in MUST_MATCH_RAW,
        }
        rows.append(rec)
        log("%s %s class=%s bb=%s none=%s pre=%s" % (code, d, cls, bb, jq_none, jq_pre))
    bad = [r for r in rows if r["class"] in ("MATCH_PRE", "MATCH_NEITHER", "INCOMPLETE")]
    must = [r for r in rows if r["must_match_raw"]]
    c001230 = next(r for r in rows if r["code"] == "001230.XSHE" and r["date"] == "2026-05-12")
    c000001 = next(r for r in rows if r["code"] == "000001.XSHE" and r["date"] == "2026-05-12")
    out = {
        "rows": rows,
        "RAW_SEMANTICS_PASS": not bad,
        "001230_RAW_PASS": c001230["class"] == "MATCH_RAW" and abs((c001230["bb_raw_close"] or 0) - 28.70) < TOL,
        "000001_RAW_PASS": c000001["class"] == "MATCH_RAW" and abs((c000001["bb_raw_close"] or 0) - 11.25) < TOL,
        "must_match_raw_pass": all(r["class"] == "MATCH_RAW" for r in must),
        "forbidden_classes_present": sorted({r["class"] for r in bad}),
    }
    return out


def main() -> int:
    st = json.loads(STATE.read_text(encoding="utf-8"))
    if st.get("failed"):
        raise SystemExit("HARD_BLOCK: download failed=%s" % st["failed"])
    if st.get("fq") != "none" or not st.get("fq_explicit"):
        raise SystemExit("HARD_BLOCK: download fq not explicit none")
    root, files, per_year = write_source_years()
    qa, df = coverage(files, per_year)
    wjson(TASK / "SOURCE_COVERAGE.json", qa)
    wjson(root / "COVERAGE.json", qa)
    log("SOURCE_COMPLETE=%s fails=%s max=%s" % (qa["RAW_SOURCE_COMPLETE"], qa["fails"], qa["SOURCE_MAX_DATE"]))
    g = golden(df)
    wjson(TASK / "RAW_SEMANTICS_GOLDEN.json", g)
    log("RAW_SEMANTICS=%s 001230=%s 000001=%s" % (g["RAW_SEMANTICS_PASS"], g["001230_RAW_PASS"], g["000001_RAW_PASS"]))
    ok = qa["RAW_SOURCE_COMPLETE"] and g["RAW_SEMANTICS_PASS"] and g["001230_RAW_PASS"] and g["000001_RAW_PASS"]
    wjson(TASK / "SOURCE_SEAL.json", {"PASS": ok, "release_root": str(root), "coverage": qa["fails"], "golden": {
        "RAW_SEMANTICS_PASS": g["RAW_SEMANTICS_PASS"],
        "001230_RAW_PASS": g["001230_RAW_PASS"],
        "000001_RAW_PASS": g["000001_RAW_PASS"],
    }})
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
