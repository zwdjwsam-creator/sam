# -*- coding: utf-8 -*-
"""R26b SCORE5050 HOLD3 N=1 PRE_PIT rerun. New run_id. Do not overwrite RAW_NONE baseline."""
from __future__ import annotations

import json
import os
import sys
from datetime import date, datetime
from pathlib import Path

import numpy as np
import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_ADJUST_FACTOR_PIT_R1_FULL_REBUILD_AND_BACKWARD_REFRESH_R1")
ARCH = Path(r"D:\CURSOR_TASK_ARCHIVE\SANNIAN_SHIBEI_R20_MA5_BACKTEST_20260721_20260814_R1")
SEAL = ARCH / "STRATEGY_SEAL_R26b_SCORE5050_HOLD3_N1"
RUN_ID = os.environ.get("R26B_RUN_ID") or ("R26b_FORMAL_PRE_PIT_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
OUT = SEAL / RUN_ID
CACHE_PTR = Path(r"E:\BLACKBOX\数据\回测缓存\CURRENT_CACHE_RELEASE.json")
sys.path.insert(0, str(ARCH))

import run_sannian_shibei_r20_ma5_local_r1 as loc  # noqa: E402
from run_sannian_profit_grid_r1 import apply_resonance, is_candidate, loc_on_or_before, precompute, run_one  # noqa: E402
from run_sannian_aug04_14_score5050_r1 import (  # noqa: E402
    END,
    QP_KEY,
    PS_KEY,
    SEL,
    SELL,
    START,
    daily_names,
    make_5050_pick,
    min_entry_ret_pct,
)
from run_sannian_rolling_pe_factor_r1 import load_fi_by_date, load_val_by_date  # noqa: E402


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def load_factor_map(root: Path) -> dict:
    frames = []
    for year in (2025, 2026):
        p = root / "ADJUST_FACTOR_PIT_R1" / "data" / f"year={year}" / f"part_{year}.parquet"
        frames.append(pd.read_parquet(p))
    df = pd.concat(frames, ignore_index=True)
    df["date"] = pd.to_datetime(df["date"]).dt.normalize()
    df["code"] = df["code"].astype(str)
    df["factor"] = pd.to_numeric(df["factor"], errors="coerce")
    out = {}
    for r in df.itertuples(index=False):
        out[(str(r.code), pd.Timestamp(r.date).date())] = float(r.factor)
    return out


def is_candidate_pre(idx, code, signal_date, mode, fmap):
    if mode != "nh_120":
        return is_candidate(idx, code, signal_date, mode)
    hit = loc_on_or_before(idx, code, signal_date)
    if hit is None:
        return False, 0.0
    i, k, pos = hit
    n = 120
    if k < n:
        return False, 0.0
    dT = pd.Timestamp(idx["dates"][i]).date()
    fT = fmap.get((code, dT))
    if fT is None or fT <= 0:
        return False, 0.0
    last_raw = float(idx["close"][i])
    last_pre = last_raw * fmap.get((code, dT), None) / fT
    priors = []
    for j in pos[k - n : k]:
        dd = pd.Timestamp(idx["dates"][j]).date()
        fd = fmap.get((code, dd))
        if fd is None or fd <= 0:
            return False, 0.0
        priors.append(float(idx["close"][j]) * fd / fT)
    prev_close = float(idx["close"][pos[k - 1]]) if k >= 1 else 0.0
    pct = (last_raw / prev_close - 1.0) if prev_close > 0 else 0.0
    return bool(last_pre > max(priors) > 0), pct


def precompute_pre(idx, trade_days, all_days, sw_by_date, daily, fmap):
    packs = []
    for today in trade_days:
        signal_date = all_days[all_days.index(today) - 1]
        day_mask = daily["date"] == pd.Timestamp(signal_date)
        day_codes = sorted(set(daily.loc[day_mask, "code"].astype(str).tolist()))
        tradeable = []
        pct_map = {}
        for code in day_codes:
            b = loc.bar_on(idx, code, signal_date)
            if b is None or b["close"] <= 0 or b["low"] <= 0 or b["high"] <= 0:
                continue
            if abs(b["close"] - b["low"]) < 0.01 or abs(b["close"] - b["high"]) < 0.01:
                continue
            tradeable.append(code)
        ind_map = sw_by_date.get(signal_date, {})
        rows = []
        for code in tradeable:
            ok, pct = is_candidate_pre(idx, code, signal_date, "nh_120", fmap)
            if ok:
                rows.append((code, pct))
                pct_map[code] = pct
        packs.append(
            {
                "today": today,
                "signal_date": signal_date,
                "ind_map": ind_map,
                "cands": {"nh_120": rows},
                "pct_map": pct_map,
            }
        )
    return packs


def main() -> int:
    cur = json.loads(CACHE_PTR.read_text(encoding="utf-8"))
    root = Path(cur["release_root"])
    loc.CACHE = root
    OUT.mkdir(parents=True, exist_ok=True)
    fmap = load_factor_map(root)
    daily = loc.load_stock_daily()
    sw = loc.load_sw_l2()
    idx = loc.build_code_index(daily)
    all_days = sorted({loc._to_date(x) for x in daily["date"].unique()})
    trade_days = [d for d in all_days if START <= d <= END]
    sw_by_date = {}
    for dt, g in sw.groupby("date", sort=False):
        sw_by_date[loc._to_date(dt)] = dict(zip(g["code"].astype(str), g["industry_name"].astype(str)))
    packs_all = precompute_pre(idx, trade_days, all_days, sw_by_date, daily, fmap)
    signal_days = [p["signal_date"] for p in packs_all]
    val_maps = load_val_by_date(signal_days)
    fi_maps = load_fi_by_date(signal_days)
    names = pd.read_parquet(
        root / "JQ20_STK_LIST_REFERENCE_PIT_R1" / "data" / "STK_LIST_REFERENCE_PIT_R1_FULL.parquet",
        columns=["code", "name"],
    )
    nm = dict(zip(names["code"].astype(str), names["name"].astype(str)))
    pick_5050 = make_5050_pick(val_maps, fi_maps)
    r50, navs, trades, sels = run_one(
        idx,
        packs_all,
        SEL,
        "pct_desc",
        SELL,
        detail=True,
        max_hold=1,
        size_mode="equal_n",
        pick_fn=pick_5050,
    )
    legacy = json.loads((SEAL / "LEGACY_RAW_NONE_BASELINE.json").read_text(encoding="utf-8")) if (SEAL / "LEGACY_RAW_NONE_BASELINE.json").exists() else {"ret_pct": 82.7478, "max_dd_pct": 0.0}
    result = {
        "run_id": RUN_ID,
        "BACKTEST_PRICE_PLANE": "PRE_PIT",
        "scheme": "R26b_SCORE5050_HOLD3_N1",
        "window": "2026-08-04..2026-08-14",
        "ret_pct": float(r50["ret_pct"]),
        "max_dd_pct": float(r50["max_dd_pct"]),
        "n_buy": int(r50["n_buy"]),
        "trades": trades,
        "daily_picks": daily_names(sels, nm),
        "sels": sels,
        "navs": navs,
        "legacy_raw_none_ret_pct": legacy.get("ret_pct", 82.7478),
        "legacy_raw_none_max_dd_pct": legacy.get("max_dd_pct", 0.0),
        "delta_vs_legacy_pp": round(float(r50["ret_pct"]) - float(legacy.get("ret_pct", 82.7478)), 4),
        "attribution": "PRICE_PLANE",
        "params_frozen": {"NH120": 120, "SW_L2_resonance": True, "score": "50/50", "N": 1, "HOLD": 3},
        "cache_release_id": cur["cache_release_id"],
        "STRATEGY_CHANGE": "FORBIDDEN",
    }
    legacy_path = SEAL / "RERUN_RAW_NONE_20260804_20260814_R1" / "CONTINUOUS_PATH_0804_0814.json"
    if legacy_path.exists():
        raw_path = json.loads(legacy_path.read_text(encoding="utf-8"))
        raw_trades = raw_path.get("trades") or []
        pre_chain = [(t.get("date"), t.get("side"), t.get("code"), t.get("name")) for t in trades]
        raw_chain = [(t.get("date"), t.get("side"), t.get("code"), t.get("name")) for t in raw_trades]
        result["raw_none_trade_chain"] = raw_chain
        result["pre_pit_trade_chain"] = pre_chain
        result["trade_chain_equal"] = pre_chain == raw_chain
    wjson(OUT / "RESULT.json", result)
    wjson(OUT / "TRADES.json", trades)
    print(json.dumps({k: result[k] for k in ("run_id", "ret_pct", "max_dd_pct", "n_buy", "delta_vs_legacy_pp", "daily_picks")}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
