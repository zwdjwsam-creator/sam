# -*- coding: utf-8 -*-
"""Explicit SW membership cache reader — level required for L2/L3.

Backward compatible:
  get_sw_membership(level=None, ...) -> defaults to L1 only (legacy).
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd

CACHE_ROOT = Path(r"E:\BLACKBOX\数据\回测缓存")
POINTER = CACHE_ROOT / "CURRENT_CACHE_RELEASE.json"

LEVEL_TO_PRODUCT = {
    "L1": "SW_L1_MEMBERSHIP_PIT_R1",
    "L2": "SW_L2_MEMBERSHIP_PIT_R1",
    "L3": "SW_L3_MEMBERSHIP_PIT_R1",
    "1": "SW_L1_MEMBERSHIP_PIT_R1",
    "2": "SW_L2_MEMBERSHIP_PIT_R1",
    "3": "SW_L3_MEMBERSHIP_PIT_R1",
}


def current_release_root() -> Path:
    import json
    ptr = json.loads(POINTER.read_text(encoding="utf-8"))
    return Path(ptr["release_root"])


def get_cache_product(product_id: str, trade_date: Optional[str] = None, release_root: Optional[Path] = None) -> pd.DataFrame:
    root = release_root or current_release_root()
    prod = root / product_id
    if not prod.exists():
        raise FileNotFoundError(f"product missing: {prod}")
    if trade_date:
        year = int(str(trade_date)[:4])
        fp = prod / f"year={year}" / f"part_{year}.parquet"
        df = pd.read_parquet(fp)
        return df.loc[pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d") == str(trade_date)[:10]].copy()
    frames = [pd.read_parquet(fp) for fp in sorted(prod.rglob("part_*.parquet"))]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def get_sw_membership(level: Optional[str] = None, trade_date: Optional[str] = None, release_root: Optional[Path] = None) -> pd.DataFrame:
    """If level is None: legacy behavior, read L1 only. Never auto-guess L2/L3."""
    lv = "L1" if level is None else str(level).upper().replace("SW_", "")
    if lv not in LEVEL_TO_PRODUCT and level is not None:
        raise ValueError(f"level must be L1/L2/L3; got {level!r}")
    return get_cache_product(LEVEL_TO_PRODUCT[lv], trade_date=trade_date, release_root=release_root)
