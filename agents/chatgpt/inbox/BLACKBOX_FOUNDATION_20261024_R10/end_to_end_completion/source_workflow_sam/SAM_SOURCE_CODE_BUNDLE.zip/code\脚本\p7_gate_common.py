#!/usr/bin/env python3
"""
p7_gate_common.py — shared gate / HAND / lock utilities for P7 minute download.
PRO dry-run safe: set dry_run=True to skip JQData API.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ── Paths ──
BLACKBOX = Path("E:/BLACKBOX")
RUNS = BLACKBOX / "运行"
SCRIPTS = BLACKBOX / "脚本"
P7_LEGACY = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P7_stock_minute")
# Canonical "raw_none replacement" paths by minute frequency.
P7_5M = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P7_stock_minute_raw_none_replacement_5m")
P7_1M = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P7_stock_raw_none_replacement_1m")
P7_30_60 = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P7_stock_minute_raw_none")
PARENT = Path(
    "E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/"
    "P7_minute_quota_aware_dynamic_batch_scheduler_fix_R1"
)
REPAIR = Path(
    "E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/"
    "P7_minute_release_blocker_repair_R1"
)
MATRIX_5M = Path(
    "E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_5m_matrix_download_R1"
)
MATRIX_1M = Path(
    "E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_1m_matrix_download_R1"
)
MATRIX_30M = Path(
    "E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_30m_matrix_download_R1"
)
MATRIX_60M = Path(
    "E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_60m_matrix_download_R1"
)

HAND_DECISION_PATH = RUNS / "HAND_DECISION.json"
HAND_MD_PATH = RUNS / "LOCAL_HAND_RELEASE_DECISION.md"
NO_REDOWLOAD_LEDGER_RUNS = RUNS / "P7_NO_REDOWLOAD_LEDGER.csv"
NO_REDOWLOAD_LEDGER_MANIFEST = PARENT / "ledger" / "p7_no_redownload_ledger.csv"

GATE_PATHS = {
    "5m": MATRIX_5M / "quality_gate" / "5m_quality_gate.json",
    "1m": MATRIX_1M / "quality_gate" / "1m_quality_gate.json",
    "30m": MATRIX_30M / "quality_gate" / "30m_quality_gate.json",
    "60m": MATRIX_60M / "quality_gate" / "60m_quality_gate.json",
}
GATE_5M_PATH = GATE_PATHS["5m"]

FREQ_FILE_PREFIX = {
    "5m": "stock_minute_5m__",
    "1m": "stock_minute_1m__",
    "30m": "stock_minute_30m__",
    "60m": "stock_minute_60m__",
}

# ── Quota constants (hard rule) ──
def root_for_freq(freq: str) -> Path:
    """Return the canonical parquet root for minute frequency."""
    if freq == "5m":
        return P7_5M
    if freq == "1m":
        return P7_1M
    if freq in ("30m", "60m"):
        return P7_30_60
    return P7_LEGACY


DAILY_QUOTA_HARD_LIMIT_INT = 200_000_000
DAILY_QUOTA_HARD_LIMIT_CN = "2亿"
DAILY_QUOTA_HARD_LIMIT_WAN = "20000万"

# ── Stage order ──
STAGE_ORDER = ["5m", "1m", "30m", "60m"]
EXPECTED_BATCH_COUNT = 1102
TOTAL_STOCKS = 5509
YEAR_RANGE = range(2014, 2027)

OLD_ENTRIES = [
    SCRIPTS / "jq_download_execution_r1.py",
    SCRIPTS / "jq_expand_minute.py",
    SCRIPTS / "jq_expand_minute_v2.py",
    SCRIPTS / "jq_expand_minute_v3.py",
    SCRIPTS / "jq_resume_r2.py",
]

GUARD_MARKER = "P7 MINUTE DIRECT ENTRY FORBIDDEN"
ALLOWED_EXECUTOR = "deepseek-v4-flash"
ALLOWED_SCRIPT_MODEL = "glm-4.7"
ALLOWED_SECOND_PASS_REVIEW_MODEL = "GLM-5.1"
ALLOWED_STAGE_GATE_REVIEW_MODEL = "glm-4.7"
ALLOWED_FINAL_REVIEW_MODEL = "GLM-5.1"
ALLOWED_VISUAL_MODEL = "glm-4.6v"
EXECUTION_FALLBACK_MODEL = "glm-4.5-air"
SCRIPT_FALLBACK_MODEL = "deepseek-v4-pro"
FINAL_GATE_OWNER = "HAND"

SCRIPT_5M_LAUNCHER = SCRIPTS / "p7_5m_matrix_launcher.py"
SCRIPT_1M_LAUNCHER = SCRIPTS / "p7_1m_matrix_launcher.py"
SCRIPT_5M_WORKER = SCRIPTS / "p7_5m_matrix_worker.py"
SCRIPT_1M_WORKER = SCRIPTS / "p7_1m_matrix_worker.py"
SCRIPT_30M_LAUNCHER = SCRIPTS / "p7_30m_matrix_launcher.py"
SCRIPT_60M_LAUNCHER = SCRIPTS / "p7_60m_matrix_launcher.py"

HAND_EXIT_CODE = 2  # HAND gate block exit code (task spec)

# ── Concurrency (3-worker ceiling, HAND may downgrade to 1-2) ──
MAX_WORKER = 3
MAX_WORKER_CEILING = 3
POOLS = ["POOL_A", "POOL_B", "POOL_C"]
CONCURRENCY_MODE = "stage_local_3_worker"
SHARED_ROOT = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_hand_shared")
LOCK_DIR = SHARED_ROOT / "locks"
GLOBAL_STOP_PATH = SHARED_ROOT / "global_stop.signal"
PARTITION_CLAIM_DIR = SHARED_ROOT / "partition_claims"
QUEUE_CLAIM_DIR = SHARED_ROOT / "queue_claims"

CONCURRENCY_FIELDS = {
    "max_worker_ceiling": MAX_WORKER_CEILING,
    "concurrency_mode": CONCURRENCY_MODE,
    "cross_stage_parallel": False,
    "quota_lock_required": True,
    "ledger_lock_required": True,
    "checkpoint_lock_required": True,
    "file_write_lock_required": True,
    "queue_claim_lock_required": True,
    "allowed_stage_only": True,
    "launcher_auto_stage_switch": False,
    "stage_complete_requires_hand_recheck": True,
}


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")


def now_ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def quota_fmt(n: int | None) -> str:
    v = int(n or 0)
    return f"{v:,} ({v / 1e8:.2f}亿 / {v / 1e4:.0f}万)"


# ── File lock (Windows-safe exclusive create) ──
class FileLock:
    def __init__(self, name: str, timeout: float = 30.0):
        safe = name.replace("/", "_").replace("\\", "_")
        self.path = LOCK_DIR / f"{safe}.lock"
        self.timeout = timeout
        self._fd: int | None = None

    def acquire(self) -> bool:
        LOCK_DIR.mkdir(parents=True, exist_ok=True)
        deadline = time.time() + self.timeout
        while time.time() < deadline:
            try:
                self._fd = os.open(
                    str(self.path),
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
                os.write(self._fd, f"pid={os.getpid()} ts={now_iso()}\n".encode())
                return True
            except FileExistsError:
                time.sleep(0.2)
        return False

    def release(self) -> None:
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None
        try:
            self.path.unlink(missing_ok=True)
        except OSError:
            pass

    def __enter__(self):
        if not self.acquire():
            raise RuntimeError(f"lock timeout: {self.path.name}")
        return self

    def __exit__(self, *args):
        self.release()


# ── Old entrypoint guard check ──
def check_old_entrypoints() -> dict[str, Any]:
    bypass = []
    guarded = []
    missing = []
    for ep in OLD_ENTRIES:
        if not ep.exists():
            missing.append(ep.name)
            continue
        txt = ep.read_text(encoding="utf-8", errors="replace")
        if GUARD_MARKER in txt:
            guarded.append(ep.name)
        else:
            bypass.append(ep.name)
    return {
        "old_entrypoint_bypass_risk_count": len(bypass),
        "guarded_count": len(guarded),
        "missing_count": len(missing),
        "bypass_risk_files": bypass,
        "guarded_files": guarded,
        "missing_files": missing,
        "guarded_entry_required": True,
        "pass": len(bypass) == 0,
    }


# ── 5m quality gate scan (no API) ──
def scan_5m_quality_gate() -> dict[str, Any]:
    by_year: dict[int, dict] = defaultdict(
        lambda: {"files": 0, "batches": set(), "sc_ok": 0, "ck_ok": 0, "sc_miss": 0, "ck_miss": 0}
    )
    real_5m = [
        f
        for f in P7_5M.glob("stock_minute_5m__*.parquet")
        if ".sidecar" not in f.name and ".checksum" not in f.name
    ]
    for f in real_5m:
        m = re.match(r"stock_minute_5m__(\d{4})__(batch\d+)__.*\.parquet", f.name)
        if not m:
            continue
        yr = int(m.group(1))
        by_year[yr]["files"] += 1
        by_year[yr]["batches"].add(m.group(2))
        sc = f.with_suffix(".parquet.sidecar.json")
        if sc.exists():
            try:
                jd = json.loads(sc.read_text(encoding="utf-8"))
                if jd.get("frequency") == "5m":
                    by_year[yr]["sc_ok"] += 1
                else:
                    by_year[yr]["sc_miss"] += 1
            except Exception:
                by_year[yr]["sc_miss"] += 1
        else:
            by_year[yr]["sc_miss"] += 1
        ck = f.with_suffix(".parquet.checksum.sha256")
        if ck.exists():
            try:
                stored = ck.read_text(encoding="utf-8").strip()
                actual = hashlib.sha256(f.read_bytes()).hexdigest()
                if stored == actual:
                    by_year[yr]["ck_ok"] += 1
                else:
                    by_year[yr]["ck_miss"] += 1
            except Exception:
                by_year[yr]["ck_miss"] += 1
        else:
            by_year[yr]["ck_miss"] += 1

    year_report = []
    all_complete = True
    empty_years = []
    for yr in YEAR_RANGE:
        info = by_year.get(yr)
        if info is None:
            empty_years.append(yr)
            all_complete = False
            year_report.append(
                {
                    "year": yr,
                    "batches_on_disk": 0,
                    "expected_batches": EXPECTED_BATCH_COUNT,
                    "batch_coverage_pct": 0.0,
                    "sidecar_ok": 0,
                    "sidecar_miss": 0,
                    "checksum_ok": 0,
                    "checksum_miss": 0,
                    "complete": False,
                    "gap": EXPECTED_BATCH_COUNT,
                }
            )
            continue
        n = len(info["batches"])
        gap = max(0, EXPECTED_BATCH_COUNT - n)
        yr_ok = gap == 0 and info["sc_miss"] == 0 and info["ck_miss"] == 0
        if not yr_ok:
            all_complete = False
        year_report.append(
            {
                "year": yr,
                "batches_on_disk": n,
                "expected_batches": EXPECTED_BATCH_COUNT,
                "batch_coverage_pct": round(n / EXPECTED_BATCH_COUNT * 100, 1) if n else 0.0,
                "sidecar_ok": info["sc_ok"],
                "sidecar_miss": info["sc_miss"],
                "checksum_ok": info["ck_ok"],
                "checksum_miss": info["ck_miss"],
                "complete": yr_ok,
                "gap": gap,
            }
        )

    gate = {
        "gate": "5m_quality_gate",
        "quality_gate_pass": all_complete,
        "five_m_quality_gate_pass": all_complete,
        "all_years_complete": all_complete,
        "year_range": f"{YEAR_RANGE.start}-{YEAR_RANGE.stop - 1}",
        "years_checked": len(year_report),
        "years_empty": empty_years,
        "years_complete": sum(1 for r in year_report if r["complete"]),
        "total_parquet_files": len(real_5m),
        "generated_at": now_iso(),
        "year_details": year_report,
    }
    if not all_complete:
        gate["block_1m_until"] = "all years complete + all sidecar OK + all checksum OK"
    return gate


def write_5m_quality_gate(gate: dict[str, Any] | None = None) -> Path:
    gate = gate or scan_5m_quality_gate()
    GATE_5M_PATH.parent.mkdir(parents=True, exist_ok=True)
    GATE_5M_PATH.write_text(json.dumps(gate, ensure_ascii=False, indent=2), encoding="utf-8")
    return GATE_5M_PATH


def load_5m_quality_gate() -> dict[str, Any] | None:
    if GATE_5M_PATH.exists():
        return json.loads(GATE_5M_PATH.read_text(encoding="utf-8"))
    return None


# ── Build 5m missing + sidecar/checksum correction queues (no API) ──
def _disk_5m_batches() -> set[tuple[int, str]]:
    disk = set()
    for f in P7_5M.glob("stock_minute_5m__*.parquet"):
        if ".sidecar" in f.name or ".checksum" in f.name:
            continue
        m = re.match(r"stock_minute_5m__(\d{4})__(batch\d+)__", f.name)
        if m:
            disk.add((int(m.group(1)), m.group(2)))
    return disk


def build_5m_missing_queue() -> list[dict[str, str]]:
    disk = _disk_5m_batches()
    rows = []
    order = 0
    for yr in sorted(YEAR_RANGE, reverse=True):
        for bi in range(EXPECTED_BATCH_COUNT):
            bn = f"batch{bi:04d}"
            if (yr, bn) in disk:
                continue
            rows.append(
                {
                    "queue_order": str(order),
                    "frequency": "5m",
                    "stage": "5m_missing",
                    "partition_key": f"5m/{yr}/{bn}",
                    "year": str(yr),
                    "batch_id": bn,
                    "api_call_allowed": "true",
                    "reason": "5m_missing",
                    "output_target": f"P7_stock_minute/stock_minute_5m__{yr}__{bn}__",
                }
            )
            order += 1
    return rows


def build_sidecar_checksum_correction_queue() -> list[dict[str, str]]:
    rows = []
    order = 0
    for f in sorted(P7_5M.glob("stock_minute_5m__*.parquet")):
        if ".sidecar" in f.name or ".checksum" in f.name:
            continue
        m = re.match(r"stock_minute_5m__(\d{4})__(batch\d+)__", f.name)
        if not m:
            continue
        yr, bt = m.group(1), m.group(2)
        sc = f.with_suffix(".parquet.sidecar.json")
        ck = f.with_suffix(".parquet.checksum.sha256")
        need_sc = not sc.exists()
        need_ck = not ck.exists()
        if ck.exists():
            try:
                if ck.read_text(encoding="utf-8").strip() != hashlib.sha256(f.read_bytes()).hexdigest():
                    need_ck = True
            except Exception:
                need_ck = True
        if not need_sc and not need_ck:
            continue
        rows.append(
            {
                "queue_order": str(order),
                "frequency": "5m",
                "stage": "5m_correction",
                "partition_key": f"5m/{yr}/{bt}",
                "year": yr,
                "batch_id": bt,
                "parquet_path": str(f),
                "need_sidecar": str(need_sc).lower(),
                "need_checksum": str(need_ck).lower(),
                "api_call_allowed": "false",
                "reason": "sidecar_checksum_correction",
            }
        )
        order += 1
    return rows


def write_csv(path: Path, rows: list[dict[str, str]]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return path
    all_keys: list[str] = []
    seen = set()
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k)
                all_keys.append(k)
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=all_keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    return path


# ── Latest checkpoint reader ──
def find_latest_checkpoint(manifest_dir: Path) -> dict[str, Any] | None:
    best = None
    best_ts = ""
    for pool in ["POOL_A", "POOL_B", "POOL_C", ""]:
        base = manifest_dir / pool / "checkpoint" if pool else manifest_dir / "checkpoint"
        if not base.exists():
            continue
        for f in base.glob("*.json"):
            if f.name > best_ts:
                best_ts = f.name
                try:
                    best = json.loads(f.read_text(encoding="utf-8"))
                except Exception:
                    pass
    return best


# ── HAND decision reader / enforcer ──
def load_hand_decision() -> dict[str, Any] | None:
    if not HAND_DECISION_PATH.exists():
        return None
    return json.loads(HAND_DECISION_PATH.read_text(encoding="utf-8"))


def enforce_hand_gate(
    *,
    script_path: Path,
    required_stage: str | None = None,
    require_one_m: bool = False,
    require_thirty_m: bool = False,
    require_sixty_m: bool = False,
    executor: str = ALLOWED_EXECUTOR,
) -> dict[str, Any]:
    """Exit HAND_EXIT_CODE if HAND not released. Returns decision dict."""
    dec = load_hand_decision()
    if dec is None:
        print(f"BLOCK: HAND_DECISION missing: {HAND_DECISION_PATH}")
        print("Run: python 脚本/p7_hand_stage_controller.py")
        sys.exit(HAND_EXIT_CODE)

    if dec.get("hand_release_allowed") is not True:
        print("BLOCK: hand_release_allowed=false")
        print(f"  reason: {dec.get('blocked_reason', 'unknown')}")
        sys.exit(HAND_EXIT_CODE)

    if dec.get("allowed_executor") != executor:
        print(f"BLOCK: allowed_executor={dec.get('allowed_executor')} != {executor}")
        sys.exit(HAND_EXIT_CODE)

    allowed = dec.get("allowed_script", "")
    if allowed and Path(allowed).resolve() != script_path.resolve():
        print(f"BLOCK: allowed_script={allowed} != {script_path}")
        sys.exit(HAND_EXIT_CODE)

    if required_stage and dec.get("current_stage") != required_stage:
        print(f"BLOCK: current_stage={dec.get('current_stage')} != {required_stage}")
        sys.exit(HAND_EXIT_CODE)

    if require_one_m and dec.get("one_m_allowed") is not True:
        print("BLOCK: one_m_allowed=false (5m gate must PASS first)")
        sys.exit(HAND_EXIT_CODE)

    if require_thirty_m and dec.get("thirty_m_allowed") is not True:
        print("BLOCK: thirty_m_allowed=false")
        sys.exit(HAND_EXIT_CODE)

    if require_sixty_m and dec.get("sixty_m_allowed") is not True:
        print("BLOCK: sixty_m_allowed=false")
        sys.exit(HAND_EXIT_CODE)

    if dec.get("cross_stage_parallel") is True:
        print("BLOCK: cross_stage_parallel=true forbidden")
        sys.exit(HAND_EXIT_CODE)

    ceiling = int(dec.get("max_worker_ceiling", dec.get("max_worker", MAX_WORKER_CEILING)))
    active = int(dec.get("active_workers", ceiling))
    if ceiling > MAX_WORKER_CEILING or ceiling < 1:
        print(f"BLOCK: max_worker_ceiling={ceiling} invalid")
        sys.exit(HAND_EXIT_CODE)
    if active < 1 or active > ceiling:
        print(f"BLOCK: active_workers={active} not in [1,{ceiling}]")
        sys.exit(HAND_EXIT_CODE)

    if dec.get("launcher_auto_stage_switch") is True:
        print("BLOCK: launcher_auto_stage_switch=true forbidden")
        sys.exit(HAND_EXIT_CODE)

    if dec.get("stage_order_violation_count", 0) != 0:
        print("BLOCK: stage_order_violation_count != 0")
        sys.exit(HAND_EXIT_CODE)

    if dec.get("old_entrypoint_bypass_risk_count", 0) != 0:
        print("BLOCK: old_entrypoint_bypass_risk_count != 0")
        sys.exit(HAND_EXIT_CODE)

    print(f"HAND gate OK: level={dec.get('hand_release_level')} stage={dec.get('current_stage')} active_workers={active}/{ceiling}")
    return dec


# ── Quota read (optional, skip in dry_run) ──
def read_quota_left(*, dry_run: bool = False) -> int | None:
    if dry_run:
        return None
    sys.path.insert(0, str(SCRIPTS))
    import jq_download_base as jdb  # noqa: PLC0415

    jdb.auth()
    return jdb.quota_left(force=True) or 0


# ── Determine current stage from gates ──
def determine_current_stage(gate_5m: dict[str, Any] | None = None) -> str:
    return determine_current_stage_full()


def next_stage(stage: str) -> str | None:
    if stage not in STAGE_ORDER:
        return None
    i = STAGE_ORDER.index(stage)
    return STAGE_ORDER[i + 1] if i + 1 < len(STAGE_ORDER) else None


def prev_stage(stage: str) -> str | None:
    if stage not in STAGE_ORDER:
        return None
    i = STAGE_ORDER.index(stage)
    return STAGE_ORDER[i - 1] if i > 0 else None


# Default safety flags for download task (no API, no mutation)
DOWNLOAD_SAFETY_DEFAULTS = {
    "official_raw_deleted": False,
    "official_raw_overwritten": False,
    "derived_30m60m_used_as_official_raw": False,
    "strategy_code_modified": False,
    "engine_modified": False,
    "backtest_run": False,
    "qmt_touched": False,
    "live_touched": False,
    "broker_touched": False,
    "complete_partition_redownload_detected": False,
}


def evaluate_hard_gate(
    freq: str,
    gate: dict[str, Any],
    entry: dict[str, Any],
    *,
    safety: dict[str, bool] | None = None,
) -> dict[str, Any]:
    """Evaluate HAND hard gate for a stage. No JQData."""
    safety = {**DOWNLOAD_SAFETY_DEFAULTS, **(safety or {})}
    failures: list[str] = []

    if not gate.get("quality_gate_pass"):
        failures.append("quality_gate_not_pass")
    if not gate.get("all_years_complete"):
        failures.append("all_years_not_complete")
    if gate.get("missing_count", 0) > 0:
        failures.append(f"missing_count={gate.get('missing_count')}")
    if gate.get("sidecar_missing_count", 0) > 0:
        failures.append(f"sidecar_missing_count={gate.get('sidecar_missing_count')}")
    if gate.get("checksum_missing_count", 0) > 0:
        failures.append(f"checksum_missing_count={gate.get('checksum_missing_count')}")
    if gate.get("review_required_count", 0) > 0:
        failures.append(f"review_required_count={gate.get('review_required_count')}")
    cc = gate.get("checksum_conflict_count", gate.get("conflict_count", 0))
    if cc > 0:
        failures.append(f"checksum_conflict_count={cc}")
    if gate.get("row_count_conflict_count", 0) > 0:
        failures.append(f"row_count_conflict_count={gate.get('row_count_conflict_count')}")
    if gate.get("stage_order_violation_count", 0) > 0:
        failures.append("stage_order_violation")
    if entry.get("old_entrypoint_bypass_risk_count", 0) > 0:
        failures.append(f"old_entrypoint_bypass_risk={entry['old_entrypoint_bypass_risk_count']}")

    for k, v in safety.items():
        if v:
            failures.append(k)

    # Ledger / lock sanity (file existence, no API)
    if not NO_REDOWLOAD_LEDGER_RUNS.exists() and not NO_REDOWLOAD_LEDGER_MANIFEST.exists():
        failures.append("no_redownload_ledger_missing")

    hg_pass = len(failures) == 0
    return {
        "frequency": freq,
        "hard_gate_pass": hg_pass,
        "hard_gate_failure_reason": "; ".join(failures) if failures else "",
        "quality_gate_pass": gate.get("quality_gate_pass"),
        "missing_count": gate.get("missing_count", 0),
        "sidecar_missing_count": gate.get("sidecar_missing_count", 0),
        "checksum_missing_count": gate.get("checksum_missing_count", 0),
        "review_required_count": gate.get("review_required_count", 0),
        "checksum_conflict_count": cc,
        "row_count_conflict_count": gate.get("row_count_conflict_count", 0),
    }


def build_hand_decision(
    *, dry_run: bool = False,
    task: str = "JQ_P7_HAND_AUTO_STAGE_ADVANCE_R1",
) -> dict[str, Any]:
    entry = check_old_entrypoints()
    gates: dict[str, dict[str, Any]] = {}
    for freq in ("5m", "1m"):
        gates[freq] = scan_frequency_quality_gate(freq)
        write_quality_gate(freq, gates[freq])
    write_stub_gate_30m_60m()
    gates["30m"] = load_quality_gate("30m") or {}
    gates["60m"] = load_quality_gate("60m") or {}

    hard_gates = {f: evaluate_hard_gate(f, gates[f], entry) for f in STAGE_ORDER}

    five_pass = hard_gates["5m"]["hard_gate_pass"]
    one_pass = hard_gates["1m"]["hard_gate_pass"]
    thirty_pass = hard_gates["30m"]["hard_gate_pass"]
    sixty_pass = hard_gates["60m"]["hard_gate_pass"]

    work_stage = determine_current_stage_full()
    idx = STAGE_ORDER.index(work_stage)

    script_map = {
        "5m": SCRIPT_5M_LAUNCHER, "1m": SCRIPT_1M_LAUNCHER,
        "30m": SCRIPT_30M_LAUNCHER, "60m": SCRIPT_60M_LAUNCHER,
    }
    level_map = {
        "5m": "RELEASE_ALLOWED_FOR_V4FLASH_5M_EXECUTION",
        "1m": "RELEASE_ALLOWED_FOR_V4FLASH_1M_EXECUTION",
        "30m": "RELEASE_ALLOWED_FOR_V4FLASH_30M_EXECUTION",
        "60m": "RELEASE_ALLOWED_FOR_V4FLASH_60M_EXECUTION",
    }

    # Auto-advance: if previous stage hard gate PASS, release work_stage
    release_stage = work_stage
    stage_transition_reason = f"work_stage_{work_stage}"
    auto_stage_advance = False
    if idx > 0:
        prev = STAGE_ORDER[idx - 1]
        if hard_gates[prev]["hard_gate_pass"]:
            auto_stage_advance = True
            stage_transition_reason = f"{prev}_hard_gate_pass_auto_advance_to_{work_stage}"
            release_stage = work_stage

    current_stage_complete = hard_gates[work_stage]["hard_gate_pass"]
    ns = next_stage(work_stage)

    # If work stage just completed, auto-release next stage
    if current_stage_complete and ns:
        release_stage = ns
        auto_stage_advance = True
        stage_transition_reason = f"{work_stage}_hard_gate_pass_auto_advance_to_{ns}"

    ql = read_quota_left(dry_run=dry_run)
    ql_int = int(ql) if ql is not None else 0
    active_workers = compute_active_workers(quota_left=ql_int, dry_run=dry_run)

    blocked_reason = ""
    hand_release_allowed = False
    hand_release_level = "BLOCKED"
    allowed_executor = ""
    allowed_script = ""
    next_action = ""
    user_confirmation_required = False
    hard_gate_pass = hard_gates.get(release_stage, hard_gates[work_stage])["hard_gate_pass"]
    hard_gate_failure_reason = ""

    if not entry["pass"]:
        blocked_reason = f"old_entrypoint_bypass_risk={entry['old_entrypoint_bypass_risk_count']}"
        user_confirmation_required = True
        hard_gate_pass = False
        hard_gate_failure_reason = blocked_reason
        next_action = "Fix hard guards on old entrypoints"
    elif release_stage == "30m" and not SCRIPT_30M_LAUNCHER.exists():
        blocked_reason = "30m_launcher_missing"
        user_confirmation_required = True
        hard_gate_pass = False
        next_action = "Deploy 30m launcher"
    elif release_stage == "60m" and not SCRIPT_60M_LAUNCHER.exists():
        blocked_reason = "60m_launcher_missing"
        user_confirmation_required = True
        hard_gate_pass = False
        next_action = "Deploy 60m launcher"
    elif release_stage == "1m" and not five_pass:
        blocked_reason = hard_gates["5m"]["hard_gate_failure_reason"] or "5m_hard_gate_not_pass"
        user_confirmation_required = True
        hard_gate_pass = False
        hard_gate_failure_reason = blocked_reason
        next_action = "Complete 5m stage"
    elif release_stage == "30m" and not one_pass:
        blocked_reason = hard_gates["1m"]["hard_gate_failure_reason"] or "1m_hard_gate_not_pass"
        user_confirmation_required = True
        hard_gate_pass = False
        hard_gate_failure_reason = blocked_reason
        next_action = "Complete 1m stage"
    elif release_stage == "60m" and not thirty_pass:
        blocked_reason = hard_gates["30m"]["hard_gate_failure_reason"] or "30m_hard_gate_not_pass"
        user_confirmation_required = True
        hard_gate_pass = False
        hard_gate_failure_reason = blocked_reason
        next_action = "Complete 30m stage"
    else:
        # Normal download release for release_stage
        hg_release = hard_gates[release_stage]
        if release_stage != work_stage or not current_stage_complete:
            # Releasing incomplete work stage for download — hard gate on work stage may fail, that's OK for download
            hand_release_allowed = True
            hand_release_level = level_map[release_stage]
            allowed_executor = ALLOWED_EXECUTOR
            allowed_script = str(script_map[release_stage])
            hard_gate_pass = hg_release["hard_gate_pass"] if current_stage_complete else False
            hard_gate_failure_reason = hg_release["hard_gate_failure_reason"]
            user_confirmation_required = False
            next_action = f"V4FLASH: {active_workers}-worker {release_stage} download"
            if auto_stage_advance:
                next_action += f" (auto-advanced: {stage_transition_reason})"
        elif current_stage_complete and ns:
            hand_release_allowed = True
            hand_release_level = level_map[release_stage]
            allowed_executor = ALLOWED_EXECUTOR
            allowed_script = str(script_map[release_stage])
            hard_gate_pass = True
            user_confirmation_required = False
            next_action = f"V4FLASH: auto-advance to {release_stage}"

    if ql_int <= 0 and hand_release_allowed and not dry_run:
        hand_release_allowed = False
        blocked_reason = blocked_reason or "quota_left_zero"
        next_action = "Wait quota reset, then re-run HAND preflight"

    if active_workers == 0 and hand_release_allowed and not dry_run:
        hand_release_allowed = False
        blocked_reason = blocked_reason or "quota_left_zero"

    one_m_allowed = five_pass
    thirty_m_allowed = one_pass
    sixty_m_allowed = thirty_pass
    next_stage_auto = auto_stage_advance and hand_release_allowed and not user_confirmation_required

    dec = {
        "task": task,
        "current_stage": release_stage,
        "current_frequency": release_stage,
        "work_stage": work_stage,
        "five_m_quality_gate_pass": gates["5m"].get("quality_gate_pass"),
        "one_m_quality_gate_pass": gates["1m"].get("quality_gate_pass"),
        "thirty_m_quality_gate_pass": gates["30m"].get("quality_gate_pass"),
        "sixty_m_quality_gate_pass": gates["60m"].get("quality_gate_pass"),
        "one_m_allowed": one_m_allowed,
        "thirty_m_allowed": thirty_m_allowed,
        "sixty_m_allowed": sixty_m_allowed,
        "hand_release_allowed": hand_release_allowed,
        "hand_release_level": hand_release_level,
        "allowed_executor": allowed_executor,
        "allowed_script": allowed_script,
        "hard_gate_required": True,
        "hard_gate_pass": hard_gate_pass,
        "hard_gate_failure_reason": hard_gate_failure_reason,
        "current_stage_complete": current_stage_complete,
        "next_stage": ns or "",
        "next_stage_auto_release_allowed": next_stage_auto,
        "auto_stage_advance_allowed": auto_stage_advance and hand_release_allowed,
        "user_confirmation_required": user_confirmation_required,
        "stage_transition_reason": stage_transition_reason,
        "hard_gates": {f: {"pass": hard_gates[f]["hard_gate_pass"],
                           "reason": hard_gates[f]["hard_gate_failure_reason"]} for f in STAGE_ORDER},
        "quota_left": ql_int,
        "quota_unit_int": DAILY_QUOTA_HARD_LIMIT_INT,
        "quota_unit_cn": DAILY_QUOTA_HARD_LIMIT_CN,
        "quota_unit_wan": DAILY_QUOTA_HARD_LIMIT_WAN,
        "stage_order_violation_count": 0,
        "old_entrypoint_bypass_risk_count": entry["old_entrypoint_bypass_risk_count"],
        "guarded_entry_required": True,
        "next_action": next_action,
        "blocked_reason": blocked_reason,
        "generated_at": now_iso(),
        "time_zone": "UTC",
        "dry_run": dry_run,
        "all_frequency_3_worker_mode_locked": True,
        "launcher_auto_stage_switch": False,
        "stage_complete_requires_hand_recheck": True,
        "hard_gate_auto_advance_patched": True,
        "user_confirmation_required_for_normal_download": False,
        "pro_script_ready_for_hand_review": True,
        "glm51_review_required": True,
        "glm51_second_pass_review_enabled": True,
        "glm46v_visual_review_only": True,
        "glm46v_code_review_forbidden": True,
        "glm47_final_review_enabled": True,
        "allowed_script_model": ALLOWED_SCRIPT_MODEL,
        "allowed_second_pass_review_model": ALLOWED_SECOND_PASS_REVIEW_MODEL,
        "allowed_stage_gate_review_model": ALLOWED_STAGE_GATE_REVIEW_MODEL,
        "allowed_final_review_model": ALLOWED_FINAL_REVIEW_MODEL,
        "allowed_visual_model": ALLOWED_VISUAL_MODEL,
        "execution_fallback_model": EXECUTION_FALLBACK_MODEL,
        "script_fallback_model": SCRIPT_FALLBACK_MODEL,
        "final_gate_owner": FINAL_GATE_OWNER,
        "model_routing_version": "HAND_MODEL_ROUTING_AFTER_MODEL_CAPABILITY_RECHECK_R1",
        "model_routing_decision_required": True,
        "deepseek_v4_flash_fallback_only": False,
        "deepseek_v4_flash_execution_primary": True,
        "glm45air_execution_fallback": True,
        "deepseek_v4_pro_fallback_only": True,
        "launch_commands": {
            "hand_preflight": f"{BLACKBOX / '.venv/Scripts/python.exe'} -u {SCRIPTS / 'p7_hand_stage_controller.py'}",
            "5m_matrix": f"{BLACKBOX / '.venv/Scripts/python.exe'} -u {SCRIPT_5M_LAUNCHER}",
            "1m_matrix": f"{BLACKBOX / '.venv/Scripts/python.exe'} -u {SCRIPT_1M_LAUNCHER}",
            "30m_matrix": f"{BLACKBOX / '.venv/Scripts/python.exe'} -u {SCRIPT_30M_LAUNCHER}",
            "60m_matrix": f"{BLACKBOX / '.venv/Scripts/python.exe'} -u {SCRIPT_60M_LAUNCHER}",
        },
    }
    dec.update(concurrency_base_fields(release_stage, active_workers=active_workers))
    return dec


QMT_CAPABILITY_LOCK_KEYS = (
    "HAND_LIFT_QMT_NO_ORDER_HARD_PROHIBITION",
    "HAND_QMT_ORDER_CAPABILITY_ALLOWED",
    "HAND_QMT_BRIDGE_ORDER_CAPABILITY_ALLOWED",
    "HAND_LIVE_TRADING_CAPABILITY_ALLOWED",
    "qmt_connect_allowed",
    "qmt_connect_scope",
    "qmt_order_allowed",
    "qmt_bridge_order_allowed",
    "live_trade_allowed",
    "QMT_ORDER_ENABLED",
    "qmt_allowed",
    "QMT_allowed",
)


def _qmt_capability_locked(prev: dict[str, Any]) -> bool:
    return prev.get("HAND_QMT_ORDER_CAPABILITY_ALLOWED") is True or prev.get(
        "qmt_connect_scope"
    ) == "CONNECT_AND_ORDER_GOVERNED"


def _incoming_keeps_qmt_capability(decision: dict[str, Any]) -> bool:
    return (
        decision.get("HAND_QMT_ORDER_CAPABILITY_ALLOWED") is True
        and decision.get("qmt_connect_scope") == "CONNECT_AND_ORDER_GOVERNED"
        and decision.get("qmt_order_allowed") is True
        and decision.get("qmt_bridge_order_allowed") is True
        and decision.get("live_trade_allowed") is True
        and str(decision.get("QMT_ORDER_ENABLED", "")).upper() == "YES"
    )


def preserve_qmt_order_capability(decision: dict[str, Any]) -> dict[str, Any]:
    """Once HAND lifted never-order, old release scripts must not silently restore NO_ORDER."""
    if not HAND_DECISION_PATH.exists():
        return decision
    try:
        prev = json.loads(HAND_DECISION_PATH.read_text(encoding="utf-8"))
    except Exception:
        return decision
    if not _qmt_capability_locked(prev):
        return decision
    if _incoming_keeps_qmt_capability(decision):
        return decision
    if decision.get("hand_qmt_capability_downgrade_authorized") is True:
        return decision
    for k in QMT_CAPABILITY_LOCK_KEYS:
        if k in prev:
            decision[k] = prev[k]
    decision["qmt_capability_preserve_applied"] = True
    decision["qmt_capability_preserve_reason"] = "SUPERSEDED_BY_HAND_QMT_ORDER_GOVERNANCE_R1"
    return decision


def write_hand_decision(decision: dict[str, Any]) -> Path:
    RUNS.mkdir(parents=True, exist_ok=True)
    decision = preserve_qmt_order_capability(decision)
    HAND_DECISION_PATH.write_text(json.dumps(decision, ensure_ascii=False, indent=2), encoding="utf-8")
    return HAND_DECISION_PATH


def write_hand_md(decision: dict[str, Any]) -> Path:
    RUNS.mkdir(parents=True, exist_ok=True)
    lines = [
        "# LOCAL HAND RELEASE DECISION",
        "",
        f"generated_at: {decision.get('generated_at')}",
        f"task: {decision.get('task')}",
        "",
        f"**hand_release_allowed**: {decision.get('hand_release_allowed')}",
        f"**hand_release_level**: {decision.get('hand_release_level')}",
        f"**current_stage**: {decision.get('current_stage')}",
        f"**allowed_executor**: {decision.get('allowed_executor')}",
        f"**qmt_connect_scope**: {decision.get('qmt_connect_scope')}",
        f"**qmt_order_allowed**: {decision.get('qmt_order_allowed')}",
        f"**qmt_bridge_order_allowed**: {decision.get('qmt_bridge_order_allowed')}",
        f"**live_trade_allowed**: {decision.get('live_trade_allowed')}",
        f"**QMT_ORDER_ENABLED**: {decision.get('QMT_ORDER_ENABLED')}",
        f"**HAND_QMT_ORDER_CAPABILITY_ALLOWED**: {decision.get('HAND_QMT_ORDER_CAPABILITY_ALLOWED')}",
        f"**allowed_script**: {decision.get('allowed_script')}",
        "",
        f"five_m_quality_gate_pass: {decision.get('five_m_quality_gate_pass')}",
        f"one_m_allowed: {decision.get('one_m_allowed')}",
        f"thirty_m_allowed: {decision.get('thirty_m_allowed')}",
        f"sixty_m_allowed: {decision.get('sixty_m_allowed')}",
        "",
        f"max_worker_ceiling: {decision.get('max_worker_ceiling', 3)}",
        f"active_workers: {decision.get('active_workers')}",
        f"launcher_auto_stage_switch: {decision.get('launcher_auto_stage_switch')}",
        f"queue_claim_lock_required: {decision.get('queue_claim_lock_required')}",
        f"glm51_review_required: {decision.get('glm51_review_required')}",
        f"glm51_second_pass_review_enabled: {decision.get('glm51_second_pass_review_enabled')}",
        f"glm47_final_review_enabled: {decision.get('glm47_final_review_enabled')}",
        f"glm46v_visual_review_only: {decision.get('glm46v_visual_review_only')}",
        f"allowed_script_model: {decision.get('allowed_script_model')}",
        f"allowed_second_pass_review_model: {decision.get('allowed_second_pass_review_model')}",
        f"allowed_stage_gate_review_model: {decision.get('allowed_stage_gate_review_model')}",
        f"allowed_final_review_model: {decision.get('allowed_final_review_model')}",
        f"allowed_visual_model: {decision.get('allowed_visual_model')}",
        f"final_gate_owner: {decision.get('final_gate_owner')}",
        f"model_routing_decision_required: {decision.get('model_routing_decision_required')}",
        "",
        f"hard_gate_required: {decision.get('hard_gate_required')}",
        f"hard_gate_pass: {decision.get('hard_gate_pass')}",
        f"current_stage_complete: {decision.get('current_stage_complete')}",
        f"next_stage: {decision.get('next_stage')}",
        f"auto_stage_advance_allowed: {decision.get('auto_stage_advance_allowed')}",
        f"next_stage_auto_release_allowed: {decision.get('next_stage_auto_release_allowed')}",
        f"user_confirmation_required: {decision.get('user_confirmation_required')}",
        f"stage_transition_reason: {decision.get('stage_transition_reason')}",
        "",
        f"quota_left: {quota_fmt(decision.get('quota_left'))}",
        f"stage_order_violation_count: {decision.get('stage_order_violation_count')}",
        f"old_entrypoint_bypass_risk_count: {decision.get('old_entrypoint_bypass_risk_count')}",
        f"user_confirmation_required: {decision.get('user_confirmation_required')}",
        "",
        f"next_action: {decision.get('next_action')}",
    ]
    if decision.get("blocked_reason"):
        lines.append(f"blocked_reason: {decision['blocked_reason']}")
    lines += ["", "## Launch Commands (deepseek-v4-flash execution after HAND PASS)", ""]
    for k, v in (decision.get("launch_commands") or {}).items():
        lines.append(f"- **{k}**: `{v}`")
    HAND_MD_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return HAND_MD_PATH


# ═══════════════════════════════════════════════════════════
#  Global concurrency + no-redownload + multi-freq gates
# ═══════════════════════════════════════════════════════════

def _classify_parquet(f: Path, freq: str) -> dict[str, Any]:
    """Classify single parquet: complete | incomplete | review_required."""
    sc = f.with_suffix(".parquet.sidecar.json")
    ck = f.with_suffix(".parquet.checksum.sha256")
    m = re.match(rf"stock_minute_{freq}__(\d{{4}})__(batch\d+)__", f.name)
    yr, bt = (m.group(1), m.group(2)) if m else ("", "")
    pk = f"{freq}/{yr}/{bt}" if yr else ""
    row_count = ""
    status = "missing"
    api_allowed = "true"
    no_redownload = "false"
    next_action = "download_missing"

    if not f.exists():
        return {"partition_key": pk, "frequency": freq, "year": yr, "batch_id": bt,
                "status": "missing", "api_call_allowed": "true", "no_redownload": "false",
                "next_action": "download_missing", "parquet_path": ""}

    if not sc.exists() or not ck.exists():
        return {"partition_key": pk, "frequency": freq, "year": yr, "batch_id": bt,
                "status": "incomplete", "api_call_allowed": "false", "no_redownload": "false",
                "next_action": "correct_sidecar_checksum", "parquet_path": str(f)}

    try:
        stored = ck.read_text(encoding="utf-8").strip()
        actual = hashlib.sha256(f.read_bytes()).hexdigest()
        if stored != actual:
            return {"partition_key": pk, "frequency": freq, "year": yr, "batch_id": bt,
                    "status": "review_required", "api_call_allowed": "false", "no_redownload": "true",
                    "next_action": "hand_review_checksum_conflict", "parquet_path": str(f)}
        jd = json.loads(sc.read_text(encoding="utf-8"))
        if jd.get("frequency") != freq:
            return {"partition_key": pk, "frequency": freq, "year": yr, "batch_id": bt,
                    "status": "review_required", "api_call_allowed": "false", "no_redownload": "true",
                    "next_action": "hand_review_sidecar_mismatch", "parquet_path": str(f)}
        row_count = str(jd.get("row_count", ""))
        return {"partition_key": pk, "frequency": freq, "year": yr, "batch_id": bt,
                "status": "complete", "api_call_allowed": "false", "no_redownload": "true",
                "next_action": "keep_existing", "parquet_path": str(f), "row_count": row_count}
    except Exception:
        return {"partition_key": pk, "frequency": freq, "year": yr, "batch_id": bt,
                "status": "review_required", "api_call_allowed": "false", "no_redownload": "true",
                "next_action": "hand_review_parse_error", "parquet_path": str(f)}


def scan_frequency_quality_gate(freq: str) -> dict[str, Any]:
    """Scan quality gate for any frequency (no API)."""
    prefix = FREQ_FILE_PREFIX.get(freq, f"stock_minute_{freq}__")
    by_year: dict[int, dict] = defaultdict(
        lambda: {"batches": set(), "sc_ok": 0, "sc_miss": 0, "ck_ok": 0, "ck_miss": 0,
                 "review": 0, "conflict": 0}
    )
    missing_count = sidecar_missing = checksum_missing = review_count = conflict_count = 0
    real = [
        f
        for f in root_for_freq(freq).glob(f"{prefix}*.parquet")
        if ".sidecar" not in f.name and ".checksum" not in f.name
    ]

    for f in real:
        cls = _classify_parquet(f, freq)
        m = re.match(rf"stock_minute_{freq}__(\d{{4}})__(batch\d+)__", f.name)
        if not m:
            continue
        yr = int(m.group(1))
        by_year[yr]["batches"].add(m.group(2))
        st = cls["status"]
        if st == "complete":
            by_year[yr]["sc_ok"] += 1
            by_year[yr]["ck_ok"] += 1
        elif st == "incomplete":
            sidecar_missing += 1
            checksum_missing += 1
            by_year[yr]["sc_miss"] += 1
            by_year[yr]["ck_miss"] += 1
        elif st == "review_required":
            review_count += 1
            by_year[yr]["review"] += 1
            if "checksum_conflict" in cls.get("next_action", ""):
                conflict_count += 1
                by_year[yr]["conflict"] += 1

    year_report = []
    all_complete = True
    for yr in YEAR_RANGE:
        info = by_year.get(yr)
        if info is None:
            gap = EXPECTED_BATCH_COUNT
            all_complete = False
            missing_count += gap
            year_report.append({"year": yr, "batches_on_disk": 0, "expected_batches": EXPECTED_BATCH_COUNT,
                                "complete": False, "gap": gap})
            continue
        n = len(info["batches"])
        gap = max(0, EXPECTED_BATCH_COUNT - n)
        missing_count += gap
        yr_ok = gap == 0 and info["sc_miss"] == 0 and info["ck_miss"] == 0 and info["review"] == 0
        if not yr_ok:
            all_complete = False
        year_report.append({"year": yr, "batches_on_disk": n, "expected_batches": EXPECTED_BATCH_COUNT,
                            "sidecar_ok": info["sc_ok"], "sidecar_miss": info["sc_miss"],
                            "checksum_ok": info["ck_ok"], "checksum_miss": info["ck_miss"],
                            "review_required_count": info["review"], "conflict_count": info["conflict"],
                            "complete": yr_ok, "gap": gap})

    entry = check_old_entrypoints()
    qg_pass = (all_complete and missing_count == 0 and sidecar_missing == 0
               and checksum_missing == 0 and review_count == 0 and conflict_count == 0
               and entry["old_entrypoint_bypass_risk_count"] == 0)

    return {
        "gate": f"{freq}_quality_gate",
        "frequency": freq,
        "quality_gate_pass": qg_pass,
        f"{freq.replace('m','')}_quality_gate_pass": qg_pass if freq != "5m" else qg_pass,
        "five_m_quality_gate_pass": qg_pass if freq == "5m" else None,
        "all_years_complete": all_complete,
        "missing_count": missing_count,
        "sidecar_missing_count": sidecar_missing,
        "checksum_missing_count": checksum_missing,
        "review_required_count": review_count,
        "conflict_count": conflict_count,
        "checksum_conflict_count": conflict_count,
        "row_count_conflict_count": 0,
        "stage_order_violation_count": 0,
        "old_entrypoint_bypass_risk_count": entry["old_entrypoint_bypass_risk_count"],
        "years_checked": len(year_report),
        "years_complete": sum(1 for r in year_report if r.get("complete")),
        "total_parquet_files": len(real),
        "generated_at": now_iso(),
        "year_details": year_report,
    }


def scan_5m_quality_gate() -> dict[str, Any]:
    g = scan_frequency_quality_gate("5m")
    g["five_m_quality_gate_pass"] = g["quality_gate_pass"]
    if not g["quality_gate_pass"]:
        g["block_1m_until"] = "5m_quality_gate_pass=true"
    return g


def write_quality_gate(freq: str, gate: dict[str, Any] | None = None) -> Path:
    gate = gate or scan_frequency_quality_gate(freq)
    path = GATE_PATHS[freq]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(gate, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def write_stub_gate_30m_60m() -> None:
    g1 = load_quality_gate("1m")
    one_pass = g1 and g1.get("quality_gate_pass") is True
    g30 = {
        "gate": "30m_quality_gate", "frequency": "30m", "quality_gate_pass": False,
        "30m_allowed": False, "blocked_until": "1m_quality_gate_pass=true",
        "one_m_quality_gate_pass": one_pass, "launcher_exists": SCRIPT_30M_LAUNCHER.exists(),
        "official_raw_required": True, "no_derived_substitute": True,
        "generated_at": now_iso(), "stub": True,
    }
    g3 = load_quality_gate("30m")
    thirty_pass = g3 and g3.get("quality_gate_pass") is True
    g60 = {
        "gate": "60m_quality_gate", "frequency": "60m", "quality_gate_pass": False,
        "60m_allowed": False, "blocked_until": "30m_quality_gate_pass=true",
        "thirty_m_quality_gate_pass": thirty_pass, "launcher_exists": SCRIPT_60M_LAUNCHER.exists(),
        "official_raw_required": True, "no_derived_substitute": True,
        "generated_at": now_iso(), "stub": True,
    }
    write_quality_gate("30m", g30)
    write_quality_gate("60m", g60)


def load_quality_gate(freq: str) -> dict[str, Any] | None:
    p = GATE_PATHS.get(freq)
    if p and p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return None


def scan_partition_inventory() -> list[dict[str, str]]:
    """Scan all frequencies on disk + expected missing slots."""
    rows = []
    order = 0
    for freq in STAGE_ORDER:
        prefix = FREQ_FILE_PREFIX[freq]
        seen_batches: set[tuple[str, str]] = set()
        for f in sorted(root_for_freq(freq).glob(f"{prefix}*.parquet")):
            if ".sidecar" in f.name or ".checksum" in f.name:
                continue
            cls = _classify_parquet(f, freq)
            cls["queue_order"] = str(order)
            rows.append({k: str(v) for k, v in cls.items()})
            seen_batches.add((cls["year"], cls["batch_id"]))
            order += 1
        for yr in YEAR_RANGE:
            for bi in range(EXPECTED_BATCH_COUNT):
                bn = f"batch{bi:04d}"
                if (str(yr), bn) in seen_batches:
                    continue
                pk = f"{freq}/{yr}/{bn}"
                rows.append({"queue_order": str(order), "partition_key": pk, "frequency": freq,
                             "year": str(yr), "batch_id": bn, "status": "missing",
                             "api_call_allowed": "true", "no_redownload": "false",
                             "next_action": "download_missing", "parquet_path": ""})
                order += 1
    return rows


def build_no_redownload_ledger(inventory: list[dict[str, str]] | None = None) -> list[dict[str, str]]:
    inv = inventory or scan_partition_inventory()
    ledger = []
    for r in inv:
        st = r.get("status", "missing")
        if st == "complete":
            ledger.append({**r, "status": "complete", "api_call_allowed": "false",
                           "no_redownload": "true", "next_action": "keep_existing"})
        elif st == "review_required":
            ledger.append({**r, "api_call_allowed": "false", "no_redownload": "true",
                           "next_action": r.get("next_action", "hand_review")})
        elif st == "incomplete":
            ledger.append({**r, "api_call_allowed": "false", "no_redownload": "false",
                           "next_action": "correct_sidecar_checksum"})
        else:
            ledger.append({**r, "api_call_allowed": "true", "no_redownload": "false",
                           "next_action": "download_missing"})
    return ledger


def load_ledger_map(path: Path | None = None) -> dict[str, dict]:
    p = path or NO_REDOWLOAD_LEDGER_RUNS
    if not p.exists() and NO_REDOWLOAD_LEDGER_MANIFEST.exists():
        p = NO_REDOWLOAD_LEDGER_MANIFEST
    m = {}
    if p.exists():
        for r in csv.DictReader(p.read_text(encoding="utf-8-sig").splitlines()):
            m[r.get("partition_key", "")] = r
    return m


def determine_current_stage_full() -> str:
    gates = {f: scan_frequency_quality_gate(f) for f in STAGE_ORDER}
    for f in STAGE_ORDER:
        if not gates[f].get("quality_gate_pass"):
            return f
    return "60m"


def concurrency_base_fields(current_stage: str, *, active_workers: int = MAX_WORKER_CEILING) -> dict[str, Any]:
    aw = max(1, min(active_workers, MAX_WORKER_CEILING))
    return {
        **CONCURRENCY_FIELDS,
        "max_worker_ceiling": MAX_WORKER_CEILING,
        "max_worker": MAX_WORKER_CEILING,  # backward compat: ceiling not forced count
        "active_workers": aw,
        "current_stage_workers_allowed": aw if current_stage else 0,
        "pools": POOLS[:aw],
        "shared_lock_root": str(SHARED_ROOT),
        "queue_claim_root": str(QUEUE_CLAIM_DIR),
    }


def count_lock_contention() -> int:
    if not LOCK_DIR.exists():
        return 0
    return len(list(LOCK_DIR.glob("*.lock")))


def compute_active_workers(*, quota_left: int | None = None, dry_run: bool = False) -> int:
    """HAND dynamic worker count: 1-3 ceiling. Not forced to 3."""
    if dry_run:
        return MAX_WORKER_CEILING
    if quota_left is None:
        return MAX_WORKER_CEILING
    if quota_left <= 0:
        return 0
    if quota_left < 10_000_000:
        return 1
    if quota_left < 50_000_000:
        return 2
    if count_lock_contention() > 5:
        return 2
    return MAX_WORKER_CEILING


def active_worker_pools(hand_dec: dict[str, Any]) -> list[str]:
    aw = int(hand_dec.get("active_workers", hand_dec.get("max_worker", MAX_WORKER_CEILING)))
    aw = max(0, min(aw, MAX_WORKER_CEILING))
    return POOLS[:aw] if aw > 0 else []


# ── Global stop signal ──
def set_global_stop(reason: str) -> None:
    SHARED_ROOT.mkdir(parents=True, exist_ok=True)
    GLOBAL_STOP_PATH.write_text(json.dumps({"stop": True, "reason": reason, "at": now_iso()}), encoding="utf-8")


def global_stop_active() -> bool:
    return GLOBAL_STOP_PATH.exists()


def clear_global_stop() -> None:
    GLOBAL_STOP_PATH.unlink(missing_ok=True)


# ── Queue claim lock (atomic: planned → claimed_by_worker_x) ──
def _claim_path(pk: str) -> Path:
    return QUEUE_CLAIM_DIR / f"{pk.replace('/', '_')}.claim"


def get_partition_claim(pk: str) -> dict[str, Any] | None:
    p = _claim_path(pk)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {"status": "claimed_by_unknown", "partition_key": pk}


def claim_partition(pk: str, worker: str) -> bool:
    """Atomic claim. Only one worker gets planned→claimed_by_worker_x."""
    QUEUE_CLAIM_DIR.mkdir(parents=True, exist_ok=True)
    claim = _claim_path(pk)
    if claim.exists():
        existing = get_partition_claim(pk)
        if existing and existing.get("worker") == worker:
            return True
        return False
    payload = {
        "partition_key": pk,
        "prev_status": "planned",
        "status": f"claimed_by_{worker}",
        "worker": worker,
        "claimed_at": now_iso(),
    }
    try:
        fd = os.open(str(claim), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, json.dumps(payload, ensure_ascii=False).encode())
        os.close(fd)
        return True
    except FileExistsError:
        return False


def release_partition_claim(pk: str, worker: str | None = None) -> None:
    claim = _claim_path(pk)
    if not claim.exists():
        return
    if worker:
        existing = get_partition_claim(pk)
        if existing and existing.get("worker") != worker:
            return
    claim.unlink(missing_ok=True)


def check_partition_before_api(
    pk: str, freq: str, year: str, batch_id: str,
    ledger_map: dict | None = None, hand_dec: dict | None = None,
    worker_id: str = "worker",
) -> tuple[bool, str]:
    """Returns (api_allowed, reason). Must claim before API."""
    hand_dec = hand_dec or load_hand_decision()
    if not hand_dec or hand_dec.get("hand_release_allowed") is not True:
        return False, "hand_not_released"
    if hand_dec.get("current_stage") != freq:
        return False, "wrong_stage"
    if hand_dec.get("stage_order_violation_count", 0) != 0:
        return False, "stage_order_violation"
    if global_stop_active():
        return False, "global_stop"
    # quota stop uses live JQData reads in worker/launcher only — not stale HAND_DECISION.quota_left

    ledger_map = ledger_map or load_ledger_map()
    le = ledger_map.get(pk)
    if le:
        if le.get("status") in ("complete", "complete_duplicate"):
            return False, "complete_no_redownload"
        if le.get("no_redownload") == "true" and le.get("api_call_allowed") == "false":
            if le.get("status") != "missing":
                return False, "no_redownload"
        if le.get("status") == "review_required":
            return False, "review_required"
        if le.get("status") == "conflict":
            return False, "conflict"

    prefix = FREQ_FILE_PREFIX.get(freq, "")
    for f in root_for_freq(freq).glob(f"{prefix}{year}__{batch_id}__*.parquet"):
        if ".sidecar" in f.name or ".checksum" in f.name:
            continue
        cls = _classify_parquet(f, freq)
        if cls["status"] == "complete":
            return False, "disk_complete"
        if cls["status"] in ("incomplete", "review_required"):
            return False, cls["status"]

    existing_claim = get_partition_claim(pk)
    if existing_claim:
        if existing_claim.get("worker") == worker_id:
            return True, "ok_already_claimed"
        return False, "claimed_by_other_worker"

    if not claim_partition(pk, worker_id):
        return False, "claimed_by_other_worker"
    return True, "ok"


def audit_launcher_hand_patch() -> list[dict[str, str]]:
    checks = [
        ("enforce_hand_gate", "HAND_DECISION read"),
        ("HAND_EXIT_CODE", "exit(2) on block"),
        ("POOL_A", "3-worker pools"),
        ("max_worker", "max_worker check"),
        ("global_stop", "global stop signal"),
    ]
    targets = [
        ("p7_5m_matrix_launcher.py", SCRIPT_5M_LAUNCHER, "5m"),
        ("p7_5m_matrix_worker.py", SCRIPT_5M_WORKER, "5m"),
        ("p7_1m_matrix_launcher.py", SCRIPT_1M_LAUNCHER, "1m"),
        ("p7_1m_matrix_worker.py", SCRIPT_1M_WORKER, "1m"),
        ("p7_30m_matrix_launcher.py", SCRIPT_30M_LAUNCHER, "30m"),
        ("p7_30m_matrix_worker.py", SCRIPTS / "p7_30m_matrix_worker.py", "30m"),
        ("p7_60m_matrix_launcher.py", SCRIPT_60M_LAUNCHER, "60m"),
        ("p7_60m_matrix_worker.py", SCRIPTS / "p7_60m_matrix_worker.py", "60m"),
    ]
    rows = []
    for name, path, stage in targets:
        exists = path.exists()
        txt = path.read_text(encoding="utf-8", errors="replace") if exists else ""
        for marker, desc in checks:
            rows.append({
                "script": name, "stage": stage, "exists": str(exists).lower(),
                "check": marker, "description": desc,
                "pass": str(marker in txt or (marker == "global_stop" and "global_stop" in txt)).lower(),
            })
    return rows


# ── P7 live download status log (append-only, workers) ──
P7_DOWNLOAD_LIVE_STATUS_LOG = RUNS / "P7_DOWNLOAD_LIVE_STATUS.log"


def append_p7_live_status(
    *,
    stage: str,
    freq: str,
    worker: str,
    event: str,
    partition: str = "",
    date_range: str = "",
    quota_left: int | str = "",
    rows: int | str = 0,
    status: str = "running",
    extra: str = "",
) -> str:
    """Append one live line to P7_DOWNLOAD_LIVE_STATUS.log and echo stdout."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = (
        f"[{ts}] stage={stage} freq={freq} worker={worker} event={event} "
        f"partition={partition} date_range={date_range} quota_left={quota_left} "
        f"rows={rows} status={status}"
    )
    if extra:
        line += f" {extra}"
    RUNS.mkdir(parents=True, exist_ok=True)
    with P7_DOWNLOAD_LIVE_STATUS_LOG.open("a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line, flush=True)
    return line


# ── HAND download monitor auto-run cache ──
HAND_MONITOR_PS1 = SCRIPTS / "p7_live_download_terminal_monitor.ps1"
HAND_MONITOR_CACHE_PATH = RUNS / "P7_HAND_MONITOR_AUTO_RUN.json"
HAND_MONITOR_PID_PATH = RUNS / "P7_HAND_MONITOR.pid"
HAND_MONITOR_VIEW_LOG = RUNS / "P7_LIVE_MONITOR_VIEW.log"


def _monitor_command() -> str:
    return (
        f'powershell -NoProfile -ExecutionPolicy Bypass -File "{HAND_MONITOR_PS1}"'
    )


def is_hand_download_monitor_running() -> bool:
    """Check if live terminal monitor PS1 is already running."""
    if HAND_MONITOR_PID_PATH.exists():
        try:
            pid = int(HAND_MONITOR_PID_PATH.read_text(encoding="utf-8").strip())
            os.kill(pid, 0)
            return True
        except (OSError, ValueError, ProcessLookupError):
            HAND_MONITOR_PID_PATH.unlink(missing_ok=True)
    try:
        import subprocess
        r = subprocess.run(
            [
                "powershell", "-NoProfile", "-Command",
                "(Get-CimInstance Win32_Process -Filter \"Name='powershell.exe'\" -ErrorAction SilentlyContinue | "
                "Where-Object { $_.CommandLine -like '*p7_live_download_terminal_monitor.ps1*' }).Count",
            ],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=15,
        )
        return int((r.stdout or "0").strip() or "0") > 0
    except Exception:
        return False


def write_hand_monitor_cache(*, trigger: str, stage: str, spawned: bool, pid: int | None = None) -> Path:
    RUNS.mkdir(parents=True, exist_ok=True)
    doc = {
        "schema_version": "1.0.0",
        "task": "P7_HAND_MONITOR_AUTO_RUN",
        "auto_run_on_download": True,
        "monitor_script": str(HAND_MONITOR_PS1),
        "monitor_command": _monitor_command(),
        "simple_tail_command": (
            f'powershell -NoProfile -Command "Get-Content \'{P7_DOWNLOAD_LIVE_STATUS_LOG}\' -Wait -Tail 100"'
        ),
        "live_log_path": str(P7_DOWNLOAD_LIVE_STATUS_LOG),
        "monitor_view_log": str(HAND_MONITOR_VIEW_LOG),
        "monitor_pid_path": str(HAND_MONITOR_PID_PATH),
        "last_trigger": trigger,
        "last_stage": stage,
        "last_spawn_at": now_iso(),
        "last_spawn_pid": pid,
        "monitor_running": spawned or is_hand_download_monitor_running(),
        "spawn_policy": "idempotent_single_instance",
    }
    HAND_MONITOR_CACHE_PATH.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    return HAND_MONITOR_CACHE_PATH


def ensure_hand_download_monitor(*, trigger: str, stage: str) -> dict[str, Any]:
    """
    HAND 缓存监控程序；每次下载启动时自动拉起（单实例）。
    只启动监控，不重启下载，不调 JQData。
    """
    import subprocess

    RUNS.mkdir(parents=True, exist_ok=True)
    if not HAND_MONITOR_PS1.exists():
        write_hand_monitor_cache(trigger=trigger, stage=stage, spawned=False, pid=None)
        return {"spawned": False, "reason": "monitor_script_missing", "cache": str(HAND_MONITOR_CACHE_PATH)}

    if is_hand_download_monitor_running():
        cache = write_hand_monitor_cache(trigger=trigger, stage=stage, spawned=False, pid=None)
        append_p7_live_status(
            stage=stage, freq=stage, worker="HAND", event="monitor_already_running",
            status="ok", extra=f"trigger={trigger}",
        )
        return {"spawned": False, "reason": "already_running", "cache": str(cache)}

    cmd = [
        "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
        "-File", str(HAND_MONITOR_PS1),
    ]
    proc = subprocess.Popen(
        cmd,
        cwd=str(BLACKBOX),
        creationflags=subprocess.CREATE_NEW_CONSOLE,
    )
    HAND_MONITOR_PID_PATH.write_text(str(proc.pid), encoding="utf-8")
    cache = write_hand_monitor_cache(trigger=trigger, stage=stage, spawned=True, pid=proc.pid)
    append_p7_live_status(
        stage=stage, freq=stage, worker="HAND", event="monitor_auto_start",
        status="running", extra=f"trigger={trigger} pid={proc.pid}",
    )
    return {"spawned": True, "pid": proc.pid, "cache": str(cache), "command": _monitor_command()}
