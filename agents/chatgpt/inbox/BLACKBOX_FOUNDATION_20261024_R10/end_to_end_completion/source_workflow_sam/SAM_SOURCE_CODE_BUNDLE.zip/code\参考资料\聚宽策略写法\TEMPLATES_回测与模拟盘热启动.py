# -*- coding: utf-8 -*-
"""
聚宽模板：回测 + 模拟盘热启动（可直接对照改写，非完整选股策略）。
标记：JOINQUANT_STRATEGY_CODING_MANDATORY
详见 JOINQUANT_STRATEGY_CODING_SSOT_R1.md
"""
from jqdata import *
import numpy as np
import pandas as pd

SCHEME_ID = "JQ_HOT_START_TEMPLATE_R1"
G_STOCK_NUM = 1
# 模块级 CFG：代码加载时会执行；模拟盘业务状态仍以 g 恢复值为准
CFG = {"n_days": 1, "recipe": "DEMO"}


def initialize(context):
    """生命周期只执行一次（回测开始 / 模拟盘首次创建）。"""
    set_benchmark("000300.XSHG")
    set_option("use_real_price", True)
    set_option("avoid_future_data", True)
    set_slippage(FixedSlippage(0.0))
    set_order_cost(
        OrderCost(
            open_tax=0,
            close_tax=0.001,
            open_commission=0.0003,
            close_commission=0.0003,
            close_today_commission=0,
            min_commission=5,
        ),
        type="stock",
    )
    log.set_level("order", "error")

    # 可 pickle、需跨日保留的状态 —— 不要用 g.__*
    g.stock_num = G_STOCK_NUM
    g.n_days = int(CFG.get("n_days", 1))
    g.day_count = 0
    g.target = []
    g.rank_list = []
    g.claim_blocked = True

    # 定时器只在此处注册一次；修改时间见 after_code_changed + unschedule_all
    run_daily(before_market_open, time="before_open", reference_security="000300.XSHG")
    run_daily(market_open_trade, time="open", reference_security="000300.XSHG")
    run_daily(after_market_close, time="after_close", reference_security="000300.XSHG")
    log.info("[INIT] %s" % SCHEME_ID)


def process_initialize(context):
    """每次进程启动（模拟盘每天）。重建不可/不宜 pickle 的对象。"""
    # query 不能 pickle —— 必须双下划线或每日重建
    g.__q = query(valuation)
    # 业务 adapter：每日重建，避免残留 jq 句柄
    g.adapter_ready = True
    log.info("[PROCESS_INIT] rebuilt non-pickle objects")


def after_code_changed(context):
    """
    模拟盘替换代码后：initialize 不重跑。
    官方：在 process_initialize 之后执行；回测也会跑一次。
    """
    g.stock_num = G_STOCK_NUM
    g.n_days = int(CFG.get("n_days", 1))
    g.claim_blocked = True
    # 若修改了 run_daily 时间/函数，取消后重挂：
    # unschedule_all()
    # run_daily(before_market_open, time='before_open', reference_security='000300.XSHG')
    # run_daily(market_open_trade, time='open', reference_security='000300.XSHG')
    # run_daily(after_market_close, time='after_close', reference_security='000300.XSHG')
    g.__q = query(valuation)
    g.adapter_ready = True
    log.info("[AFTER_CODE_CHANGED] %s recipe=%s" % (SCHEME_ID, CFG.get("recipe")))


def before_market_open(context):
    g.day_count = int(getattr(g, "day_count", 0)) + 1
    need = (g.day_count == 1) or ((g.day_count - 1) % g.n_days == 0)
    if not need:
        return
    # 信号日：上一交易日（避免未来函数）
    signal_date = context.previous_date
    # demo：空选 → EMPTY KEEP
    ranked = []
    if ranked:
        g.rank_list = list(ranked[: g.stock_num])
        g.target = list(g.rank_list)
    else:
        g.rank_list = []
        log.info("[SELECT] EMPTY KEEP sig=%s old=%s" % (signal_date, getattr(g, "target", [])))


def market_open_trade(context):
    current_data = get_current_data()
    targets = list(getattr(g, "target", []) or [])
    if not targets:
        return
    # 先卖非目标（涨停锁定示例）
    locked = []
    for stock in list(context.portfolio.positions.keys()):
        if stock in targets:
            continue
        pos = context.portfolio.positions[stock]
        if pos.total_amount <= 0:
            continue
        try:
            if current_data[stock].last_price >= current_data[stock].high_limit * 0.999:
                locked.append(stock)
                continue
            if current_data[stock].paused:
                continue
        except Exception:
            pass
        order_target(stock, 0)
    if locked:
        g.target = locked[: g.stock_num]
        log.warn("[TRADE] limit-locked keep=%s" % g.target)
        return
    cash_per = context.portfolio.total_value / float(max(g.stock_num, 1))
    for stock in targets[: g.stock_num]:
        try:
            if current_data[stock].paused or current_data[stock].last_price <= 0:
                continue
            if current_data[stock].last_price >= current_data[stock].high_limit * 0.999:
                continue
        except Exception:
            continue
        if stock in context.portfolio.positions and context.portfolio.positions[stock].total_amount > 0:
            continue
        order_value(stock, cash_per * 0.98)


def after_market_close(context):
    holds = [s for s, p in context.portfolio.positions.items() if p.total_amount > 0]
    log.info(
        "[EOD] value=%.2f holds=%s target=%s"
        % (context.portfolio.total_value, holds, getattr(g, "target", []))
    )


# ---- 常见坑（注释备忘）----
# 1) from jqdata import * 后不要写 tw = sum(dict.values())，改 np.sum
# 2) 不要 from dataclasses import dataclass
# 3) 不要 from __future__ import annotations
# 4) 大 DataFrame 不要长期挂 g（模拟盘 pickle ≤30MB）
