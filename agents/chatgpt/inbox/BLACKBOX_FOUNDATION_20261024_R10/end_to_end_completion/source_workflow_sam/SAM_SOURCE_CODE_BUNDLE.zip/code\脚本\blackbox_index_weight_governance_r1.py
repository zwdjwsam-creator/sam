#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INDEX_WEIGHT_PIT_R1 productization + ETF exposure governance R1.

TASK_ID = BLACKBOX_ETF_INDEX_WEIGHT_DATA_LAYER_AND_INCREMENT_GOVERNANCE_R1
Does not run ETF strategy / backtest. Does not mutate repair_v1 RAW.
Does not switch CACHE/CLEANING CURRENT.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PY = ROOT / ".venv" / "Scripts" / "python.exe"
TASK_ID = "BLACKBOX_ETF_INDEX_WEIGHT_DATA_LAYER_AND_INCREMENT_GOVERNANCE_R1"
TASK = ROOT / "任务" / TASK_ID
RAW_DIR = (
    ROOT
    / "数据"
    / "原始只读"
    / "JQData_9999_official_raw"
    / "P3_index"
    / "index_weights_code_preserved__asof_20260702__repair_v1"
)
P3_INDEX = ROOT / "数据" / "原始只读" / "JQData_9999_official_raw" / "P3_index"
TRACK_DIR = (
    ROOT
    / "数据"
    / "原始只读"
    / "JQData_9999_official_raw"
    / "P4_fund_etf"
    / "fund_tracking_index_mapping"
)
LEDGER = ROOT / "运行" / "BLACKBOX_JQ_ACCESSIBLE_DATASET_LEDGER_CURRENT.json"
INDEX_PATH = ROOT / "运行" / "BLACKBOX_DATA_ACCESS_INDEX_CURRENT.json"
FACTS = ROOT / "运行" / "BLACKBOX_PRODUCT_CAPABILITY_FACTS_CURRENT.json"
SIDECAR = ROOT / "运行" / "BLACKBOX_SIDECAR_CACHE_PRODUCTS_CURRENT.json"
DAILY_RULE = ROOT / "规则库" / "hand_hard_rules" / "BLACKBOX_HAND_DAILY_INCREMENTAL_UPDATE_WITH_SW_L123_CACHE_R1.json"
DAILY_CUR = ROOT / "运行" / "BLACKBOX_HAND_DAILY_INCREMENTAL_UPDATE_WITH_SW_L123_CACHE_CURRENT.json"
CATALOG = ROOT / "数据" / "回测缓存" / "registry" / "CACHE_PRODUCT_CATALOG.csv"
CACHE_CURRENT = ROOT / "数据" / "回测缓存" / "CURRENT_CACHE_RELEASE.json"
ORCH = ROOT / "脚本" / "blackbox_daily_increment_orchestrator_r1.py"
CODE_RE = re.compile(r"^\d{6}\.(XSHG|XSHE)$")
OVERSEAS_KW = ("德国", "纳斯达克", "纳指", "日经", "恒生", "标普", "道琼斯", "欧洲", "美国", "香港", "H股")
COMMODITY_KW = ("黄金", "白银", "原油", "豆粕", "有色", "商品", "能源", "黄金ETF")


def now_cn() -> str:
    return datetime.now(timezone(timedelta(hours=8))).strftime("%Y-%m-%dT%H:%M:%S+0800")


def stamp() -> str:
    return datetime.now(timezone(timedelta(hours=8))).strftime("%Y%m%d_%H%M%S")


def jdump(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def cache_root() -> Path:
    cur = load_json(CACHE_CURRENT)
    return Path(cur["release_root"])


def list_repair_files() -> list[Path]:
    if not RAW_DIR.is_dir():
        return []
    return sorted(p for p in RAW_DIR.iterdir() if p.suffix == ".parquet" and p.is_file())


def load_repair_raw() -> pd.DataFrame:
    files = list_repair_files()
    if not files:
        return pd.DataFrame()
    frames = []
    for p in files:
        df = pd.read_parquet(p)
        df["raw_file"] = p.name
        frames.append(df)
    out = pd.concat(frames, ignore_index=True)
    for c in ("date", "query_date"):
        if c in out.columns:
            out[c] = pd.to_datetime(out[c], errors="coerce").dt.strftime("%Y-%m-%d")
    return out


def audit_machine() -> dict:
    orch_txt = ORCH.read_text(encoding="utf-8") if ORCH.is_file() else ""
    daily_rule = load_json(DAILY_RULE) if DAILY_RULE.is_file() else {}
    daily_cur = load_json(DAILY_CUR) if DAILY_CUR.is_file() else {}
    idx = load_json(INDEX_PATH) if INDEX_PATH.is_file() else {}
    facts = load_json(FACTS) if FACTS.is_file() else {}
    catalog_txt = CATALOG.read_text(encoding="utf-8") if CATALOG.is_file() else ""
    resolver = (ROOT / "脚本" / "blackbox_data_access_resolver_r1.py").read_text(encoding="utf-8")
    products = idx.get("products") or []
    pids = {p.get("product_id") for p in products}
    facts_pids = set((facts.get("products") or {}).keys())
    daily_blob = json.dumps(daily_rule, ensure_ascii=False) + json.dumps(daily_cur, ensure_ascii=False)
    in_daily = (
        "INDEX_WEIGHT_PIT_R1" in daily_blob
        or "get_index_weights" in daily_blob
        or "index_weights" in daily_blob
        or "INDEX_WEIGHT" in orch_txt
    )
    formal = "INDEX_WEIGHT_PIT_R1" in pids or "INDEX_WEIGHT_PIT_R1" in catalog_txt
    cache_prod = False
    cache_path = None
    for p in products:
        if p.get("product_id") == "INDEX_WEIGHT_PIT_R1":
            cache_path = p.get("cache_product_path")
            cache_prod = bool(cache_path and Path(str(cache_path)).exists())
    if not cache_prod:
        cr = cache_root()
        cache_prod = (cr / "INDEX_WEIGHT_PIT_R1").is_dir()
        cache_path = str(cr / "INDEX_WEIGHT_PIT_R1") if cache_prod else None
    resolver_entry = (
        "INDEX_WEIGHT_PIT_R1" in resolver
        or "index_weight" in resolver
        or "get_index_weights" in resolver
    )
    ledger = load_json(LEDGER) if LEDGER.is_file() else {}
    fps_api = False
    fps_raw = False
    fps_formal = "FUND_PORTFOLIO_STOCK_PIT_R1" in pids
    fps_ptr_ok = False
    fps_entries = []
    for row in (ledger.get("datasets") or ledger.get("items") or []):
        if not isinstance(row, dict):
            continue
        did = str(row.get("dataset_id") or "")
        if did == "finance.FUND_PORTFOLIO_STOCK":
            fps_api = True
            fps_entries.append(
                {
                    "download_status": row.get("download_status"),
                    "local_raw_rel": row.get("local_raw_rel"),
                    "path": (row.get("local_stats") or {}).get("path"),
                }
            )
            rel = str(row.get("local_raw_rel") or "")
            if rel == "P4b_fund_expand":
                fps_ptr_ok = False
            elif "portfolio_stock" in rel.lower():
                fps_ptr_ok = True
                fps_raw = True
    if "finance.FUND_PORTFOLIO_STOCK" in json.dumps(ledger, ensure_ascii=False):
        fps_api = True
    track_files = []
    if TRACK_DIR.is_dir():
        track_files = sorted(p.name for p in TRACK_DIR.iterdir() if p.suffix == ".parquet")
    track_formal = "ETF_TRACKING_INDEX_MAP_R1" in pids
    repair_files = list_repair_files()
    out = {
        "INDEX_WEIGHT_IN_DAILY_INCREMENT": "YES" if in_daily else "NO",
        "INDEX_WEIGHT_FORMAL_PRODUCT_EXISTS": "YES" if formal else "NO",
        "INDEX_WEIGHT_CACHE_PRODUCT_EXISTS": "YES" if cache_prod else "NO",
        "INDEX_WEIGHT_RESOLVER_ENTRY_EXISTS": "YES" if resolver_entry else "NO",
        "FUND_PORTFOLIO_STOCK_SOURCE_API_EXISTS": "YES" if fps_api else "NO",
        "FUND_PORTFOLIO_STOCK_LOCAL_RAW_EXISTS": "YES" if fps_raw else "NO",
        "FUND_PORTFOLIO_STOCK_FORMAL_PRODUCT_EXISTS": "YES" if fps_formal else "NO",
        "FUND_PORTFOLIO_STOCK_LEDGER_POINTER_CORRECT": "YES" if fps_ptr_ok else "NO",
        "ETF_TRACKING_INDEX_MAP_EXISTS": "YES" if (track_files or track_formal) else "NO",
        "ETF_TRACKING_INDEX_MAP_FORMAL": "YES" if track_formal else "NO",
        "ETF_TRACKING_INDEX_MAP_RAW_FILES": track_files,
        "evidence": {
            "orchestrator": str(ORCH),
            "orchestrator_mentions_index_weight": "INDEX_WEIGHT" in orch_txt or "get_index_weights" in orch_txt,
            "daily_must_include": daily_cur.get("daily_must_include"),
            "daily_required_cache_products": daily_cur.get("required_cache_products") or daily_rule.get("required_cache_products"),
            "data_access_index_pids_sample": sorted(pids)[:30],
            "INDEX_WEIGHT_in_data_access_index": "INDEX_WEIGHT_PIT_R1" in pids,
            "INDEX_CONSTITUENT_in_data_access_index": "INDEX_CONSTITUENT_PIT_R1" in pids,
            "INDEX_WEIGHT_in_capability_facts": "INDEX_WEIGHT_PIT_R1" in facts_pids,
            "INDEX_WEIGHT_in_catalog": "INDEX_WEIGHT_PIT_R1" in catalog_txt,
            "cache_product_path": cache_path,
            "repair_v1_dir": str(RAW_DIR),
            "repair_v1_exists": RAW_DIR.is_dir(),
            "repair_v1_file_count": len(repair_files),
            "fund_portfolio_stock_ledger_entries": fps_entries,
            "p4_nav_api_mapping": "get_extras + finance.FUND_NET_VALUE",
            "p4b_status": "DEFERRED_NAV_EXPAND_NOT_HOLDINGS",
        },
    }
    return out


def qa_raw(df: pd.DataFrame) -> dict:
    files = list_repair_files()
    if df.empty:
        return {"INDEX_WEIGHT_RAW_PRESENT": False, "INDEX_WEIGHT_RAW_QA_PASS": False, "reason": "RAW_DIR_EMPTY"}
    n = len(df)
    cc = df["component_code"].astype(str) if "component_code" in df.columns else pd.Series([""] * n)
    nonempty_rate = float(((cc.str.len() > 0) & (~cc.str.lower().isin(["nan", "none", ""]))).mean())
    fmt_ok = float(cc.map(lambda x: bool(CODE_RE.match(str(x)))).mean()) if n else 0.0
    key_cols = ["index_code", "date", "component_code"]
    dup = int(df.duplicated(key_cols).sum()) if all(c in df.columns for c in key_cols) else -1
    w = pd.to_numeric(df["weight"], errors="coerce") if "weight" in df.columns else pd.Series([float("nan")] * n)
    finite = float(w.map(lambda x: bool(pd.notna(x) and abs(x) < 1e12)).mean()) if n else 0.0
    sums = []
    if all(c in df.columns for c in ("index_code", "date", "weight")):
        g = df.assign(weight=w).groupby(["index_code", "date"], dropna=False)["weight"].sum()
        for (idx, dt), s in g.items():
            sums.append({"index_code": idx, "source_snapshot_date": dt, "weight_sum": float(s), "near_100": abs(float(s) - 100.0) <= 1.5})
    near100 = all(x["near_100"] for x in sums) if sums else False
    top10_ok = True
    top10_notes = []
    if all(c in df.columns for c in ("index_code", "date", "weight", "component_code")):
        sample_keys = df.groupby(["index_code", "date"]).size().reset_index()[:8]
        for _, row in sample_keys.iterrows():
            sub = df[(df["index_code"] == row["index_code"]) & (df["date"] == row["date"])].copy()
            sub["weight"] = pd.to_numeric(sub["weight"], errors="coerce")
            full_top = sub.sort_values("weight", ascending=False).head(10)["component_code"].tolist()
            chk = sub.nlargest(10, "weight")["component_code"].tolist()
            if full_top != chk:
                top10_ok = False
                top10_notes.append({"index_code": row["index_code"], "date": row["date"]})
    name_ok = True
    if "display_name" in df.columns:
        nm = df["display_name"].astype(str)
        looks_code = nm.str.match(r"^\d{6}")
        if float(looks_code.mean()) > 0.05:
            name_ok = False
    old_defective = sorted(p.name for p in P3_INDEX.iterdir() if p.is_file() and p.name.startswith("index_weights__") and p.suffix == ".parquet") if P3_INDEX.is_dir() else []
    repair_fixed = nonempty_rate >= 0.999 and fmt_ok >= 0.99
    dates = sorted(df["date"].dropna().astype(str).unique().tolist()) if "date" in df.columns else []
    dates_2026 = [d for d in dates if str(d).startswith("2026")]
    latest_snapshot = max(dates_2026) if dates_2026 else None
    qdates = sorted(df["query_date"].dropna().astype(str).unique().tolist()) if "query_date" in df.columns else []
    qdates_2026 = [d for d in qdates if str(d).startswith("2026")]
    latest_query = max(qdates_2026) if qdates_2026 else None
    # RAW dump asof is query_date (dir asof_20260702). date=official reconstitution snapshot (e.g. 2026-06-30).
    latest_2026 = latest_query or latest_snapshot
    lookahead_rows = 0
    if "query_date" in df.columns and "date" in df.columns:
        q = pd.to_datetime(df["query_date"], errors="coerce")
        d = pd.to_datetime(df["date"], errors="coerce")
        lookahead_rows = int((q < d).sum())
    indexes = sorted(df["index_code"].dropna().astype(str).unique().tolist()) if "index_code" in df.columns else []
    qa_pass = (
        nonempty_rate >= 0.999
        and fmt_ok >= 0.99
        and dup == 0
        and finite >= 0.999
        and near100
        and top10_ok
        and name_ok
        and latest_query == "2026-07-02"
        and lookahead_rows == 0
        and len(files) == 104
    )
    return {
        "INDEX_WEIGHT_RAW_PRESENT": True,
        "INDEX_WEIGHT_RAW_QA_PASS": bool(qa_pass),
        "file_count": len(files),
        "row_count": int(n),
        "index_codes": indexes,
        "index_count": len(indexes),
        "component_code_nonempty_rate": nonempty_rate,
        "component_code_format_ok_rate": fmt_ok,
        "duplicate_pk": dup,
        "weight_finite_rate": finite,
        "weight_sum_groups": sums,
        "weight_sum_all_near_100": near100,
        "top10_consistent": top10_ok,
        "top10_fail_samples": top10_notes[:5],
        "display_name_not_code_like": name_ok,
        "repair_v1_fixed_missing_component_code": repair_fixed,
        "old_defective_sibling_files_one_level": len(old_defective),
        "snapshot_dates": dates,
        "latest_2026_snapshot": latest_snapshot,
        "latest_2026_query_asof": latest_query,
        "latest_2026_is_2026_07_02": latest_query == "2026-07-02",
        "query_date_before_snapshot_rows": lookahead_rows,
        "backward_fill_future_to_past_in_raw": False,
        "note_no_dense_daily_panel": "RAW is discrete snapshots; reader must not backfill future→past",
    }


def probe_cadence() -> dict:
    sys.path.insert(0, str(ROOT / "脚本"))
    import jq_download_base as jdb  # noqa: WPS433
    import jqdatasdk as jq  # noqa: WPS433

    jdb.auth()
    indices = ["000300.XSHG", "399006.XSHE"]
    dates = ["2026-08-13", "2026-08-14", "2026-08-17", "2026-07-01", "2026-07-02", "2026-07-03"]
    rows = []
    for idx in indices:
        for d in dates:
            rec = {"index_code": idx, "query_date": d}
            try:
                w = jq.get_index_weights(idx, date=d)
                if w is None:
                    rec.update({"ok": False, "error": "NONE"})
                else:
                    df = w.reset_index() if hasattr(w, "reset_index") else w
                    if not isinstance(df, pd.DataFrame):
                        df = pd.DataFrame(df)
                    cols = [str(c) for c in df.columns]
                    date_col = None
                    for c in df.columns:
                        if str(c).lower() in ("date", "day"):
                            date_col = c
                            break
                    snap = None
                    if date_col is not None and len(df):
                        snap = str(pd.to_datetime(df[date_col], errors="coerce").dropna().max().date()) if pd.notna(pd.to_datetime(df[date_col], errors="coerce").max()) else None
                    codes = []
                    if df.index.name or (hasattr(df, "index") and len(df)):
                        idx_vals = [str(x) for x in df.index.tolist()[:5]]
                        if any("." in x for x in idx_vals):
                            codes = sorted(str(x) for x in df.index.tolist())
                    if "component_code" in df.columns:
                        codes = sorted(df["component_code"].astype(str).tolist())
                    rec.update(
                        {
                            "ok": True,
                            "n": int(len(df)),
                            "columns": cols,
                            "source_snapshot_date": snap,
                            "component_fingerprint": hashlib.sha256((",".join(codes)).encode()).hexdigest()[:16] if codes else None,
                            "weight_sum": float(pd.to_numeric(df["weight"], errors="coerce").sum()) if "weight" in df.columns else None,
                        }
                    )
            except Exception as e:  # noqa: BLE001
                rec.update({"ok": False, "error": type(e).__name__})
            rows.append(rec)
    semantics = "UNKNOWN"
    ok_rows = [r for r in rows if r.get("ok")]
    if ok_rows:
        by_idx = {}
        for r in ok_rows:
            by_idx.setdefault(r["index_code"], []).append(r)
        daily_like = True
        last_known_like = True
        sparse_like = True
        for idx, rs in by_idx.items():
            snaps = [r.get("source_snapshot_date") for r in rs]
            fps = [r.get("component_fingerprint") for r in rs]
            qs = [r.get("query_date") for r in rs]
            if not all(s == q for s, q in zip(snaps, qs) if s and q):
                daily_like = False
            if len(set(x for x in snaps if x)) <= 1 and len(set(x for x in fps if x)) <= 1:
                pass
            else:
                last_known_like = False
            if len(set(x for x in snaps if x)) > 1 and not all(s == q for s, q in zip(snaps, qs) if s and q):
                sparse_like = True
            else:
                sparse_like = False
        # adjacent D-2/D-1/D around 2026-08-17
        recent = [r for r in ok_rows if r["query_date"] in ("2026-08-13", "2026-08-14", "2026-08-17")]
        recent_snaps = {r.get("source_snapshot_date") for r in recent}
        around = [r for r in ok_rows if r["query_date"] in ("2026-07-01", "2026-07-02", "2026-07-03")]
        around_snaps = {r.get("source_snapshot_date") for r in around}
        if daily_like:
            semantics = "DAILY"
        elif len(recent_snaps) <= 1 and len(around_snaps) <= 2:
            # date= returns a snapshot identity that does not track every query date
            same_fp = len({r.get("component_fingerprint") for r in recent}) <= 1
            if same_fp:
                semantics = "DATE_QUERY_RETURNS_LAST_KNOWN"
            else:
                semantics = "SPARSE_SNAPSHOT"
        elif sparse_like:
            semantics = "SPARSE_SNAPSHOT"
        elif last_known_like:
            semantics = "DATE_QUERY_RETURNS_LAST_KNOWN"
        else:
            semantics = "UNKNOWN"
    policy = {
        "DAILY": "FETCH_TARGET_DATE_EACH_TRADING_DAY",
        "SPARSE_SNAPSHOT": "CHECK_FOR_NEW_SNAPSHOT_FETCH_ONLY_IF_NEW_EFFECTIVE_SNAPSHOT",
        "DATE_QUERY_RETURNS_LAST_KNOWN": "CHECK_LATEST_SOURCE_SNAPSHOT_APPEND_IF_SOURCE_SNAPSHOT_DATE_GT_LOCAL_MAX",
        "UNKNOWN": "CHECK_LATEST_SOURCE_SNAPSHOT_NO_UNCONDITIONAL_FULL_HISTORY",
    }[semantics]
    return {
        "SOURCE_UPDATE_SEMANTICS": semantics,
        "INDEX_WEIGHT_UPDATE_POLICY": policy,
        "probe_rows": rows,
        "secret_value_printed": False,
    }


def pit_valid_from(snapshot: str) -> str:
    d = datetime.strptime(snapshot, "%Y-%m-%d").date()
    return (d + timedelta(days=1)).strftime("%Y-%m-%d")


def productize(df: pd.DataFrame, qa: dict, probe: dict) -> dict:
    ts = stamp()
    rel_id = f"BLACKBOX_CACHE_R1_INDEX_WEIGHT_PIT_ASOF_20260702_{ts}"
    cache_rel = ROOT / "数据" / "回测缓存" / "releases" / rel_id
    prod = cache_rel / "INDEX_WEIGHT_PIT_R1"
    prod.mkdir(parents=True, exist_ok=True)
    out = df.copy()
    out["source_snapshot_date"] = out["date"]
    out["source"] = "get_index_weights"
    out["source_release"] = "index_weights_code_preserved__asof_20260702__repair_v1"
    out["pit_valid_from"] = out["source_snapshot_date"].map(pit_valid_from)
    out["known_at_contract"] = "SOURCE_SNAPSHOT_DATE_PLUS_1_CALENDAR_DAY_NOT_PREOPEN"
    out["coverage_status"] = "OFFICIAL_SNAPSHOT"
    keep = [
        "index_code",
        "component_code",
        "source_snapshot_date",
        "weight",
        "display_name",
        "source",
        "source_release",
        "pit_valid_from",
        "known_at_contract",
        "coverage_status",
        "query_date",
    ]
    for c in keep:
        if c not in out.columns:
            out[c] = None
    out = out[keep]
    full = prod / "data"
    full.mkdir(exist_ok=True)
    out.to_parquet(full / "INDEX_WEIGHT_PIT_R1_FULL.parquet", index=False)
    years = sorted({str(x)[:4] for x in out["source_snapshot_date"].dropna().astype(str)})
    for y in years:
        ydir = prod / f"year={y}"
        ydir.mkdir(exist_ok=True)
        sl = out[out["source_snapshot_date"].astype(str).str.startswith(y)]
        sl.to_parquet(ydir / "part_000.parquet", index=False)
        snaps = sorted(sl["source_snapshot_date"].dropna().astype(str).unique().tolist())
        sdir = prod / "snapshots" / y
        sdir.mkdir(parents=True, exist_ok=True)
        for s in snaps:
            sl[sl["source_snapshot_date"] == s].to_parquet(sdir / f"snapshot={s}.parquet", index=False)
    cov = {
        "product_id": "INDEX_WEIGHT_PIT_R1",
        "SOURCE_MIN_DATE": min(qa.get("snapshot_dates") or ["2014-12-31"]),
        "SOURCE_MAX_DATE": max(qa.get("snapshot_dates") or ["2026-07-02"]),
        "LOCAL_MAX_SNAPSHOT": qa.get("latest_2026_snapshot") or max(qa.get("snapshot_dates") or [None]),
        "index_codes": qa.get("index_codes"),
        "row_count": qa.get("row_count"),
        "grain": "index_code/source_snapshot_date/component_code",
        "not_daily_exact_weight": True,
        "forward_fill_old_to_future": "ALLOWED",
        "backfill_future_to_past": "FORBIDDEN",
        "weight_mode_default": "LAST_KNOWN_OFFICIAL_SNAPSHOT",
        "pit_valid_from_rule": "source_snapshot_date + 1 calendar day; not proven preopen-visible",
        "SOURCE_UPDATE_SEMANTICS": probe.get("SOURCE_UPDATE_SEMANTICS"),
        "UPDATE_POLICY": probe.get("INDEX_WEIGHT_UPDATE_POLICY"),
        "HISTORICAL_BACKTEST_ELIGIBLE": False,
        "LAST_KNOWN_SNAPSHOT_FORWARD_SUPPORTED": True,
        "PIT_VISIBILITY_CONTRACT": "UNRESOLVED",
        "INDEX_WEIGHT_HISTORICAL_BACKTEST_ELIGIBLE": False,
        "HISTORICAL_BACKTEST_MODE": "LAST_KNOWN_OFFICIAL_SNAPSHOT_AFTER_PIT_VALID_FROM_NOT_PROVEN",
        "HAND_DECISION_index_weights_historical_backtest_eligible": False,
        "HAND_DECISION_not_forged": True,
    }
    meta = {
        "product_id": "INDEX_WEIGHT_PIT_R1",
        "semantic": "official index component weights at a source snapshot",
        "source_api": "get_index_weights(index, date=)",
        "not": ["INDEX_CONSTITUENT_PIT_R1", "FUND_PORTFOLIO_STOCK_PIT_R1", "ETF_DAILY_PCF"],
        "forbidden_proxy": ["amount", "money", "market_cap", "INDEX_CONSTITUENT", "similar_index"],
        "reader": "脚本/blackbox_index_weight_governance_r1.py::read_index_weight",
        "cache_release_id": rel_id,
        "parent_cache_current_not_switched": True,
        "raw_immutable": str(RAW_DIR),
    }
    prov = {
        "raw_dir": str(RAW_DIR),
        "raw_file_count": qa.get("file_count"),
        "qa_pass": qa.get("INDEX_WEIGHT_RAW_QA_PASS"),
        "built_at_cn": now_cn(),
        "task_id": TASK_ID,
    }
    jdump(prod / "COVERAGE.json", cov)
    jdump(prod / "PRODUCT_META.json", meta)
    jdump(prod / "PROVENANCE.json", prov)

    # tracking map product
    tprod = cache_rel / "ETF_TRACKING_INDEX_MAP_R1"
    tprod.mkdir(parents=True, exist_ok=True)
    tfiles = sorted(TRACK_DIR.glob("fund_tracking_index_mapping__*.parquet")) if TRACK_DIR.is_dir() else []
    tdf = pd.DataFrame()
    if tfiles:
        latest_all = [p for p in tfiles if "__ALL__" in p.name]
        use = latest_all[-1] if latest_all else tfiles[-1]
        tdf = pd.read_parquet(use)
        tdf["map_source_file"] = use.name
    if not tdf.empty:
        tdf = tdf.copy()
        tdf["etf_code"] = tdf.get("code", tdf.iloc[:, 0]).astype(str)
        tdf["tracking_index_code"] = tdf.get("traced_index_code", "").astype(str)
        tdf["tracking_index_name"] = tdf.get("traced_index_name", "").astype(str)
        tdf["etf_name"] = tdf.get("name", "").astype(str)
        weight_univ = set(qa.get("index_codes") or [])

        def _cls(row):
            blob = f"{row.get('etf_name','')} {row.get('tracking_index_name','')}"
            if any(k in blob for k in COMMODITY_KW):
                return "COMMODITY_ETF", "EQUITY_COMPONENT_WEIGHT_NOT_APPLICABLE", "EQUITY_COMPONENT_WEIGHT_NOT_APPLICABLE"
            if any(k in blob for k in OVERSEAS_KW):
                return "OVERSEAS_INDEX_ETF", "EXTERNAL_INDEX_WEIGHT_REQUIRED", "UNSUPPORTED_CURRENTLY"
            ic = str(row.get("tracking_index_code") or "")
            if ic in weight_univ:
                return "A_SHARE_INDEX_ETF", "INDEX_WEIGHT_PIT_R1", "COVERED"
            if CODE_RE.match(ic):
                return "A_SHARE_INDEX_ETF", "INDEX_WEIGHT_PIT_R1", "SOURCE_NOT_ACQUIRED"
            return "UNKNOWN", "UNSUPPORTED_CURRENTLY", "UNCLASSIFIED"

        cls = tdf.apply(_cls, axis=1, result_type="expand")
        tdf["asset_class"] = cls[0]
        tdf["exposure_product"] = cls[1]
        tdf["coverage_status"] = cls[2]
        tdf["exposure_method"] = "OFFICIAL_INDEX_WEIGHT_IF_COVERED_ELSE_EXPLICIT_MISS"
        cols = [
            "etf_code",
            "etf_name",
            "asset_class",
            "tracking_index_code",
            "tracking_index_name",
            "exposure_method",
            "exposure_product",
            "coverage_status",
            "start_date",
            "end_date",
            "pub_date",
        ]
        for c in cols:
            if c not in tdf.columns:
                tdf[c] = None
        tdf[cols].to_parquet(tprod / "ETF_TRACKING_INDEX_MAP_R1.parquet", index=False)
        jdump(
            tprod / "PRODUCT_META.json",
            {
                "product_id": "ETF_TRACKING_INDEX_MAP_R1",
                "source": "finance.FUND_INVEST_TARGET / fund_tracking_index_mapping RAW",
                "reused_raw": True,
                "second_mapping_forbidden": True,
                "cache_release_id": rel_id,
            },
        )
        jdump(
            tprod / "COVERAGE.json",
            {
                "product_id": "ETF_TRACKING_INDEX_MAP_R1",
                "row_count": int(len(tdf)),
                "source_file": tdf["map_source_file"].iloc[0] if "map_source_file" in tdf.columns else None,
            },
        )
    sidecar = {
        "schema_version": "1.0.0",
        "note": "Successor cache products without switching CACHE CURRENT.",
        "cache_release_id": rel_id,
        "parent_cache_current_unchanged": True,
        "products": {
            "INDEX_WEIGHT_PIT_R1": {
                "cache_release_id": rel_id,
                "cache_product_path": str(prod),
                "do_not_inherit_from_cache_current_root": True,
            },
            "ETF_TRACKING_INDEX_MAP_R1": {
                "cache_release_id": rel_id,
                "cache_product_path": str(tprod),
                "do_not_inherit_from_cache_current_root": True,
            },
        },
        "written_at_cn": now_cn(),
        "task_id": TASK_ID,
    }
    jdump(SIDECAR, sidecar)
    jdump(cache_rel / "RELEASE.json", {"cache_release_id": rel_id, "mode": "sidecar_successor_no_current_switch", "asof": "2026-07-02"})
    return {
        "cache_release_id": rel_id,
        "INDEX_WEIGHT_path": str(prod),
        "ETF_TRACKING_path": str(tprod),
        "sidecar": str(SIDECAR),
        "row_count": int(len(out)),
        "tracking_rows": int(len(tdf)),
    }


def read_index_weight(index_code: str, signal_date: str, mode: str = "LAST_KNOWN_OFFICIAL_SNAPSHOT", snapshot_date: str | None = None) -> dict:
    side = load_json(SIDECAR) if SIDECAR.is_file() else {}
    path = Path((side.get("products") or {}).get("INDEX_WEIGHT_PIT_R1", {}).get("cache_product_path") or "")
    full = path / "data" / "INDEX_WEIGHT_PIT_R1_FULL.parquet"
    if not full.is_file():
        return {
            "ok": False,
            "CAN_SERVE": "NO",
            "blocker": "FORMAL_PRODUCT_PATH_MISSING",
            "OFFICIAL_WEIGHT_SOURCE_STATUS": "SOURCE_NOT_ACQUIRED" if not RAW_DIR.is_dir() else "SOURCE_PRESENT_AUTHORITY_NOT_PRODUCTIZED",
            "WEIGHT_PROXY_FORBIDDEN": True,
        }
    df = pd.read_parquet(full)
    ic = index_code if "." in index_code else None
    if ic is None:
        # allow 000300 / 000698
        cand = df[df["index_code"].astype(str).str.startswith(str(index_code))]
        codes = sorted(cand["index_code"].astype(str).unique().tolist())
        if len(codes) == 1:
            ic = codes[0]
        elif str(index_code) in ("000698", "000698.XSHG"):
            ic = "000698.XSHG"
        elif str(index_code) in ("399303", "399303.XSHE"):
            ic = "399303.XSHE"
        else:
            ic = str(index_code)
    sub = df[df["index_code"].astype(str) == str(ic)]
    if sub.empty:
        return {
            "ok": False,
            "CAN_SERVE": "NO",
            "index_code": ic,
            "requested_date": signal_date,
            "OFFICIAL_WEIGHT_SOURCE_STATUS": "SOURCE_NOT_ACQUIRED",
            "WEIGHT_PROXY_FORBIDDEN": True,
            "proxy_allowed": False,
        }
    if snapshot_date:
        if snapshot_date > signal_date:
            return {
                "ok": False,
                "CAN_SERVE": "NO",
                "blocker": "LOOKAHEAD_FORBIDDEN",
                "requested_date": signal_date,
                "source_snapshot_date": snapshot_date,
                "WEIGHT_PROXY_FORBIDDEN": True,
            }
        hit = sub[sub["source_snapshot_date"] == snapshot_date]
        if hit.empty:
            return {"ok": False, "CAN_SERVE": "NO", "blocker": "EXACT_SNAPSHOT_ABSENT", "WEIGHT_PROXY_FORBIDDEN": True}
        used = snapshot_date
        wmode = "EXACT_SNAPSHOT"
    else:
        elig = sub[sub["pit_valid_from"] <= signal_date]
        if elig.empty:
            return {
                "ok": False,
                "CAN_SERVE": "NO",
                "blocker": "NO_SNAPSHOT_WITH_PIT_VALID_FROM_LE_SIGNAL",
                "requested_date": signal_date,
                "WEIGHT_PROXY_FORBIDDEN": True,
            }
        used = str(elig["source_snapshot_date"].max())
        hit = sub[sub["source_snapshot_date"] == used]
        wmode = "LAST_KNOWN_OFFICIAL_SNAPSHOT" if used != signal_date else "EXACT_SNAPSHOT"
        if mode == "EXACT_SNAPSHOT" and used != signal_date:
            return {
                "ok": False,
                "CAN_SERVE": "NO",
                "blocker": "EXACT_SNAPSHOT_NOT_AVAILABLE",
                "local_max_snapshot": used,
                "WEIGHT_PROXY_FORBIDDEN": True,
            }
    pvf = str(hit["pit_valid_from"].iloc[0])
    age = (datetime.strptime(signal_date, "%Y-%m-%d").date() - datetime.strptime(used, "%Y-%m-%d").date()).days
    weights = hit[["component_code", "display_name", "weight"]].copy()
    return {
        "ok": True,
        "CAN_SERVE": "YES",
        "CAN_SERVE_PLANE": "SIDECAR",
        "CAN_SERVE_LIVE_CURRENT": "NO",
        "LAST_KNOWN_SNAPSHOT_FORWARD_SUPPORTED": True,
        "INDEX_WEIGHT_HISTORICAL_BACKTEST_ELIGIBLE": False,
        "PIT_VISIBILITY_CONTRACT": "UNRESOLVED",
        "product_id": "INDEX_WEIGHT_PIT_R1",
        "index_code": ic,
        "requested_date": signal_date,
        "source_snapshot_date": used,
        "pit_valid_from": pvf,
        "snapshot_age_days": int(age),
        "weight_mode": wmode,
        "n": int(len(weights)),
        "weight_sum": float(pd.to_numeric(weights["weight"], errors="coerce").sum()),
        "weights": weights.to_dict(orient="records"),
        "WEIGHT_PROXY_FORBIDDEN": True,
        "not_same_day_realtime": True,
    }


def load_tracking_map() -> pd.DataFrame:
    side = load_json(SIDECAR) if SIDECAR.is_file() else {}
    path = Path((side.get("products") or {}).get("ETF_TRACKING_INDEX_MAP_R1", {}).get("cache_product_path") or "")
    pq = path / "ETF_TRACKING_INDEX_MAP_R1.parquet"
    if pq.is_file():
        return pd.read_parquet(pq)
    return pd.DataFrame()


def get_etf_exposure(etf_code: str, signal_date: str, mode: str = "official") -> dict:
    code = str(etf_code)
    if "." not in code and code.isdigit():
        # try both suffixes via map
        pass
    tdf = load_tracking_map()
    if tdf.empty:
        return {
            "ok": False,
            "CAN_SERVE": "NO",
            "blocker": "ETF_TRACKING_INDEX_MAP_ABSENT",
            "WEIGHT_PROXY_FORBIDDEN": True,
        }
    hit = tdf[tdf["etf_code"].astype(str).str.startswith(code.split(".")[0])]
    if hit.empty:
        return {
            "ok": False,
            "CAN_SERVE": "NO",
            "etf_code": code,
            "blocker": "ETF_NOT_IN_TRACKING_MAP",
            "WEIGHT_PROXY_FORBIDDEN": True,
        }
    row = hit.iloc[0].to_dict()
    ac = row.get("asset_class")
    route = {
        "A_SHARE_INDEX_ETF": "INDEX_WEIGHT_PIT_R1",
        "OVERSEAS_INDEX_ETF": "EXTERNAL_INDEX_WEIGHT_REQUIRED",
        "COMMODITY_ETF": "EQUITY_COMPONENT_WEIGHT_NOT_APPLICABLE",
    }.get(ac, "UNSUPPORTED_CURRENTLY")
    base = {
        "etf_code": row.get("etf_code"),
        "etf_name": row.get("etf_name"),
        "asset_class": ac,
        "tracking_index_code": row.get("tracking_index_code"),
        "tracking_index_name": row.get("tracking_index_name"),
        "exposure_method": row.get("exposure_method"),
        "exposure_product": row.get("exposure_product"),
        "coverage_status": row.get("coverage_status"),
        "route": route,
        "mode": mode,
        "signal_date": signal_date,
        "WEIGHT_PROXY_FORBIDDEN": True,
    }
    if ac == "OVERSEAS_INDEX_ETF":
        base.update({"ok": False, "CAN_SERVE": "NO", "blocker": "EXTERNAL_INDEX_WEIGHT_REQUIRED / UNSUPPORTED_CURRENTLY"})
        return base
    if ac == "COMMODITY_ETF":
        base.update({"ok": False, "CAN_SERVE": "NO", "blocker": "EQUITY_COMPONENT_WEIGHT_NOT_APPLICABLE"})
        return base
    if row.get("coverage_status") == "SOURCE_NOT_ACQUIRED":
        base.update(
            {
                "ok": False,
                "CAN_SERVE": "NO",
                "OFFICIAL_WEIGHT_SOURCE_STATUS": "SOURCE_NOT_ACQUIRED",
                "blocker": "SOURCE_NOT_ACQUIRED",
            }
        )
        return base
    w = read_index_weight(str(row.get("tracking_index_code")), signal_date, mode="LAST_KNOWN_OFFICIAL_SNAPSHOT")
    base["weight_result"] = {k: v for k, v in w.items() if k != "weights"}
    if w.get("ok"):
        base.update({"ok": True, "CAN_SERVE": "YES", "weights": w.get("weights")})
        base["weight_result"]["n"] = w.get("n")
        base["source_snapshot_date"] = w.get("source_snapshot_date")
        base["snapshot_age_days"] = w.get("snapshot_age_days")
        base["pit_valid_from"] = w.get("pit_valid_from")
        base["weight_mode"] = w.get("weight_mode")
    else:
        base.update({"ok": False, "CAN_SERVE": "NO", "blocker": w.get("blocker") or w.get("OFFICIAL_WEIGHT_SOURCE_STATUS")})
    return base


def constituent_weight_request() -> dict:
    return {
        "product_id": "INDEX_CONSTITUENT_PIT_R1",
        "field": "weight",
        "result_status": "SEMANTIC_FIELD_NOT_SUPPORTED",
        "WEIGHT_PROXY_FORBIDDEN": True,
        "note": "INDEX_CONSTITUENT = membership only (get_index_stocks). Empty weight is expected. Do not synthesize.",
    }


def fund_portfolio_stock_status() -> dict:
    return {
        "dataset_id": "finance.FUND_PORTFOLIO_STOCK",
        "SOURCE_API_STATUS": "AVAILABLE",
        "SOURCE_API_AVAILABLE": "YES",
        "LOCAL_RAW_STATUS": "ABSENT",
        "LOCAL_RAW_PRESENT": "NO",
        "FORMAL_PRODUCT_STATUS": "ABSENT",
        "FORMAL_PRODUCT_AVAILABLE": "NO",
        "CACHE_PRODUCT_AVAILABLE": "NO",
        "OLD_LEDGER_POINTER_STATUS": "MISCLASSIFIED_NAV_SOURCE",
        "must_not_return": "NAV / get_extras / P4b_fund_expand",
        "semantic": "open-end fund quarterly disclosed stock holdings; not ETF PCF; not index weights",
        "download_this_round": False,
    }


def fix_ledger() -> dict:
    if not LEDGER.is_file():
        return {"ok": False, "reason": "LEDGER_MISSING"}
    obj = load_json(LEDGER)
    n_patch = 0

    def _patch_row(row: dict) -> None:
        nonlocal n_patch
        if str(row.get("dataset_id")) != "finance.FUND_PORTFOLIO_STOCK":
            return
        row["download_status"] = "NOT_DOWNLOADED_MISCLASSIFIED_NAV_POINTER"
        row["SOURCE_API_STATUS"] = "AVAILABLE"
        row["LOCAL_RAW_STATUS"] = "ABSENT"
        row["FORMAL_PRODUCT_STATUS"] = "ABSENT"
        row["OLD_LEDGER_POINTER_STATUS"] = "MISCLASSIFIED_NAV_SOURCE"
        row["local_raw_rel_previous"] = row.get("local_raw_rel")
        row["local_raw_rel"] = None
        row["pointer_correction_note"] = (
            "P4b_fund_expand / open_fund extras are NAV (get_extras/unit_net_value), not FUND_PORTFOLIO_STOCK holdings."
        )
        row["corrected_at_cn"] = now_cn()
        row["corrected_by_task"] = TASK_ID
        n_patch += 1

    def _walk(node) -> None:
        if isinstance(node, dict):
            _patch_row(node)
            for v in node.values():
                _walk(v)
        elif isinstance(node, list):
            for x in node:
                _walk(x)

    _walk(obj)
    obj["FUND_PORTFOLIO_STOCK_CORRECTION_R1"] = {
        "SOURCE_API_STATUS": "AVAILABLE",
        "LOCAL_RAW_STATUS": "ABSENT",
        "FORMAL_PRODUCT_STATUS": "ABSENT",
        "OLD_LEDGER_POINTER_STATUS": "MISCLASSIFIED_NAV_SOURCE",
        "download_status_must_not_be": "DOWNLOADED",
        "corrected_at_cn": now_cn(),
        "task_id": TASK_ID,
    }
    jdump(LEDGER, obj)
    return {"ok": True, "n_patch": n_patch}


def patch_catalog() -> None:
    if not CATALOG.is_file():
        return
    txt = CATALOG.read_text(encoding="utf-8")
    lines = [
        "INDEX_WEIGHT_PIT_R1,L1,INDEX,ACTIVE,index/snapshot,Official index component weights PIT last-known snapshot",
        "ETF_TRACKING_INDEX_MAP_R1,L1,ETF,ACTIVE,etf_code,ETF tracking index mapping (FUND_INVEST_TARGET RAW reused)",
    ]
    extra = ""
    for ln in lines:
        if ln.split(",")[0] not in txt:
            extra += ln + "\n"
    if extra:
        CATALOG.write_text(txt.rstrip() + "\n" + extra, encoding="utf-8")


def patch_data_access_index(prod_info: dict) -> None:
    if not INDEX_PATH.is_file():
        return
    obj = load_json(INDEX_PATH)
    products = obj.setdefault("products", [])
    by_id = {p.get("product_id"): p for p in products}
    if "INDEX_CONSTITUENT_PIT_R1" in by_id:
        by_id["INDEX_CONSTITUENT_PIT_R1"]["forbidden_fields"] = ["weight"]
        by_id["INDEX_CONSTITUENT_PIT_R1"]["semantic"] = "index membership only; get_index_stocks; weight not supported"
        by_id["INDEX_CONSTITUENT_PIT_R1"]["weight_supported"] = False
        by_id["INDEX_CONSTITUENT_PIT_R1"]["not_a_substitute_for"] = ["INDEX_WEIGHT_PIT_R1"]
    def _upsert(pid, path, desc, pit, aliases):
        rec = {
            "product_id": pid,
            "layer": "L1",
            "asset_type": "INDEX" if pid.startswith("INDEX_") else "ETF",
            "status": "READY" if Path(path).exists() else "PATH_NOT_FOUND",
            "grain": "index/snapshot" if pid.startswith("INDEX_WEIGHT") else "etf_code",
            "description": desc,
            "cache_release_id": prod_info.get("cache_release_id"),
            "cache_product_path": path,
            "sidecar_not_cache_current": True,
            "security_namespace": "INDEX" if pid.startswith("INDEX_") else "ETF",
            "cross_section_contract": "INNER_ON_INDEX_CODE" if pid.startswith("INDEX_") else "ON_ETF_CODE",
            "pit_policy": pit,
            "asof_behavior": "PIT_VALID_FROM_LE_SIGNAL_TIME",
            "aliases": aliases,
        }
        if pid in by_id:
            by_id[pid].update(rec)
        else:
            products.append(rec)
    _upsert(
        "INDEX_WEIGHT_PIT_R1",
        prod_info["INDEX_WEIGHT_path"],
        "Official index component weights (get_index_weights); last-known snapshot PIT",
        "LAST_KNOWN_OFFICIAL_SNAPSHOT_PLUS_1D",
        ["index_weight", "INDEX_WEIGHT", "get_index_weights"],
    )
    _upsert(
        "ETF_TRACKING_INDEX_MAP_R1",
        prod_info["ETF_TRACKING_path"],
        "ETF → tracking index map reused from P4 FUND_INVEST_TARGET RAW",
        "MAP_ASOF",
        ["etf_tracking_index", "tracking_index"],
    )
    obj["product_count"] = len(products)
    obj["index_weight_governance_task"] = TASK_ID
    obj["index_weight_governance_at_cn"] = now_cn()
    jdump(INDEX_PATH, obj)


def patch_facts(qa: dict, probe: dict, prod_info: dict) -> None:
    obj = load_json(FACTS) if FACTS.is_file() else {"products": {}}
    products = obj.setdefault("products", {})
    snaps = qa.get("snapshot_dates") or []
    products["INDEX_WEIGHT_PIT_R1"] = {
        "PATH_RESOLVED": True,
        "PATH_PRODUCT_ID": "INDEX_WEIGHT_PIT_R1",
        "SOURCE_STATE": "SPARSE_OFFICIAL_SNAPSHOTS_PRESENT",
        "PROCESSING_STATE": "PIT_READY",
        "AUTHORITY_STATE": "SIDECAR_SUCCESSOR_MOUNTED_CURRENT_NOT_SWITCHED",
        "FORMAL_COVERAGE_MIN": min(snaps) if snaps else None,
        "FORMAL_COVERAGE_MAX": max(snaps) if snaps else None,
        "OBSERVED_MAX_DATE": max(snaps) if snaps else None,
        "FORMAL_FRESHNESS": max(snaps) if snaps else None,
        "DECLARED_GAPS": ["000698.XSHG", "399303.XSHE", "OVERSEAS", "COMMODITY"],
        "GAP_CLASSIFICATION": "SOURCE_NOT_ACQUIRED_FOR_UNLISTED_INDEX",
        "REQUIRED_FIELDS_OK": True,
        "FACT_CONFLICT": False,
        "KNOWN_AT_RULE": "source_snapshot_date_plus_1_calendar_day",
        "EARLIEST_USABLE_TIME_RULE": "pit_valid_from_le_signal_time",
        "CAN_SERVE_NOTE": "sidecar last-known mechanics supported; LIVE_CURRENT CAN_SERVE=NO until product is in CACHE CURRENT; HISTORICAL_BACKTEST_ELIGIBLE=FALSE until pit visibility contract closes",
        "CAN_SERVE_LIVE_CURRENT": False,
        "LIVE_CAN_SERVE": False,
        "LAST_KNOWN_SNAPSHOT_FORWARD_SUPPORTED": True,
        "INDEX_WEIGHT_HISTORICAL_BACKTEST_ELIGIBLE": False,
        "PIT_VISIBILITY_CONTRACT": "UNRESOLVED",
        "SOURCE_UPDATE_SEMANTICS": probe.get("SOURCE_UPDATE_SEMANTICS"),
        "UPDATE_POLICY": probe.get("INDEX_WEIGHT_UPDATE_POLICY"),
        "sidecar_path": prod_info.get("INDEX_WEIGHT_path"),
        "WEIGHT_PROXY_FORBIDDEN": True,
    }
    products["ETF_TRACKING_INDEX_MAP_R1"] = {
        "PATH_RESOLVED": True,
        "PATH_PRODUCT_ID": "ETF_TRACKING_INDEX_MAP_R1",
        "SOURCE_STATE": "RAW_REUSED",
        "PROCESSING_STATE": "MAP_READY",
        "AUTHORITY_STATE": "SIDECAR_SUCCESSOR_MOUNTED_CURRENT_NOT_SWITCHED",
        "REQUIRED_FIELDS_OK": True,
        "FACT_CONFLICT": False,
        "sidecar_path": prod_info.get("ETF_TRACKING_path"),
    }
    products["FUND_PORTFOLIO_STOCK_PIT_R1"] = {
        "PATH_RESOLVED": False,
        "PATH_PRODUCT_ID": "FUND_PORTFOLIO_STOCK_PIT_R1",
        "SOURCE_STATE": "SOURCE_API_AVAILABLE",
        "PROCESSING_STATE": "NOT_PRODUCTIZED",
        "AUTHORITY_STATE": "ABSENT",
        "LOCAL_RAW_PRESENT": False,
        "FORMAL_PRODUCT_AVAILABLE": False,
        "OLD_LEDGER_POINTER_STATUS": "MISCLASSIFIED_NAV_SOURCE",
        "must_not_return": "NAV",
        "REQUIRED_FIELDS_OK": False,
        "FACT_CONFLICT": False,
    }
    obj["index_weight_governance_at_cn"] = now_cn()
    jdump(FACTS, obj)


def patch_daily_rules(probe: dict, qa: dict) -> None:
    managed = {
        "product_id": "INDEX_WEIGHT_PIT_R1",
        "source_api": "get_index_weights",
        "SOURCE_UPDATE_SEMANTICS": probe.get("SOURCE_UPDATE_SEMANTICS"),
        "update_policy": probe.get("INDEX_WEIGHT_UPDATE_POLICY"),
        "entrypoint": "脚本/blackbox_index_weight_daily_increment_check_r1.py",
        "unconditional_full_history_redownload": False,
        "local_max_snapshot": qa.get("latest_2026_snapshot"),
        "semantic_lock": "INDEX_CONSTITUENT != INDEX_WEIGHT != FUND_PORTFOLIO_STOCK",
    }
    if DAILY_RULE.is_file():
        r = load_json(DAILY_RULE)
        r["managed_snapshot_products"] = [managed]
        r["INDEX_WEIGHT_PIT_R1"] = "MANAGED_SNAPSHOT_CHECK"
        r["amended_index_weight_governance_at_cn"] = now_cn()
        inv = r.setdefault("daily_increment_invariants_r1", {})
        inv["INVARIANT_9"] = "INDEX_WEIGHT is managed by daily increment check; not unconditional full history fetch."
        inv["INVARIANT_10"] = "INDEX_CONSTITUENT != INDEX_WEIGHT != FUND_PORTFOLIO_STOCK; official weight proxy forbidden."
        jdump(DAILY_RULE, r)
    if DAILY_CUR.is_file():
        c = load_json(DAILY_CUR)
        must = list(c.get("daily_must_include") or [])
        token = "index_weights_snapshot_check (not full redownload)"
        if token not in must:
            must.append(token)
        c["daily_must_include"] = must
        c["managed_snapshot_products"] = [managed]
        c["INDEX_WEIGHT_PIT_R1"] = "MANAGED_SNAPSHOT_CHECK"
        c["amended_index_weight_governance_at_cn"] = now_cn()
        jdump(DAILY_CUR, c)


def pick_etf_for_index(index_code: str) -> str | None:
    tdf = load_tracking_map()
    if tdf.empty:
        return None
    short = str(index_code).split(".")[0]
    hit = tdf[tdf["tracking_index_code"].astype(str).str.contains(short, regex=False)]
    covered = hit[hit["coverage_status"].astype(str) == "COVERED"] if "coverage_status" in hit.columns else hit
    use = covered if not covered.empty else hit
    if use.empty:
        return None
    return str(use.iloc[0]["etf_code"])


def semantic_tests() -> dict:
    cases = {}
    etf300 = pick_etf_for_index("000300.XSHG")
    etfcyb = pick_etf_for_index("399006.XSHE")
    sig = "2026-08-17"
    a = get_etf_exposure(etf300 or "510300.XSHG", sig) if etf300 or True else {}
    cases["CASE_A_HS300_ETF"] = {
        "etf_code": etf300,
        "ok": bool(a.get("ok")),
        "route": a.get("route"),
        "source_snapshot_date": a.get("source_snapshot_date"),
        "snapshot_age_days": a.get("snapshot_age_days"),
        "expected_route": "INDEX_WEIGHT_PIT_R1",
        "pass": bool(a.get("ok") and a.get("route") == "INDEX_WEIGHT_PIT_R1" and a.get("source_snapshot_date")),
    }
    b = get_etf_exposure(etfcyb or "159915.XSHE", sig)
    cases["CASE_B_CHINEXT_ETF"] = {
        "etf_code": etfcyb,
        "ok": bool(b.get("ok")),
        "route": b.get("route"),
        "source_snapshot_date": b.get("source_snapshot_date"),
        "pass": bool(b.get("ok") and b.get("route") == "INDEX_WEIGHT_PIT_R1"),
    }
    c = read_index_weight("000698.XSHG", sig)
    cases["CASE_C_STAR100"] = {
        "OFFICIAL_WEIGHT_SOURCE_STATUS": c.get("OFFICIAL_WEIGHT_SOURCE_STATUS"),
        "WEIGHT_PROXY_FORBIDDEN": c.get("WEIGHT_PROXY_FORBIDDEN"),
        "pass": c.get("OFFICIAL_WEIGHT_SOURCE_STATUS") == "SOURCE_NOT_ACQUIRED" and c.get("WEIGHT_PROXY_FORBIDDEN") is True,
    }
    d = read_index_weight("399303.XSHE", sig)
    cases["CASE_D_CN2000"] = {
        "OFFICIAL_WEIGHT_SOURCE_STATUS": d.get("OFFICIAL_WEIGHT_SOURCE_STATUS"),
        "WEIGHT_PROXY_FORBIDDEN": d.get("WEIGHT_PROXY_FORBIDDEN"),
        "pass": d.get("OFFICIAL_WEIGHT_SOURCE_STATUS") == "SOURCE_NOT_ACQUIRED" and d.get("WEIGHT_PROXY_FORBIDDEN") is True,
    }
    e = constituent_weight_request()
    cases["CASE_E_CONSTITUENT_WEIGHT"] = {
        "result_status": e.get("result_status"),
        "pass": e.get("result_status") == "SEMANTIC_FIELD_NOT_SUPPORTED",
    }
    f = fund_portfolio_stock_status()
    cases["CASE_F_FUND_PORTFOLIO_STOCK"] = {
        "SOURCE_API_AVAILABLE": f.get("SOURCE_API_AVAILABLE"),
        "FORMAL_PRODUCT_STATUS": f.get("FORMAL_PRODUCT_STATUS"),
        "must_not_return": f.get("must_not_return"),
        "pass": f.get("SOURCE_API_AVAILABLE") == "YES" and f.get("FORMAL_PRODUCT_STATUS") == "ABSENT",
    }
    g = read_index_weight("000300.XSHG", "2024-12-30", snapshot_date="2024-12-31")
    cases["CASE_G_LOOKAHEAD"] = {
        "blocker": g.get("blocker"),
        "pass": g.get("blocker") == "LOOKAHEAD_FORBIDDEN",
    }
    # overseas / commodity must not pseudo-succeed via A-share resolver
    tdf = load_tracking_map()
    overseas_pass = True
    if not tdf.empty:
        ov = tdf[tdf["asset_class"] == "OVERSEAS_INDEX_ETF"]
        if not ov.empty:
            ox = get_etf_exposure(str(ov.iloc[0]["etf_code"]), sig)
            overseas_pass = ox.get("CAN_SERVE") == "NO" and "EXTERNAL" in str(ox.get("blocker"))
    cases["CASE_OVERSEAS_NO_PSEUDO_SUCCESS"] = {"pass": overseas_pass}
    all_pass = all(v.get("pass") for v in cases.values())
    return {"all_pass": all_pass, "cases": cases}


def daily_check(target: str, probe: dict | None = None, qa: dict | None = None, live: bool = False) -> dict:
    qa = qa or {}
    probe = probe or {}
    local_max = qa.get("latest_2026_snapshot")
    if not local_max and SIDECAR.is_file():
        path = Path((load_json(SIDECAR).get("products") or {}).get("INDEX_WEIGHT_PIT_R1", {}).get("cache_product_path") or "")
        covp = path / "COVERAGE.json"
        if covp.is_file():
            local_max = load_json(covp).get("LOCAL_MAX_SNAPSHOT")
    source_latest = None
    semantics = probe.get("SOURCE_UPDATE_SEMANTICS") or "UNKNOWN"
    if live:
        try:
            sys.path.insert(0, str(ROOT / "脚本"))
            import jq_download_base as jdb  # noqa: WPS433
            import jqdatasdk as jq  # noqa: WPS433
            jdb.auth()
            w = jq.get_index_weights("000300.XSHG", date=target)
            df = w.reset_index() if hasattr(w, "reset_index") else w
            if "date" in getattr(df, "columns", []):
                source_latest = str(pd.to_datetime(df["date"], errors="coerce").max().date())
        except Exception as e:  # noqa: BLE001
            source_latest = None
            semantics = semantics or "UNKNOWN"
            live_err = type(e).__name__
        else:
            live_err = None
    else:
        live_err = None
        if probe.get("probe_rows"):
            ok = [r for r in probe["probe_rows"] if r.get("ok") and r.get("index_code") == "000300.XSHG"]
            if ok:
                source_latest = max(r.get("source_snapshot_date") or "" for r in ok) or None
    update_token = "NO"
    source_refresh_status = "OK"
    if source_latest and local_max and source_latest > local_max:
        update_required = True
        update_token = "YES"
        reason = "NEW_SOURCE_SNAPSHOT"
    elif source_latest and local_max and source_latest <= local_max:
        update_required = False
        update_token = "NO"
        reason = "NO_NEW_SOURCE_SNAPSHOT"
    elif not source_latest:
        update_required = False
        probe_failed = bool(probe.get("failed")) or (live and live_err)
        if probe_failed or (semantics == "UNKNOWN" and not source_latest):
            update_token = "UNKNOWN"
            source_refresh_status = "UNKNOWN_SOURCE_UNREACHABLE"
            reason = "SOURCE_UNREACHABLE_UPDATE_NOT_PROVEN"
        else:
            update_token = "NO"
            reason = "NO_NEW_SOURCE_SNAPSHOT"
    return {
        "INDEX_WEIGHT_MANAGED_BY_DAILY_INCREMENT": "YES",
        "SOURCE_UPDATE_SEMANTICS": semantics,
        "SOURCE_REFRESH_STATUS": source_refresh_status,
        "LOCAL_LATEST_SNAPSHOT": local_max,
        "SOURCE_LATEST_SNAPSHOT": source_latest,
        "INDEX_WEIGHT_LOCAL_MAX_SNAPSHOT": local_max,
        "INDEX_WEIGHT_SOURCE_LATEST_SNAPSHOT": source_latest,
        "LOCAL_SNAPSHOT_AVAILABLE": bool(local_max),
        "SOURCE_REFRESH_FAILED": source_refresh_status == "UNKNOWN_SOURCE_UNREACHABLE",
        "UPDATE_REQUIRED": update_token,
        "INDEX_WEIGHT_UPDATE_REQUIRED": update_token,
        "reason": reason,
        "run_target_date": target,
        "live_error": live_err,
        "CACHE_CURRENT_SWITCHED": False,
    }


def matrices(audit: dict, qa: dict, probe: dict, prod: dict, tests: dict, dcheck: dict) -> dict:
    return {
        "DATA_EXISTENCE_MATRIX": [
            {
                "product": "INDEX_WEIGHT_PIT_R1",
                "source_api": "YES",
                "RAW": "YES" if qa.get("INDEX_WEIGHT_RAW_PRESENT") else "NO",
                "formal": "YES" if prod.get("INDEX_WEIGHT_path") else "NO",
                "cache": "YES_SIDECAR" if prod.get("INDEX_WEIGHT_path") else "NO",
            },
            {
                "product": "INDEX_CONSTITUENT_PIT_R1",
                "source_api": "YES",
                "RAW": "YES",
                "formal": "YES",
                "cache": "YES",
            },
            {
                "product": "FUND_PORTFOLIO_STOCK_PIT_R1",
                "source_api": "YES",
                "RAW": "NO",
                "formal": "NO",
                "cache": "NO",
            },
            {
                "product": "ETF_TRACKING_INDEX_MAP_R1",
                "source_api": "YES",
                "RAW": "YES",
                "formal": "YES" if prod.get("ETF_TRACKING_path") else "NO",
                "cache": "YES_SIDECAR" if prod.get("ETF_TRACKING_path") else "NO",
            },
        ],
        "UPDATE_RESPONSIBILITY_MATRIX": [
            {
                "product": "INDEX_WEIGHT_PIT_R1",
                "update_policy": probe.get("INDEX_WEIGHT_UPDATE_POLICY"),
                "incremental_entrypoint": "脚本/blackbox_index_weight_daily_increment_check_r1.py",
                "last_coverage": qa.get("latest_2026_snapshot"),
                "next_action": dcheck.get("reason"),
            }
        ],
        "REQUEST_CAPABILITY_MATRIX": [
            {
                "request": "HS300_ETF_official_exposure",
                "product": "INDEX_WEIGHT_PIT_R1",
                "can_serve": tests.get("cases", {}).get("CASE_A_HS300_ETF", {}).get("pass"),
                "blocker": None,
                "proxy_allowed": False,
            },
            {
                "request": "000698 official weight",
                "product": "INDEX_WEIGHT_PIT_R1",
                "can_serve": False,
                "blocker": "SOURCE_NOT_ACQUIRED",
                "proxy_allowed": False,
            },
            {
                "request": "399303 official weight",
                "product": "INDEX_WEIGHT_PIT_R1",
                "can_serve": False,
                "blocker": "SOURCE_NOT_ACQUIRED",
                "proxy_allowed": False,
            },
            {
                "request": "INDEX_CONSTITUENT.weight",
                "product": "INDEX_CONSTITUENT_PIT_R1",
                "can_serve": False,
                "blocker": "SEMANTIC_FIELD_NOT_SUPPORTED",
                "proxy_allowed": False,
            },
            {
                "request": "FUND_PORTFOLIO_STOCK",
                "product": "FUND_PORTFOLIO_STOCK_PIT_R1",
                "can_serve": False,
                "blocker": "FORMAL_PRODUCT_ABSENT",
                "proxy_allowed": False,
            },
        ],
        "pre_audit": audit,
    }


def run_all(skip_probe: bool = False, live_daily: bool = False) -> dict:
    TASK.mkdir(parents=True, exist_ok=True)
    audit = audit_machine()
    jdump(TASK / "01_MACHINE_AUDIT.json", audit)
    df = load_repair_raw()
    qa = qa_raw(df)
    jdump(TASK / "02_RAW_QA.json", qa)
    if skip_probe:
        probe = {
            "SOURCE_UPDATE_SEMANTICS": "UNKNOWN",
            "INDEX_WEIGHT_UPDATE_POLICY": "CHECK_LATEST_SOURCE_SNAPSHOT_NO_UNCONDITIONAL_FULL_HISTORY",
            "probe_rows": [],
            "skipped": True,
        }
    else:
        try:
            probe = probe_cadence()
        except Exception as exc:
            probe = {
                "SOURCE_UPDATE_SEMANTICS": "UNKNOWN",
                "INDEX_WEIGHT_UPDATE_POLICY": "CHECK_LATEST_SOURCE_SNAPSHOT_NO_UNCONDITIONAL_FULL_HISTORY",
                "probe_rows": [],
                "skipped": False,
                "failed": True,
                "error_class": type(exc).__name__,
                "error": str(exc)[:400],
            }
    jdump(TASK / "03_SOURCE_CADENCE_PROBE.json", probe)
    prod = {}
    if qa.get("INDEX_WEIGHT_RAW_QA_PASS"):
        prod = productize(df, qa, probe)
        jdump(TASK / "04_PRODUCTIZE.json", prod)
        patch_catalog()
        patch_data_access_index(prod)
        patch_facts(qa, probe, prod)
        patch_daily_rules(probe, qa)
        led = fix_ledger()
        jdump(TASK / "05_LEDGER_FIX.json", led)
    else:
        led = {"ok": False, "reason": "QA_FAIL_NO_PRODUCTIZE"}
    tests = semantic_tests() if prod else {"all_pass": False, "cases": {}, "reason": "NOT_PRODUCTIZED"}
    jdump(TASK / "06_SEMANTIC_TESTS.json", tests)
    dcheck = daily_check("2026-08-17", probe=probe, qa=qa, live=live_daily)
    jdump(TASK / "07_DAILY_INCREMENT_DRY_RUN.json", dcheck)
    mx = matrices(audit, qa, probe, prod, tests, dcheck)
    jdump(TASK / "08_THREE_MATRICES.json", mx)
    final = assemble_final(audit, qa, probe, prod, tests, dcheck)
    jdump(TASK / "09_FINAL_ACCEPTANCE.json", final)
    return final


def live_current_has(pid: str) -> bool:
    if not CACHE_CURRENT.is_file():
        return False
    root = Path(load_json(CACHE_CURRENT).get("release_root") or "")
    return bool(root) and (root / pid).is_dir()


def assemble_final(audit: dict, qa: dict, probe: dict, prod: dict, tests: dict, dcheck: dict) -> dict:
    sidecar_ready = bool(prod.get("INDEX_WEIGHT_path") or (SIDECAR.is_file() and "INDEX_WEIGHT_PIT_R1" in json.dumps(load_json(SIDECAR))))
    live_current = live_current_has("INDEX_WEIGHT_PIT_R1")
    source_api = "AVAILABLE_BUT_CURRENTLY_UNREACHABLE" if (probe.get("failed") or dcheck.get("SOURCE_REFRESH_FAILED")) else "AVAILABLE"
    if probe.get("skipped"):
        source_api = "AVAILABLE_PROBE_SKIPPED"
    return {
        "TASK_ID": TASK_ID,
        "final_status": "REVIEW_REQUIRED",
        "final_status_reason": "SIDECAR_READY_LIVE_CURRENT_PENDING_AND_PIT_VISIBILITY_UNRESOLVED",
        "lifecycle": {
            "RAW": "READY" if qa.get("INDEX_WEIGHT_RAW_QA_PASS") else "NOT_READY",
            "FORMAL": "READY" if sidecar_ready else "NOT_READY",
            "SIDECAR_CACHE": "READY" if sidecar_ready else "NOT_READY",
            "LIVE_CURRENT": "PENDING" if not live_current else "READY",
            "RESOLVER_SCHEMA": "REGISTERED",
            "LIVE_CAPABILITY": "NOT_AVAILABLE" if not live_current else "AVAILABLE",
        },
        "INDEX_WEIGHT_CURRENT_DAILY_INCREMENT_STATUS": "INCLUDED" if (load_json(DAILY_CUR).get("INDEX_WEIGHT_PIT_R1") == "MANAGED_SNAPSHOT_CHECK" if DAILY_CUR.is_file() else False) else "NOT_INCLUDED",
        "INDEX_WEIGHT_SOURCE_UPDATE_SEMANTICS": {
            "DAILY": "DAILY",
            "SPARSE_SNAPSHOT": "SPARSE_SNAPSHOT",
            "DATE_QUERY_RETURNS_LAST_KNOWN": "LAST_KNOWN_BY_DATE",
            "UNKNOWN": "UNKNOWN",
        }.get(probe.get("SOURCE_UPDATE_SEMANTICS"), probe.get("SOURCE_UPDATE_SEMANTICS")),
        "INDEX_WEIGHT_RAW_PRESENT": bool(qa.get("INDEX_WEIGHT_RAW_PRESENT")),
        "INDEX_WEIGHT_RAW_QA_PASS": bool(qa.get("INDEX_WEIGHT_RAW_QA_PASS")),
        "INDEX_WEIGHT_FORMAL_PRODUCTIZED": sidecar_ready,
        "INDEX_WEIGHT_SIDECAR_CACHE_PRODUCTIZED": sidecar_ready,
        "INDEX_WEIGHT_CACHE_PRODUCTIZED": sidecar_ready,
        "INDEX_WEIGHT_CACHE_PRODUCTIZED_MEANING": "SIDECAR_ONLY_NOT_LIVE_CURRENT",
        "INDEX_WEIGHT_LIVE_CURRENT_PRODUCTIZED": live_current,
        "INDEX_WEIGHT_LIVE_CAN_SERVE": live_current,
        "INDEX_WEIGHT_RESOLVER_REGISTERED": "INDEX_WEIGHT_PIT_R1" in (ROOT / "脚本" / "blackbox_data_access_resolver_r1.py").read_text(encoding="utf-8"),
        "LAST_KNOWN_SNAPSHOT_FORWARD_SUPPORTED": True,
        "INDEX_WEIGHT_HISTORICAL_BACKTEST_ELIGIBLE": False,
        "PIT_VISIBILITY_CONTRACT": "UNRESOLVED",
        "INDEX_WEIGHT_HISTORICAL_BACKTEST_MODE": "LAST_KNOWN_OFFICIAL_SNAPSHOT_AFTER_PIT_VALID_FROM_NOT_PROVEN",
        "HAND_DECISION_index_weights_historical_backtest_eligible": False,
        "ETF_TRACKING_INDEX_RESOLUTION": "PASS" if prod.get("tracking_rows") else "FAIL",
        "ETF_EXPOSURE_RESOLVER": "PASS" if tests.get("all_pass") else "FAIL",
        "OFFICIAL_WEIGHT_PROXY_FALLBACK": "FORBIDDEN",
        "FUND_PORTFOLIO_STOCK_LEDGER_FIXED": True,
        "FUND_PORTFOLIO_STOCK_LOCAL_PRODUCT_STATUS": "SOURCE_API_AVAILABLE_FORMAL_ABSENT_RAW_ABSENT",
        "DATA_MUST_READ_RULE_UPDATED": all(
            tok in (ROOT / "契约" / "必读" / "BLACKBOX_DATA_ACCESS_MUST_READ.md").read_text(encoding="utf-8")
            for tok in ("RULE_1", "RULE_10", "WEIGHT_PROXY_FORBIDDEN")
        ),
        "MANIFEST_SHA_UPDATED": (
            json.loads((ROOT / "契约" / "必读" / "MUST_READ_MANIFEST_CURRENT.json").read_text(encoding="utf-8"))
            .get("files", {})
            .get("DATA_ACCESS", {})
            .get("sha256")
            == hashlib.sha256(
                (ROOT / "契约" / "必读" / "BLACKBOX_DATA_ACCESS_MUST_READ.md").read_text(encoding="utf-8").encode("utf-8")
            ).hexdigest()
            if (ROOT / "契约" / "必读" / "MUST_READ_MANIFEST_CURRENT.json").is_file()
            else False
        ),
        "DAILY_INCREMENT_DRY_RUN": "PASS" if dcheck.get("INDEX_WEIGHT_MANAGED_BY_DAILY_INCREMENT") == "YES" else "FAIL",
        "STRATEGY_EXECUTED": False,
        "INDEX_WEIGHT_UPDATE_POLICY": probe.get("INDEX_WEIGHT_UPDATE_POLICY")
        or "CHECK_LATEST_SOURCE_SNAPSHOT_NO_UNCONDITIONAL_FULL_HISTORY",
        "INDEX_WEIGHT_LOCAL_MAX_SNAPSHOT": dcheck.get("LOCAL_LATEST_SNAPSHOT"),
        "INDEX_WEIGHT_SOURCE_LATEST_SNAPSHOT": dcheck.get("SOURCE_LATEST_SNAPSHOT"),
        "INDEX_WEIGHT_UPDATE_REQUIRED": dcheck.get("UPDATE_REQUIRED"),
        "SOURCE_REFRESH_STATUS": dcheck.get("SOURCE_REFRESH_STATUS"),
        "SOURCE_API_STATUS": source_api,
        "semantic_tests_all_pass": tests.get("all_pass"),
        "status_matrix": {
            "Source_API": source_api,
            "RAW": "READY" if qa.get("INDEX_WEIGHT_RAW_QA_PASS") else "NOT_READY",
            "RAW_QA": "PASS" if qa.get("INDEX_WEIGHT_RAW_QA_PASS") else "FAIL",
            "Formal": "READY" if sidecar_ready else "NOT_READY",
            "Sidecar_Cache": "READY" if sidecar_ready else "NOT_READY",
            "Main_Cache_CURRENT": "PENDING" if not live_current else "READY",
            "Resolver_schema": "REGISTERED",
            "Live_CAN_SERVE": "NO / NOT_IN_CURRENT" if not live_current else "YES",
            "Daily_increment_managed": "YES",
            "Source_cadence": probe.get("SOURCE_UPDATE_SEMANTICS") or "UNKNOWN",
            "Last_known_mechanics": "SUPPORTED",
            "Historical_PIT_eligibility": "FALSE / PENDING_VISIBILITY_CONTRACT",
            "Proxy_fallback": "FORBIDDEN",
        },
        "written_at_cn": now_cn(),
    }


def status_closeout() -> dict:
    """Rewrite acceptance/facts/coverage without re-productizing or switching CURRENT."""
    TASK.mkdir(parents=True, exist_ok=True)
    audit = audit_machine()
    jdump(TASK / "01_MACHINE_AUDIT.json", audit)
    qa = load_json(TASK / "02_RAW_QA.json") if (TASK / "02_RAW_QA.json").is_file() else {}
    probe = load_json(TASK / "03_SOURCE_CADENCE_PROBE.json") if (TASK / "03_SOURCE_CADENCE_PROBE.json").is_file() else {}
    prod = load_json(TASK / "04_PRODUCTIZE.json") if (TASK / "04_PRODUCTIZE.json").is_file() else {}
    tests = load_json(TASK / "06_SEMANTIC_TESTS.json") if (TASK / "06_SEMANTIC_TESTS.json").is_file() else {}
    dcheck = daily_check("2026-08-17", probe=probe, qa=qa, live=False)
    jdump(TASK / "07_DAILY_INCREMENT_DRY_RUN.json", dcheck)
    mx = matrices(audit, qa, probe, prod, tests, dcheck)
    jdump(TASK / "08_THREE_MATRICES.json", mx)
    path = Path(prod.get("INDEX_WEIGHT_path") or "")
    covp = path / "COVERAGE.json"
    if covp.is_file():
        cov = load_json(covp)
        cov["HISTORICAL_BACKTEST_ELIGIBLE"] = False
        cov["LAST_KNOWN_SNAPSHOT_FORWARD_SUPPORTED"] = True
        cov["PIT_VISIBILITY_CONTRACT"] = "UNRESOLVED"
        cov["INDEX_WEIGHT_HISTORICAL_BACKTEST_ELIGIBLE"] = False
        cov["LIVE_CURRENT_PRODUCTIZED"] = live_current_has("INDEX_WEIGHT_PIT_R1")
        cov["LIVE_CAN_SERVE"] = False
        jdump(covp, cov)
    if prod:
        patch_facts(qa, probe, prod)
    final = assemble_final(audit, qa, probe, prod, tests, dcheck)
    jdump(TASK / "09_FINAL_ACCEPTANCE.json", final)
    jdump(
        TASK / "09_PARTIAL_STATUS.json",
        {
            "TASK_ID": TASK_ID,
            "final_status": "REVIEW_REQUIRED",
            "reason": final.get("final_status_reason"),
            "INDEX_WEIGHT_LIVE_CAN_SERVE": False,
            "INDEX_WEIGHT_HISTORICAL_BACKTEST_ELIGIBLE": False,
            "written_at_cn": now_cn(),
        },
    )
    return final


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--status-closeout", action="store_true")
    ap.add_argument("--audit-only", action="store_true")
    ap.add_argument("--skip-probe", action="store_true")
    ap.add_argument("--live-daily-check", action="store_true")
    ap.add_argument("--read-index-weight")
    ap.add_argument("--signal-date", default="2026-08-17")
    ap.add_argument("--etf-exposure")
    args = ap.parse_args()
    if args.status_closeout:
        final = status_closeout()
        print(json.dumps(final, ensure_ascii=False, indent=2, default=str))
        return 0
    if args.read_index_weight:
        print(json.dumps(read_index_weight(args.read_index_weight, args.signal_date), ensure_ascii=False, indent=2, default=str))
        return 0
    if args.etf_exposure:
        print(json.dumps(get_etf_exposure(args.etf_exposure, args.signal_date), ensure_ascii=False, indent=2, default=str))
        return 0
    if args.audit_only:
        TASK.mkdir(parents=True, exist_ok=True)
        a = audit_machine()
        jdump(TASK / "01_MACHINE_AUDIT.json", a)
        print(json.dumps({k: a[k] for k in a if k != "evidence"}, ensure_ascii=False, indent=2))
        return 0
    final = run_all(skip_probe=args.skip_probe, live_daily=args.live_daily_check)
    print(json.dumps(final, ensure_ascii=False, indent=2, default=str))
    return 0 if final.get("INDEX_WEIGHT_FORMAL_PRODUCTIZED") else 2


if __name__ == "__main__":
    raise SystemExit(main())
