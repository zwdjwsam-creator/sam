#!/usr/bin/env python3
"""P7 .venv-only runtime guard — block non-venv Python before any download logic."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from pathlib import Path

ALLOWED_VENV_PYTHON = Path(r"E:\BLACKBOX\.venv\Scripts\python.exe").resolve()
BLOCK_LOG = Path(r"E:\BLACKBOX\运行\P7_BLOCKED_NON_VENV_PYTHON.log")
NON_VENV_EXIT_CODE = 77


def _parent_pid() -> int | str:
    pid = os.getpid()
    ps = (
        f"(Get-CimInstance Win32_Process -Filter \"ProcessId={pid}\" -ErrorAction SilentlyContinue).ParentProcessId"
    )
    try:
        import subprocess
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=8,
        )
        out = (r.stdout or "").strip()
        return int(out) if out.isdigit() else out or "unknown"
    except Exception:
        return "unknown"


def _append_block_log(reason: str) -> None:
    BLOCK_LOG.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "sys.executable": sys.executable,
        "sys.executable_resolved": str(Path(sys.executable).resolve()),
        "allowed": str(ALLOWED_VENV_PYTHON),
        "argv": sys.argv,
        "pid": os.getpid(),
        "parent_pid": _parent_pid(),
        "reason": reason,
    }
    with BLOCK_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def is_allowed_venv_python() -> bool:
    try:
        return Path(sys.executable).resolve() == ALLOWED_VENV_PYTHON
    except OSError:
        return False


def enforce_venv_only_or_exit() -> None:
    """Call at process entry; exit 77 if not .venv python."""
    if is_allowed_venv_python():
        return
    _append_block_log("non_venv_python_blocked")
    print(f"BLOCK: non_venv_python executable={sys.executable} required={ALLOWED_VENV_PYTHON}")
    raise SystemExit(NON_VENV_EXIT_CODE)
