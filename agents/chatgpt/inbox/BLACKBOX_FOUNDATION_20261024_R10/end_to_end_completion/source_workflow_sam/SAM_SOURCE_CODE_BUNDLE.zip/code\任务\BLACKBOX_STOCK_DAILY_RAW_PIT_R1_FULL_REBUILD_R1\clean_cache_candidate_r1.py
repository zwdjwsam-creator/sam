# -*- coding: utf-8 -*-
"""CLEAN → ALIGN → PIT → CACHE candidate. No CURRENT switch. No price adjustment. No R26."""
from __future__ import annotations

import json
import os
import shutil
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_STOCK_DAILY_RAW_PIT_R1_FULL_REBUILD_R1")
SRC_PTR = Path(r"E:\BLACKBOX\数据\原始只读\strategy_data_plane_additions\STOCK_DAILY_RAW_NONE_FULL_HISTORY_R1\CURRENT_SOURCE_RELEASE.json")
CLEAN_ROOT = Path(r"E:\BLACKBOX\数据\清洗成品")
CLEAN_PTR = CLEAN_ROOT / "CURRENT_CLEANING_RELEASE.json"
CACHE_ROOT = Path(r"E:\BLACKBOX\数据\回测缓存")
CACHE_PTR = CACHE_ROOT / "CURRENT_CACHE_RELEASE.json"
CAL = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P0_meta\calendar_cn_exchange\calendar_cn_exchange_v2_asof_20260814\CALENDAR_TRADE_DAYS.parquet")
ASOF = pd.Timestamp("2026-08-14")
START = pd.Timestamp("2014-01-01")
PRODUCT = "STOCK_DAILY_RAW_PIT_R1"
CONTRACT_FIELDS = [
    "date", "code", "open", "high", "low", "close", "volume", "money",
    "signal_date", "data_date", "asset_type", "price_adj_tag", "asof_rule",
    "pit_status", "source_version", "known_at",
]


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print("[%s] %s" % (now_cn(), msg), flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def inherit_tree(src: Path, dst: Path) -> str:
    if not src.exists():
        return "SKIP_MISSING"
    if dst.exists():
        return "EXISTS"
    os.system('mklink /J "%s" "%s" >NUL 2>&1' % (dst, src))
    if dst.exists():
        return "JUNCTION"
    shutil.copytree(src, dst)
    return "COPYTREE"


def hardlink_file(src: Path, dst: Path) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return "EXISTS"
    try:
        os.link(src, dst)
        return "HARDLINK"
    except OSError:
        shutil.copy2(src, dst)
        return "COPY"


def normalize_year(src: Path, cleaning_id: str) -> pd.DataFrame:
    df = pd.read_parquet(src)
    df["date"] = pd.to_datetime(df["date"]).dt.normalize()
    df["code"] = df["code"].astype(str)
    df = df.loc[(df["date"] >= START) & (df["date"] <= ASOF)].copy()
    df["signal_date"] = df["date"]
    df["data_date"] = df["date"]
    df["asset_type"] = "STOCK"
    df["price_adj_tag"] = "RAW_NONE"
    df["asof_rule"] = "SAME_DAY_KNOWN_EOD"
    df["pit_status"] = "OK"
    df["source_version"] = cleaning_id
    df["known_at"] = df["date"] + pd.Timedelta(hours=15)
    missing = [c for c in CONTRACT_FIELDS if c not in df.columns]
    if missing:
        raise SystemExit("HARD_BLOCK: missing contract fields %s" % missing)
    extra_price_cols = [c for c in ("open", "high", "low", "close") if c in df.columns]
    # forbid any adjustment: values must equal source file
    src_df = pd.read_parquet(src, columns=["date", "code", "close"])
    src_df["date"] = pd.to_datetime(src_df["date"]).dt.normalize()
    chk = df[["date", "code", "close"]].merge(src_df, on=["date", "code"], suffixes=("_c", "_s"))
    if len(chk) and (chk["close_c"] - chk["close_s"]).abs().max() > 1e-12:
        raise SystemExit("HARD_BLOCK: cleaning changed close")
    return df[CONTRACT_FIELDS].sort_values(["code", "date"])


def pit_probe(root: Path) -> dict:
    p = root / "year=2026" / "part_2026.parquet"
    df = pd.read_parquet(p, columns=["date", "code", "close"])
    df["date"] = pd.to_datetime(df["date"]).dt.normalize()
    t = pd.Timestamp("2026-08-11")
    after_t = df.loc[df["date"] > t]
    asof_view = df.loc[df["date"] <= t]
    future = df.loc[df["date"] > ASOF]
    return {
        "request_asof": "2026-08-11",
        "rows_after_request_asof": int(len(after_t)),
        "rows_le_request_asof": int(len(asof_view)),
        "asof_view_max": None if asof_view.empty else str(asof_view["date"].max().date()),
        "max_date_in_product": str(df["date"].max().date()),
        "rows_after_product_asof": int(len(future)),
        "PIT_PASS": (asof_view.empty or asof_view["date"].max() <= t) and len(future) == 0,
        "ANTI_LOOKAHEAD_PASS": len(future) == 0,
        "rule": "reader date<=requested_asof; product cutoff 2026-08-14; no future bars",
    }


def main() -> int:
    src = json.loads(SRC_PTR.read_text(encoding="utf-8"))
    src_root = Path(src["release_root"])
    src_files = sorted((src_root / "data").glob("year=*/part_*.parquet"))
    if len(src_files) != 13:
        raise SystemExit("HARD_BLOCK: expected 13 year parts, got %s" % len(src_files))
    cov = json.loads((TASK / "SOURCE_COVERAGE.json").read_text(encoding="utf-8"))
    gold = json.loads((TASK / "RAW_SEMANTICS_GOLDEN.json").read_text(encoding="utf-8"))
    if not cov.get("RAW_SOURCE_COMPLETE") or not gold.get("RAW_SEMANTICS_PASS"):
        raise SystemExit("HARD_BLOCK: source/golden not PASS")

    parent = json.loads(CLEAN_PTR.read_text(encoding="utf-8"))
    parent_root = Path(parent["standard_root"]).parent
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    rid = "BLACKBOX_FORMAL_CLEANING_R27_STOCK_DAILY_RAW_PIT_ASOF_20260814_%s" % stamp
    seal = "BLACKBOX_CLEANING_LAYER_SEAL_R27_STOCK_DAILY_RAW_%s" % stamp
    dst = CLEAN_ROOT / "releases" / rid
    std = dst / "standard"
    std.mkdir(parents=True, exist_ok=True)
    inherited = {}
    for child in (parent_root / "standard").iterdir():
        if child.name == "price":
            continue
        inherited[child.name] = inherit_tree(child, std / child.name)
    price_src = parent_root / "standard" / "price"
    price_dst = std / "price"
    price_dst.mkdir(parents=True, exist_ok=True)
    if price_src.exists():
        for sub in price_src.iterdir():
            if sub.name == "A股_stock_daily_raw":
                continue
            inherited["price/" + sub.name] = inherit_tree(sub, price_dst / sub.name)
    clean_prod = price_dst / "A股_stock_daily_raw"
    year_files = []
    for f in src_files:
        year = f.parent.name.split("=")[1]
        df = normalize_year(f, rid)
        outp = clean_prod / ("year=%s" % year) / ("part_%s.parquet" % year)
        outp.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(outp, index=False)
        year_files.append(outp)
        log("CLEAN year=%s rows=%s" % (year, len(df)))
    cal = pd.read_parquet(CAL)
    days = set(pd.to_datetime(cal["trade_date"]).dt.normalize())
    sample = pd.read_parquet(year_files[-1], columns=["date"])
    sample["date"] = pd.to_datetime(sample["date"]).dt.normalize()
    extra = [str(d.date()) for d in set(sample["date"]) if d not in days]
    pit = pit_probe(clean_prod)
    pit["CLEAN_PASS"] = extra == []
    pit["YEAR_SLICE_PASS"] = len(year_files) == 13
    pit["price_adjusted"] = False
    wjson(clean_prod / "PIT_CONTRACT.json", {
        "product_id": PRODUCT,
        "known_at": "date EOD 15:00",
        "asof_cutoff": "2026-08-14",
        "fq": "none",
        "price_adj_tag": "RAW_NONE",
        "forbid": ["price_adjustment", "fq=pre", "omit_fq", "p2_fallback", "raw_fallback"],
    })
    wjson(clean_prod / "COVERAGE.json", cov)
    wjson(dst / "RELEASE.json", {
        **parent,
        "release_id": rid,
        "seal_id": seal,
        "sealed": False,
        "candidate_only": True,
        "CURRENT_SWITCHED": False,
        "standard_root": str(std),
        "parent_release_id": parent["release_id"],
        "switch_reason": "STOCK_DAILY_RAW_PIT_R1_CANDIDATE_NOT_CURRENT",
        "STOCK_DAILY_RAW_PIT_R1": "CANDIDATE",
        "created_at_cn": now_cn(),
        "notes": [
            "Inherit current cleaning; ADD A股_stock_daily_raw fq=none full history",
            "Do not overwrite P2 or STOCK_DAILY_PIT_R1",
            "CURRENT not switched until all gates PASS",
        ],
    })
    wjson(TASK / "CLEANING_CANDIDATE.json", {"release_id": rid, "standard_root": str(std), "pit": pit, "inherited": inherited})

    cur = json.loads(CACHE_PTR.read_text(encoding="utf-8"))
    parent_c = Path(cur["release_root"])
    crid = "BLACKBOX_CACHE_R1_STOCK_DAILY_RAW_PIT_ASOF_20260814_%s" % stamp
    cdst = CACHE_ROOT / "releases" / crid
    cdst.mkdir(parents=True, exist_ok=True)
    inh = 0
    for child in parent_c.iterdir():
        if child.name == PRODUCT:
            continue
        if child.is_file():
            shutil.copy2(child, cdst / child.name)
            continue
        if child.is_dir():
            mode = inherit_tree(child, cdst / child.name)
            if mode in ("JUNCTION", "COPYTREE", "EXISTS"):
                inh += 1
    prod = cdst / PRODUCT
    for f in year_files:
        hardlink_file(f, prod / f.parent.name / f.name)
    wjson(prod / "COVERAGE.json", {**cov, "product_id": PRODUCT, "cleaning_release_id": rid})
    wjson(prod / "PIT_CONTRACT.json", {
        "product_id": PRODUCT,
        "fq": "none",
        "price_adj_tag": "RAW_NONE",
        "cleaning_release_id": rid,
        "raw_fallback_allowed": False,
    })
    wjson(prod / "LINEAGE.json", {
        "product_id": PRODUCT,
        "source_api": "get_price(frequency='daily', fq='none')",
        "cleaning_release_id": rid,
        "full_history_start": "2014-01-01",
        "end": "2026-08-14",
        "legacy_p2": "KEPT_AS_EVIDENCE_NOT_SOURCE",
        "parent_cache": cur["cache_release_id"],
        "STOCK_DAILY_PIT_R1": "INHERITED_EVIDENCE_NOT_RAW_AUTHORITY",
        "pipeline": "SOURCE → CLEAN → ALIGN → PIT → YEAR_SLICE → CACHE_CANDIDATE",
    })
    wjson(cdst / "RELEASE.json", {
        **cur,
        "cache_release_id": crid,
        "release_root": str(cdst),
        "published_at_cn": now_cn(),
        "parent_release_id": cur["cache_release_id"],
        "source_cleaning_release": rid,
        "mode": "stock_daily_raw_pit_candidate_not_current",
        "CURRENT_SWITCHED": False,
        "candidate_only": True,
        "STOCK_DAILY_RAW_PIT_R1": "CANDIDATE",
        "STOCK_DAILY_PIT_R1_RAW_AUTHORITY": "FAIL",
        "asof": "2026-08-14",
    })
    wjson(TASK / "CACHE_CANDIDATE.json", {
        "cache_release_id": crid,
        "release_root": str(cdst),
        "inherited_n": inh,
        "YEAR_SLICE_PASS": pit["YEAR_SLICE_PASS"],
        "CLEAN_PASS": pit["CLEAN_PASS"],
        "PIT_PASS": pit["PIT_PASS"],
        "ANTI_LOOKAHEAD_PASS": pit["ANTI_LOOKAHEAD_PASS"],
        "CURRENT_SWITCHED": False,
    })
    log("CANDIDATE cleaning=%s cache=%s CURRENT_SWITCHED=false" % (rid, crid))
    return 0 if pit["CLEAN_PASS"] and pit["YEAR_SLICE_PASS"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
