#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BLACKBOX Unified Data + Research Orchestrator R2 — status / night scaffold."""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
PY = ROOT / ".venv" / "Scripts" / "python.exe"
CN = timezone(timedelta(hours=8))
TASK = ROOT / "任务" / "BLACKBOX_UNIFIED_DATA_RESEARCH_ORCHESTRATOR_R2"
PRODUCTS_CFG = TASK / "契约" / "NIGHT_RESEARCH_PRODUCTS.json"
CASE_SHENGYI = TASK / "案例库" / "SHENGYI_ELECTRONICS_DYNAMIC_DISCOVERY_20260826.json"
CURRENT = ROOT / "运行" / "BLACKBOX_UNIFIED_DATA_RESEARCH_ORCHESTRATOR_CURRENT.json"
OS_ROOT = ROOT / "研究系统"
NIGHT_CUR = OS_ROOT / "CURRENT" / "NIGHT_RESEARCH"
NIGHT_DAILY = OS_ROOT / "DAILY" / "NIGHT_RESEARCH"
MANIFEST = OS_ROOT / "数据平面" / "CURRENT" / "DAILY_DATA_MANIFEST_CURRENT.json"
US_FINE = ROOT / "运行" / "BLACKBOX_US_MARKET_FINE_GRAINED_FLOW_PROFIT_POOL_CURRENT.json"
SELLSIDE = ROOT / "数据" / "研究报告" / "CURRENT" / "SELLSIDE_DAILY_INCREMENTAL_CURRENT.json"
ROS = ROOT / "脚本" / "run_blackbox_research_os.py"
US_FINE_SCRIPT = ROOT / "脚本" / "run_blackbox_us_fine_grained_flow_profit_pool_r1.py"
PLANE = ROOT / "脚本" / "run_blackbox_daily_incremental_data_plane_r1.py"


def now_cn() -> str:
    return datetime.now(CN).strftime("%Y-%m-%dT%H:%M:%S%z")


def today_cn() -> str:
    return datetime.now(CN).strftime("%Y-%m-%d")


def load_json(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def atomic_write_json(p: Path, obj: dict[str, Any]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(p)


def run_py(script: Path, args: list[str]) -> int:
    if not script.exists():
        print(f"[SKIP] missing {script}", flush=True)
        return 1
    cmd = [str(PY), "-u", str(script)] + args
    print(f"[RUN] {' '.join(cmd)}", flush=True)
    return subprocess.run(cmd, cwd=str(ROOT)).returncode


def authority_snapshot() -> dict[str, Any]:
    m = load_json(MANIFEST)
    uf = load_json(US_FINE)
    ss = load_json(SELLSIDE)
    return {
        "manifest_ready": m.get("DAILY_INCREMENTAL_READY"),
        "cn_research_date": m.get("CN_RESEARCH_DATE"),
        "us_fine_status": uf.get("STATUS"),
        "us_market_date": uf.get("US_MARKET_DATE"),
        "sellside_asof": ss.get("asof"),
        "sellside_status": ss.get("TASK_STATUS"),
        "shengyi_case_present": CASE_SHENGYI.exists(),
        "static_prior_ne_live_winner": True,
        "ORDER_ALLOWED": False,
    }


def write_night_stubs(cn_date: str) -> dict[str, Any]:
    cfg = load_json(PRODUCTS_CFG)
    products = cfg.get("products", [])
    day_dir = NIGHT_DAILY / cn_date
    day_dir.mkdir(parents=True, exist_ok=True)
    NIGHT_CUR.mkdir(parents=True, exist_ok=True)
    auth = authority_snapshot()
    written: list[str] = []

    focus = NIGHT_CUR / "15_TOMORROW_FOCUS_PANEL.md"
    focus_body = "\n".join(
        [
            f"# TOMORROW_FOCUS_PANEL — {cn_date}",
            "",
            f"BUILD_TIME_CN: {now_cn()}",
            "STATUS: SCAFFOLD_READY_AWAITING_FULL_NIGHT_LOOP",
            "ORDER_ALLOWED: FALSE",
            "",
            "## Permanent method reminder",
            "",
            "> STATIC_PRIOR != LIVE_WINNER — 静态池只是 Prior；盘中允许动态发现（生益电子方法案例）。",
            "",
            "## A. 明天重点利润池 (target 3–5)",
            "",
            "- [ ] fill from US_FINE + SELLSIDE + CN confirmation",
            "",
            "## B. 为什么",
            "",
            "- [ ] PAYER / MONETIZATION / WHY_NOW",
            "",
            "## C. 美国昨晚谁在交易",
            "",
            f"- US_FINE status={auth.get('us_fine_status')} date={auth.get('us_market_date')}",
            "",
            "## D–J",
            "",
            "- CN yesterday precursor / minute acceptance / intersection / overheat / dynamic seeds / best expressions / wait auction",
            "",
            "## Authority",
            "",
            "```json",
            json.dumps(auth, ensure_ascii=False, indent=2),
            "```",
            "",
        ]
    )
    focus.write_text(focus_body + "\n", encoding="utf-8")
    (day_dir / "15_TOMORROW_FOCUS_PANEL.md").write_text(focus_body + "\n", encoding="utf-8")
    written.append(str(focus))

    book = {
        "schema_version": "1.0.0",
        "PRODUCT": "14_TOMORROW_CANDIDATE_BOOK",
        "CN_RESEARCH_DATE": cn_date,
        "BUILD_TIME_CN": now_cn(),
        "ORDER_ALLOWED": False,
        "STATUS": "SCAFFOLD",
        "STATIC_PRIOR_NE_LIVE_WINNER": True,
        "PRIOR_CANDIDATES": [],
        "DYNAMIC_DISCOVERY_SEEDS": [],
        "THEME_INTERSECTION_CANDIDATES": [],
        "MINUTE_ACCEPTANCE_CANDIDATES": [],
        "NOTE": "Scaffold only — full night loop fills themes 3-5 and names 2-5 each",
        "authority": auth,
    }
    atomic_write_json(NIGHT_CUR / "14_TOMORROW_CANDIDATE_BOOK.json", book)
    atomic_write_json(day_dir / "14_TOMORROW_CANDIDATE_BOOK.json", book)
    written.append(str(NIGHT_CUR / "14_TOMORROW_CANDIDATE_BOOK.json"))

    gaps = NIGHT_CUR / "16_DATA_GAPS_AND_NEXT_COLLECTION.md"
    gaps.write_text(
        "\n".join(
            [
                f"# DATA_GAPS_AND_NEXT_COLLECTION — {cn_date}",
                "",
                "RESEARCH → DATA_REQUIREMENT → NEXT_COLLECTION",
                "",
                "- If SOFTWARE too coarse → Cybersecurity / Identity / Endpoint / Cloud / Enterprise SaaS",
                "- If COPPER too coarse → Mining / Smelting / Cable / Connector / High-Speed Interconnect",
                "",
                f"authority={json.dumps(auth, ensure_ascii=False)}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    written.append(str(gaps))

    # lightweight index stubs for remaining products
    for p in products:
        pid = p["id"]
        if pid.startswith(("14_", "15_", "16_")):
            continue
        path = NIGHT_CUR / f"{pid}.{p.get('ext', 'md')}"
        if not path.exists():
            if p.get("ext") == "json":
                atomic_write_json(path, {"PRODUCT": pid, "STATUS": "SCAFFOLD", "CN_RESEARCH_DATE": cn_date})
            else:
                path.write_text(f"# {pid}\n\nSTATUS: SCAFFOLD\nCN_RESEARCH_DATE: {cn_date}\n", encoding="utf-8")
            written.append(str(path))

    return {"written": written, "day_dir": str(day_dir), "authority": auth}


def publish_current(*, mode: str, night: dict[str, Any] | None = None) -> dict[str, Any]:
    auth = authority_snapshot()
    body = {
        "schema_version": "1.0.0",
        "task_id": "BLACKBOX_UNIFIED_DATA_RESEARCH_ORCHESTRATOR_R2",
        "IDENTITY": "MASTER_DATA_RESEARCH_ORCHESTRATOR",
        "STATUS": "ACTIVE",
        "MODE_LAST": mode,
        "ORDER_ALLOWED": False,
        "KEEP_PERSISTENT": True,
        "STATIC_PRIOR_NE_LIVE_WINNER": True,
        "BUILD_TIME_CN": now_cn(),
        "authority": auth,
        "FIXED_PATHS": {
            "task": str(TASK),
            "master_contract": str(TASK / "契约" / "MASTER_CONTRACT_R2.md"),
            "handoff": str(TASK / "HANDOFF_COMMAND.md"),
            "shengyi_case": str(CASE_SHENGYI),
            "night_current": str(NIGHT_CUR),
            "night_products_cfg": str(PRODUCTS_CFG),
            "research_os_entry": str(ROS),
        },
        "night": night or {},
        "FINAL_STATUS_TARGET": "UNIFIED_DATA_RESEARCH_LOOP_ACTIVE",
    }
    atomic_write_json(CURRENT, body)
    return body


def mode_status() -> int:
    body = publish_current(mode="status")
    print(json.dumps({
        "IDENTITY": body["IDENTITY"],
        "STATUS": body["STATUS"],
        "ORDER_ALLOWED": False,
        "STATIC_PRIOR_NE_LIVE_WINNER": True,
        "authority": body["authority"],
        "current": str(CURRENT),
    }, ensure_ascii=False, indent=2))
    return 0


def mode_premarket_check() -> int:
    """Validate authority before premarket research; does not invent focus names."""
    auth = authority_snapshot()
    ok = auth.get("shengyi_case_present") and auth.get("manifest_ready") in ("YES", "DEGRADED", True)
    publish_current(mode="premarket_check")
    print(json.dumps({"premarket_check": "PASS" if ok else "DEGRADED", "authority": auth}, ensure_ascii=False, indent=2))
    return 0 if ok else 1


def mode_night(*, run_collect: bool) -> int:
    cn = today_cn()
    print(f"[ORCH] NIGHT start cn={cn} collect={run_collect}", flush=True)
    rc = 0
    if run_collect:
        rc |= run_py(PLANE, ["--mode", "status"])
        rc |= run_py(US_FINE_SCRIPT, ["--phase", "daily", "--cn-date", cn])
    night = write_night_stubs(cn)
    body = publish_current(mode="night", night={"cn_date": cn, **{k: night[k] for k in ("day_dir", "authority")}})
    print(f"[ORCH] night scaffold written → {NIGHT_CUR}", flush=True)
    print(f"[ORCH] FOCUS={NIGHT_CUR / '15_TOMORROW_FOCUS_PANEL.md'}", flush=True)
    print("NOTE: full STEP1-15 research fill is ACTIVE_CONTRACT; this run seals scaffold + authority bind", flush=True)
    print(f"FINAL_STATUS={'PASS_SCAFFOLD' if body else 'FAIL'}", flush=True)
    return 0 if CASE_SHENGYI.exists() else 1


def main() -> int:
    ap = argparse.ArgumentParser(description="BLACKBOX Unified Data Research Orchestrator R2")
    ap.add_argument("--mode", default="status", choices=["status", "night", "premarket_check"])
    ap.add_argument("--run-collect", action="store_true", help="night: also refresh plane status + US fine")
    args = ap.parse_args()
    if args.mode == "status":
        return mode_status()
    if args.mode == "premarket_check":
        return mode_premarket_check()
    if args.mode == "night":
        return mode_night(run_collect=bool(args.run_collect))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
