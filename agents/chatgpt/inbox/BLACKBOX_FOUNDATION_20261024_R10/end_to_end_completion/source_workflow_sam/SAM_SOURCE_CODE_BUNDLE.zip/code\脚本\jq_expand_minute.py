#!/usr/bin/env python3
# P7 HARD GUARD — inserted by JQ_P7_MINUTE_RELEASE_BLOCKER_REPAIR_R1
# Date: 2026-06-14T18:59:36+00:00
# This script is BLOCKED as a P7 minute download entry.
# Use: guard/jq_p7_minute_guarded_download_entry_r1.py ONLY
#
if __name__ != "__main__":
    raise SystemExit(0)
print("=" * 60)
print("BLOCKED: P7 MINUTE DIRECT ENTRY FORBIDDEN")
print("Use guarded entry: jq_p7_minute_guarded_download_entry_r1.py")
print("This old entrypoint has been blocked.")
print("=" * 60)
raise SystemExit(1)
# END P7 HARD GUARD

# P7 HARD GUARD — inserted by JQ_P7_MINUTE_RELEASE_BLOCKER_REPAIR_R1
# Date: 2026-06-14T18:59:14+00:00
# This script is BLOCKED as a P7 minute download entry.
# Use: guard/jq_p7_minute_guarded_download_entry_r1.py ONLY
#
if __name__ != "__main__":
    raise SystemExit(0)
print("=" * 60)
print("BLOCKED: P7 MINUTE DIRECT ENTRY FORBIDDEN")
print("Use guarded entry: jq_p7_minute_guarded_download_entry_r1.py")
print("This old entrypoint has been blocked.")
print("=" * 60)
raise SystemExit(1)
# END P7 HARD GUARD

"""
全量分钟线下载 — 扩展到全部 A 股
跳过已下载的股票，额度降到0才停止。
"""
import sys, os, json, subprocess, tempfile, time
from pathlib import Path
from datetime import datetime
sys.stdout.reconfigure(encoding='utf-8')
sys.dont_write_bytecode = True

# ─── 配置 ───────────────────────────────────────────────
ROOT = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw")
CRED_FILE = Path("E:/BLACKBOX/配置/secrets/已验证/聚宽账号.txt")
META_DIR = ROOT / "P0_meta"

# EXACT_LEGACY_DELETION_REVIEW_R1: LEGACY_P7_STOCK_MINUTE_ARCHIVED_HARD_ABORT
# This script historically wrote/read bare P7_stock_minute (legacy 1m/5m).
# Current sealed canonical paths:
#   1m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_raw_none_replacement_1m
#   5m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_minute_raw_none_replacement_5m
#   30m/60m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_minute_raw_none
# Do not relaunch into legacy. Deletion not executed by this review.
raise SystemExit('HARD_ABORT: legacy P7_stock_minute writer archived; use sealed raw_none replacement paths')
OUT_DIR = ROOT / "P7_stock_minute"
BATCH_PY = Path("E:/BLACKBOX/脚本/_download_batch.py")
SCHEMA_VER = "1.0.0"
TIMEOUT = 90

YEARS = list(range(2014, 2027))
FREQS = ["1m", "30m", "60m"]
BATCH_SIZES = {"1m": 20, "30m": 5, "60m": 5}  # 跟之前一致

# ─── 读取凭据 ───────────────────────────────────────────
def load_cred():
    lines = CRED_FILE.read_text(encoding="utf-8").strip().split("\n")
    u = p = None
    for line in lines:
        line = line.strip()
        if not line: continue
        sep = "：" if "：" in line else ":"
        k, v = line.split(sep, 1)
        k, v = k.strip(), v.strip()
        if "账号" in k or "user" in k.lower(): u = v
        if "密码" in k or "pass" in k.lower(): p = v
    return u, p

CRED_U, CRED_P = load_cred()

# ─── 额度检查 ───────────────────────────────────────────
_QUOTA_CACHE = {"spare": None, "ts": 0}
def quota_left():
    import jqdatasdk as jq
    now = time.time()
    cache = _QUOTA_CACHE
    if cache["spare"] is not None and now - cache["ts"] < 3:
        return cache["spare"]
    try:
        jq.auth(CRED_U, CRED_P)
        q = jq.get_query_count()
        s = q.get("spare", 0)
        cache["spare"] = s
        cache["ts"] = now
        return s
    except Exception:
        return cache.get("spare")

# ─── 子进程下载 ─────────────────────────────────────────
def subproc_download(stocks, start_date, end_date, freq, out_path, timeout=TIMEOUT):
    """通过子进程下载 minute 数据"""
    tmp = Path(tempfile.gettempdir()) / f"_jq_min_{os.getpid()}_{int(time.time()*1000)}_{freq}.parquet"
    cmd = [
        sys.executable, "-u", str(BATCH_PY),
        json.dumps(stocks), start_date, end_date, freq,
        str(tmp), datetime.now().strftime("%Y%m%d_%H%M%S"), SCHEMA_VER,
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)
        tmp.unlink(missing_ok=True)
        return None
    if proc.returncode != 0:
        tmp.unlink(missing_ok=True)
        return None
    if tmp.exists() and tmp.stat().st_size > 200:
        import pandas as pd
        try:
            df = pd.read_parquet(tmp)
            if len(df) > 0:
                df.to_parquet(out_path, index=False)
            tmp.unlink(missing_ok=True)
            return df
        except Exception:
            tmp.unlink(missing_ok=True)
            return None
    tmp.unlink(missing_ok=True)
    return None

# ─── 加载全部 A 股 ──────────────────────────────────────
def load_all_stocks():
    import pandas as pd
    codes = []
    for sf in sorted(META_DIR.glob("securities_stock__*.parquet")):
        codes.extend(pd.read_parquet(sf)["code"].dropna().unique().tolist())
    stocks = sorted(set(c.strip() for c in codes if c and isinstance(c, str)))
    return [s for s in stocks if s.endswith(("XSHE", "XSHG"))]

# ─── 获取已下载的股票代码 ────────────────────────────────
def get_downloaded_codes(freq):
    """从已存在的 parquet 文件中提取已下载的股票代码"""
    import pandas as pd
    codes = set()
    files = sorted(OUT_DIR.glob(f"stock_minute_{freq}__*.parquet"))
    # 每个 frequency 只需要采样前几个文件就知道了
    for f in files[:60]:  # 60 文件 × 20 股票 = 1200 只足够覆盖
        try:
            df = pd.read_parquet(f)
            codes.update(df["code"].dropna().unique())
        except:
            pass
    return codes

# ─── 按频率下载 ─────────────────────────────────────────
def download_freq(freq, all_stocks, already_downloaded):
    """下载指定频率的所有未下载股票"""
    batch_size = BATCH_SIZES.get(freq, 5)
    pending = [s for s in all_stocks if s not in already_downloaded]
    if not pending:
        print(f"  [{freq}] 全部已下载, 跳过")
        return 0, []

    # 分批 — 从原始未占用的 batch label 开始
    n_downloaded = len(already_downloaded)
    start_batch = n_downloaded // batch_size  # 原始 batch 索引偏移
    batches = [pending[i:i+batch_size] for i in range(0, len(pending), batch_size)]
    print(f"  [{freq}] 待下载: {len(pending)} 只股票, {len(batches)} 批 (起始batch={start_batch})")

    total_rows = 0
    total_files = 0
    skipped_stocks = []

    for batch_offset, batch in enumerate(batches):
        batch_label = f"batch{batch_offset + start_batch:04d}"

        # 检查额度
        q = quota_left()
        if q is not None and q <= 0:
            print(f"\n  额度已耗尽(剩余={q})，停止下载")
            return total_files, skipped_stocks

        # 每年单独下载 — 跳过所有年份
        all_years_exist = True
        for year in YEARS:
            pattern = f"stock_minute_{freq}__{year}__{batch_label}__{SCHEMA_VER}__*.parquet"
            existing = list(OUT_DIR.glob(pattern))
            if not existing:
                all_years_exist = False
                break
        if all_years_exist:
            continue  # 全部跳过了，这一批不用处理

        for year in YEARS:
            q = quota_left()
            if q is not None and q <= 0:
                print(f"\n  额度耗尽，停止")
                return total_files, skipped_stocks

            start = f"{year}-01-01"
            end = f"{year}-12-31"
            pattern = f"stock_minute_{freq}__{year}__{batch_label}__{SCHEMA_VER}__*.parquet"
            existing = list(OUT_DIR.glob(pattern))
            if existing:
                continue  # 该年份已存在

            out_path = OUT_DIR / f"stock_minute_{freq}__{year}__{batch_label}__{SCHEMA_VER}__{datetime.now().strftime('%Y%m%d_%H%M%S')}.parquet"
            t0 = time.time()
            df = subproc_download(batch, start, end, freq, out_path)
            t = time.time() - t0

            if df is not None and len(df) > 0:
                total_rows += len(df)
                total_files += 1
            elif df is None:
                for s in batch:
                    skipped_stocks.append(s)
                break  # 超时，跳出年份循环

        # 每批完成后显示进度和额度
        q = quota_left()
        prog = (batch_offset + 1) / len(batches) * 100
        print(f"   批 {batch_offset+1}/{len(batches)} ({prog:.0f}%), 文件={total_files}, 行={total_rows:,}, 剩余额度={q}", flush=True)

    return total_files, skipped_stocks

# ─── 主流程 ─────────────────────────────────────────────
def main():
    print("="*60)
    print("全量分钟线下载 — 扩展到全部 A 股")
    print(f"开始: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60)

    q0 = quota_left()
    print(f"初始额度: {q0:,}")

    all_stocks = load_all_stocks()
    print(f"全部A股: {len(all_stocks)} 只")

    grand_total_files = 0
    grand_total_rows = 0
    all_skipped = []

    for freq in FREQS:
        if quota_left() is not None and quota_left() <= 0:
            print(f"\n额度耗尽，停止所有下载")
            break

        print(f"\n--- 频率 {freq} ---")
        downloaded = get_downloaded_codes(freq)
        print(f"  已下载: {len(downloaded)} 只股票")
        nf, sk = download_freq(freq, all_stocks, downloaded)
        grand_total_files += nf
        all_skipped.extend(sk)

    q_end = quota_left()
    print(f"\n{'='*60}")
    print(f"下载完成")
    print(f"新增: {grand_total_files} 文件")
    print(f"跳过的股票(超时): {len(set(all_skipped))} 只")
    if all_skipped:
        print(f"  列表: {sorted(set(all_skipped))[:10]}...")
    print(f"初始额度: {q0:,}")
    print(f"剩余额度: {q_end}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
