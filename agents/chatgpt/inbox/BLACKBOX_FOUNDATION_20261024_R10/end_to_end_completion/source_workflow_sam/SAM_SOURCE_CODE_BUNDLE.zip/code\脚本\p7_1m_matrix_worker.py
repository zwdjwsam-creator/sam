#!/usr/bin/env python3  # noqa: SMOKE_TEST_FIXTURE
"""
JQ_P7_1M_MATRIX_WORKER — single-pool 1m download worker.
Usage: python p7_1m_matrix_worker.py <POOL_NAME>   e.g. pool_A
Each worker runs independently; launcher spawns 3 workers in parallel.
"""
import sys, os, json, csv, hashlib, time, re, shutil
from pathlib import Path
from datetime import datetime, timezone

if len(sys.argv) < 2:
    print("Usage: p7_1m_matrix_worker.py <POOL_NAME>"); sys.exit(1)

POOL = sys.argv[1].upper()
FREQ = "1m"
TASK = f"JQ_P7_1M_MATRIX_WORKER_{POOL}"

sys.stdout.reconfigure(encoding="utf-8")
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path("E:/BLACKBOX/脚本")))
import p7_gate_common as gc
import p7_1m_batch_code_mapping_r6 as map_r6

# HAND gate (worker level)
_dec = gc.load_hand_decision()
if not _dec or _dec.get("hand_release_allowed") is not True:
    print(f"[{POOL}] BLOCK: HAND not released"); sys.exit(3)
if _dec.get("current_stage") != "1m" or _dec.get("one_m_allowed") is not True:
    print(f"[{POOL}] BLOCK: 1m not allowed by HAND"); sys.exit(3)

# ===== PATHS =====
REPAIR = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_minute_release_blocker_repair_R1")

# EXACT_LEGACY_DELETION_REVIEW_R1: LEGACY_P7_STOCK_MINUTE_ARCHIVED_HARD_ABORT
# This script historically wrote/read bare P7_stock_minute (legacy 1m/5m).
# Current sealed canonical paths:
#   1m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_raw_none_replacement_1m
#   5m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_minute_raw_none_replacement_5m
#   30m/60m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_minute_raw_none
# Do not relaunch into legacy. Deletion not executed by this review.
P7_DIR = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P7_stock_raw_none_replacement_1m")
PARENT = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_minute_quota_aware_dynamic_batch_scheduler_fix_R1")
MATRIX = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_1m_matrix_download_R1")
OUT = MATRIX / POOL

NOW_TS = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
NOW_ISO = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")

for s in ["preflight","execution_log","quota_log","checkpoint","reports","manifest"]:
    (OUT / s).mkdir(parents=True, exist_ok=True)

# ===== CONSTANTS =====
TOTAL_STOCKS = 5509; STOCKS_PER_BATCH = 5
QUOTA_LIMIT = 200_000_000  # JQ_P7_QUOTA_UNIT_FIX_R1

# ===== PREFLIGHT =====
print(f"=== WORKER {POOL}: PREFLIGHT ===")
pool_queue_path = REPAIR / "queue_fix" / "1m_matrix_pools" / f"p7_1m_queue_{POOL}.csv"
if not pool_queue_path.exists():
    print(f"BLOCK: pool queue missing: {pool_queue_path}"); sys.exit(2)

ledger_path = PARENT / "ledger" / "p7_no_redownload_ledger.csv"
# Check shared checkpoint (for cross-worker skip)
shared_checkpoint_dir = MATRIX / "_shared"

# Load queue
queue_data = list(csv.DictReader(pool_queue_path.read_text(encoding="utf-8-sig").splitlines()))
print(f"Pool {POOL}: {len(queue_data)} queue items")

# Load ledger
ledger_raw = list(csv.DictReader(ledger_path.read_text(encoding="utf-8-sig").splitlines())) if ledger_path.exists() else []
ledger_map = gc.load_ledger_map()
for r in ledger_raw:
    ledger_map[r.get("partition_key","")] = r

# ===== AUTH (staggered) =====
import random as _rand
stagger = {"POOL_A": 0.0, "POOL_B": 1.5, "POOL_C": 3.0}
time.sleep(stagger.get(POOL, 0.0))
sys.path.insert(0, str(Path("E:/BLACKBOX/脚本")))
import jq_download_base as jdb
jdb.auth()
q = jdb.quota_left(force=True)
spare = q or 0
print(f"[{POOL}] auth OK, spare={spare}")

if spare is not None and spare <= 0:
    print(f"[{POOL}] Quota 0, writing checkpoint and exiting")
    cp = {
        "task": TASK, "pool": POOL, "current_frequency": FREQ,
        "completed": 0, "failed": 0, "skipped": 0,
        "quota_used": 0, "quota_left": 0, "stop_reason": "quota_left_zero",
        "pool_complete": False, "self_continue": True,
        "generated_at": NOW_ISO,
    }
    (OUT / f"checkpoint/worker_{POOL}_checkpoint_{NOW_TS}.json").parent.mkdir(parents=True, exist_ok=True)
    (OUT / f"checkpoint/worker_{POOL}_checkpoint_{NOW_TS}.json").write_text(json.dumps(cp, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[{POOL}] DONE (quota=0)"); sys.exit(0)

import pandas as _pd
_SEC_DF = map_r6.load_securities_df()
ALL_CODES = map_r6.all_stock_codes(_SEC_DF)

# ===== DOWNLOAD LOOP =====
filtered = [r for r in queue_data if r.get("api_call_allowed","") == "true"]
print(f"[{POOL}] Processing {len(filtered)} items...")

parquet_count = sidecar_count = checksum_count = 0
completed = failed = skipped = 0
quota_used = 0
last_pk = ""
stop_reason = ""
execution_rows = []
req_count = 0  # for rate limiting

t0_total = time.time()
for idx, item in enumerate(filtered):
    if gc.global_stop_active():
        stop_reason = "global_stop"; break
    year = item.get("year","")
    batch_id = item.get("batch_id","")
    pk = item.get("partition_key", f"1m/{year}/{batch_id}")
    est = int(item.get("estimated_quota", 290000))

    req_count += 1
    if req_count % 3 == 0:
        time.sleep(0.05)

    curr_q = jdb.quota_left(force=(idx % 15 == 0))
    if curr_q is not None and curr_q < max(est, 5000):
        gc.set_global_stop("quota_exhausted")
        stop_reason = "quota_exhausted"
        print(f"\n[{POOL}] Quota low ({curr_q}), stopping")
        break

    ok_api, reason = gc.check_partition_before_api(pk, "1m", year, batch_id, ledger_map, worker_id=POOL)
    if not ok_api:
        skipped += 1
        continue

    mapping = map_r6.classify_partition(year, batch_id, queue_row=item, sec=_SEC_DF, all_codes=ALL_CODES)
    eligible = map_r6.parse_codes_field(mapping["eligible_codes"])
    expected_empty = map_r6.parse_codes_field(mapping["expected_empty_codes"])
    if mapping["mapping_class"] == "all_expected_empty":
        skipped += 1
        execution_rows.append({
            "timestamp": NOW_ISO, "worker": POOL, "frequency": FREQ,
            "partition_key": pk, "stock_code": mapping["resolved_codes"][:100],
            "year": year, "batch_id": batch_id,
            "jqdata_api_called": "false", "rows_returned": "0",
            "quota_estimated": "0", "parquet_written": "false",
            "sidecar_written": "false", "checksum_written": "false",
            "result_status": "expected_empty_done", "error_type": "",
            "notes": f"expected_empty_codes={','.join(expected_empty)}",
        })
        ledger_map[pk] = {
            "partition_key": pk, "frequency": FREQ, "year": year, "batch_id": batch_id,
            "status": "expected_empty_done", "no_redownload": "true",
            "expected_empty_codes": ",".join(expected_empty),
            "worker": POOL,
        }
        continue
    if not eligible:
        skipped += 1
        execution_rows.append({
            "timestamp": NOW_ISO, "worker": POOL, "frequency": FREQ,
            "partition_key": pk, "stock_code": mapping.get("unknown_codes", "")[:100],
            "year": year, "batch_id": batch_id,
            "jqdata_api_called": "false", "rows_returned": "0",
            "quota_estimated": "0", "parquet_written": "false",
            "sidecar_written": "false", "checksum_written": "false",
            "result_status": "mapping_unknown", "error_type": "mapping_unknown",
            "notes": pk,
        })
        continue

    codes = eligible
    codes_str = ",".join(codes)
    if idx % 10 == 0:
        print(f"  [{POOL}] {idx+1}/{len(filtered)} {year} {batch_id} elig={len(codes)} exp_skip={len(expected_empty)} q~{jdb.quota_left(force=True)}")

    # === API CALL ===
    try:
        import jqdatasdk as jq_d
        sd = map_r6.year_start_for(year).isoformat()
        ed = map_r6.year_end_for(year).isoformat()

        result = jq_d.get_price(codes, start_date=sd, end_date=ed, **map_r6.GET_PRICE_KWARGS_1M)

        if result is not None and len(result) > 0:
            ver = "1.0.0"
            fn = f"stock_minute_1m__{year}__{batch_id}__{ver}__{NOW_TS}.parquet"
            out_path = P7_DIR / fn
            if isinstance(result, _pd.DataFrame):
                result.to_parquet(str(out_path), index=True)
            else:
                _pd.DataFrame(result).to_parquet(str(out_path), index=True)
            parquet_count += 1

            result_status = "completed_with_expected_empty_skips" if expected_empty else "success"
            sc_data = {
                "stock_codes": codes, "expected_empty_codes": expected_empty,
                "frequency": FREQ, "year": year, "batch_id": batch_id,
                "start_date": sd, "end_date": ed, "row_count": len(result), "version": ver,
                "generated_at": NOW_ISO, "source": "JQData get_price", "worker": POOL,
                "mapping_class": mapping["mapping_class"],
            }
            sc_path = out_path.with_suffix(".parquet.sidecar.json")
            sc_path.write_text(json.dumps(sc_data, ensure_ascii=False, indent=2), encoding="utf-8")
            sidecar_count += 1

            ck = hashlib.sha256(out_path.read_bytes()).hexdigest()
            ck_path = out_path.with_suffix(".parquet.checksum.sha256")
            ck_path.write_text(ck, encoding="utf-8")
            checksum_count += 1

            ledger_map[pk] = {
                "partition_key": pk, "frequency": FREQ, "year": year, "batch_id": batch_id,
                "status": "complete", "no_redownload": "true",
                "parquet_path": str(out_path.relative_to(P7_DIR.parent.parent)),
                "sidecar_path": str(sc_path.relative_to(P7_DIR.parent.parent)),
                "checksum_path": str(ck_path.relative_to(P7_DIR.parent.parent)),
                "checksum_value": ck, "row_count": str(len(result)),
                "worker": POOL,
            }

            completed += 1; last_pk = pk; quota_used += est
            execution_rows.append({
                "timestamp": NOW_ISO, "worker": POOL, "frequency": FREQ,
                "partition_key": pk, "stock_code": codes_str[:100],
                "year": year, "batch_id": batch_id,
                "jqdata_api_called": "true", "rows_returned": str(len(result)),
                "quota_estimated": str(est), "parquet_written": "true",
                "sidecar_written": "true", "checksum_written": "true",
                "result_status": result_status, "error_type": "", "notes": fn,
            })
        else:
            failed += 1
            execution_rows.append({
                "timestamp": NOW_ISO, "worker": POOL, "frequency": FREQ,
                "partition_key": pk, "stock_code": codes_str[:100],
                "year": year, "batch_id": batch_id,
                "jqdata_api_called": "true", "rows_returned": "0",
                "quota_estimated": str(est), "parquet_written": "false",
                "sidecar_written": "false", "checksum_written": "false",
                "result_status": "suspicious_empty", "error_type": "suspicious_empty", "notes": pk,
            })
    except Exception as e:
        failed += 1; em = str(e)[:200]
        execution_rows.append({
            "timestamp": NOW_ISO, "worker": POOL, "frequency": FREQ,
            "partition_key": pk, "stock_code": codes_str[:100],
            "year": year, "batch_id": batch_id,
            "jqdata_api_called": "true", "rows_returned": "0",
            "quota_estimated": str(est), "parquet_written": "false",
            "sidecar_written": "false", "checksum_written": "false",
            "result_status": "error", "error_type": em, "notes": pk,
        })
        if any(kw in em.lower() for kw in ("quota","insufficient","额度")):
            stop_reason = "api_quota_empty"; break

# ===== POST-RUN =====
curr_q = jdb.quota_left(force=True)
if curr_q is not None and curr_q <= 0 and not stop_reason:
    stop_reason = "quota_left_zero"

elapsed = time.time() - t0_total
print(f"\n[{POOL}] STOP: {stop_reason or 'pool_done'}")
print(f"[{POOL}] completed={completed} failed={failed} skipped={skipped}")
print(f"[{POOL}] parquet={parquet_count} sidecar={sidecar_count} checksum={checksum_count}")
print(f"[{POOL}] quota_used={quota_used} quota_left={curr_q} elapsed={elapsed:.0f}s")

# Pool complete?
import re as _re
disk_set = set()
for f in P7_DIR.glob("stock_minute_1m__*.parquet"):
    if ".sidecar" in f.name or ".checksum" in f.name: continue
    m = _re.match(r"stock_minute_1m__(\d{4})__(batch\d+)__.*", f.name)
    if m: disk_set.add((int(m.group(1)), m.group(2)))
# Check our pool's years
pool_years = set(int(r["year"]) for r in queue_data)
pool_missing = 0
for r in queue_data:
    yr = int(r["year"]); bt = r["batch_id"]
    if (yr, bt) not in disk_set:
        pool_missing += 1
pool_complete = (pool_missing == 0)
print(f"[{POOL}] pool_missing={pool_missing} pool_complete={pool_complete}")

# === CHECKPOINT ===
cp_data = {
    "task": TASK, "pool": POOL, "current_frequency": FREQ,
    "completed": completed, "failed": failed, "skipped": skipped,
    "parquet": parquet_count, "sidecar": sidecar_count, "checksum": checksum_count,
    "quota_used": quota_used, "quota_left": curr_q, "stop_reason": stop_reason or "pool_done",
    "pool_complete": pool_complete, "pool_missing": pool_missing,
    "self_continue": not bool(stop_reason and stop_reason not in ("quota_exhausted","quota_left_zero","api_quota_empty")),
    "generated_at": NOW_ISO,
}
cp_path = OUT / f"checkpoint/worker_{POOL}_checkpoint_{NOW_TS}.json"
cp_path.parent.mkdir(parents=True, exist_ok=True)
cp_path.write_text(json.dumps(cp_data, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"[{POOL}] Checkpoint: {cp_path.name}")

# === EXECUTION LOG ===
if execution_rows:
    el_path = OUT / f"execution_log/worker_{POOL}_execution_{NOW_TS}.csv"
    with open(str(el_path), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(execution_rows[0].keys()))
        w.writeheader(); w.writerows(execution_rows)
    print(f"[{POOL}] Execution log: {el_path.name} ({len(execution_rows)} entries)")

# === QUOTA LOG ===
ql_path = OUT / f"quota_log/worker_{POOL}_quota_{NOW_TS}.csv"
with open(str(ql_path), "w", newline="", encoding="utf-8-sig") as f:
    f.write("timestamp,worker,quota_before,quota_after,quota_used,stop_reason\n")
    f.write(f"{NOW_ISO},{POOL},{spare},{curr_q},{quota_used},{stop_reason or 'pool_done'}\n")
print(f"[{POOL}] Quota log: {ql_path.name}")

# === REPORT ===
fs = ""
if pool_complete: fs = "POOL_COMPLETE"
elif stop_reason in ("quota_exhausted","quota_left_zero","api_quota_empty"): fs = "PAUSED_QUOTA_EXHAUSTED"
else: fs = "RUNNING"

rmd = f"""# {TASK} 报告
工人: {POOL} | 时间: {NOW_ISO}
## final_status: {fs}
| 完成 | {completed} | 失败 | {failed} | 跳过 | {skipped} |
| parquet | {parquet_count} | sidecar | {sidecar_count} | checksum | {checksum_count} |
| 配额消耗 | {quota_used} | 剩余 | {curr_q} | 停止原因 | {stop_reason or 'pool_done'} |
| pool 完成 | {pool_complete} | 缺失 | {pool_missing} |
"""
rp = OUT / f"reports/worker_{POOL}_report_{NOW_TS}.md"
rp.parent.mkdir(parents=True, exist_ok=True); rp.write_text(rmd, encoding="utf-8")

# === MANIFEST ===
man = {
    "task": TASK, "pool": POOL, "final_status": fs, "output_root": str(OUT),
    "current_frequency": FREQ, "jqdata_api_called": completed > 0,
    "quota_used": quota_used, "quota_left": curr_q, "stop_reason": stop_reason or "pool_done",
    "parquet_written": parquet_count, "sidecar_written": sidecar_count, "checksum_written": checksum_count,
    "pool_complete": pool_complete, "pool_missing": pool_missing,
    "generated_at": NOW_ISO, "generated_by": TASK,
}
mt = json.dumps(man, ensure_ascii=False, indent=2)
man["sha256"] = hashlib.sha256(mt.encode()).hexdigest()
mp = OUT / f"manifest/worker_{POOL}_manifest_{NOW_TS}.json"
mp.parent.mkdir(parents=True, exist_ok=True); mp.write_text(mt, encoding="utf-8")

print(f"[{POOL}] Report: {rp.name}")
print(f"[{POOL}] Manifest: {mp.name}")
print(f"[{POOL}] DONE (exit_code=0)")
sys.exit(0)
