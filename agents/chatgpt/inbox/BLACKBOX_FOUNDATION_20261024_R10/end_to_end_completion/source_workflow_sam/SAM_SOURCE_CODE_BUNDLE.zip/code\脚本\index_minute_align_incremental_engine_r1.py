#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INDEX MINUTE ALIGN incremental successor engine R1.

MODEL A: unchanged partitions = hardlink reuse; affected = key-merge rebuild.
Transactional staging + orphan registry. Does not change logical BAR_END/PIT semantics.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
import traceback
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).resolve().parent))

ROOT = Path(r"E:\BLACKBOX")
P3 = ROOT / "数据/原始只读/JQData_9999_official_raw/P3_index_minute"
CAL_DIR = ROOT / "数据/原始只读/JQData_9999_official_raw/P0_meta/calendar_cn_exchange"
REG = ROOT / "规则库/hand_hard_rules/INDEX_CLASSIFICATION_AND_BENCHMARK_REGISTRY_R1.json"
MASTER = (
    ROOT
    / "任务/20260804_230632_BLACKBOX_BUILD_CANONICAL_786aec/artifacts/CANONICAL_INDEX_SECURITY_MASTER_R1.parquet"
)
RELEASES = ROOT / "数据/清洗成品/releases"
POINTER = ROOT / "数据/清洗成品/CURRENT_INDEX_MINUTE_ALIGN_RELEASE.json"
ORPHAN_REGISTRY = ROOT / "运行/BLACKBOX_STORAGE_ORPHAN_REGISTRY_CURRENT.json"
STORAGE_LEDGER_DIR = ROOT / "运行/index_minute_align_storage_ledgers"
FREQS = ["5m", "1m", "30m", "60m"]
SCHEMA_COLS = [
    "canonical_index_id",
    "code",
    "time",
    "bar_end_ts",
    "trade_date",
    "frequency",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "amount",
    "bar_complete",
    "available_from_ts",
    "market_timezone",
    "source_fq",
    "source_provider",
    "source_api",
    "calendar_asof",
    "cutoff_ts",
    "raw_source_path",
]
PRIMARY_KEY = ["code", "frequency", "time"]


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def now_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda: f.read(1024 * 1024), b""):
            h.update(c)
    return h.hexdigest()


def code_from_safe(c: str) -> str:
    if c.endswith("_XSHE"):
        return c[:-5] + ".XSHE"
    if c.endswith("_XSHG"):
        return c[:-5] + ".XSHG"
    return c


def code_to_safe(c: str) -> str:
    return c.replace(".", "_")


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def load_calendar(cutoff_date: str) -> tuple[set[str], Path]:
    cals = sorted(CAL_DIR.glob("calendar_cn_exchange_v2_asof_*"))
    if not cals:
        raise FileNotFoundError("calendar missing")
    latest = cals[-1]
    if latest.is_dir():
        trade = latest / "CALENDAR_TRADE_DAYS.parquet"
        all_d = latest / "CALENDAR_ALL_DATES.parquet"
        if trade.exists():
            path = trade
        elif all_d.exists():
            path = all_d
        else:
            pq = list(latest.glob("*.parquet"))
            if not pq:
                raise FileNotFoundError(latest)
            path = pq[0]
    else:
        path = latest
    df = pd.read_parquet(path) if path.suffix == ".parquet" else pd.read_csv(path)
    for col in ("calendar_date", "trade_date", "date", "cal_date", "day"):
        if col in df.columns:
            s = pd.to_datetime(df[col]).dt.strftime("%Y-%m-%d")
            break
    else:
        s = pd.to_datetime(df.iloc[:, 0]).dt.strftime("%Y-%m-%d")
    for flag in ("is_trade_day", "is_open", "open", "is_trading"):
        if flag in df.columns:
            s = s[df[flag].astype(int) == 1]
            break
    days = {d for d in s.astype(str) if d <= cutoff_date}
    return days, path


def latest_raw_partition_map(raw_root: Path | None = None) -> dict[tuple[str, str, str], Path]:
    root = raw_root or P3
    by: dict[tuple[str, str, str], list[Path]] = defaultdict(list)
    for p in root.rglob("index_minute__*.parquet"):
        parts = p.name.split("__")
        if len(parts) < 4:
            continue
        by[(code_from_safe(parts[1]), parts[2], parts[3])].append(p)

    def score(p: Path) -> tuple:
        n = p.name
        pri = 0
        if "tail_gap" in n:
            pri = 4
        elif "incremental" in n:
            # Prefer day incremental over year full for asof bumps:
            # year full often uses index-col schema and lags the tip day.
            pri = 3
        elif "migrated_p9" in n:
            pri = 2
        elif "full" in n:
            pri = 1
        return (pri, p.stat().st_mtime, p.stat().st_size)

    return {k: sorted(paths, key=score, reverse=True)[0] for k, paths in by.items()}


def list_aligned_partitions(aligned_root: Path) -> dict[tuple[str, str, str], Path]:
    out: dict[tuple[str, str, str], Path] = {}
    for p in aligned_root.rglob("index_minute_aligned__*.parquet"):
        parts = p.name.split("__")
        if len(parts) < 4:
            continue
        code = code_from_safe(parts[1])
        freq, year = parts[2], parts[3]
        out[(code, freq, year)] = p
    return out


def hardlink_or_copy(src: Path, dst: Path) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    try:
        os.link(src, dst)
        return "HARDLINK"
    except OSError:
        shutil.copy2(src, dst)
        return "COPY_FALLBACK"


def load_active_windows(required: Iterable[str]) -> dict[str, tuple[str, str | None]]:
    required_set = set(required)
    master = pd.read_parquet(MASTER)
    master = master[master["provider_native_code"].astype(str).isin(required_set)]
    active: dict[str, tuple[str, str | None]] = {}
    for r in master.itertuples():
        code = str(r.provider_native_code)
        a0 = str(getattr(r, "active_from", None) or getattr(r, "launch_date", None) or "2014-01-01")[:10]
        a1 = getattr(r, "active_to", None) or getattr(r, "termination_date", None)
        a1s = (
            None
            if a1 is None or (isinstance(a1, float) and pd.isna(a1)) or str(a1) in ("", "None", "nan")
            else str(a1)[:10]
        )
        active[code] = (a0, a1s)
    for code in required_set:
        active.setdefault(code, ("2014-01-01", None))
    return active


def align_raw_frame(
    df: pd.DataFrame,
    *,
    code: str,
    freq: str,
    cutoff: pd.Timestamp,
    cal_days: set[str],
    active: dict[str, tuple[str, str | None]],
    cal_path_name: str,
    raw_source_path: str,
) -> tuple[pd.DataFrame, dict]:
    stats = {
        "rows_in": 0,
        "rows_out": 0,
        "rows_dropped_lookahead": 0,
        "rows_dropped_non_calendar": 0,
        "rows_dropped_inactive": 0,
        "rows_dropped_dup": 0,
        "lookahead_fail": False,
        "fq_fail": False,
    }
    if "time" not in df.columns:
        df = df.reset_index().rename(columns={"index": "time"})
    df = df.copy()
    df["time"] = pd.to_datetime(df["time"])
    stats["rows_in"] = len(df)
    leak = df["time"] > cutoff
    if leak.any():
        stats["rows_dropped_lookahead"] = int(leak.sum())
        stats["lookahead_fail"] = True
    df = df.loc[~leak]
    df["trade_date"] = df["time"].dt.strftime("%Y-%m-%d")
    cal_ok = df["trade_date"].isin(cal_days)
    stats["rows_dropped_non_calendar"] = int((~cal_ok).sum())
    df = df.loc[cal_ok]
    a0, a1 = active.get(code, ("2014-01-01", None))
    act = df["trade_date"] >= a0
    if a1:
        act &= df["trade_date"] <= a1
    stats["rows_dropped_inactive"] = int((~act).sum())
    df = df.loc[act]
    before = len(df)
    df = df.drop_duplicates(subset=["time"], keep="last").sort_values("time")
    stats["rows_dropped_dup"] = before - len(df)
    if df.empty:
        return pd.DataFrame(columns=SCHEMA_COLS), stats
    if "source_fq" in df.columns and df["source_fq"].astype(str).isin(["pre", "post"]).any():
        stats["fq_fail"] = True
    out = pd.DataFrame(
        {
            "canonical_index_id": f"IDX::{code}",
            "code": code,
            "time": df["time"],
            "bar_end_ts": df["time"],
            "trade_date": df["trade_date"],
            "frequency": freq,
            "open": df["open"],
            "high": df["high"],
            "low": df["low"],
            "close": df["close"],
            "volume": df["volume"],
            "amount": df["money"] if "money" in df.columns else df.get("amount"),
            "bar_complete": True,
            "available_from_ts": df["time"],
            "market_timezone": "Asia/Shanghai",
            "source_fq": "NOT_APPLICABLE",
            "source_provider": "JQData",
            "source_api": "aligned_from_P3_index_minute",
            "calendar_asof": cal_path_name,
            "cutoff_ts": str(cutoff),
            "raw_source_path": raw_source_path,
        }
    )
    stats["rows_out"] = len(out)
    return out, stats


def merge_aligned(base: pd.DataFrame, delta: pd.DataFrame) -> pd.DataFrame:
    if base is None or base.empty:
        g = delta.copy()
    elif delta is None or delta.empty:
        g = base.copy()
    else:
        g = pd.concat([base, delta], ignore_index=True)
    if g.empty:
        return g
    g["time"] = pd.to_datetime(g["time"])
    g["bar_end_ts"] = pd.to_datetime(g["bar_end_ts"])
    before = len(g)
    g = g.drop_duplicates(subset=["time"], keep="last").sort_values("time")
    if "trade_date" not in g.columns:
        g["trade_date"] = g["time"].dt.strftime("%Y-%m-%d")
    return g.reset_index(drop=True)


@dataclass
class StorageMetrics:
    authoritative_incremental_source_bytes: int = 0
    new_physical_bytes: int = 0
    reused_logical_bytes: int = 0
    full_history_copy_bytes: int = 0
    affected_partition_count: int = 0
    unchanged_partition_count: int = 0
    untouched_partition_rewrite_count: int = 0
    orphan_bytes: int = 0
    hardlink_count: int = 0
    copy_fallback_count: int = 0
    write_amplification: float | None = None
    physical_write_to_reused_logical_ratio: float | None = None

    def finalize(self) -> None:
        if self.authoritative_incremental_source_bytes > 0:
            self.write_amplification = self.new_physical_bytes / self.authoritative_incremental_source_bytes
        else:
            self.write_amplification = None if self.new_physical_bytes == 0 else float("inf")
        if self.reused_logical_bytes > 0:
            self.physical_write_to_reused_logical_ratio = self.new_physical_bytes / self.reused_logical_bytes
        else:
            self.physical_write_to_reused_logical_ratio = None


@dataclass
class BuildContext:
    task_id: str
    mode: str
    previous_release_id: str
    previous_root: Path
    previous_aligned: Path
    previous_cutoff: str
    new_cutoff: str
    release_id: str
    staging_root: Path
    aligned_root: Path
    universe_codes: list[str]
    publication_generation_id: str
    inject_fail: str | None = None
    raw_root: Path = P3
    no_cutover: bool = False
    no_hand_update: bool = False
    dry_run_plan_only: bool = False
    skip_source_completeness: bool = False
    extra_trade_dates: list[str] = field(default_factory=list)
    metrics: StorageMetrics = field(default_factory=StorageMetrics)
    affected: set[tuple[str, str, str]] = field(default_factory=set)
    increment_dates: list[str] = field(default_factory=list)
    status: str = "STAGING"
    failure_phase: str | None = None
    failure_reason: str | None = None


def read_previous_cutoff(prev_root: Path) -> str:
    seal = prev_root / "SEAL.json"
    if seal.exists():
        return str(json.loads(seal.read_text(encoding="utf-8")).get("cutoff"))
    # filename fallback
    parts = list((prev_root / "standard" / "index_minute").rglob("*.parquet"))
    if not parts:
        raise FileNotFoundError("previous release has no seal/cutoff")
    name = parts[0].name
    if "asof_" in name:
        tag = name.split("asof_")[-1].replace(".parquet", "")
        return f"{tag[:4]}-{tag[4:6]}-{tag[6:8]}"
    raise FileNotFoundError("cannot infer previous cutoff")


def load_current_pointer() -> dict:
    if not POINTER.exists():
        raise FileNotFoundError(POINTER)
    return json.loads(POINTER.read_text(encoding="utf-8"))


def plan_affected_partitions(
    *,
    prev_parts: dict[tuple[str, str, str], Path],
    raw_parts: dict[tuple[str, str, str], Path],
    required_set: set[str],
    previous_cutoff: str,
    new_cutoff: str,
    increment_dates: list[str] | None,
    force_keys: Iterable[tuple[str, str, str]] | None = None,
) -> tuple[set[tuple[str, str, str]], list[str]]:
    """Affected = partitions whose year intersects increment dates, or force_keys."""
    if force_keys is not None:
        dates = sorted(set(increment_dates or []))
        return set(force_keys), dates

    if increment_dates:
        # Explicit increment/gapfill dates: trust caller; only enforce <= new_cutoff
        dates = sorted({d for d in increment_dates if d <= new_cutoff})
    else:
        # default: all calendar days strictly after previous cutoff up to new
        cal_days, _ = load_calendar(new_cutoff)
        dates = sorted(d for d in cal_days if previous_cutoff < d <= new_cutoff)

    years = {d[:4] for d in dates}
    affected: set[tuple[str, str, str]] = set()
    for code in required_set:
        for freq in FREQS:
            for y in years:
                key = (code, freq, y)
                if key in prev_parts or key in raw_parts:
                    affected.add(key)
    # new year partitions only in raw
    for key in raw_parts:
        code, freq, year = key
        if code in required_set and year in years:
            affected.add(key)
    return affected, dates


def source_completeness_gate(
    *,
    increment_dates: list[str],
    required_codes: list[str],
    raw_parts: dict[tuple[str, str, str], Path],
    active: dict[str, tuple[str, str | None]],
    allow_empty_codes: set[str] | None = None,
    sample_limit_per_file: int | None = None,
) -> dict:
    if not increment_dates:
        return {
            "gate": "INDEX_MINUTE_INCREMENT_SOURCE_COMPLETENESS_GATE_R1",
            "status": "PASS",
            "SOURCE_COMPLETENESS": "PASS",
            "increment_dates": [],
            "note": "EMPTY_INCREMENT_IDEMPOTENT_OR_REUSE_ONLY",
            "authoritative_incremental_source_bytes_estimate": 0,
            "BLOCKED_PARTIAL_SOURCE": False,
        }
    allow_empty = allow_empty_codes or set()
    expected_freqs = list(FREQS)
    missing = []
    partial = []
    observed = 0
    source_bytes = 0
    counted_files: set[str] = set()
    for d in increment_dates:
        y = d[:4]
        for code in required_codes:
            a0, a1 = active.get(code, ("2014-01-01", None))
            if d < a0 or (a1 and d > a1):
                continue
            for freq in expected_freqs:
                key = (code, freq, y)
                src = raw_parts.get(key)
                if src is None:
                    if code in allow_empty:
                        continue
                    missing.append({"date": d, "code": code, "freq": freq, "reason": "NO_RAW_PARTITION"})
                    continue
                sp = str(src)
                if sp not in counted_files:
                    source_bytes += src.stat().st_size
                    counted_files.add(sp)
                try:
                    df = pd.read_parquet(src, columns=["time"])
                    if "time" not in df.columns:
                        df = pd.read_parquet(src)
                        if "time" not in df.columns:
                            df = df.reset_index().rename(columns={"index": "time"})
                    t = pd.to_datetime(df["time"])
                    has = (t.dt.strftime("%Y-%m-%d") == d).any()
                    if not has:
                        partial.append({"date": d, "code": code, "freq": freq, "reason": "DATE_ABSENT_IN_YEAR_FILE"})
                    else:
                        observed += 1
                except Exception as e:
                    missing.append({"date": d, "code": code, "freq": freq, "reason": f"READ_FAIL:{e}"})
    # Structural missing year partitions → FAIL. All-date-absent → partial/canary FAIL.
    status = "PASS"
    marker = None
    if missing:
        status = "FAIL"
        marker = "MISSING_RAW_PARTITIONS"
    elif observed == 0 and increment_dates:
        status = "FAIL"
        marker = "BLOCKED_PARTIAL_SOURCE_ZERO_OBSERVED"
    return {
        "gate": "INDEX_MINUTE_INCREMENT_SOURCE_COMPLETENESS_GATE_R1",
        "status": status,
        "SOURCE_COMPLETENESS": status,
        "expected_codes_n": len(required_codes),
        "expected_frequencies": expected_freqs,
        "increment_dates": increment_dates,
        "observed_code_freq_date_hits": observed,
        "missing_partitions": missing[:50],
        "missing_partitions_n": len(missing),
        "date_absent_n": len(partial),
        "authoritative_incremental_source_bytes_estimate": source_bytes,
        "marker": marker,
        "BLOCKED_PARTIAL_SOURCE": status != "PASS",
    }


def storage_non_regression_gate(
    metrics: StorageMetrics,
    *,
    incremental_days: int,
    previous_current: str,
    new_current: str | None,
) -> dict:
    fail = []
    if incremental_days <= 1 and metrics.untouched_partition_rewrite_count > 0:
        fail.append("UNTOUCHED_PARTITION_REWRITE_ON_SINGLE_DAY")
    if metrics.full_history_copy_bytes > 0:
        fail.append("FULL_HISTORY_COPY_BYTES_GT_0")
    status = "PASS" if not fail else "FAIL"
    return {
        "gate": "INDEX_MINUTE_INCREMENTAL_STORAGE_NON_REGRESSION_R1",
        "status": status,
        "failures": fail,
        "authoritative_incremental_source_bytes": metrics.authoritative_incremental_source_bytes,
        "new_physical_bytes": metrics.new_physical_bytes,
        "write_amplification": metrics.write_amplification,
        "physical_write_to_reused_logical_ratio": metrics.physical_write_to_reused_logical_ratio,
        "affected_partition_count": metrics.affected_partition_count,
        "unchanged_partition_count": metrics.unchanged_partition_count,
        "untouched_partition_rewrite_count": metrics.untouched_partition_rewrite_count,
        "full_history_copy_bytes": metrics.full_history_copy_bytes,
        "orphan_bytes": metrics.orphan_bytes,
        "previous_current": previous_current,
        "new_current": new_current,
        "incremental_days": incremental_days,
    }


def register_orphan(ctx: BuildContext) -> dict:
    phys = 0
    nfiles = 0
    if ctx.staging_root.exists():
        for p in ctx.staging_root.rglob("*"):
            if p.is_file():
                phys += p.stat().st_size
                nfiles += 1
    marker = {
        "status": "ABORTED_STAGING",
        "task_id": ctx.task_id,
        "candidate_release_id": ctx.release_id,
        "staging_root": str(ctx.staging_root),
        "created_at": now_iso(),
        "failure_phase": ctx.failure_phase,
        "failure_reason": ctx.failure_reason,
        "physical_bytes": phys,
        "file_count": nfiles,
        "current_reference": load_current_pointer().get("release_id") if POINTER.exists() else None,
        "formal_reference": ctx.previous_release_id,
        "safe_reclaim_candidate": True,
        "CURRENT_UNCHANGED": True,
    }
    wjson(ctx.staging_root / "ORPHAN_MANIFEST.json", marker)
    wjson(ctx.staging_root / "ABORTED_STAGING.json", marker)
    reg = []
    if ORPHAN_REGISTRY.exists():
        try:
            reg = json.loads(ORPHAN_REGISTRY.read_text(encoding="utf-8"))
            if not isinstance(reg, list):
                reg = [reg]
        except Exception:
            reg = []
    reg.append(marker)
    ORPHAN_REGISTRY.parent.mkdir(parents=True, exist_ok=True)
    wjson(ORPHAN_REGISTRY, {"updated_at": now_iso(), "orphans": reg})
    ctx.metrics.orphan_bytes = phys
    return marker


def maybe_inject(ctx: BuildContext, phase: str, progress: float) -> None:
    inj = (ctx.inject_fail or "").upper()
    if not inj:
        return
    mapping = {
        "BUILD_25": ("BUILD", 0.25),
        "BUILD_75": ("BUILD", 0.75),
        "QA_FAIL": ("QA", 1.0),
        "MANIFEST_FAIL": ("MANIFEST", 1.0),
        "SEAL_KILL": ("SEAL", 1.0),
        "CUTOVER_KILL": ("CUTOVER", 1.0),
    }
    if inj not in mapping:
        return
    p_phase, p_prog = mapping[inj]
    if phase == p_phase and progress >= p_prog:
        raise RuntimeError(f"INJECTED_FAIL:{inj}")


def build_incremental(ctx: BuildContext) -> dict:
    required = ctx.universe_codes
    required_set = set(required)
    cutoff = pd.Timestamp(f"{ctx.new_cutoff} 15:30:00")
    cal_days, cal_path = load_calendar(ctx.new_cutoff)
    for d in ctx.extra_trade_dates:
        cal_days.add(d)
    active = load_active_windows(required)
    prev_parts = list_aligned_partitions(ctx.previous_aligned)
    raw_parts = latest_raw_partition_map(ctx.raw_root)

    affected, dates = plan_affected_partitions(
        prev_parts=prev_parts,
        raw_parts=raw_parts,
        required_set=required_set,
        previous_cutoff=ctx.previous_cutoff,
        new_cutoff=ctx.new_cutoff,
        increment_dates=ctx.increment_dates or None,
    )
    ctx.affected = affected
    ctx.increment_dates = dates
    ctx.metrics.affected_partition_count = len(affected)

    if ctx.skip_source_completeness:
        sc = {
            "gate": "INDEX_MINUTE_INCREMENT_SOURCE_COMPLETENESS_GATE_R1",
            "status": "PASS",
            "SOURCE_COMPLETENESS": "PASS",
            "skipped": True,
            "authoritative_incremental_source_bytes_estimate": 0,
            "BLOCKED_PARTIAL_SOURCE": False,
        }
    else:
        sc = source_completeness_gate(
            increment_dates=dates,
            required_codes=required,
            raw_parts=raw_parts,
            active=active,
        )
    if dates and sc["status"] != "PASS" and not ctx.inject_fail:
        ctx.failure_phase = "SOURCE_COMPLETENESS"
        ctx.failure_reason = json.dumps(sc, ensure_ascii=False)[:2000]
        raise RuntimeError("INCREMENTAL_ALIGN=BLOCKED_PARTIAL_SOURCE")

    ctx.metrics.authoritative_incremental_source_bytes = int(
        sc.get("authoritative_incremental_source_bytes_estimate") or 0
    )

    plan = {
        "previous_release_id": ctx.previous_release_id,
        "previous_cutoff": ctx.previous_cutoff,
        "new_cutoff": ctx.new_cutoff,
        "increment_dates": dates,
        "affected_partition_count": len(affected),
        "previous_partition_count": len(prev_parts),
        "affected_sample": [list(k) for k in sorted(affected)[:20]],
        "source_completeness": sc,
        "publication_generation_id": ctx.publication_generation_id,
    }
    wjson(ctx.staging_root / "INCREMENTAL_PLAN.json", plan)
    if ctx.dry_run_plan_only:
        return {"plan": plan, "status": "PLAN_ONLY"}

    ctx.staging_root.mkdir(parents=True, exist_ok=True)
    wjson(
        ctx.staging_root / "CANDIDATE_STATUS.json",
        {"status": "STAGING", "release_id": ctx.release_id, "at": now_iso()},
    )
    ctx.aligned_root.mkdir(parents=True, exist_ok=True)

    antileak = {
        "INDEX_MINUTE_ANTILEAK_PASS": True,
        "INDEX_MINUTE_DICTIONARY_DATE_ALIGN_PASS": True,
        "INDEX_MINUTE_UNIVERSE_REGISTRY_ALIGN_PASS": True,
        "MARKET_STATE_SLICE_COMPLETED_BAR_PASS": False,
        "universe_n": len(required),
        "failures": [],
        "stats": {
            "partitions_seen": 0,
            "partitions_written": 0,
            "partitions_reused": 0,
            "rows_in": 0,
            "rows_out": 0,
            "rows_dropped_lookahead": 0,
            "rows_dropped_non_calendar": 0,
            "rows_dropped_inactive": 0,
            "rows_dropped_dup": 0,
        },
    }
    binding_paths: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
    lineage = []

    all_keys = sorted(set(prev_parts) | affected)
    total = max(1, len(all_keys))
    done = 0

    for key in all_keys:
        code, freq, year = key
        if code not in required_set:
            continue
        done += 1
        maybe_inject(ctx, "BUILD", done / total)
        dest_dir = ctx.aligned_root / code_to_safe(code) / freq
        dest = dest_dir / (
            f"index_minute_aligned__{code_to_safe(code)}__{freq}__{year}__asof_{ctx.new_cutoff.replace('-', '')}.parquet"
        )
        antileak["stats"]["partitions_seen"] += 1

        if key not in affected:
            src_prev = prev_parts.get(key)
            if src_prev is None:
                continue
            mode = hardlink_or_copy(src_prev, dest)
            sz = src_prev.stat().st_size
            ctx.metrics.reused_logical_bytes += sz
            ctx.metrics.unchanged_partition_count += 1
            if mode == "HARDLINK":
                ctx.metrics.hardlink_count += 1
            else:
                ctx.metrics.copy_fallback_count += 1
                ctx.metrics.full_history_copy_bytes += sz
                ctx.metrics.untouched_partition_rewrite_count += 1
                ctx.metrics.new_physical_bytes += sz
            antileak["stats"]["partitions_reused"] += 1
            binding_paths[code][freq].append(str(dest))
            lineage.append({"key": list(key), "action": "REUSE_" + mode, "src": str(src_prev)})
            continue

        # affected: merge previous aligned year + delta from raw for increment dates
        base = pd.read_parquet(prev_parts[key]) if key in prev_parts else pd.DataFrame(columns=SCHEMA_COLS)
        raw_src = raw_parts.get(key)
        delta = pd.DataFrame(columns=SCHEMA_COLS)
        st_delta = {}
        if raw_src is not None and dates:
            rdf = pd.read_parquet(raw_src)
            if "time" not in rdf.columns:
                rdf = rdf.reset_index().rename(columns={"index": "time"})
            rdf["time"] = pd.to_datetime(rdf["time"])
            rdf["_td"] = rdf["time"].dt.strftime("%Y-%m-%d")
            rdf = rdf[rdf["_td"].isin(set(dates))].drop(columns=["_td"])
            delta, st_delta = align_raw_frame(
                rdf,
                code=code,
                freq=freq,
                cutoff=cutoff,
                cal_days=cal_days,
                active=active,
                cal_path_name=cal_path.name,
                raw_source_path=str(raw_src),
            )
            for k in (
                "rows_in",
                "rows_out",
                "rows_dropped_lookahead",
                "rows_dropped_non_calendar",
                "rows_dropped_inactive",
                "rows_dropped_dup",
            ):
                antileak["stats"][k] += int(st_delta.get(k, 0))
            if st_delta.get("lookahead_fail"):
                antileak["INDEX_MINUTE_ANTILEAK_PASS"] = False
                antileak["failures"].append({"marker": "LOOKAHEAD", "code": code, "freq": freq, "year": year})
            if st_delta.get("fq_fail"):
                antileak["INDEX_MINUTE_ANTILEAK_PASS"] = False
                antileak["failures"].append({"marker": "FQ", "code": code, "freq": freq, "year": year})

        # also drop any base rows beyond new cutoff (should be none if prev cutoff < new)
        if not base.empty:
            base = base.copy()
            base["time"] = pd.to_datetime(base["time"])
            base = base[base["time"] <= cutoff]
            # refresh metadata cutoff
            base["cutoff_ts"] = str(cutoff)

        out = merge_aligned(base, delta)
        if out.empty and key not in prev_parts:
            continue
        # duplicate pk check
        if not out.empty and out.duplicated(subset=["time"]).any():
            antileak["failures"].append({"marker": "DUP_KEY", "code": code, "freq": freq, "year": year})
            antileak["INDEX_MINUTE_ANTILEAK_PASS"] = False
        dest.parent.mkdir(parents=True, exist_ok=True)
        out.to_parquet(dest, index=False)
        new_sz = dest.stat().st_size
        ctx.metrics.new_physical_bytes += new_sz
        antileak["stats"]["partitions_written"] += 1
        antileak["stats"]["rows_out"] += len(out)
        binding_paths[code][freq].append(str(dest))
        lineage.append(
            {
                "key": list(key),
                "action": "MERGE_REBUILD",
                "prev": str(prev_parts.get(key)) if key in prev_parts else None,
                "raw": str(raw_src) if raw_src else None,
                "rows": len(out),
                "delta_stats": st_delta,
            }
        )

    maybe_inject(ctx, "QA", 1.0)
    # Market state probe
    probe_code = "000300.XSHG" if "000300.XSHG" in required_set else (required[0] if required else None)
    ms_ok = False
    ms_detail = {}
    if probe_code:
        files_1m = binding_paths.get(probe_code, {}).get("1m", [])
        frames = [pd.read_parquet(f) for f in files_1m if ctx.new_cutoff[:4] in f or True]
        # prefer year files containing cutoff year
        frames = [pd.read_parquet(f) for f in files_1m if f"__{ctx.new_cutoff[:4]}__" in Path(f).name]
        if not frames and files_1m:
            frames = [pd.read_parquet(files_1m[-1])]
        if frames:
            g = pd.concat(frames, ignore_index=True)
            g["bar_end_ts"] = pd.to_datetime(g["bar_end_ts"])
            probe_cutoff = pd.Timestamp(f"{ctx.new_cutoff} 13:10:00")
            sub = g[g["bar_end_ts"] <= probe_cutoff]
            if len(sub):
                last = sub.sort_values("bar_end_ts").iloc[-1]
                ms_ok = pd.Timestamp(last["bar_end_ts"]) <= probe_cutoff
                ms_detail = {
                    "probe_code": probe_code,
                    "signal_cutoff_ts": str(probe_cutoff),
                    "last_completed_bar_end_ts": str(last["bar_end_ts"]),
                    "index_close": float(last["close"]),
                }
    antileak["MARKET_STATE_SLICE_COMPLETED_BAR_PASS"] = bool(ms_ok) if probe_code else True
    antileak["INDEX_MINUTE_DICTIONARY_DATE_ALIGN_PASS"] = (
        antileak["stats"]["partitions_written"] + antileak["stats"]["partitions_reused"]
    ) > 0

    if ctx.inject_fail and ctx.inject_fail.upper() == "QA_FAIL":
        antileak["INDEX_MINUTE_ANTILEAK_PASS"] = False
        antileak["failures"].append({"marker": "INJECTED_QA_FAIL"})

    all_pass = all(
        [
            antileak["INDEX_MINUTE_ANTILEAK_PASS"],
            antileak["INDEX_MINUTE_DICTIONARY_DATE_ALIGN_PASS"],
            antileak["INDEX_MINUTE_UNIVERSE_REGISTRY_ALIGN_PASS"],
            antileak["MARKET_STATE_SLICE_COMPLETED_BAR_PASS"],
        ]
    )
    if not all_pass:
        ctx.failure_phase = "QA"
        ctx.failure_reason = "ACCEPTANCE_FAIL"
        raise RuntimeError("QA_FAIL")

    maybe_inject(ctx, "MANIFEST", 1.0)
    if ctx.inject_fail and ctx.inject_fail.upper() == "MANIFEST_FAIL":
        raise RuntimeError("INJECTED_FAIL:MANIFEST_FAIL")

    binding = {
        "artifact_id": "INDEX_MARKET_STATE_MINUTE_BINDING_R1",
        "status": "MATERIALIZED",
        "generated_at": now_iso(),
        "domain_id": "INDEX_MINUTE_ALIGNED_R1",
        "aligned_release_id": ctx.release_id,
        "aligned_root": str(ctx.aligned_root),
        "calendar_asof": str(cal_path),
        "cutoff_ts": str(cutoff),
        "publication_generation_id": ctx.publication_generation_id,
        "successor_mode": "INCREMENTAL_MODEL_A",
        "paths_by_code_freq": binding_paths,
        "completed_bar_probe": ms_detail,
        "acceptance": {k: antileak[k] for k in antileak if k.endswith("_PASS")},
    }
    wjson(ctx.staging_root / "INDEX_MARKET_STATE_MINUTE_BINDING_R1.json", binding)
    wjson(ctx.staging_root / "PARTITION_LINEAGE.json", lineage)
    wjson(ctx.staging_root / "ACCEPTANCE.json", antileak)

    maybe_inject(ctx, "SEAL", 1.0)
    ctx.metrics.finalize()
    seal = {
        "seal_id": f"BLACKBOX_INDEX_MINUTE_ALIGN_SEAL_R1_{now_stamp()}",
        "release_id": ctx.release_id,
        "generated_at": now_iso(),
        "cutoff": ctx.new_cutoff,
        "calendar_asof": str(cal_path),
        "all_pass": True,
        "acceptance": antileak,
        "aligned_root": str(ctx.aligned_root),
        "partitions_written": antileak["stats"]["partitions_written"],
        "partitions_reused": antileak["stats"]["partitions_reused"],
        "publication_generation_id": ctx.publication_generation_id,
        "successor_mode": "INCREMENTAL_MODEL_A",
        "storage_metrics": asdict(ctx.metrics),
        "previous_release_id": ctx.previous_release_id,
    }
    wjson(ctx.staging_root / "SEAL.json", seal)

    sgate = storage_non_regression_gate(
        ctx.metrics,
        incremental_days=len(dates),
        previous_current=ctx.previous_release_id,
        new_current=None,
    )
    wjson(ctx.staging_root / "STORAGE_NON_REGRESSION_GATE.json", sgate)
    if sgate["status"] != "PASS" and not ctx.inject_fail:
        ctx.failure_phase = "STORAGE_GATE"
        ctx.failure_reason = json.dumps(sgate["failures"])
        raise RuntimeError("STORAGE_NON_REGRESSION_FAIL")

    # promote staging dir name: already under releases/{id}.STAGING → rename to {id}
    formal = RELEASES / ctx.release_id
    maybe_inject(ctx, "CUTOVER", 1.0)
    if ctx.no_cutover:
        wjson(
            ctx.staging_root / "CANDIDATE_STATUS.json",
            {"status": "CANDIDATE_READY_NO_CUTOVER", "release_id": ctx.release_id, "at": now_iso()},
        )
        return {
            "all_pass": True,
            "release_id": ctx.release_id,
            "staging_root": str(ctx.staging_root),
            "cutover": False,
            "seal": seal,
            "storage_gate": sgate,
            "plan": plan,
            "metrics": asdict(ctx.metrics),
        }

    if ctx.staging_root.resolve() != formal.resolve():
        if formal.exists():
            raise RuntimeError(f"formal release already exists: {formal}")
        # Windows: rename of large hardlink trees can transiently hit WinError 5
        # if any handle is still open. Retry with backoff before aborting.
        last_err: Exception | None = None
        for attempt in range(1, 9):
            try:
                ctx.staging_root.rename(formal)
                last_err = None
                break
            except PermissionError as e:
                last_err = e
                time.sleep(min(30, 2 * attempt))
        if last_err is not None:
            raise last_err
        ctx.staging_root = formal
        ctx.aligned_root = formal / "standard" / "index_minute"

    pointer_obj = {
        "release_id": ctx.release_id,
        "release_root": str(formal),
        "seal_id": seal["seal_id"],
        "all_pass": True,
        "set_at": now_iso(),
        "publication_generation_id": ctx.publication_generation_id,
        "successor_mode": "INCREMENTAL_MODEL_A",
        "previous_release_id": ctx.previous_release_id,
    }
    # atomic-ish: write temp then replace
    tmp = POINTER.with_suffix(".json.tmp")
    wjson(tmp, pointer_obj)
    tmp.replace(POINTER)
    sgate["new_current"] = ctx.release_id
    wjson(formal / "STORAGE_NON_REGRESSION_GATE.json", sgate)
    STORAGE_LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    wjson(STORAGE_LEDGER_DIR / f"{ctx.release_id}.json", {**sgate, "metrics": asdict(ctx.metrics)})

    if not ctx.no_hand_update:
        try:
            import p7_gate_common as gc

            dec = gc.load_hand_decision() or {}
            dec.update(
                {
                    "index_minute_align_clean_pass": True,
                    "index_minute_align_release_id": ctx.release_id,
                    "index_minute_align_seal_id": seal["seal_id"],
                    "index_minute_align_successor_mode": "INCREMENTAL_MODEL_A",
                    "generated_at": gc.now_iso(),
                }
            )
            gc.write_hand_decision(dec)
            gc.write_hand_md(dec)
        except Exception as e:
            # cutover pointer already set; record warning
            wjson(formal / "HAND_UPDATE_WARNING.json", {"error": str(e)})

    wjson(formal / "CANDIDATE_STATUS.json", {"status": "FORMAL", "at": now_iso()})
    return {
        "all_pass": True,
        "release_id": ctx.release_id,
        "cutover": True,
        "seal": seal,
        "storage_gate": sgate,
        "plan": plan,
        "metrics": asdict(ctx.metrics),
        "CURRENT_ALIGN_AFTER": ctx.release_id,
    }


def run_guarded(ctx: BuildContext) -> dict:
    try:
        return build_incremental(ctx)
    except Exception as e:
        ctx.status = "ABORTED_STAGING"
        if not ctx.failure_phase:
            ctx.failure_phase = "BUILD"
        if not ctx.failure_reason:
            ctx.failure_reason = f"{type(e).__name__}:{e}"
        orphan = register_orphan(ctx)
        return {
            "all_pass": False,
            "CURRENT_UNCHANGED": True,
            "FORMAL_RELEASE_POLLUTION": False,
            "ABORTED_STAGING_IDENTIFIED": True,
            "ORPHAN_REGISTERED": True,
            "orphan": orphan,
            "error": ctx.failure_reason,
            "traceback": traceback.format_exc()[-4000:],
        }


def resolve_universe(mode: str) -> list[str]:
    if mode == "required_1m":
        reg = json.loads(REG.read_text(encoding="utf-8"))
        return list(reg["required_1m_codes"])
    if mode == "from_previous":
        return []  # filled by caller from previous partitions
    # jq_all_732 from previous CURRENT codes
    return []


def main(argv: list[str] | None = None) -> int:
    global RELEASES, ORPHAN_REGISTRY, POINTER, STORAGE_LEDGER_DIR
    ap = argparse.ArgumentParser(description="INDEX MINUTE incremental ALIGN engine R1")
    ap.add_argument("--previous-root", type=str, default="")
    ap.add_argument("--new-cutoff", type=str, required=True)
    ap.add_argument("--increment-dates", type=str, default="", help="comma YYYY-MM-DD")
    ap.add_argument("--universe", choices=["required_1m", "from_previous", "explicit"], default="from_previous")
    ap.add_argument("--codes", type=str, default="", help="comma codes for explicit/fixture")
    ap.add_argument("--raw-root", type=str, default=str(P3))
    ap.add_argument("--releases-root", type=str, default=str(RELEASES))
    ap.add_argument("--no-cutover", action="store_true")
    ap.add_argument("--no-hand-update", action="store_true")
    ap.add_argument("--plan-only", action="store_true")
    ap.add_argument("--inject-fail", type=str, default="")
    ap.add_argument("--task-id", type=str, default="BLACKBOX_INDEX_MINUTE_INCREMENTAL_ALIGN_ARCHITECTURE_FIX_R1")
    ap.add_argument("--skip-source-gate", action="store_true", help="fixtures only")
    ap.add_argument("--extra-trade-dates", type=str, default="", help="comma dates force into calendar set")
    ap.add_argument("--pointer-path", type=str, default="", help="override CURRENT pointer path (fixtures)")
    ap.add_argument("--orphan-registry-path", type=str, default="", help="override orphan registry path")
    args = ap.parse_args(argv)

    RELEASES = Path(args.releases_root)
    if args.pointer_path:
        POINTER = Path(args.pointer_path)
    if args.orphan_registry_path:
        ORPHAN_REGISTRY = Path(args.orphan_registry_path)

    if args.previous_root:
        prev_root = Path(args.previous_root)
        prev_id = prev_root.name
    else:
        cur = load_current_pointer()
        prev_id = cur["release_id"]
        prev_root = Path(cur["release_root"])
    prev_aligned = prev_root / "standard" / "index_minute"
    prev_cutoff = read_previous_cutoff(prev_root)
    new_cutoff = args.new_cutoff
    if new_cutoff < prev_cutoff:
        raise SystemExit("new_cutoff < previous_cutoff")

    if args.universe == "required_1m":
        codes = resolve_universe("required_1m")
    elif args.codes:
        codes = [c.strip() for c in args.codes.split(",") if c.strip()]
    else:
        parts = list_aligned_partitions(prev_aligned)
        codes = sorted({c for c, _, _ in parts})

    stamp = now_stamp()
    release_id = f"BLACKBOX_INDEX_MINUTE_ALIGN_R1_ASOF_{new_cutoff.replace('-', '')}_{stamp}"
    staging = RELEASES / f"{release_id}.STAGING"
    gen = f"ALIGN_INCR_{stamp}"
    dates = [d.strip() for d in args.increment_dates.split(",") if d.strip()]

    ctx = BuildContext(
        task_id=args.task_id,
        mode="incremental",
        previous_release_id=prev_id,
        previous_root=prev_root,
        previous_aligned=prev_aligned,
        previous_cutoff=prev_cutoff,
        new_cutoff=new_cutoff,
        release_id=release_id,
        staging_root=staging,
        aligned_root=staging / "standard" / "index_minute",
        universe_codes=codes,
        publication_generation_id=gen,
        inject_fail=args.inject_fail or None,
        raw_root=Path(args.raw_root),
        no_cutover=args.no_cutover,
        no_hand_update=args.no_hand_update,
        dry_run_plan_only=args.plan_only,
        increment_dates=dates,
        skip_source_completeness=bool(args.skip_source_gate),
        extra_trade_dates=[d.strip() for d in args.extra_trade_dates.split(",") if d.strip()],
    )

    result = run_guarded(ctx)
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    return 0 if result.get("all_pass") else 2


if __name__ == "__main__":
    raise SystemExit(main())
