#!/usr/bin/env python3
"""
JQ_P7_5M_MATRIX_LAUNCHER — HAND-gated 3-pool 5m download + quality gate.
Requires 运行/HAND_DECISION.json with hand_release_allowed=true.
"""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).resolve().parent))
from p7_runtime_guard import enforce_venv_only_or_exit

DRY_RUN = "--dry-run" in sys.argv
enforce_venv_only_or_exit()
if DRY_RUN:
    print("VENV_ONLY_GUARD: PASS dry-run launcher")
    raise SystemExit(0)

import json, time, subprocess, hashlib
from datetime import datetime, timezone

import p7_gate_common as gc

SCRIPT_SELF = Path(__file__).resolve()
NOW_TS = gc.now_ts()
NOW_ISO = gc.now_iso()
TASK = "JQ_P7_5M_MATRIX_DOWNLOAD_R1"
MATRIX = gc.MATRIX_5M
PYTHON = "E:/BLACKBOX/.venv/Scripts/python.exe"
WORKER = str(gc.SCRIPT_5M_WORKER)

for s in ["logs", "reports", "manifest", "quality_gate"]:
    (MATRIX / s).mkdir(parents=True, exist_ok=True)

print("=" * 60)
print(f"{TASK} — 5M MATRIX LAUNCHER (HAND-GATED)")
print("=" * 60)

# ── HAND gate (mandatory) ──
hand = gc.enforce_hand_gate(script_path=SCRIPT_SELF, required_stage="5m")
mon = gc.ensure_hand_download_monitor(trigger=TASK, stage="5m")
print(f"HAND monitor: spawned={mon.get('spawned')} reason={mon.get('reason','ok')} pid={mon.get('pid','')}")
gc.clear_global_stop()
POOLS = gc.active_worker_pools(hand)
aw = hand.get("active_workers", len(POOLS))
ceiling = hand.get("max_worker_ceiling", gc.MAX_WORKER_CEILING)
print(f"HAND level: {hand.get('hand_release_level')} | active_workers={aw}/{ceiling} | mode={hand.get('concurrency_mode')}")
print(f"launcher_auto_stage_switch: {hand.get('launcher_auto_stage_switch', False)} (must be false)")

# ── Auth + quota ──
import jq_download_base as jdb
jdb.auth()
ql = jdb.quota_left(force=True) or 0
print(f"\nQuota: {gc.quota_fmt(ql)}")

# ── Quality gate (always) ──
print("\n" + "=" * 60)
print("5M QUALITY GATE")
print("=" * 60)
gate = gc.scan_5m_quality_gate()
gate["generated_by"] = TASK
GATE_FILE = gc.write_5m_quality_gate(gate)
for r in gate["year_details"]:
    # p7_gate_common returns a compact year_detail dict:
    # {year, batches_on_disk, expected_batches, complete, gap}
    flag = "OK" if r.get("complete") else f"MISS{r.get('gap')}"
    print(
        f"  {r.get('year')}: {r.get('batches_on_disk')}/{r.get('expected_batches')}  {flag}"
    )
qg_pass = gate["quality_gate_pass"]
print(f"\nALL_YEARS_COMPLETE: {qg_pass}")
print(f"Gate: {GATE_FILE}")

if qg_pass:
    print("\n*** 5M QUALITY GATE PASS — return to HAND for 1m approval ***")
    rmd = f"# {TASK}\n时间: {NOW_ISO} | final_status: ALL_COMPLETE\nquality_gate_pass: True\nreturned_to_HAND_for_review: true\n"
    RP = MATRIX / f"reports/5M_MATRIX_REPORT_{NOW_TS}.md"
    RP.write_text(rmd, encoding="utf-8")
    man = {"task": TASK, "final_status": "ALL_COMPLETE", "quality_gate_pass": True,
           "1m_allowed": False, "returned_to_HAND_for_review": True, "generated_at": NOW_ISO}
    mt = json.dumps(man, ensure_ascii=False, indent=2)
    man["sha256"] = hashlib.sha256(mt.encode()).hexdigest()
    (MATRIX / f"manifest/5M_MATRIX_MANIFEST_{NOW_TS}.json").write_text(mt, encoding="utf-8")
    print("Re-run: p7_hand_stage_controller.py for 1m release decision")
    sys.exit(0)

if ql <= 0:
    print("\nQuality gate FAIL + quota=0. Dry checkpoints.")
    for p in POOLS:
        cp = {"pool": p, "quota": 0, "stop": "quota_left_zero", "self_continue": True, "generated_at": NOW_ISO}
        (MATRIX / p / "checkpoint").mkdir(parents=True, exist_ok=True)
        (MATRIX / p / f"checkpoint/worker_{p}_ckpt_{NOW_TS}.json").write_text(json.dumps(cp, ensure_ascii=False, indent=2), encoding="utf-8")
    sys.exit(0)

# ── Launch workers (HAND active_workers, ceiling=3) ──
print(f"\nQuality gate FAIL + quota>0. Launching {len(POOLS)} worker(s)...")
procs = {}
for pool in POOLS:
    lp = MATRIX / "logs" / f"worker_{pool}_{NOW_TS}.log"
    lf = open(str(lp), "w", encoding="utf-8")
    procs[pool] = {"proc": subprocess.Popen([PYTHON, "-u", WORKER, pool], stdout=lf, stderr=subprocess.STDOUT), "log": lf}
    print(f"  {pool}: PID={procs[pool]['proc'].pid}")

try:
    while procs:
        for pool in list(procs):
            if procs[pool]["proc"].poll() is not None:
                procs[pool]["log"].close()
                print(f"\n[{pool}] DONE")
                del procs[pool]
        if procs:
            time.sleep(5)
except KeyboardInterrupt:
    for i in procs.values():
        try: i["proc"].terminate(); i["log"].close()
        except: pass
    sys.exit(1)

# ── Collect + post-gate ──
tc = tf = tp = tq = 0
all_ok = True
for pool in POOLS:
    cks = sorted((MATRIX / pool / "checkpoint").glob("*.json"))
    if cks:
        ck = json.loads(cks[-1].read_text(encoding="utf-8"))
        tc += ck.get("done", 0); tf += ck.get("fail", 0); tp += ck.get("pq", 0); tq += ck.get("quota", 0)
        if not ck.get("pool_complete"): all_ok = False
        print(f"  {pool}: done={ck.get('done')} pq={ck.get('pq')} complete={ck.get('pool_complete')}")
    else:
        all_ok = False

print("\nPOST-DOWNLOAD QUALITY GATE")
gate2 = gc.scan_5m_quality_gate()
gate2["generated_by"] = TASK
gc.write_5m_quality_gate(gate2)
qg2 = gate2["quality_gate_pass"]
fs = "ALL_COMPLETE" if (all_ok and qg2) else "PARTIAL_QUALITY_GATE_FAIL"

man = {"task": TASK, "final_status": fs, "done": tc, "fail": tf, "pq": tp,
       "quota_used": tq, "quality_gate_pass": qg2, "1m_allowed": False,
       "returned_to_HAND_for_review": True, "executor": gc.ALLOWED_EXECUTOR,
       "generated_at": NOW_ISO}
mt = json.dumps(man, ensure_ascii=False, indent=2)
man["sha256"] = hashlib.sha256(mt.encode()).hexdigest()
(MATRIX / f"manifest/5M_MATRIX_MANIFEST_{NOW_TS}.json").write_text(mt, encoding="utf-8")

print(f"\nDONE: {fs} | returned_to_HAND_for_review: true")
print("Re-run: p7_hand_stage_controller.py")
sys.exit(0 if qg2 else 1)
