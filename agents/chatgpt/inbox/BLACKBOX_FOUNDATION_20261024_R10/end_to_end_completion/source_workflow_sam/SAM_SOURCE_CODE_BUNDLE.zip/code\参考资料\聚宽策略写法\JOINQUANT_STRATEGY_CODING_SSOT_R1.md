# 聚宽策略写法 SSOT（回测 / 模拟盘 / 热启动）

> **标记：`JOINQUANT_STRATEGY_CODING_MANDATORY` — 聚宽策略写法必读取**  
> HAND 规则：`规则库/hand_hard_rules/BLACKBOX_HAND_JOINQUANT_STRATEGY_CODING_R1.json`  
> Cursor alwaysApply：`.cursor/rules/blackbox_joinquant_strategy_coding_mandatory.mdc`  
> 官方主源：[JoinQuantAPI.pdf](https://cdn.joinquant.com/help/img/JoinQuantAPI.pdf)

本文件整理官方生命周期与 BLACKBOX 强制约束。写任何聚宽粘贴策略前必须读完，并打开日频范本代码看一眼。

**日频范本（USER 指定）**

- 代码：`参考资料/聚宽策略写法/聚宽范本_日频模拟盘_V4_R21_HOTSTART_R5.py`
- 纪律：`参考资料/聚宽策略写法/聚宽范本_日频必读.md`
- HAND：`BLACKBOX_HAND_JOINQUANT_DAILY_FANBEN_R1`

日频：信号只用 `previous_date`；禁止采集盘中参数做历史排名。桥接密钥留在范本 `.py`，替换时不要删。

---

## 0. 三环境

| 环境 | 用途 | 关键注意 |
|---|---|---|
| 研究 | 探数据、画图、`!pip list` | 部分♠ API 不可用；可有不同 Python 内核 |
| 回测 | 历史事件驱动 | 有 `initialize` 一次；也会跑 `process_initialize` +（通常）一次 `after_code_changed` |
| 模拟盘 | 日切休眠/重启 + pickle `g` | **热启动核心**；`initialize` 生命周期只一次 |

---

## 1. 生命周期（官方顺序）

### 1.1 用户可实现函数

| 函数 | 必选 | 时机 |
|---|---|---|
| `initialize(context)` | 是 | 回测开始 / 模拟盘**首次**创建时各一次 |
| `process_initialize(context)` | 强烈建议 | 每次进程启动；模拟盘**每天**；在 `initialize` 之后 |
| `after_code_changed(context)` | 模拟盘必会用到 | 代码变更后恢复时；官方：在 `process_initialize` **之后**也会在回测执行一次 |
| `before_trading_start` / `handle_data` / `after_trading_end` | 可选 | 日频钩子（或用 `run_daily`） |
| `on_strategy_end` | 可选 | 正常结束时 |

### 1.2 模拟盘日切恢复（官方摘要）

1. 加载策略代码（模块级代码会再执行一遍）  
2. pickle 恢复 `g` / `context` / 可序列化全局  
3. 执行 `process_initialize`  
4. 若代码相对上次有修改且定义了 `after_code_changed` → 执行之  

**重启后不再执行 `initialize`。**

### 1.3 `g` 持久化规则（模拟盘）

- 可 pickle 的 `g.xxx` → 会保存（状态上限约 30MB；超 20MB 警告）  
- `g.__xxx`（双下划线）→ **不保存**；必须在 `process_initialize` 重建  
- `query(...)`、文件句柄、DB/网络连接、部分自定义对象 → 不可 pickle → 放 `g.__*` + `process_initialize`  
- 模块级全局变量也会被尝试恢复；改代码后要用 `after_code_changed` + `global` 刷新  

### 1.4 热启动 / 替换代码模板

```python
# -*- coding: utf-8 -*-
from jqdata import *
import numpy as np
import pandas as pd

# 模块级常量：每天加载代码会执行，但模拟盘恢复后「旧 g」仍覆盖业务状态
SCHEME_ID = 'EXAMPLE_R1'
G_STOCK_NUM = 1

def initialize(context):
    set_benchmark('000300.XSHG')
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_slippage(FixedSlippage(0.0))
    set_order_cost(OrderCost(
        open_tax=0, close_tax=0.001,
        open_commission=0.0003, close_commission=0.0003,
        close_today_commission=0, min_commission=5
    ), type='stock')
    # 只放「可持久化」状态
    g.stock_num = G_STOCK_NUM
    g.target = []
    g.rank_list = []
    g.day_count = 0
    # 定时任务只在 initialize 注册一次；改时间见 after_code_changed
    run_daily(before_market_open, time='before_open', reference_security='000300.XSHG')
    run_daily(market_open_trade, time='open', reference_security='000300.XSHG')
    run_daily(after_market_close, time='after_close', reference_security='000300.XSHG')


def process_initialize(context):
    # 每次进程启动：重建不可/不宜 pickle 的对象
    # 例：query、adapter、大缓存句柄
    g.__q = query(valuation)
    # 若业务对象不宜持久化，也在这里重建（可用普通名，但勿依赖昨天残留）
    g.adapter = build_adapter()  # 用户函数；勿把 jq 连接塞进会 pickle 失败的结构


def after_code_changed(context):
    # 模拟盘「替换代码」后 initialize 不重跑 —— 在这里刷新参数/定时器
    g.stock_num = G_STOCK_NUM
    # 若改了 run_daily 时间：
    # unschedule_all()
    # run_daily(before_market_open, time='before_open', reference_security='000300.XSHG')
    # ...
    g.adapter = build_adapter()
    log.info('[AFTER_CODE_CHANGED] %s' % SCHEME_ID)


def before_market_open(context):
    pass


def market_open_trade(context):
    pass


def after_market_close(context):
    pass


def build_adapter():
    return object()
```

---

## 2. 回测写法 vs 模拟盘写法

| 主题 | 回测 | 模拟盘 |
|---|---|---|
| `initialize` | 整段回测开始一次 | 创建模拟盘时一次，之后日切不跑 |
| `process_initialize` | 建议写（兼容）；通常启动时一次 | **每天必跑** — 重建 `query`/adapter |
| `after_code_changed` | 官方也会执行一次 | 替换代码 / 检测到代码变化时刷新 `g` |
| 状态 | 一般不依赖日切 pickle | 依赖 `g` pickle；控制体积 |
| 数据时间 | `context.current_dt` / `previous_date` 历史推进 | 实时日历；盘中创建可能跳过已过时刻 |
| `get_current_data` | 可用 | 更贴近盘口/停牌/涨跌停 |
| 真实价格 | 强烈建议 `set_option('use_real_price', True)` | 同左（官方强烈建议） |
| 未来函数 | `avoid_future_data=True` | 同左 |

**正确做法：一份代码同时满足回测与模拟盘** —— 可持久化状态放 `initialize`；不可 pickle 放 `process_initialize`；参数热更新放 `after_code_changed`。

---

## 3. BLACKBOX / 聚宽粘贴硬禁（事故沉淀）

触发 A：`ModuleNotFoundError: dataclasses`（2026-08-09）。  
触发 B：`ImportError: cannot import name 'get_all_securities'` + `g.adapter cannot serialized ... ContextFilter`（2026-08-09）。  
触发 C：`AttributeError: 'Series' object has no attribute 'to_numpy'`（2026-08-09）。

**证据（用户回测日志，非臆测）**：栈路径为  
`/opt/conda/lib/python3.6/site-packages/pandas/core/generic.py` → 回测引擎为 **Python 3.6 + 无 `Series.to_numpy` 的旧 pandas**（`to_numpy` 自 pandas 0.24 起）。  
说明：本机代理访问 `www.joinquant.com` 帮助页可能被地域拦截；**以回测进程 traceback 与官方 PDF（cdn）为准，不得编造库版本表**。社区旁证：回测/部分执行环境长期为 Py3.6。

| 禁止 | 原因 | 替代 |
|---|---|---|
| `from dataclasses import ...` / `@dataclass` | 引擎报找不到库 | 普通 `class` + `__init__` |
| `from __future__ import annotations` | 旧内核可能无 | 不用 |
| **`Series.to_numpy()` / `DataFrame.to_numpy()`** | 旧 pandas 无此方法（已实测） | `series.values` / `series.values.astype(float)` / `np.asarray(...)` |
| **`from jqdata import get_all_securities`（及同类 from-import 子名）** | 回测沙箱里 `jqdata` **模块常不导出**这些名字；API 已由顶栏 `from jqdata import *` 注入**策略 globals** | 直接调用全局 `get_all_securities(...)`，或用 `_jq_api('get_all_securities')` 从 `globals()` 取 |
| `from jqdata import get_price / get_trade_days / get_fundamentals / get_industry / query` | 同上 | 同上 |
| 把 `log` 挂到 `g.adapter` / 可 pickle 的 `g.xxx` | `log` 含 `ContextFilter`，日切序列化警告/失败 | **不存 log**；需要时用全局 `log.info`；adapter 放 `g.__adapter` |
| 依赖 Py≥3.7+ 独有语法 | 内核版本不确定 | 保持 3.6 友好写法 |
| `from jqdata import *` 后用内置 `sum`/`min`/`max` | 可能被遮蔽 | `np.sum` 等 |
| 在 `initialize` 持久化 `query` / adapter | 次日丢失或 pickle 失败 | `process_initialize` + `g.__*` |
| 改 `initialize` 指望模拟盘热更新 | `initialize` 不重跑 | `after_code_changed` |
| 未声明复权/空排名却宣称对齐 | BLACKBOX 回测硬门 | PREFLIGHT |
| 发明 volume 代理换手 / 伪造 ROE PIT | 掩盖 DATA_NOT_EQUIVALENT | 标 NOT_EQ，禁止凑合 |

### 3.1 正确 API 取用（回测/模拟）

```python
from jqdata import *   # 顶栏一次即可

def demo(context):
    # ✅ 正确：用全局 API
    secs = get_all_securities(types=['stock'], date=context.previous_date)
    # ❌ 错误：再从 jqdata 模块 from-import 子名
    # from jqdata import get_all_securities
```

本地 `jqdatasdk` 脚本可用 `import jqdatasdk as jq; jq.get_all_securities(...)`，**不要**把本地写法原样粘进回测。

### 3.2 数组转换（回测 Py3.6 / 旧 pandas）

```python
import numpy as np

# ✅ 兼容聚宽回测
arr = close_series.values.astype(float)
arr2 = np.asarray(df['close'].values, dtype=float)

# ❌ 本地新 pandas 习惯，回测会炸
# arr = close_series.to_numpy(dtype=float)
```

粘贴组装器会对 AST 抽出的 CANONICAL 代码做 `.to_numpy(...)` → `.values` 降级。

允许且推荐：

- `from jqdata import *`（策略惯例）+ `numpy` / `pandas`  
- `typing`（若环境有；仍避免 dataclasses）  
- `run_daily(..., time='before_open'|'open'|'after_close')`  
- `set_option('use_real_price', True)` + `avoid_future_data`  
- 涨跌停持仓：`HOLD_LIMIT` 单票锁定，勿残留现金误买第二只  

---

## 4. 常用 API 速查（策略侧）

```text
set_benchmark / set_option / set_slippage / set_order_cost
run_daily / run_weekly / run_monthly / unschedule_all
get_price / attribute_history / get_current_data
get_fundamentals(query(...), date=...)
get_all_securities / get_trade_days / get_industry
order / order_target / order_value / order_target_value
log.info / warn / error
context.previous_date / context.current_dt / context.portfolio
```

研究环境 ≠ 回测：带♠的下单/账户 API 不能在研究里当回测用。

---

## 5. BLACKBOX 粘贴包约定

- 组装器：`D:\CURSOR_TASK_ARCHIVE\R21_LOCAL_STRATEGY_REPRODUCTION_GATE_R1\jq_adapter\assemble_jq_paste.py`  
- 输出：`JQ_PASTE_CANONICAL_*_VIA_ADAPTER_R*.txt`（Downloads 同步）  
- DataPlane：**无 dataclasses**  
- Adapter：只供数；`DATA_NOT_EQUIVALENT` 不得掩盖  
- 壳：`process_initialize` 重建 `g.adapter`；`after_code_changed` 刷新 CFG/adapter  
- 选股公式来自研究 AST，禁止在壳里重写 `industry_org` / `tech_core` / `filters`  

---

## 6. AG 检查清单（提交聚宽代码前）

1. 是否 `import dataclasses`？→ 必须否  
2. 是否 `from __future__ import annotations`？→ 必须否  
3. 是否存在 `.to_numpy(`？→ 必须否（改 `.values` / `np.asarray`）  
4. 是否存在 `from jqdata import get_*` / `from jqdata import query`？→ 必须否（用全局 API）  
5. `sum(`/`min(`/`max(` 是否可能被 `jqdata *` 遮蔽？→ 改 `np.*`  
6. adapter / query 是否在 `process_initialize` 且优先 `g.__*`？是否误存 `log`？  
7. 模拟盘参数变更是否写在 `after_code_changed`？  
8. 改定时器是否 `unschedule_all` 再注册？  
9. `g` 是否塞了超大 DataFrame？（30MB）  
10. 宣称 JQ/live 对齐前是否过 BLACKBOX `BACKTEST_PREFLIGHT`？  
11. 价格是否声明 `price_adj_tag`（JQ 前复权 ≠ 本地 R31 bridge）？  
12. 是否打开日频范本 `.py` 对照：`signal_date=previous_date`、09:20 缓存 / 09:30 交易、空排名不卖、持股对齐第一名、桥接字段未删？  
13. 是否把盘中 `last_price` 写进历史 RANK/BIAS/共振？→ 必须否  
14. 模拟盘 09:25 是否把 `EMPTY` 误当作「无需重试」？（见 `聚宽代码写法经验_模拟盘热替换_R1.md`）  
15. `_current_hold` 是否只 return 第一只仓？多持仓必须拒绝自动换仓  
16. 桥接买入量是否读下单后 `positions.total_amount`？必须改订单对象/计划量，0 股实盘不发 HTTP  
17. `process_initialize` 是否错误地重新武装热替换或在恢复函数里下单？→ 必须否  

---

## 7. 与其它 HAND 规则关系

- 下载/清洗/HAND 放行：`blackbox_hand_project_gate.mdc`（本规则不放行下载）  
- 回测空排名/复权硬门：`BLACKBOX_HAND_TOP_LEVEL_BACKTEST_EXECUTION_R1`  
- 禁止 QMT/实盘下单：`blackbox_hard_boundary.mdc`  
- 本规则只约束**聚宽策略代码写法与生命周期**，不改 `HAND_DECISION.json`

---

## 8. 模拟盘执行层事故（2026-08-19）

对照标准写法：`E:\反杀策略只买最弱针对7-8月窗口.txt`。  
经验全文：`参考资料/聚宽策略写法/聚宽代码写法经验_模拟盘热替换_R1.md`。

| 事故 | 错误写法 | 后果 |
|---|---|---|
| 09:25 重试失效 | `status not in (READY, EMPTY)` 才重算 | 09:20 失败写成 EMPTY 后 09:25 不重试 |
| 热替换当天不选股 | `after_code_changed` 只清成 EMPTY | 落在 09:20–09:25 之间则当天不换仓 |
| 单持仓假设 | 第一只 amount>0 即 hold | 多仓时漏卖，账户漂移 |
| 桥接数量 | 下单后读持仓总量 | 可能 BUY 0 股或把旧仓总量当新单 |

标准：失败首轮 `FAILED`；09:25 对非「今日 READY」做 `final_attempt`；热替换立刻 `previous_date` 重算且只武装一次；真实账户持仓列表；订单 `amount`/`filled`/计划量；0 股实盘 HTTP 拦截。
