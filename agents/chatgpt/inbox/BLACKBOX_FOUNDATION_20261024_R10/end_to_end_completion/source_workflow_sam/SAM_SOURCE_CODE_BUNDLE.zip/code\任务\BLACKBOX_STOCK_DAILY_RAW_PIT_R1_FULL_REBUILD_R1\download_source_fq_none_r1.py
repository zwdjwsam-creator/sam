# -*- coding: utf-8 -*-
"""Download STOCK_DAILY RAW SOURCE with explicit fq='none'. Do not touch P2."""
from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_STOCK_DAILY_RAW_PIT_R1_FULL_REBUILD_R1")
STAGING = TASK / "staging" / "source_batches"
STATE = TASK / "staging" / "DOWNLOAD_STATE.json"
P0 = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P0_meta")
P2_LEGACY = Path(r"E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P2_stock_daily")
START = "2014-01-01"
END = "2026-08-14"
BATCH = 400
FQ = "none"
FIELDS = ["open", "high", "low", "close", "volume", "money"]
YEARS = list(range(2014, 2027))
JQ_API = "get_price(frequency='daily', fq='none')"

sys.path.insert(0, str(Path(r"E:\BLACKBOX\脚本")))
from jq_download_base import auth, quota_left  # noqa: E402


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print("[%s] %s" % (now_cn(), msg), flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def empty_frame() -> pd.DataFrame:
    return pd.DataFrame(columns=["date", "code"] + FIELDS)


def flatten_ohlc(df: pd.DataFrame, code: str | None = None) -> pd.DataFrame:
    if df is None or len(df) == 0:
        return empty_frame()
    x = df.copy()
    if isinstance(x.columns, pd.MultiIndex):
        lv0 = [str(v) for v in x.columns.get_level_values(0).unique()]
        lv1 = [str(v) for v in x.columns.get_level_values(1).unique()]
        if set(FIELDS).issubset(set(lv0)):
            x.columns = x.columns.set_names(["field", "code"])
            x = x.stack(level="code", future_stack=True)
            if isinstance(x, pd.Series):
                x = x.rename("value").reset_index()
            else:
                x = x.reset_index()
        elif set(FIELDS).issubset(set(lv1)):
            x.columns = x.columns.set_names(["code", "field"])
            x = x.stack(level="code", future_stack=True)
            if isinstance(x, pd.Series):
                x = x.rename("value").reset_index()
            else:
                x = x.reset_index()
        else:
            raise SystemExit("HARD_BLOCK: unexpected MultiIndex %s / %s" % (lv0[:8], lv1[:8]))
        if "time" in x.columns and "date" not in x.columns:
            x = x.rename(columns={"time": "date"})
        if "index" in x.columns and "date" not in x.columns:
            x = x.rename(columns={"index": "date"})
        if "level_0" in x.columns and "date" not in x.columns:
            x = x.rename(columns={"level_0": "date"})
    else:
        x = x.reset_index()
        if "time" in x.columns and "date" not in x.columns:
            x = x.rename(columns={"time": "date"})
        if "index" in x.columns and "date" not in x.columns:
            x = x.rename(columns={"index": "date"})
        if "security" in x.columns and "code" not in x.columns:
            x = x.rename(columns={"security": "code"})
        if "code" not in x.columns:
            if code:
                x["code"] = code
            else:
                raise SystemExit("HARD_BLOCK: no code column %s" % list(x.columns))
    if "date" not in x.columns:
        raise SystemExit("HARD_BLOCK: no date column %s" % list(x.columns))
    missing = [c for c in FIELDS if c not in x.columns]
    if missing:
        raise SystemExit("HARD_BLOCK: missing fields %s cols=%s" % (missing, list(x.columns)))
    x["date"] = pd.to_datetime(x["date"], errors="coerce").dt.normalize()
    x["code"] = x["code"].astype(str)
    for c in FIELDS:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    x = x.dropna(subset=["date", "code"])
    x = x.loc[x["date"] >= pd.Timestamp("1990-01-01")]
    return x[["date", "code"] + FIELDS].copy()


def load_universe() -> list[str]:
    codes: set[str] = set()
    for p in sorted(P0.glob("securities_stock__*.parquet")):
        df = pd.read_parquet(p)
        col = "code" if "code" in df.columns else df.columns[0]
        codes.update(df[col].dropna().astype(str).tolist())
    import jqdatasdk as jq

    live = jq.get_all_securities(types=["stock"], date=END)
    if live is not None and len(live):
        codes.update(live.index.astype(str).tolist())
    out = sorted(c for c in codes if c.endswith((".XSHE", ".XSHG")))
    if len(out) < 4000:
        raise SystemExit("HARD_BLOCK: universe too small n=%s" % len(out))
    return out


def year_end(year: int) -> str:
    if year == 2026:
        return END
    return "%s-12-31" % year


def canary(jq) -> dict:
    cases = [
        ("001230.XSHE", "2026-05-12", 28.70, 20.21),
        ("000001.XSHE", "2026-05-12", 11.25, 10.89),
    ]
    rows = []
    ok = True
    for code, d, expect_none, expect_pre in cases:
        raw = jq.get_price(
            security=code,
            start_date=d,
            end_date=d,
            frequency="daily",
            fields=FIELDS,
            fq=FQ,
        )
        pre = jq.get_price(
            security=code,
            start_date=d,
            end_date=d,
            frequency="daily",
            fields=["close"],
            fq="pre",
        )
        part = flatten_ohlc(raw, code=code)
        got = None if part.empty else float(part.iloc[-1]["close"])
        pre_px = None
        if pre is not None and len(pre):
            px = pre.reset_index() if "close" in getattr(pre, "columns", []) else pre
            if "close" in px.columns:
                pre_px = float(px.iloc[-1]["close"])
        match_raw = got is not None and abs(got - expect_none) < 0.015
        not_pre = got is not None and abs(got - expect_pre) >= 0.015
        rec = {
            "code": code,
            "date": d,
            "bb_raw_close": got,
            "expect_jq_none": expect_none,
            "jq_pre": pre_px,
            "expect_jq_pre": expect_pre,
            "MATCH_RAW": bool(match_raw and not_pre),
        }
        rows.append(rec)
        if not rec["MATCH_RAW"]:
            ok = False
    out = {"PASS": ok, "fq": FQ, "jq_api": JQ_API, "rows": rows}
    wjson(TASK / "CANARY_FQ_NONE.json", out)
    log("CANARY %s" % out)
    if not ok:
        raise SystemExit("HARD_BLOCK: canary fq=none failed")
    return out


def main() -> int:
    if P2_LEGACY.exists():
        log("LEGACY_KEEP %s (do not overwrite; not formal RAW)" % P2_LEGACY)
    STAGING.mkdir(parents=True, exist_ok=True)
    auth()
    import jqdatasdk as jq

    q = quota_left(force=True)
    log("quota_spare=%s FULL_HISTORY=%s..%s fq=%r api=%s" % (q, START, END, FQ, JQ_API))
    if q is not None and q < 20000:
        log("WARN: quota spare low; continue with resume")
    canary(jq)
    if "--canary-only" in sys.argv:
        return 0
    codes = load_universe()
    batches = [codes[i : i + BATCH] for i in range(0, len(codes), BATCH)]
    log("universe=%s batches=%s years=%s..%s" % (len(codes), len(batches), YEARS[0], YEARS[-1]))
    wjson(
        TASK / "staging" / "UNIVERSE.json",
        {
            "n": len(codes),
            "start": START,
            "end": END,
            "fq": FQ,
            "fq_explicit": True,
            "jq_api": JQ_API,
            "batch": BATCH,
            "fields": FIELDS,
            "codes_head": codes[:20],
        },
    )
    done = 0
    skip = 0
    fail = 0
    for year in YEARS:
        sd, ed = "%s-01-01" % year, year_end(year)
        for bi, batch in enumerate(batches):
            outp = STAGING / ("year=%s" % year) / ("batch_%03d.parquet" % bi)
            meta = outp.with_suffix(".sidecar.json")
            if outp.exists() and meta.exists():
                skip += 1
                continue
            t0 = time.time()
            try:
                raw = jq.get_price(
                    security=batch,
                    start_date=sd,
                    end_date=ed,
                    frequency="daily",
                    fields=FIELDS,
                    fq=FQ,
                )
            except Exception as e:
                fail += 1
                log("FAIL year=%s batch=%s err=%s:%s" % (year, bi, type(e).__name__, e))
                wjson(
                    STAGING / ("year=%s" % year) / ("batch_%03d.fail.json" % bi),
                    {"error": str(e), "fq": FQ, "jq_api": JQ_API},
                )
                time.sleep(2)
                continue
            part = flatten_ohlc(raw)
            outp.parent.mkdir(parents=True, exist_ok=True)
            part.to_parquet(outp, index=False)
            wjson(
                meta,
                {
                    "year": year,
                    "batch": bi,
                    "n_codes_requested": len(batch),
                    "rows": int(len(part)),
                    "n_codes": int(part["code"].nunique()) if len(part) else 0,
                    "date_min": None if part.empty else str(part["date"].min().date()),
                    "date_max": None if part.empty else str(part["date"].max().date()),
                    "fq": FQ,
                    "fq_explicit": True,
                    "jq_api": JQ_API,
                    "fields": FIELDS,
                    "elapsed_s": round(time.time() - t0, 2),
                },
            )
            done += 1
            if done % 3 == 0 or bi == 0:
                log(
                    "OK year=%s batch=%s/%s rows=%s done=%s skip=%s fail=%s"
                    % (year, bi, len(batches) - 1, len(part), done, skip, fail)
                )
    state = {
        "done_new": done,
        "skipped": skip,
        "failed": fail,
        "fq": FQ,
        "fq_explicit": True,
        "jq_api": JQ_API,
        "start": START,
        "end": END,
        "finished_at_cn": now_cn(),
        "quota_spare_end": quota_left(force=True),
    }
    wjson(STATE, state)
    log("DOWNLOAD_LOOP_END %s" % state)
    if fail:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
