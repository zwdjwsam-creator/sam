#!/usr/bin/env python3
# P7 HARD GUARD — inserted by JQ_P7_MINUTE_RELEASE_BLOCKER_REPAIR_R1
# Date: 2026-06-14T18:59:36+00:00
# This script is BLOCKED as a P7 minute download entry.
# Use: guard/jq_p7_minute_guarded_download_entry_r1.py ONLY
#
if __name__ != "__main__":
    raise SystemExit(0)
print("=" * 60)
print("BLOCKED: P7 MINUTE DIRECT ENTRY FORBIDDEN")
print("Use guarded entry: jq_p7_minute_guarded_download_entry_r1.py")
print("This old entrypoint has been blocked.")
print("=" * 60)
raise SystemExit(1)
# END P7 HARD GUARD

# P7 HARD GUARD — inserted by JQ_P7_MINUTE_RELEASE_BLOCKER_REPAIR_R1
# Date: 2026-06-14T18:59:14+00:00
# This script is BLOCKED as a P7 minute download entry.
# Use: guard/jq_p7_minute_guarded_download_entry_r1.py ONLY
#
if __name__ != "__main__":
    raise SystemExit(0)
print("=" * 60)
print("BLOCKED: P7 MINUTE DIRECT ENTRY FORBIDDEN")
print("Use guarded entry: jq_p7_minute_guarded_download_entry_r1.py")
print("This old entrypoint has been blocked.")
print("=" * 60)
raise SystemExit(1)
# END P7 HARD GUARD

"""
全量分钟线下载 V2 — 高效模式
策略：
  1. 不扫描已下载股票（慢），直接按 batch label 分段
  2. 每 5 批才检查一次额度
  3. 用已知的起始 batch label 避免浪费
"""
import sys, os, json, subprocess, tempfile, time
from pathlib import Path
from datetime import datetime
sys.stdout.reconfigure(encoding='utf-8')
sys.dont_write_bytecode = True

ROOT = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw")
CRED_FILE = Path("E:/BLACKBOX/配置/secrets/已验证/聚宽账号.txt")
META_DIR = ROOT / "P0_meta"
OUT_DIR = ROOT / "P7_stock_minute"
BATCH_PY = Path("E:/BLACKBOX/脚本/_download_batch.py")
SCHEMA_VER = "1.0.0"
TIMEOUT = 90
YEARS = list(range(2014, 2027))
FREQS = ["1m", "30m", "60m"]
BATCH_SIZES = {"1m": 20, "30m": 5, "60m": 5}

# 原始 batch 覆盖数（从已存在的文件推断）
START_BATCH = {"1m": 43, "30m": 40, "60m": 40}

# ─── 读取凭据 ───────────────────────────────────────────
def load_cred():
    lines = CRED_FILE.read_text(encoding="utf-8").strip().split("\n")
    u = p = None
    for line in lines:
        line = line.strip()
        if not line: continue
        sep = "：" if "：" in line else ":"
        k, v = line.split(sep, 1)
        k, v = k.strip(), v.strip()
        if "账号" in k or "user" in k.lower(): u = v
        if "密码" in k or "pass" in k.lower(): p = v
    return u, p

CRED_U, CRED_P = load_cred()

# ─── 额度检查（精简版，不频繁 auth）───────────────────────
_AUTHED = False
_QUOTA_SPARE = None
_QUOTA_CHECK_COUNT = 0

def quota_check(force=False):
    """每 5 批调一次 get_query_count，其余时间读取缓存"""
    global _AUTHED, _QUOTA_SPARE, _QUOTA_CHECK_COUNT
    if not _AUTHED:
        import jqdatasdk as jq
        jq.auth(CRED_U, CRED_P)
        _AUTHED = True
    _QUOTA_CHECK_COUNT += 1
    if force or _QUOTA_CHECK_COUNT % 5 == 0:
        import jqdatasdk as jq
        try:
            q = jq.get_query_count()
            _QUOTA_SPARE = q.get("spare", 0)
        except:
            pass
    return _QUOTA_SPARE

# ─── 加载全部 A 股 ──────────────────────────────────────
def load_all_stocks():
    import pandas as pd
    codes = []
    for sf in sorted(META_DIR.glob("securities_stock__*.parquet")):
        codes.extend(pd.read_parquet(sf)["code"].dropna().unique().tolist())
    stocks = sorted(set(c.strip() for c in codes if c and isinstance(c, str)))
    return [s for s in stocks if s.endswith(("XSHE", "XSHG"))]

# ─── 子进程下载 ─────────────────────────────────────────
def subproc_download(stocks, start_date, end_date, freq, out_path):
    tmp = Path(tempfile.gettempdir()) / f"_jq_min_{os.getpid()}_{int(time.time()*1000)}_{freq}.parquet"
    cmd = [
        sys.executable, "-u", str(BATCH_PY),
        json.dumps(stocks), start_date, end_date, freq,
        str(tmp), datetime.now().strftime("%Y%m%d_%H%M%S"), SCHEMA_VER,
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        proc.wait(timeout=TIMEOUT)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)
        tmp.unlink(missing_ok=True)
        return None
    if proc.returncode != 0:
        tmp.unlink(missing_ok=True)
        return None
    if tmp.exists() and tmp.stat().st_size > 200:
        import pandas as pd
        try:
            df = pd.read_parquet(tmp)
            if len(df) > 0:
                df.to_parquet(out_path, index=False)
            tmp.unlink(missing_ok=True)
            return df
        except:
            tmp.unlink(missing_ok=True)
            return None
    tmp.unlink(missing_ok=True)
    return None

# ─── 主流程 ─────────────────────────────────────────────
def main():
    print("="*60)
    print("全量分钟线下载 V2 — 扩展到全部 A 股")
    print(f"开始: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60)

    all_stocks = load_all_stocks()
    print(f"全部A股: {len(all_stocks)} 只")

    q0 = quota_check(force=True)
    print(f"初始额度: {q0:,}")
    if q0 is not None and q0 <= 0:
        print("额度已耗尽")
        return

    t_start = time.time()

    grand_total_files = 0
    grand_total_rows = 0
    all_skipped = []
    total_api_calls = 0

    for freq in FREQS:
        batch_size = BATCH_SIZES[freq]
        start_batch = START_BATCH[freq]
        n_batches = (len(all_stocks) + batch_size - 1) // batch_size  # 全部A股的批次总数
        pending_batches = list(range(start_batch, n_batches))
        if not pending_batches:
            print(f"\n[{freq}] 全部批已下载")
            continue

        print(f"\n--- 频率 {freq} (batch_size={batch_size}) ---")
        print(f"  起始batch={start_batch}, 待下载: {len(pending_batches)} 批")

        local_files = 0
        local_rows = 0

        for bi, batch_idx in enumerate(pending_batches):
            batch_label = f"batch{batch_idx:04d}"
            # 该批覆盖的股票
            s = batch_idx * batch_size
            e = min(s + batch_size, len(all_stocks))
            batch_stocks = all_stocks[s:e]

            # 先检查是否所有年份都已存在
            all_have = True
            for year in YEARS:
                pattern = f"stock_minute_{freq}__{year}__{batch_label}__{SCHEMA_VER}__*.parquet"
                if not list(OUT_DIR.glob(pattern)):
                    all_have = False
                    break
            if all_have:
                continue  # 整批跳过

            for year in YEARS:
                pattern = f"stock_minute_{freq}__{year}__{batch_label}__{SCHEMA_VER}__*.parquet"
                if list(OUT_DIR.glob(pattern)):
                    continue  # 该年份已存在

                out_path = OUT_DIR / f"stock_minute_{freq}__{year}__{batch_label}__{SCHEMA_VER}__{datetime.now().strftime('%Y%m%d_%H%M%S')}.parquet"
                t0 = time.time()
                df = subproc_download(batch_stocks, f"{year}-01-01", f"{year}-12-31", freq, out_path)
                t = time.time() - t0
                total_api_calls += 1

                if df is not None and len(df) > 0:
                    local_rows += len(df)
                    local_files += 1
                elif df is None:
                    for s_code in batch_stocks:
                        all_skipped.append(s_code)
                    break  # 超时，跳过整批

            # 每 5 批输出进度 + 检查额度
            if (bi + 1) % 5 == 0 or bi == len(pending_batches) - 1:
                q = quota_check()
                elapsed_s = time.time() - t_start
                print(f"  [{freq}]批 {bi+1}/{len(pending_batches)}, "
                      f"文件={local_files}, 行={local_rows:,}, "
                      f"剩余额度={q}, API调用={total_api_calls}, "
                      f"耗时={elapsed_s:.0f}s", flush=True)
                if q is not None and q <= 0:
                    print(f"\n  额度耗尽! 停止下载")
                    grand_total_files += local_files
                    grand_total_rows += local_rows
                    print(f"\n{'='*60}")
                    print(f"已下载: {grand_total_files} 文件, {grand_total_rows:,} 行")
                    print(f"初始额度: {q0:,}")
                    print(f"剩余额度: {q}")
                    print(f"跳过的股票(超时): {len(set(all_skipped))} 只")
                    print(f"{'='*60}")
                    return

        grand_total_files += local_files
        grand_total_rows += local_rows
        print(f"  [{freq}]完成: {local_files}文件, {local_rows:,}行, {total_api_calls}次API调用")

    q_end = quota_check(force=True)
    print(f"\n{'='*60}")
    print(f"全部完成")
    print(f"总计: {grand_total_files} 文件, {grand_total_rows:,} 行")
    print(f"API调用: {total_api_calls} 次")
    print(f"跳过的股票(超时): {len(set(all_skipped))} 只")
    if all_skipped:
        print(f"  前10: {sorted(set(all_skipped))[:10]}")
    print(f"初始额度: {q0:,}")
    print(f"剩余额度: {q_end}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
