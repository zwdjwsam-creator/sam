#!/usr/bin/env python3
"""JQ_P7_5M_MATRIX_WORKER — single-pool 5m download worker."""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).resolve().parent))
from p7_runtime_guard import enforce_venv_only_or_exit

enforce_venv_only_or_exit()
DRY_RUN = "--dry-run" in sys.argv
POOL = sys.argv[1].upper() if len(sys.argv) > 1 and sys.argv[1] != "--dry-run" else (
    sys.argv[2].upper() if len(sys.argv) > 2 and sys.argv[1] == "--dry-run" else None
)
if POOL is None and not DRY_RUN:
    print("Usage: <POOL>"); raise SystemExit("Usage: <POOL>")
if DRY_RUN:
    print(f"VENV_ONLY_GUARD: PASS dry-run worker pool={POOL or 'N/A'}")
    raise SystemExit(0)

import os, json, csv, hashlib, time, re
from datetime import datetime, timezone

# Quota constants (unified, hard rule)
DAILY_QUOTA_HARD_LIMIT_INT = 200_000_000   # = 2亿 = 20000万
DAILY_QUOTA_HARD_LIMIT_CN  = "2亿"
DAILY_QUOTA_HARD_LIMIT_WAN = "20000万"
# FORBIDDEN: 200000万 (=20亿) — never use as daily quota

FREQ = "5m"

import p7_gate_common as gc

# HAND gate (worker level)
_dec = gc.load_hand_decision()
if not _dec or _dec.get("hand_release_allowed") is not True:
    gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="BLOCK",status="blocked",extra="reason=HAND_not_released")
    print(f"[{POOL}] BLOCK: HAND not released"); sys.exit(3)
if _dec.get("current_stage") != "5m":
    gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="BLOCK",status="blocked",extra=f"reason=wrong_stage={_dec.get('current_stage')}")
    print(f"[{POOL}] BLOCK: current_stage={_dec.get('current_stage')} != 5m"); sys.exit(3)

MATRIX = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_5m_matrix_download_R1")
OUT = MATRIX / POOL

# EXACT_LEGACY_DELETION_REVIEW_R1: LEGACY_P7_STOCK_MINUTE_ARCHIVED_HARD_ABORT
# This script historically wrote/read bare P7_stock_minute (legacy 1m/5m).
# Current sealed canonical paths:
#   1m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_raw_none_replacement_1m
#   5m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_minute_raw_none_replacement_5m
#   30m/60m: E:\BLACKBOX\数据\原始只读\JQData_9999_official_raw\P7_stock_minute_raw_none
# Do not relaunch into legacy. Deletion not executed by this review.
P7 = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P7_stock_minute_raw_none_replacement_5m")
PARENT = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_minute_quota_aware_dynamic_batch_scheduler_fix_R1")
REPAIR = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_minute_release_blocker_repair_R1")
NOW_TS = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
NOW_ISO = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")
for s in ["preflight","execution_log","checkpoint","reports","manifest"]: (OUT / s).mkdir(parents=True, exist_ok=True)

# Preflight
pool_q = REPAIR / "queue_fix" / "5m_matrix_pools" / f"p7_5m_queue_{POOL}.csv"
if not pool_q.exists(): print("BLOCK: queue missing"); sys.exit(2)
queue = list(csv.DictReader(pool_q.read_text(encoding="utf-8-sig").splitlines()))
print(f"[{POOL}] queue={len(queue)} items")

# Auth (staggered)
stagger = {"POOL_A":0,"POOL_B":1.5,"POOL_C":3.0}
time.sleep(stagger.get(POOL, 0))
sys.path.insert(0, "E:/BLACKBOX/脚本"); import jq_download_base as jdb
jdb.auth()
spare = jdb.quota_left(force=True) or 0
print(f"[{POOL}] spare={spare:,} ({spare/1e8:.2f}亿 / {spare/1e4:.0f}万)")
gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="worker_start",quota_left=spare,rows=0,status="running",extra=f"queue={len(queue)}")
if spare <= 0:
    gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="BLOCK",quota_left=0,status="blocked",extra="reason=quota_left_zero")
    cp = {"pool":POOL,"quota":0,"stop":"quota_left_zero","self_continue":True,"generated_at":NOW_ISO}
    (OUT/"checkpoint"/f"worker_{POOL}_ckpt_{NOW_TS}.json").write_text(json.dumps(cp,ensure_ascii=False,indent=2))
    print(f"[{POOL}] DONE (quota=0)"); sys.exit(0)

# Stock codes
import pandas as _pd
p0 = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P0_meta")
ALL_C = sorted(set(c for c in _pd.read_parquet(sorted(p0.glob("securities_stock__*.parquet"))[-1])["code"].dropna().unique() if isinstance(c,str) and c.endswith(("XSHE","XSHG"))))

filtered = [r for r in queue if r.get("api_call_allowed")=="true"]
ledger_map = gc.load_ledger_map()
print(f"[{POOL}] Processing {len(filtered)}...")
pq = scq = ckq = comp = fail = skip = qu = 0
stop = ""; last = ""; rows = []

for idx, item in enumerate(filtered):
    if gc.global_stop_active():
        stop = "global_stop"; break
    yr = item.get("year",""); bt = item.get("batch_id","")
    pk = item.get("partition_key", f"5m/{yr}/{bt}")
    est = int(item.get("estimated_quota",58000))
    time.sleep(0.02)

    qnow = jdb.quota_left(force=True)
    if qnow is not None and qnow <= 0:
        gc.set_global_stop("quota_left_zero"); stop = "quota_left_zero"; break

    ok_api, reason = gc.check_partition_before_api(pk, "5m", yr, bt, ledger_map, worker_id=POOL)
    if not ok_api:
        skip += 1
        gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="queue_claim_skip",partition=pk,date_range=f"{yr}",quota_left=qnow or "",rows=0,status="skip",extra=f"reason={reason}")
        if reason == "claimed_by_other_worker":
            time.sleep(0.1)
        continue

    gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="queue_claim_success",partition=pk,date_range=f"{yr}",quota_left=qnow or "",rows=0,status="claimed")

    try: bi=int(bt.replace("batch",""))
    except: bi=0
    codes = ALL_C[bi*5:bi*5+5]
    if not codes: skip+=1; continue

    try:
        import jqdatasdk as jq_d
        sd=f"{yr}-01-01"; ed=f"{yr}-12-31"
        if yr=="2026": ed=min("2026-12-31",datetime.now().strftime("%Y-%m-%d"))
        dr=f"{sd}~{ed}"
        gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="api_call_start",partition=pk,date_range=dr,quota_left=qnow,rows=0,status="running")
        r=jq_d.get_price(codes,start_date=sd,end_date=ed,frequency="5m",fields=["open","close","high","low","volume","money"],skip_paused=True,fq=None)
        nrow=len(r) if r is not None else 0
        qa = jdb.quota_left(force=True)
        gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="api_call_done",partition=pk,date_range=dr,quota_left=qa if qa is not None else "",rows=nrow,status="ok" if nrow else "empty")
        q_after = 0 if qa is None else qa
        if q_after <= 0:
            gc.set_global_stop("quota_left_zero"); stop = "quota_left_zero"
        if r is not None and len(r)>0:
            fn=f"stock_minute_5m__{yr}__{bt}__1.0.0__{NOW_TS}.parquet"
            fp=P7/fn
            with gc.FileLock(f"parquet_{pk}"):
                (_pd.DataFrame(r) if not isinstance(r,_pd.DataFrame) else r).to_parquet(str(fp),index=True); pq+=1
            gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="parquet_write_done",partition=pk,date_range=dr,rows=nrow,status="ok")
            sc={ "stock_codes":codes,"frequency":"5m","year":yr,"batch_id":bt,"start_date":sd,"end_date":ed,"row_count":len(r),"version":"1.0.0","generated_at":NOW_ISO,"source":"JQData","worker":POOL }
            with gc.FileLock(f"sidecar_{pk}"):
                sp=fp.with_suffix(".parquet.sidecar.json"); sp.write_text(json.dumps(sc,ensure_ascii=False,indent=2),encoding="utf-8"); scq+=1
            gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="sidecar_write_done",partition=pk,rows=nrow,status="ok")
            with gc.FileLock(f"checksum_{pk}"):
                ck=fp.with_suffix(".parquet.checksum.sha256"); ck.write_text(hashlib.sha256(fp.read_bytes()).hexdigest(),encoding="utf-8"); ckq+=1
            gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="checksum_write_done",partition=pk,rows=nrow,status="ok")
            gc.release_partition_claim(pk, POOL)
            comp+=1; last=pk; qu+=est
            gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="partition_complete",partition=pk,date_range=dr,quota_left=jdb.quota_left(force=True) or "",rows=nrow,status="complete",extra=f"completed={comp}")
            rows.append({"ts":NOW_ISO,"worker":POOL,"freq":"5m","pk":pk,"codes":",".join(codes),"yr":yr,"bt":bt,"rows":str(len(r)),"est":str(est),"pq":"true","sc":"true","ck":"true","status":"success","notes":fn})
        else:
            fail+=1; rows.append({"ts":NOW_ISO,"worker":POOL,"freq":"5m","pk":pk,"codes":",".join(codes),"yr":yr,"bt":bt,"rows":"0","est":str(est),"pq":"false","sc":"false","ck":"false","status":"empty","notes":pk})
        if stop == "quota_left_zero":
            break
    except Exception as e:
        fail+=1; em=str(e)[:200]
        rows.append({"ts":NOW_ISO,"worker":POOL,"freq":"5m","pk":pk,"codes":",".join(codes),"yr":yr,"bt":bt,"rows":"0","est":str(est),"pq":"false","sc":"false","ck":"false","status":"error","notes":em})
        if any(kw in em.lower() for kw in ("quota","insufficient")):
            gc.set_global_stop("quota_left_zero"); stop="quota_left_zero"; break
        gc.release_partition_claim(pk, POOL)

    if comp%10==0 and comp>0:
        ql=jdb.quota_left(force=True)
        print(f"  [{POOL}] {comp} done, q~{ql}")
        gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="quota_update",partition=last,quota_left=ql or "",rows=comp,status="running",extra=f"fail={fail} skip={skip}")

q_end = jdb.quota_left(force=True) or 0
if q_end <= 0 and not stop: stop = "quota_left_zero"
print(f"\n[{POOL}] stop={stop or 'done'} done={comp} fail={fail} skip={skip} pq={pq} q={qu} left={q_end}")
gc.append_p7_live_status(stage="5m",freq="5m",worker=POOL,event="worker_checkpoint",quota_left=q_end,rows=comp,status=stop or "done",extra=f"fail={fail} skip={skip} pq={pq}")

# Pool complete?
disk2=set()
for f in P7.glob("stock_minute_5m__*.parquet"):
    if ".sidecar" in f.name or ".checksum" in f.name: continue
    m=re.match(r"stock_minute_5m__(\d{4})__(batch\d+)__",f.name)
    if m: disk2.add((int(m.group(1)),m.group(2)))
pool_yrs=set(int(r["year"]) for r in queue)
pm=sum(1 for r in queue if (int(r["year"]),r["batch_id"]) not in disk2)
pc=(pm==0)

cp={ "pool":POOL,"done":comp,"fail":fail,"skip":skip,"pq":pq,"sc":scq,"ck":ckq,"quota":qu,"left":q_end,"stop":stop or "done","pool_complete":pc,"missing":pm,"self_continue":not bool(stop and stop not in ("quota_left_zero","api_quota_empty")),"generated_at":NOW_ISO }
(OUT/"checkpoint"/f"worker_{POOL}_ckpt_{NOW_TS}.json").write_text(json.dumps(cp,ensure_ascii=False,indent=2))

if rows:
    p=(OUT/f"execution_log/worker_{POOL}_{NOW_TS}.csv"); p.parent.mkdir(parents=True,exist_ok=True)
    with open(str(p),"w",newline="",encoding="utf-8-sig") as f: w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

fs="POOL_COMPLETE" if pc else ("PAUSED" if stop in ("quota_left_zero","api_quota_empty") else "RUNNING")
rmd=f"# 5M MATRIX {POOL}\nfinal: {fs} | done={comp} fail={fail} skip={skip} pq={pq} q={qu} pool_ok={pc} missing={pm}\n"
(RP:=OUT/f"reports/worker_{POOL}_{NOW_TS}.md").parent.mkdir(parents=True,exist_ok=True); RP.write_text(rmd,encoding="utf-8")
mn={"task":"JQ_P7_5M_MATRIX_{POOL}","final":fs,"done":comp,"fail":fail,"pq":pq,"quota":qu,"left":q_end,"pool_complete":pc,"generated_at":NOW_ISO}
mt=json.dumps(mn,ensure_ascii=False,indent=2); mn["sha256"]=hashlib.sha256(mt.encode()).hexdigest()
MP=OUT/f"manifest/worker_{POOL}_{NOW_TS}.json"; MP.parent.mkdir(parents=True,exist_ok=True); MP.write_text(mt,encoding="utf-8")

print(f"[{POOL}] DONE (fs={fs})")
