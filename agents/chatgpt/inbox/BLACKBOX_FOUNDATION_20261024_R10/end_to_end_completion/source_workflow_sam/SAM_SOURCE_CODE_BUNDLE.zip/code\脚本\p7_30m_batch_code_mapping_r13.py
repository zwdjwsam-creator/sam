#!/usr/bin/env python3
"""P7_30M_BATCH_CODE_MAPPING_R13 — PIT batch mapping for 30m (no JQ API)."""
from __future__ import annotations

import json
import re
from datetime import date
from pathlib import Path
from typing import Any

import pandas as pd

import p7_gate_common as gc

STOCKS_PER_BATCH = 5
FREQ = "30m"
P0 = Path("E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/P0_meta")
P7_DIR = gc.P7
R13_ROOT = Path(
    "E:/BLACKBOX/数据/原始只读/JQData_9999_official_raw/_manifest/P7_30m_matrix_download_R13"
)
POOL_DIR = R13_ROOT / "queue_fix" / "30m_matrix_pools"
PARQUET_PREFIX = "stock_minute_30m__"

GET_PRICE_KWARGS_30M: dict[str, Any] = {
    "frequency": "30m",
    "fields": ["open", "close", "high", "low", "volume", "money"],
    "skip_paused": True,
    "fq": "pre",
    "count": None,
    "panel": False,
    "fill_paused": True,
    "round": True,
}

R9_SEAL = Path(
    "E:/BLACKBOX/任务报告/P7_1M_FINAL_SEAL_AND_ADVANCE_NEXT_STAGE_R9/P7_1M_STAGE_COMPLETE_MARKER.json"
)


def year_end_for(year: str | int) -> date:
    y = int(year)
    if y >= 2026:
        return min(date(y, 12, 31), date.today())
    return date(y, 12, 31)


def year_start_for(year: str | int) -> date:
    return date(int(year), 1, 1)


def load_securities_df() -> pd.DataFrame:
    sec = sorted(P0.glob("securities_stock__*.parquet"))[-1]
    df = pd.read_parquet(sec)
    df["code"] = df["code"].astype(str)
    return df


def all_stock_codes(sec: pd.DataFrame | None = None) -> list[str]:
    sec = sec if sec is not None else load_securities_df()
    return sorted(
        c for c in sec["code"].dropna().unique()
        if isinstance(c, str) and c.endswith(("XSHE", "XSHG"))
    )


def runtime_codes_from_batch(batch_id: str, all_codes: list[str] | None = None) -> list[str]:
    try:
        bi = int(str(batch_id).replace("batch", ""))
    except ValueError:
        return []
    codes = all_codes if all_codes is not None else all_stock_codes()
    return codes[bi * STOCKS_PER_BATCH : bi * STOCKS_PER_BATCH + STOCKS_PER_BATCH]


def parse_codes_field(raw: str | None) -> list[str]:
    if not raw or not str(raw).strip():
        return []
    s = str(raw).strip()
    if s.startswith("["):
        try:
            return [str(x) for x in json.loads(s) if x]
        except json.JSONDecodeError:
            pass
    return [c.strip() for c in re.split(r"[|,;]", s) if c.strip()]


def partition_key(year: str | int, batch_id: str) -> str:
    return f"30m/{year}/{batch_id}"


def parquet_exists(year: str | int, batch_id: str) -> tuple[bool, str]:
    for f in P7_DIR.glob(f"{PARQUET_PREFIX}{year}__{batch_id}__*.parquet"):
        if ".sidecar" in f.name or ".checksum" in f.name:
            continue
        return True, str(f)
    return False, ""


def classify_partition(
    year: str | int,
    batch_id: str,
    *,
    queue_row: dict[str, str] | None = None,
    sec: pd.DataFrame | None = None,
    all_codes: list[str] | None = None,
) -> dict[str, Any]:
    sec = sec if sec is not None else load_securities_df()
    all_codes = all_codes if all_codes is not None else all_stock_codes(sec)
    row = queue_row or {"year": str(year), "batch_id": batch_id}
    codes = runtime_codes_from_batch(batch_id, all_codes)
    ys = year_start_for(year)
    ye = year_end_for(year)
    eligible: list[str] = []
    expected_empty: list[str] = []
    unknown: list[str] = []

    for code in codes:
        sub = sec[sec["code"] == code]
        if sub.empty:
            unknown.append(code)
            continue
        sd = pd.Timestamp(sub.iloc[0]["start_date"]).date()
        ed_raw = sub.iloc[0]["end_date"]
        ed = pd.Timestamp(ed_raw).date() if pd.notna(ed_raw) else date(2200, 1, 1)
        if sd > ye:
            expected_empty.append(code)
        elif ed < ys:
            expected_empty.append(code)
        else:
            eligible.append(code)

    if not codes:
        mc = "unknown"
    elif eligible and expected_empty:
        mc = "partial_expected_empty"
    elif not eligible and not unknown:
        mc = "all_expected_empty"
    elif unknown:
        mc = "unknown"
    else:
        mc = "still_downloadable"

    return {
        "year": str(year),
        "batch_id": batch_id,
        "partition_key": partition_key(year, batch_id),
        "eligible_codes": "|".join(eligible),
        "expected_empty_codes": "|".join(expected_empty),
        "unknown_codes": "|".join(unknown),
        "resolved_codes": "|".join(codes),
        "mapping_class": mc,
        "year_start": ys.isoformat(),
        "year_end": ye.isoformat(),
    }


def load_r9_1m_seal() -> dict[str, Any] | None:
    if not R9_SEAL.exists():
        return None
    try:
        d = json.loads(R9_SEAL.read_text(encoding="utf-8"))
        if d.get("stage_status") == "COMPLETE" and int(d.get("pending_after", 1)) == 0:
            return d
    except Exception:
        return None
    return None


def is_launcher_stub(path: Path) -> bool:
    if not path.exists():
        return True
    t = path.read_text(encoding="utf-8").lower()
    return "stub" in t and "sys.exit(0)" in t.replace(" ", "")
