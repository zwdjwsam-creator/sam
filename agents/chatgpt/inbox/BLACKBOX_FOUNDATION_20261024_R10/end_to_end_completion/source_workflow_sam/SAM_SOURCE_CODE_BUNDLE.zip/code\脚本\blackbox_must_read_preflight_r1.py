#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MUST_READ Manifest preflight R1.

Kernel is the only alwaysApply. This script:
- resolves TASK_CLASS → required files from MUST_READ_MANIFEST_CURRENT.json
- verifies SHA256 vs manifest
- enforces context budget
- does not accept HAND_READ as sufficient
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from _base import *  # noqa: F401,F403

PACK_DIR = ROOT / "契约" / "必读"
MANIFEST_PATH = PACK_DIR / "MUST_READ_MANIFEST_CURRENT.json"
KERNEL_PATH = ROOT / ".cursor" / "rules" / "BLACKBOX_KERNEL_ALWAYS_APPLY.mdc"

DEFAULT_BUDGETS = {
    "ALWAYS_APPLY_BUDGET_BYTES": 4096,
    "TASK_RULE_BUDGET_BYTES": 20480,
    "MAX_REQUIRED_RULE_FILES": 4,
    "LINE_CAP": 120,
}

FILE_KEYS = {
    "BOOTSTRAP": "BLACKBOX_BOOTSTRAP_MUST_READ.md",
    "DATA_ACCESS": "BLACKBOX_DATA_ACCESS_MUST_READ.md",
    "ACQUISITION": "BLACKBOX_ACQUISITION_MUST_READ.md",
    "FACTOR": "BLACKBOX_FACTOR_RESEARCH_MUST_READ.md",
    "BACKTEST": "BLACKBOX_BACKTEST_MUST_READ.md",
    "QMT": "BLACKBOX_QMT_MUST_READ.md",
}

CLASS_ALIASES = {
    "GENERAL": ["BOOTSTRAP"],
    "ENGINE": ["BOOTSTRAP"],
    "DATA": ["BOOTSTRAP", "DATA_ACCESS"],
    "CACHE": ["BOOTSTRAP", "DATA_ACCESS"],
    "ACQUISITION": ["BOOTSTRAP", "DATA_ACCESS", "ACQUISITION"],
    "DOWNLOAD": ["BOOTSTRAP", "DATA_ACCESS", "ACQUISITION"],
    "FACTOR": ["BOOTSTRAP", "DATA_ACCESS", "FACTOR"],
    "FACTOR_RESEARCH": ["BOOTSTRAP", "DATA_ACCESS", "FACTOR"],
    "JQ260": ["BOOTSTRAP", "DATA_ACCESS", "FACTOR"],
    "BACKTEST": ["BOOTSTRAP", "DATA_ACCESS", "BACKTEST"],
    "STRATEGY": ["BOOTSTRAP", "DATA_ACCESS", "BACKTEST"],
    "QMT": ["BOOTSTRAP", "QMT"],
    "LIVE": ["BOOTSTRAP", "QMT"],
}


def _parse_classes(raw: str) -> list[str]:
    parts = [p.strip().upper().replace("-", "_") for p in raw.replace(";", ",").split(",") if p.strip()]
    return parts or ["GENERAL"]


def _required_keys(classes: list[str]) -> list[str]:
    ordered: list[str] = []
    for c in classes:
        if c in ("FACTOR_RESEARCH", "JQ260"):
            c = "FACTOR"
        keys = CLASS_ALIASES.get(c)
        if keys is None:
            raise SystemExit(f"UNKNOWN_TASK_CLASS={c}")
        for k in keys:
            if k not in ordered:
                ordered.append(k)
    return ordered


def _meta(path: Path) -> dict:
    if not path.is_file():
        return {"path": str(path), "exists": False, "sha256": None, "lines": -1, "bytes": 0}
    text = read_text(path)
    raw = path.read_bytes()
    return {
        "path": str(path),
        "exists": True,
        "sha256": sha256_text(text),
        "lines": len(text.splitlines()),
        "bytes": len(raw),
        "text": text,
    }


def _build_manifest(file_metas: dict, kernel_meta: dict, budgets: dict) -> dict:
    files = {}
    for k, name in FILE_KEYS.items():
        m = file_metas[k]
        files[k] = {
            "path": f"契约/必读/{name}",
            "sha256": m.get("sha256"),
            "required": True,
            "lines": m.get("lines"),
        }
    classes = {c: keys for c, keys in CLASS_ALIASES.items()}
    return {
        "schema_version": "1.0.0",
        "rule_id": "BLACKBOX_MUST_READ_MANIFEST_R1",
        "status": "ACTIVE",
        "budgets": budgets,
        "kernel": {
            "path": ".cursor/rules/BLACKBOX_KERNEL_ALWAYS_APPLY.mdc",
            "sha256": kernel_meta.get("sha256"),
            "alwaysApply": True,
            "bytes": kernel_meta.get("bytes"),
        },
        "classes": classes,
        "files": files,
        "gates": {
            "DATA_ABSENCE": "脚本/blackbox_data_absence_gate_r1.py",
            "ACQUISITION_PAGINATION": "脚本/blackbox_acquisition_pagination_engine_r1.py",
        },
        "note": "On-demand disk load only. Accident recaps stay in HAND/task archives. HAND_READ is not sufficient.",
    }


def _always_apply_mdc_names() -> list[str]:
    names = []
    rules = ROOT / ".cursor" / "rules"
    for p in sorted(rules.glob("*.mdc")):
        text = read_text(p)
        if not text.startswith("---"):
            continue
        parts = text.split("---", 2)
        if len(parts) < 3:
            continue
        for line in parts[1].splitlines():
            if line.strip() == "alwaysApply: true":
                names.append(p.name)
                break
    return names


def _acceptance() -> int:
    from blackbox_data_absence_gate_r1 import _selftest as absence_selftest  # noqa: WPS433

    kernel_meta = _meta(KERNEL_PATH)
    file_metas = {k: _meta(PACK_DIR / name) for k, name in FILE_KEYS.items()}
    man = _build_manifest(file_metas, kernel_meta, dict(DEFAULT_BUDGETS))
    write_text(MANIFEST_PATH, json.dumps(man, ensure_ascii=False, indent=2) + "\n")

    rows = []
    aa = _always_apply_mdc_names()
    g1 = aa == ["BLACKBOX_KERNEL_ALWAYS_APPLY.mdc"]
    rows.append(("G1_ALWAYS_APPLY_DISK", "PASS" if g1 else "FAIL", f"count={len(aa)} files={aa}"))

    expect = {
        "GENERAL": ["BOOTSTRAP"],
        "DATA": ["BOOTSTRAP", "DATA_ACCESS"],
        "DATA,ACQUISITION": ["BOOTSTRAP", "DATA_ACCESS", "ACQUISITION"],
        "FACTOR_RESEARCH": ["BOOTSTRAP", "DATA_ACCESS", "FACTOR"],
        "BACKTEST": ["BOOTSTRAP", "DATA_ACCESS", "BACKTEST"],
    }
    iso_ok = True
    iso_notes = []
    for raw, keys in expect.items():
        got = _required_keys(_parse_classes(raw))
        if got != keys:
            iso_ok = False
            iso_notes.append(f"{raw}->{got} expected {keys}")
        if raw == "DATA" and "BACKTEST" in got:
            iso_ok = False
            iso_notes.append("DATA_LEAK_BACKTEST")
        if raw == "FACTOR_RESEARCH" and "ACQUISITION" in got:
            iso_ok = False
            iso_notes.append("FACTOR_LEAK_ACQUISITION")
    over = _required_keys(_parse_classes("DATA,ACQUISITION,FACTOR,BACKTEST"))
    if len(over) <= DEFAULT_BUDGETS["MAX_REQUIRED_RULE_FILES"]:
        iso_ok = False
        iso_notes.append("OVERLOAD_NOT_TRIGGERED")
    rows.append(("G3_TASK_CLASS_ISOLATION", "PASS" if iso_ok else "FAIL", ";".join(iso_notes) or "ok"))

    boot = PACK_DIR / FILE_KEYS["BOOTSTRAP"]
    orig = read_text(boot)
    tamper_ok = False
    try:
        write_text(boot, orig + "\n# SHA_TAMPER_PROBE\n")
        man = json.loads(read_text(MANIFEST_PATH))
        expected = man["files"]["BOOTSTRAP"]["sha256"]
        actual = sha256_text(read_text(boot))
        mismatch = expected != actual
        tamper_ok = mismatch
        rows.append(
            (
                "G2_SHA_FAIL_CLOSED",
                "PASS" if tamper_ok else "FAIL",
                f"MUST_READ_PRECHECK={'FAIL' if mismatch else 'PASS'} AUTHORITY_READY={'NO' if mismatch else 'YES'} TASK_EXECUTION_FORBIDDEN={str(mismatch).upper()}",
            )
        )
    finally:
        write_text(boot, orig)

    abs_rc = absence_selftest()
    rows.append(("G4_DATA_ABSENCE_MATRIX", "PASS" if abs_rc == OK else "FAIL", f"exit={abs_rc}"))

    all_pass = all(r[1] == "PASS" for r in rows)
    print("BLACKBOX_KERNEL_ACCEPTANCE")
    for name, st, note in rows:
        print(f"{name} = {st}  {note}")
    print("ALWAYS_APPLY_FILE_COUNT =", len(aa))
    print("ALWAYS_APPLY_FILE =", ",".join(aa) if aa else "NONE")
    print("final_status =", "PASS" if all_pass else "FAIL")
    return OK if all_pass else FAIL


def main() -> int:
    set_runtime_context(
        task_type="SETUP_INFRASTRUCTURE_BOOTSTRAP",
        exemption_paths=[str(PACK_DIR), str(ROOT / ".cursor" / "rules")],
    )
    ap = argparse.ArgumentParser()
    ap.add_argument("--task-class", default="GENERAL")
    ap.add_argument("--write-manifest", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--acceptance", action="store_true")
    args = ap.parse_args()
    if args.acceptance:
        return _acceptance()

    budgets = dict(DEFAULT_BUDGETS)
    kernel_meta = _meta(KERNEL_PATH)
    file_metas = {k: _meta(PACK_DIR / name) for k, name in FILE_KEYS.items()}

    if args.write_manifest:
        man = _build_manifest(file_metas, kernel_meta, budgets)
        write_text(MANIFEST_PATH, json.dumps(man, ensure_ascii=False, indent=2) + "\n")
        print(f"WROTE {MANIFEST_PATH}")

    if not MANIFEST_PATH.is_file():
        print("MISSING_MANIFEST", MANIFEST_PATH)
        return FAIL
    manifest = json.loads(read_text(MANIFEST_PATH))
    budgets = {**DEFAULT_BUDGETS, **(manifest.get("budgets") or {})}

    classes = _parse_classes(args.task_class)
    required = _required_keys(classes)

    problems: list[str] = []
    if not kernel_meta["exists"]:
        problems.append("KERNEL_MISSING")
    elif kernel_meta["bytes"] > budgets["ALWAYS_APPLY_BUDGET_BYTES"]:
        problems.append("ALWAYS_APPLY_BUDGET_EXCEEDED")

    rules_loaded = []
    task_bytes = 0
    for k in required:
        m = file_metas[k]
        expected = ((manifest.get("files") or {}).get(k) or {}).get("sha256")
        status = "MISSING"
        if not m["exists"]:
            problems.append(f"MISSING_{k}")
        elif m["lines"] > budgets["LINE_CAP"]:
            problems.append(f"LINE_CAP_{k}")
            status = "LINE_CAP_FAIL"
        elif expected and m["sha256"] != expected:
            problems.append(f"SHA_MISMATCH_{k}")
            status = "SHA_MISMATCH"
        else:
            status = "VERIFIED"
            task_bytes += m["bytes"]
        rules_loaded.append(
            {
                "key": k,
                "path": m["path"],
                "expected_sha256": expected,
                "actual_sha256": m.get("sha256"),
                "status": status,
                "lines": m.get("lines"),
            }
        )

    if len(required) > budgets["MAX_REQUIRED_RULE_FILES"]:
        problems.append("RULESET_OVERLOADED_FILE_COUNT")
    if task_bytes > budgets["TASK_RULE_BUDGET_BYTES"]:
        problems.append("RULESET_OVERLOADED_BYTES")

    k_expected = (manifest.get("kernel") or {}).get("sha256")
    kernel_status = "VERIFIED"
    if k_expected and kernel_meta.get("sha256") != k_expected:
        problems.append("SHA_MISMATCH_KERNEL")
        kernel_status = "SHA_MISMATCH"

    ok = not problems
    block = [
        "MUST_READ_PRECHECK = " + ("PASS" if ok else "FAIL"),
        f"TASK_CLASS = {','.join(classes)}",
        f"KERNEL_SHA256 = {kernel_meta.get('sha256')}",
        f"KERNEL_STATUS = {kernel_status}",
        f"KERNEL_BYTES = {kernel_meta.get('bytes')}",
        "HAND_READ = NOT_SUFFICIENT",
        "AUTHORITY_READY = " + ("YES" if ok else "NO"),
        "TASK_EXECUTION = " + ("ALLOWED" if ok else "FORBIDDEN"),
        "TASK_EXECUTION_FORBIDDEN = " + ("FALSE" if ok else "TRUE"),
    ]
    if problems:
        block.append("PROBLEMS = " + ",".join(problems))
    block.append("rules_loaded:")
    for item in rules_loaded:
        block.append(f"  - {item['key']}")
        block.append(f"    expected_sha256 = {item['expected_sha256']}")
        block.append(f"    actual_sha256   = {item['actual_sha256']}")
        block.append(f"    status = {item['status']}")

    payload = {
        "ok": ok,
        "MUST_READ_PRECHECK": "PASS" if ok else "FAIL",
        "task_class": classes,
        "required": required,
        "problems": problems,
        "kernel": {kk: kernel_meta[kk] for kk in ("path", "exists", "sha256", "bytes", "lines")},
        "rules_loaded": rules_loaded,
        "preflight_block": "\n".join(block),
    }
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(payload["preflight_block"])
        print("READ_THESE:")
        for item in rules_loaded:
            print(" - " + item["path"])
    return OK if ok else FAIL


if __name__ == "__main__":
    raise SystemExit(main())
