# -*- coding: utf-8 -*-
"""
BLACKBOX HAND 顶部回测 PREFLIGHT 硬门。

正式规则（非补丁提示）：
  rule_id = BLACKBOX_HAND_TOP_LEVEL_BACKTEST_EXECUTION_R1

用途：
  回测开跑前必须提交 BACKTEST_PREFLIGHT_RECEIPT.json 并通过本门。
  用错撮合（空仓政策）或复权/价源 → HARD_BLOCK，exit=2，不予回测。

用法示例：
  E:\\BLACKBOX\\.venv\\Scripts\\python.exe -u E:\\BLACKBOX\\脚本\\blackbox_backtest_preflight_gate.py ^
    --receipt D:\\CURSOR_TASK_ARCHIVE\\xxx\\BACKTEST_PREFLIGHT_RECEIPT.json

  或由 stdout 校验现有 receipt 字段。
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from _base import OK, FAIL, ROOT, write_text  # noqa: E402

RULE_ID = "BLACKBOX_HAND_TOP_LEVEL_BACKTEST_EXECUTION_R1"
RULE_JSON = ROOT / "规则库/hand_hard_rules" / f"{RULE_ID}.json"

ALLOWED_EMPTY = {"EMPTY_KEEP_HOLDING", "EMPTY_TO_CASH"}
REQUIRED_FIELDS = [
    "empty_rank_policy",
    "price_adj_tag",
    "price_source",
    "claim_jq_or_live_match",
    "rebalance_clock_rule",
]


def _boolish(v) -> bool | None:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        s = v.strip().lower()
        if s in {"true", "yes", "1", "y"}:
            return True
        if s in {"false", "no", "0", "n"}:
            return False
    return None


def validate_receipt(data: dict) -> list[str]:
    fails: list[str] = []
    for k in REQUIRED_FIELDS:
        if k not in data or data[k] in (None, "", []):
            fails.append(f"missing_field:{k}")

    empty = str(data.get("empty_rank_policy") or "").strip()
    if empty and empty not in ALLOWED_EMPTY:
        fails.append(f"invalid_empty_rank_policy:{empty}")

    claim = _boolish(data.get("claim_jq_or_live_match"))
    if claim is None and "claim_jq_or_live_match" in data:
        fails.append("claim_jq_or_live_match_not_bool")

    # JQ/live 对齐主结论必须留旧仓
    if claim is True:
        if empty != "EMPTY_KEEP_HOLDING":
            fails.append("EMPTY_RANK_POLICY_MISMATCH:jq_live_requires_EMPTY_KEEP_HOLDING")
        labels = data.get("labels") or []
        if isinstance(labels, str):
            labels = [labels]
        if empty == "EMPTY_TO_CASH":
            fails.append("claim_live_or_jq_aligned_while_using_EMPTY_TO_CASH")
        if "RESEARCH_EMPTY_TO_CASH" in labels:
            fails.append("claim_jq_or_live_match_true_but_research_empty_to_cash")

    # EMPTY_TO_CASH 研究必须正确贴标签且不得宣称对齐
    if empty == "EMPTY_TO_CASH":
        labels = data.get("labels") or []
        if isinstance(labels, str):
            labels = [labels]
        need = {"RESEARCH_EMPTY_TO_CASH", "NOT_LIVE_OR_JQ_MATCH_EXECUTION"}
        missing = sorted(need - set(labels))
        if missing:
            fails.append("empty_to_cash_missing_labels:" + ",".join(missing))
        if claim is True:
            fails.append("EMPTY_TO_CASH_cannot_claim_jq_or_live_match")

    # 价源硬门
    tag = str(data.get("price_adj_tag") or "").strip()
    src = str(data.get("price_source") or "").strip().lower()
    bridge = data.get("bridge_method")
    if tag.upper() in {"", "UNKNOWN", "GUESS", "TBD", "NA", "N/A"}:
        fails.append("PRICE_ADJ_POLICY_VIOLATION:undeclared_or_unknown_price_adj_tag")

    # none_adj 路径却声明 pre，且无 bridge → 打回
    if "none_adj" in src and any(x in tag.upper() for x in ["PRE", "QFQ", "FORMAL_BRIDGE"]):
        if not bridge or str(bridge).strip().lower() in {"", "none", "null", "n/a"}:
            fails.append("PRICE_ADJ_POLICY_VIOLATION:none_adj_source_with_pre_tag_no_bridge")

    if data.get("silent_none_adj_splice") is True:
        fails.append("WRONG_DATA_BLOCKED:silent_none_adj_splice")

    if data.get("fq_identity_from_filename_only") is True:
        fails.append("PRICE_ADJ_POLICY_VIOLATION:fq_identity_from_filename_only")

    # 价格平面合同 R1：历史回测 ≠ 实盘成交字段
    bt_plane = str(data.get("BACKTEST_PRICE_PLANE") or "").strip().upper()
    live_plane = str(data.get("LIVE_EXECUTION_PRICE_PLANE") or "").strip().upper()
    sig_plane = str(data.get("SIGNAL_PRICE_PLANE") or "").strip().upper()
    exe_plane = str(data.get("BACKTEST_EXECUTION_PRICE_PLANE") or "").strip().upper()
    labels = data.get("labels") or []
    if isinstance(labels, str):
        labels = [labels]
    labelset = set(str(x) for x in labels)
    research_raw = "RESEARCH_RAW_NONE_EXPLICIT" in labelset or "LEGACY_RAW_NONE_BASELINE" in labelset

    if not bt_plane:
        fails.append("missing_field:BACKTEST_PRICE_PLANE")
    if not live_plane:
        fails.append("missing_field:LIVE_EXECUTION_PRICE_PLANE")
    if live_plane and live_plane != "RAW_REAL_PRICE":
        fails.append("LIVE_EXECUTION_PRICE_PLANE_MUST_BE_RAW_REAL_PRICE")
    if bt_plane == "RAW_REAL_PRICE":
        fails.append("BACKTEST_PRICE_PLANE_MUST_NOT_BE_LIVE_RAW")
    if exe_plane == "RAW_REAL_PRICE":
        fails.append("REVOKED_BACKTEST_EXECUTION_EQUALS_RAW_REAL_PRICE")
    if (sig_plane == "PRE_PIT" and exe_plane in {"RAW_REAL_PRICE", "RAW_NONE", "RAW"}) or (
        bt_plane == "PRE_PIT" and exe_plane in {"RAW_REAL_PRICE", "RAW_NONE", "RAW"}
    ):
        fails.append("PRE_SIGNAL_PLUS_RAW_BACKTEST_FILL")
    if sig_plane in {"RAW_NONE", "RAW_REAL_PRICE", "RAW"} and exe_plane == "PRE_PIT":
        fails.append("RAW_SIGNAL_PLUS_PRE_FILL")
    if research_raw:
        if bt_plane and bt_plane != "RAW_NONE":
            fails.append("LEGACY_OR_RESEARCH_RAW_NONE_REQUIRES_BACKTEST_PRICE_PLANE=RAW_NONE")
    elif bt_plane and bt_plane != "PRE_PIT":
        fails.append("FORMAL_BACKTEST_REQUIRES_PRE_PIT_OR_EXPLICIT_RAW_NONE_LABEL")

    # 显式错误旗标
    for bad in data.get("hard_block_flags") or []:
        fails.append(f"flag:{bad}")

    return fails


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="HAND top-level backtest preflight hard gate")
    p.add_argument("--receipt", type=str, required=True, help="path to BACKTEST_PREFLIGHT_RECEIPT.json")
    p.add_argument("--write-verdict", type=str, default="", help="optional path to write verdict json")
    args = p.parse_args(argv)

    receipt_path = Path(args.receipt)
    if not receipt_path.exists():
        print(f"final_status=FAILED marker=BACKTEST_PREFLIGHT_FAILED reason=missing_receipt path={receipt_path}")
        print("HARD_BLOCK_NO_BACKTEST")
        return FAIL

    try:
        raw = receipt_path.read_text(encoding="utf-8-sig")
        data = json.loads(raw)
    except Exception as e:
        print(f"final_status=FAILED marker=BACKTEST_PREFLIGHT_FAILED reason=bad_json err={e}")
        print("HARD_BLOCK_NO_BACKTEST")
        return FAIL

    if not RULE_JSON.exists():
        print(f"final_status=FAILED marker=TOP_LEVEL_BACKTEST_RULE_VIOLATION reason=missing_rule_json")
        return FAIL

    fails = validate_receipt(data if isinstance(data, dict) else {})
    verdict = {
        "rule_id": RULE_ID,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "receipt_path": str(receipt_path),
        "pass": len(fails) == 0,
        "fails": fails,
        "block_mode": "HARD_BLOCK",
        "on_fail": "不予回测",
        "markers": [] if not fails else ["BACKTEST_PREFLIGHT_FAILED", "TOP_LEVEL_BACKTEST_RULE_VIOLATION"]
        + (["WRONG_DATA_BLOCKED"] if any("PRICE" in f or "WRONG" in f or "none_adj" in f for f in fails) else [])
        + (["EMPTY_RANK_POLICY_MISMATCH"] if any("EMPTY" in f for f in fails) else []),
    }

    if args.write_verdict:
        write_text(Path(args.write_verdict), json.dumps(verdict, ensure_ascii=False, indent=2))

    if fails:
        print("final_status=FAILED")
        print("marker=BACKTEST_PREFLIGHT_FAILED")
        print("HARD_BLOCK_NO_BACKTEST")
        print("on_fail=不予回测")
        for f in fails:
            print(f"fail={f}")
        return FAIL

    print("final_status=PASS")
    print("marker=BACKTEST_PREFLIGHT_OK")
    print("allowed_to_backtest=YES")
    print(f"empty_rank_policy={data.get('empty_rank_policy')}")
    print(f"price_adj_tag={data.get('price_adj_tag')}")
    print(f"claim_jq_or_live_match={data.get('claim_jq_or_live_match')}")
    return OK


if __name__ == "__main__":
    sys.exit(main())
