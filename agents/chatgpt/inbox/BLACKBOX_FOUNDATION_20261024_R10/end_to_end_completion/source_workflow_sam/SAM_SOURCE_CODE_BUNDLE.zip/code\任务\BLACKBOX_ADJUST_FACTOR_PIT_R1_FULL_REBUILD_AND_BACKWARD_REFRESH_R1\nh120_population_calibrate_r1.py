# -*- coding: utf-8 -*-
"""Golden NH120 + population calibration vs JQ fq='pre' closes. No R26 param change."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_ADJUST_FACTOR_PIT_R1_FULL_REBUILD_AND_BACKWARD_REFRESH_R1")
CACHE_PTR = Path(r"E:\BLACKBOX\数据\回测缓存\CURRENT_CACHE_RELEASE.json")
sys.path.insert(0, r"E:\BLACKBOX\脚本")
from jq_download_base import auth  # noqa: E402
sys.path.insert(0, str(TASK))
from download_source_fq_pre_r1 import flatten_factor  # noqa: E402


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print(f"[{now_cn()}] {msg}", flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def load_factor() -> pd.DataFrame:
    root = Path(json.loads(CACHE_PTR.read_text(encoding="utf-8"))["release_root"])
    files = sorted((root / "ADJUST_FACTOR_PIT_R1" / "data").glob("year=*/part_*.parquet"))
    df = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
    df["date"] = pd.to_datetime(df["date"]).dt.normalize()
    df["code"] = df["code"].astype(str)
    return df


def load_raw() -> pd.DataFrame:
    root = Path(json.loads(CACHE_PTR.read_text(encoding="utf-8"))["release_root"])
    frames = []
    for year in (2025, 2026):
        p = root / "STOCK_DAILY_PIT_R1" / f"year={year}" / f"part_{year}.parquet"
        frames.append(pd.read_parquet(p, columns=["date", "code", "close", "volume"]))
    out = pd.concat(frames, ignore_index=True)
    out["date"] = pd.to_datetime(out["date"]).dt.normalize()
    out["code"] = out["code"].astype(str)
    out["close"] = pd.to_numeric(out["close"], errors="coerce")
    out["volume"] = pd.to_numeric(out["volume"], errors="coerce")
    return out.dropna(subset=["date", "code", "close"])


def nh120_from_close(g: pd.DataFrame, t: pd.Timestamp) -> bool | None:
    g = g.sort_values("date")
    sub = g.loc[g["date"] <= t]
    if sub.empty or sub.iloc[-1]["date"] != t:
        return None
    last = float(sub.iloc[-1]["close"])
    prior = sub.iloc[:-1].tail(120)
    if len(prior) < 120:
        return None
    return bool(last > float(prior["close"].max()) > 0)


def bb_pre_close(raw: pd.DataFrame, fac: pd.DataFrame, t: pd.Timestamp) -> pd.DataFrame:
    win_start = t - pd.Timedelta(days=400)
    r = raw.loc[(raw["date"] >= win_start) & (raw["date"] <= t)].copy()
    f = fac.loc[(fac["date"] >= win_start) & (fac["date"] <= t), ["date", "code", "factor"]]
    m = r.merge(f, on=["date", "code"], how="left")
    ft = f.loc[f["date"] == t, ["code", "factor"]].rename(columns={"factor": "factor_T"})
    m = m.merge(ft, on="code", how="left")
    miss = m["factor"].isna() | m["factor_T"].isna() | (m["factor"] <= 0) | (m["factor_T"] <= 0)
    m = m.loc[~miss].copy()
    m["close"] = m["close"] * m["factor"] / m["factor_T"]
    return m[["date", "code", "close"]]


def jq_pre_close(codes: list[str], start: str, end: str) -> pd.DataFrame:
    import jqdatasdk as jq

    parts = []
    for i in range(0, len(codes), 400):
        batch = codes[i : i + 400]
        df = jq.get_price(
            security=batch,
            start_date=start,
            end_date=end,
            frequency="daily",
            fields=["close"],
            fq="pre",
        )
        if df is None or len(df) == 0:
            log(f"jq pre close batch {i//400+1} EMPTY n={len(batch)}")
            continue
        x = df.reset_index() if "code" not in getattr(df, "columns", []) else df.copy()
        if "time" in x.columns:
            x = x.rename(columns={"time": "date"})
        if "date" not in x.columns:
            x = x.rename(columns={x.columns[0]: "date"})
        x["date"] = pd.to_datetime(x["date"]).dt.normalize()
        x["code"] = x["code"].astype(str)
        x["close"] = pd.to_numeric(x["close"], errors="coerce")
        parts.append(x[["date", "code", "close"]].dropna())
        log(f"jq pre close batch {i//400+1} n={len(batch)}")
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=["date", "code", "close"])


def pop_at(raw, fac, t: pd.Timestamp, jq_pre: pd.DataFrame) -> dict:
    bb = bb_pre_close(raw, fac, t)
    bb_codes = []
    for code, g in bb.groupby("code"):
        hit = nh120_from_close(g, t)
        if hit:
            bb_codes.append(code)
    jq_codes = []
    jq_t = jq_pre.loc[jq_pre["date"] <= t]
    for code, g in jq_t.groupby("code"):
        hit = nh120_from_close(g, t)
        if hit:
            jq_codes.append(code)
    bb_s, jq_s = set(bb_codes), set(jq_codes)
    return {
        "signal_date": str(t.date()),
        "BLACKBOX_PRE_PIT_NH120_N": len(bb_s),
        "JQ_PRE_NH120_N": len(jq_s),
        "BLACKBOX_ONLY_N": len(bb_s - jq_s),
        "JQ_ONLY_N": len(jq_s - bb_s),
        "INTERSECT_N": len(bb_s & jq_s),
        "BLACKBOX_ONLY": sorted(bb_s - jq_s),
        "JQ_ONLY": sorted(jq_s - bb_s),
        "match": bb_s == jq_s,
    }


def golden_nh(raw, fac) -> dict:
    out = {}
    for code, t, expect_raw, expect_pre in [
        ("001230.XSHE", pd.Timestamp("2026-08-11"), False, True),
        ("600351.XSHG", pd.Timestamp("2026-08-13"), False, True),
    ]:
        r = raw.loc[raw["code"] == code]
        f = fac.loc[fac["code"] == code]
        raw_nh = nh120_from_close(r.rename(columns={"close": "close"}), t)
        pre = bb_pre_close(r, f, t)
        pre_nh = nh120_from_close(pre, t)
        rec = {
            "code": code,
            "signal_date": str(t.date()),
            "RAW_NH120": raw_nh,
            "PRE_PIT_NH120": pre_nh,
            "expect_raw": expect_raw,
            "expect_pre": expect_pre,
            "pass": raw_nh is expect_raw and pre_nh is expect_pre,
        }
        if code == "001230.XSHE":
            row = pre.loc[pre["date"] == t]
            rec["signal_close_pre"] = None if row.empty else float(row.iloc[-1]["close"])
        out[code] = rec
    return out


def main() -> int:
    auth()
    fac = load_factor()
    raw = load_raw()
    gnh = golden_nh(raw, fac)
    wjson(TASK / "GOLDEN_NH120.json", gnh)
    log(f"golden_nh { {k: v['pass'] for k,v in gnh.items()} }")
    codes = sorted(set(raw.loc[raw["date"] >= "2026-08-01", "code"]))
    jq_pre = jq_pre_close(codes, "2026-01-05", "2026-08-13")
    pops = [
        pop_at(raw, fac, pd.Timestamp("2026-08-11"), jq_pre),
        pop_at(raw, fac, pd.Timestamp("2026-08-13"), jq_pre),
    ]
    wjson(TASK / "NH120_POPULATION_CALIBRATION.json", {"pops": pops, "all_match": all(p["match"] for p in pops)})
    log(json.dumps(pops, ensure_ascii=False))
    if not all(v["pass"] for v in gnh.values()):
        return 2
    if not all(p["match"] for p in pops):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
