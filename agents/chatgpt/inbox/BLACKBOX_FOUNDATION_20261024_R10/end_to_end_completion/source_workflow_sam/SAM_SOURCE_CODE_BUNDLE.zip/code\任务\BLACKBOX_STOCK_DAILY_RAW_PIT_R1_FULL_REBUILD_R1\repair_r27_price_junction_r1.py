# -*- coding: utf-8 -*-
"""Repair R27 price junction leak into R26 parent. Do not delete cache files."""
from __future__ import annotations

import os
import shutil
from pathlib import Path

PARENT_PRICE = Path(r"E:\BLACKBOX\数据\清洗成品\releases\BLACKBOX_FORMAL_CLEANING_R26_ADJFACTOR_PIT_ASOF_20260814_20260816_044000\standard\price")
R27_PRICE = Path(r"E:\BLACKBOX\数据\清洗成品\releases\BLACKBOX_FORMAL_CLEANING_R27_STOCK_DAILY_RAW_PIT_ASOF_20260814_20260816_070301\standard\price")
CACHE_PROD = Path(r"E:\BLACKBOX\数据\回测缓存\releases\BLACKBOX_CACHE_R1_STOCK_DAILY_RAW_PIT_ASOF_20260814_20260816_070301\STOCK_DAILY_RAW_PIT_R1")
POLLUTE = PARENT_PRICE / "A股_stock_daily_raw"


def main() -> int:
    if not PARENT_PRICE.exists():
        raise SystemExit("HARD_BLOCK: parent price missing")
    if not CACHE_PROD.exists():
        raise SystemExit("HARD_BLOCK: cache product missing")
    if R27_PRICE.exists():
        rc = os.system('cmd /c rmdir "' + str(R27_PRICE) + '"')
        print("rmdir_junction", rc, "still", R27_PRICE.exists())
        if R27_PRICE.exists():
            raise SystemExit("HARD_BLOCK: junction rmdir failed")
    R27_PRICE.mkdir(parents=True)
    for child in PARENT_PRICE.iterdir():
        if child.name == "A股_stock_daily_raw":
            continue
        dst = R27_PRICE / child.name
        os.system('cmd /c mklink /J "' + str(dst) + '" "' + str(child) + '" >NUL')
        print("J", child.name, dst.exists())
    newp = R27_PRICE / "A股_stock_daily_raw"
    newp.mkdir()
    for src in CACHE_PROD.rglob("*"):
        rel = src.relative_to(CACHE_PROD)
        dst = newp / rel
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.link(src, dst)
            mode = "HARDLINK"
        except OSError:
            shutil.copy2(src, dst)
            mode = "COPY"
        print(mode, rel)
    if POLLUTE.exists():
        shutil.rmtree(POLLUTE)
    print("parent_polluted_gone", not POLLUTE.exists())
    print("parent_children", os.listdir(PARENT_PRICE))
    print("r27_children", os.listdir(R27_PRICE))
    print("r27_new", os.listdir(newp))
    if POLLUTE.exists():
        return 2
    if "A股_stock_daily_raw" not in os.listdir(R27_PRICE):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
