#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Daily increment managed check for ETF_MINUTE_1M_R1.

Target-date D only. Does not rewrite full history.
Does not switch Cleaning/Cache CURRENT.
If production matrix does not require minute: NON_BLOCKING_KNOWN_EXCEPTION.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from blackbox_daily_increment_common_r1 import PRODUCTION_MATRIX_PRODUCTS  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
CLEANING_PTR = ROOT / "数据" / "清洗成品" / "CURRENT_CLEANING_RELEASE.json"
DAY_RE = re.compile(r"__1m__(?P<date>\d{4}-\d{2}-\d{2})__")
PRODUCT = "ETF_MINUTE_1M_R1"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-target-date", required=True)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    d = args.run_target_date
    cleaning = json.loads(CLEANING_PTR.read_text(encoding="utf-8"))
    etf_dir = Path(cleaning["standard_root"]) / "price" / "ETF_1m"
    hits = [p.name for p in etf_dir.glob("*.parquet") if DAY_RE.search(p.name) and DAY_RE.search(p.name).group("date") == d] if etf_dir.is_dir() else []
    required_in_prod = PRODUCT in PRODUCTION_MATRIX_PRODUCTS
    if hits:
        status = "PASS"
        update_required = False
        result = "DAILY_SLICE_PRESENT"
    else:
        status = "FAIL" if required_in_prod else "NON_BLOCKING_KNOWN_EXCEPTION"
        update_required = True
        result = "DAILY_SLICE_MISSING"
    out = {
        "product": PRODUCT,
        "frequency": "1m",
        "update_policy": "TARGET_DATE_DAILY_SLICE_ONLY",
        "daily_increment_entrypoint": "脚本/blackbox_etf_minute_daily_increment_check_r1.py",
        "ETF_MINUTE_TARGET_DATE": d,
        "SOURCE_REFRESH_STATUS": "NOT_FETCHED_THIS_CHECK",
        "RAW_PARTITION_STATUS": "NOT_CHECKED_RAW_WRITE",
        "CLEANING_STATUS": "SLICE_PRESENT" if hits else "SLICE_ABSENT_IN_CURRENT",
        "ANTI_LOOKAHEAD_STATUS": "N/A_CHECK_ONLY",
        "FORMAL_PARTITION_STATUS": "PRESENT" if hits else "MISSING",
        "CACHE_PRODUCT_STATUS": "METADATA_ONLY_CANDIDATE",
        "COVERAGE_REFRESH_STATUS": "DEFERRED_TO_READER",
        "CAPABILITY_STATUS": status,
        "update_required": update_required,
        "result": result,
        "n_day_files": len(hits),
        "day_files": hits,
        "production_required": required_in_prod,
        "dry_run": bool(args.dry_run),
        "apply_download": False,
        "silent_missing_symbol_forbidden": True,
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
