#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BLACKBOX US Fine-Grained Flow vs Price-Acceptance Profit Pool Collector R1."""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import feedparser
import yfinance as yf

ROOT = Path(__file__).resolve().parents[1]
US_ROOT = ROOT / "数据" / "美国市场"
FINE_ROOT = US_ROOT / "细粒度利润池"
TAXONOMY_PATH = US_ROOT / "CONFIG" / "US_L234_PROFIT_POOL_TAXONOMY.json"
L1_TAXONOMY_PATH = US_ROOT / "CONFIG" / "US_L1_TAXONOMY.json"
MARKET_STATE_CURRENT = US_ROOT / "市场状态" / "CURRENT" / "US_MARKET_STATE_CURRENT.json"
CURRENT_POINTER = ROOT / "运行" / "BLACKBOX_US_MARKET_FINE_GRAINED_FLOW_PROFIT_POOL_CURRENT.json"
ET = ZoneInfo("America/New_York")
CN = ZoneInfo("Asia/Shanghai")

PHASE_SCHEDULE: dict[str, tuple[int, int]] = {
    "open": (9, 40),
    "intraday1": (11, 0),
    "intraday2": (13, 30),
    "intraday3": (15, 30),
    "close": (16, 10),
}

FORBIDDEN_TRADE_TERMS = (
    "buy", "sell", "long", "short", "买入", "卖出", "做多", "做空", "下单", "建仓", "清仓",
)
FORBIDDEN_FLOW_TERMS = ("net inflow", "net_inflow", "资金净流入", "净流入")


def now_cn() -> str:
    return datetime.now(CN).strftime("%Y-%m-%dT%H:%M:%S%z")


def now_et() -> datetime:
    return datetime.now(ET)


def load_json(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def atomic_write_json(p: Path, obj: dict[str, Any]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(p)


def heartbeat(module: str, state: str, done: int, total: int, *, note: str = "") -> None:
    print(f"[HEARTBEAT] MODULE={module} STATE={state} ITEMS_DONE={done} ITEMS_TOTAL={total} {note}", flush=True)


def trading_day_back(d: date, n: int = 1) -> date:
    cur = d
    steps = 0
    while steps < n:
        cur -= timedelta(days=1)
        if cur.weekday() < 5:
            steps += 1
    return cur


def is_us_trading_day(d: date) -> bool:
    if d.weekday() >= 5:
        return False
    try:
        hist = yf.Ticker("^GSPC").history(start=d.isoformat(), end=(d + timedelta(days=1)).isoformat())
        return not hist.empty
    except Exception:
        return d.weekday() < 5


def latest_complete_us_session(today_et: date) -> date:
    candidate = today_et
    et_now = now_et()
    if candidate == et_now.date() and et_now.hour * 60 + et_now.minute < 16 * 60 + 5:
        candidate = trading_day_back(candidate, 1)
    while not is_us_trading_day(candidate):
        candidate = trading_day_back(candidate, 1)
    return candidate


def resolve_session_date(today_et: date, et_dt: datetime) -> date:
    mins = et_dt.hour * 60 + et_dt.minute
    if is_us_trading_day(today_et) and mins >= 9 * 60 + 35:
        return today_et
    return latest_complete_us_session(today_et)


def cn_research_date(us_market_date: date) -> str:
    return (us_market_date + timedelta(days=1)).isoformat()


def validate_open_close_alignment(session_date: date) -> dict[str, Any]:
    mkt = load_json(MARKET_STATE_CURRENT)
    aligned = mkt.get("US_MARKET_DATE") == session_date.isoformat()
    return {
        "US_MARKET_STATE_CURRENT": str(MARKET_STATE_CURRENT),
        "market_state_date": mkt.get("US_MARKET_DATE"),
        "fine_session_date": session_date.isoformat(),
        "aligned": aligned,
        "note": "PASS" if aligned else "MISMATCH_USE_FINE_SESSION_LOGIC",
    }


def resolve_target_phase(phase_arg: str, et_dt: datetime, session_date: date) -> str:
    if phase_arg != "daily":
        return phase_arg
    if session_date != et_dt.date() or not is_us_trading_day(et_dt.date()):
        return "close"
    mins = et_dt.hour * 60 + et_dt.minute
    thresholds = [
        ("close", 16 * 60 + 10),
        ("intraday3", 15 * 60 + 30),
        ("intraday2", 13 * 60 + 30),
        ("intraday1", 11 * 60 + 0),
        ("open", 9 * 60 + 40),
    ]
    for name, threshold in thresholds:
        if mins >= threshold:
            return name
    return "close"


def fetch_symbol_metrics(symbol: str, session_date: date, *, asof_phase: str) -> dict[str, Any]:
    tk = yf.Ticker(symbol)
    try:
        daily = tk.history(start=(session_date - timedelta(days=12)).isoformat(), end=(session_date + timedelta(days=1)).isoformat())
    except Exception as exc:
        return {"symbol": symbol, "error": str(exc)}
    if daily.empty:
        return {"symbol": symbol, "error": "NO_DATA"}
    daily.index = daily.index.tz_localize(None)
    row = None
    for idx in daily.index:
        if idx.date() == session_date:
            row = daily.loc[idx]
            break
    if row is None:
        return {"symbol": symbol, "error": "NO_SESSION_ROW"}
    prev = daily[daily.index.date < session_date]
    prev_close = float(prev["Close"].iloc[-1]) if not prev.empty else float(row["Open"])
    close_px = float(row["Close"])
    open_px = float(row["Open"])
    volume = float(row.get("Volume", 0) or 0)
    vol_hist = daily[daily.index.date <= session_date]["Volume"].tail(6).astype(float)
    avg_vol = float(vol_hist.iloc[:-1].mean()) if len(vol_hist) > 1 else volume
    vol_ratio = (volume / avg_vol) if avg_vol else 1.0
    if asof_phase == "open" and session_date == now_et().date():
        intraday = tk.history(period="1d", interval="5m")
        px = open_px
        if not intraday.empty:
            intraday.index = intraday.index.tz_convert(ET)
            win = intraday[(intraday.index.hour == 9) & (intraday.index.minute >= 35) & (intraday.index.minute <= 45)]
            if not win.empty:
                px = float(win["Close"].iloc[0])
        ret = (px - prev_close) / prev_close if prev_close else 0.0
        return {
            "symbol": symbol,
            "price": px,
            "prev_close": prev_close,
            "return_pct": round(ret * 100, 3),
            "volume": volume,
            "volume_ratio_vs_5d": round(vol_ratio, 3),
        }
    ret = (close_px - prev_close) / prev_close if prev_close else 0.0
    return {
        "symbol": symbol,
        "open": open_px,
        "close": close_px,
        "prev_close": prev_close,
        "return_pct": round(ret * 100, 3),
        "volume": volume,
        "volume_ratio_vs_5d": round(vol_ratio, 3),
    }


def aggregate_pool_metrics(pool: dict[str, Any], session_date: date, *, asof_phase: str, bench: dict[str, float]) -> dict[str, Any]:
    symbols = list(dict.fromkeys((pool.get("proxy_etfs") or []) + (pool.get("core_tickers") or [])))
    sym_metrics: list[dict[str, Any]] = []
    for sym in symbols:
        sym_metrics.append(fetch_symbol_metrics(sym, session_date, asof_phase=asof_phase))
    valid = [m for m in sym_metrics if "return_pct" in m]
    core_syms = pool.get("core_tickers") or []
    core_valid = [m for m in valid if m["symbol"] in core_syms]
    avg_ret = sum(m["return_pct"] for m in valid) / len(valid) if valid else 0.0
    core_up = sum(1 for m in core_valid if m.get("return_pct", 0) > 0)
    core_n = len(core_valid) or 1
    breadth = round(core_up / core_n, 3)
    avg_vol_ratio = sum(m.get("volume_ratio_vs_5d", 1.0) for m in valid) / len(valid) if valid else 1.0
    bench_key = "XLK" if pool.get("l1") in ("Software", "Semiconductor") else (
        "XLB" if pool.get("l1") == "Materials" else ("XLE" if pool.get("l1") == "Energy" else "SPX")
    )
    bench_ret = bench.get(bench_key, bench.get("SPX", 0.0))
    rel_strength = round(avg_ret - bench_ret, 3)
    labels: list[str] = []
    if avg_ret >= 0.8:
        labels.append("PRICE_STRENGTH")
    elif avg_ret >= 0.3:
        labels.append("ACCEPTANCE")
    if avg_vol_ratio >= 1.15:
        labels.append("TURNOVER_EXPANSION")
    if not labels and avg_ret > 0:
        labels.append("ACCEPTANCE")
    return {
        "pool_id": pool["pool_id"],
        "l0": pool["l0"],
        "l1": pool["l1"],
        "l2": pool["l2"],
        "l3": pool["l3"],
        "l4_profit_pool": pool["l4_profit_pool"],
        "avg_return_pct": round(avg_ret, 3),
        "relative_strength_vs_bench": rel_strength,
        "benchmark_used": bench_key,
        "breadth_core_up_ratio": breadth,
        "BREADTH_SCOPE": "CORE_SAMPLE",
        "avg_volume_ratio_vs_5d": round(avg_vol_ratio, 3),
        "price_acceptance_labels": labels,
        "FLOW_STATUS": "UNKNOWN",
        "core_confirmation": core_valid[:4],
        "payer": pool.get("payer"),
        "monetization": pool.get("monetization"),
        "symbols_raw": sym_metrics,
    }


def leadership_state(current: dict[str, Any], prior: dict[str, Any] | None) -> str:
    if not prior:
        return "NEW"
    prev_ret = prior.get("avg_return_pct", 0)
    cur_ret = current.get("avg_return_pct", 0)
    prev_rank = prior.get("_rank", 99)
    cur_rank = current.get("_rank", 99)
    if cur_ret > prev_ret + 0.4 and cur_rank < prev_rank:
        return "STRENGTHENED"
    if cur_ret < prev_ret - 0.4 or cur_rank > prev_rank + 3:
        return "WEAKENED"
    if cur_ret < 0 and prev_ret > 0.5:
        return "FADED"
    return "UNCHANGED"


def fetch_news_hits(pool: dict[str, Any], since: datetime) -> list[dict[str, Any]]:
    l1_tax = load_json(L1_TAXONOMY_PATH)
    hits: list[dict[str, Any]] = []
    keywords = [k.lower() for k in pool.get("keywords", [])]
    for feed in l1_tax.get("rss_feeds", []):
        try:
            parsed = feedparser.parse(feed["url"])
        except Exception:
            continue
        for entry in parsed.entries[:40]:
            title = getattr(entry, "title", "") or ""
            summary = getattr(entry, "summary", "") or ""
            text = f"{title} {summary}".lower()
            if not any(k in text for k in keywords[:6]):
                continue
            pub = getattr(entry, "published_parsed", None)
            pub_dt = datetime(*pub[:6], tzinfo=ET) if pub else since
            if pub_dt < since:
                continue
            hits.append({
                "headline": title[:240],
                "published_et": pub_dt.strftime("%Y-%m-%dT%H:%M:%S"),
                "source": feed.get("url", "")[:120],
                "why_subindustry": f"Keyword hit for {pool['l3']}/{pool['l4_profit_pool']}",
            })
            if len(hits) >= 3:
                break
    return hits


def build_top_real_flow() -> dict[str, Any]:
    return {
        "schema_version": "1.0.0",
        "PRODUCT": "TOP_REAL_FLOW_SECTORS",
        "ORDER_ALLOWED": False,
        "rows": [],
        "EVIDENCE_GAPS": [
            "ETF_FUND_FLOW_NOT_AVAILABLE_VIA_YFINANCE_R1",
            "NO_VERIFIED_ACTIVE_BUY_EVIDENCE",
            "TABLE_INTENTIONALLY_EMPTY_UNTIL_PAID_FLOW_SOURCE",
        ],
        "note": "R1: no verified fund-flow claims without paid flow source",
    }


def build_top_price_acceptance(pools: list[dict[str, Any]], top_n: int = 8) -> dict[str, Any]:
    ranked = sorted(pools, key=lambda p: (p.get("avg_return_pct", 0), p.get("relative_strength_vs_bench", 0)), reverse=True)
    rows = []
    for i, p in enumerate(ranked[:top_n], 1):
        rows.append({
            "rank": i,
            "pool_id": p["pool_id"],
            "l3": p["l3"],
            "l4_profit_pool": p["l4_profit_pool"],
            "avg_return_pct": p["avg_return_pct"],
            "relative_strength_vs_bench": p["relative_strength_vs_bench"],
            "price_acceptance_labels": p["price_acceptance_labels"],
            "breadth_core_up_ratio": p["breadth_core_up_ratio"],
            "BREADTH_SCOPE": p["BREADTH_SCOPE"],
            "avg_volume_ratio_vs_5d": p["avg_volume_ratio_vs_5d"],
            "FLOW_STATUS": "UNKNOWN",
        })
    return {
        "schema_version": "1.0.0",
        "PRODUCT": "TOP_PRICE_ACCEPTANCE_SECTORS",
        "ORDER_ALLOWED": False,
        "rows": rows,
    }


def build_leadership_table(pools: list[dict[str, Any]], prior_rows: dict[str, dict[str, Any]], news_map: dict[str, list]) -> dict[str, Any]:
    ranked = sorted(pools, key=lambda p: p.get("avg_return_pct", 0), reverse=True)
    for i, p in enumerate(ranked, 1):
        p["_rank"] = i
    rows = []
    for p in ranked:
        prior = prior_rows.get(p["pool_id"])
        state = leadership_state(p, prior)
        news = news_map.get(p["pool_id"], [])
        rows.append({
            "pool_id": p["pool_id"],
            "L1": p["l1"],
            "L2": p["l2"],
            "L3": p["l3"],
            "L4_PROFIT_POOL": p["l4_profit_pool"],
            "PRICE_RETURN_PCT": p["avg_return_pct"],
            "BREADTH": p["breadth_core_up_ratio"],
            "BREADTH_SCOPE": p["BREADTH_SCOPE"],
            "TURNOVER": p["avg_volume_ratio_vs_5d"],
            "FLOW_STATUS": "UNKNOWN",
            "CORE_CONFIRMATION": [m["symbol"] for m in p.get("core_confirmation", []) if "return_pct" in m][:4],
            "CATALYST": news[0]["headline"] if news else None,
            "CATALYST_PIT_ET": news[0]["published_et"] if news else None,
            "PAYER": p.get("payer"),
            "MONETIZATION": p.get("monetization"),
            "LEADERSHIP_STATE": state,
            "PRICE_ACCEPTANCE_LABELS": p.get("price_acceptance_labels", []),
        })
    return {
        "schema_version": "1.0.0",
        "PRODUCT": "FINE_GRAINED_LEADERSHIP_TABLE",
        "ORDER_ALLOWED": False,
        "rows": rows,
    }


def build_mapping_prior(top_pools: list[dict[str, Any]], taxonomy_pools: dict[str, dict]) -> dict[str, Any]:
    rows = []
    for p in top_pools[:6]:
        src = taxonomy_pools.get(p["pool_id"], {})
        hints = src.get("cn_same_profit_pool_hint", [])
        conf = "MEDIUM"
        if p.get("avg_return_pct", 0) >= 1.0 and p.get("relative_strength_vs_bench", 0) > 0:
            conf = "HIGH"
        elif p.get("avg_return_pct", 0) <= 0:
            conf = "LOW"
        rows.append({
            "US_PROFIT_POOL": p["l4_profit_pool"],
            "US_L3": p["l3"],
            "US_POOL_ID": p["pool_id"],
            "CN_SAME_PROFIT_POOL": hints,
            "confidence": conf,
            "basis": "PRICE_ACCEPTANCE_ONLY_NOT_FLOW",
            "mapping_type": "PRIOR_NOT_TRADE",
        })
    body = {
        "schema_version": "1.0.0",
        "PRODUCT": "A_SHARE_MAPPING_PRIOR",
        "ORDER_ALLOWED": False,
        "ORDER_ATTEMPTED": False,
        "rows": rows,
        "disclaimer": "Mapping prior only; not A-share stock selection or trade instruction",
    }
    text_blob = json.dumps(body, ensure_ascii=False).lower()
    for term in FORBIDDEN_TRADE_TERMS:
        if term in text_blob:
            body["validation_error"] = f"FORBIDDEN_TERM_{term}"
    return body


def build_one_line(top_rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not top_rows:
        line = "No fine-grained profit pool signal today (sub-industry data unavailable)."
    else:
        names = [f"{r['l3']}/{r['l4_profit_pool']}" for r in top_rows[:3]]
        line = "US session price-acceptance leads: " + "; ".join(names) + " (flow unverified)."
    return {
        "schema_version": "1.0.0",
        "PRODUCT": "ONE_LINE_CONCLUSION",
        "ORDER_ALLOWED": False,
        "text": line,
    }


def run_acceptance_checks(flow: dict, price: dict, leadership: dict, mapping: dict, one_line: dict) -> dict[str, Any]:
    checks: dict[str, Any] = {
        "SPLIT_FLOW_AND_PRICE_TABLES": "PASS" if flow.get("PRODUCT") != price.get("PRODUCT") else "FAIL",
        "NO_NET_INFLOW_WITHOUT_EVIDENCE": "PASS",
        "LEADERSHIP_HAS_L3_L4": "FAIL",
        "A_SHARE_MAPPING_NO_TRADE": "PASS",
        "ONE_LINE_SUBINDUSTRY": "FAIL",
        "ORDER_ATTEMPTED": False,
    }
    blob = json.dumps(
        {
            "flow_rows": flow.get("rows", []),
            "price_rows": price.get("rows", []),
            "leadership_rows": leadership.get("rows", []),
            "mapping_rows": mapping.get("rows", []),
            "one_line_text": one_line.get("text", ""),
        },
        ensure_ascii=False,
    ).lower()
    if any(t in blob for t in FORBIDDEN_FLOW_TERMS):
        checks["NO_NET_INFLOW_WITHOUT_EVIDENCE"] = "FAIL"
    for row in leadership.get("rows", []):
        if row.get("L3") and row.get("L4_PROFIT_POOL"):
            checks["LEADERSHIP_HAS_L3_L4"] = "PASS"
            break
    map_blob = json.dumps(mapping, ensure_ascii=False).lower()
    if any(t in map_blob for t in FORBIDDEN_TRADE_TERMS):
        checks["A_SHARE_MAPPING_NO_TRADE"] = "FAIL"
    if re.search(r"/", one_line.get("text", "")):
        checks["ONE_LINE_SUBINDUSTRY"] = "PASS"
    fail_keys = [k for k, v in checks.items() if v == "FAIL" and k != "ORDER_ATTEMPTED"]
    checks["FINAL_STATUS"] = "PASS" if not fail_keys else "FAIL"
    return checks


def run_collector(*, phase: str = "daily", cn_folder: str | None = None) -> dict[str, Any]:
    taxonomy = load_json(TAXONOMY_PATH)
    pools_cfg = taxonomy.get("profit_pools", [])
    pool_by_id = {p["pool_id"]: p for p in pools_cfg}
    et_now = now_et()
    today_et = et_now.date()
    session_date = resolve_session_date(today_et, et_now)
    target_phase = resolve_target_phase(phase, et_now, session_date)
    cn_iso = cn_folder or datetime.now(CN).strftime("%Y-%m-%d")
    cn_research = cn_research_date(session_date)
    alignment = validate_open_close_alignment(session_date)

    benchmarks = taxonomy.get("benchmarks", {"SPX": "^GSPC", "XLK": "XLK", "SMH": "SMH", "XLE": "XLE", "XLB": "XLB"})
    bench_metrics: dict[str, float] = {}
    for k, sym in benchmarks.items():
        m = fetch_symbol_metrics(sym, session_date, asof_phase=target_phase)
        bench_metrics[k] = m.get("return_pct", 0.0)

    prior_snap = load_json(FINE_ROOT / "CURRENT" / "US_FINE_GRAINED_SNAPSHOT_CURRENT.json")
    prior_lead = {
        r["pool_id"]: r
        for r in (prior_snap.get("leadership_preview") or [])
        if r.get("pool_id")
    }
    since = datetime.combine(session_date, datetime.min.time(), tzinfo=ET)

    pool_metrics: list[dict[str, Any]] = []
    news_map: dict[str, list] = {}
    total = len(pools_cfg)
    for i, pool in enumerate(pools_cfg, 1):
        heartbeat("US_FINE", f"POOL_{pool['pool_id']}", i, total)
        pm = aggregate_pool_metrics(pool, session_date, asof_phase=target_phase, bench=bench_metrics)
        pool_metrics.append(pm)
        if i <= 8:
            news_map[pool["pool_id"]] = fetch_news_hits(pool, since)

    flow_table = build_top_real_flow()
    price_table = build_top_price_acceptance(pool_metrics)
    leadership = build_leadership_table(pool_metrics, prior_lead, news_map)
    top_for_map = sorted(pool_metrics, key=lambda p: p.get("avg_return_pct", 0), reverse=True)[:6]
    mapping = build_mapping_prior(top_for_map, pool_by_id)
    one_line = build_one_line(price_table.get("rows", []))

    snapshot = {
        "schema_version": "1.0.0",
        "PRODUCT": "US_FINE_GRAINED_SNAPSHOT",
        "BUILD_TIME_CN": now_cn(),
        "US_MARKET_DATE": session_date.isoformat(),
        "CN_RESEARCH_DATE": cn_research,
        "CN_DISCOVERY_DATE": cn_iso,
        "PHASE": target_phase,
        "PHASE_REQUESTED": phase,
        "ORDER_ALLOWED": False,
        "ORDER_ATTEMPTED": False,
        "FLOW_NE_PRICE_STRENGTH": True,
        "A_SHARE_OUTPUT": "MAPPING_PRIOR_ONLY",
        "SESSION_ALIGNMENT": alignment,
        "BENCHMARK_RETURNS": bench_metrics,
        "leadership_preview": [{"pool_id": p["pool_id"], "avg_return_pct": p["avg_return_pct"], "_rank": p.get("_rank")} for p in pool_metrics],
        "STATUS": "PASS",
    }

    cur_dir = FINE_ROOT / "CURRENT"
    atomic_write_json(cur_dir / "US_FINE_GRAINED_SNAPSHOT_CURRENT.json", snapshot)
    atomic_write_json(cur_dir / "TOP_REAL_FLOW_SECTORS_CURRENT.json", flow_table)
    atomic_write_json(cur_dir / "TOP_PRICE_ACCEPTANCE_SECTORS_CURRENT.json", price_table)
    atomic_write_json(cur_dir / "FINE_GRAINED_LEADERSHIP_TABLE_CURRENT.json", leadership)
    atomic_write_json(cur_dir / "A_SHARE_MAPPING_PRIOR_CURRENT.json", mapping)
    atomic_write_json(cur_dir / "ONE_LINE_CONCLUSION_CURRENT.json", one_line)

    inc_dir = FINE_ROOT / "日增量" / cn_iso
    inc_dir.mkdir(parents=True, exist_ok=True)
    slice_name = f"US_FINE_GRAINED_{target_phase.upper()}.json"
    atomic_write_json(inc_dir / slice_name, {
        "snapshot": snapshot,
        "flow": flow_table,
        "price": price_table,
        "leadership": leadership,
        "mapping": mapping,
        "one_line": one_line,
    })

    pointer = {
        "schema_version": "1.0.0",
        "task_id": "BLACKBOX_US_MARKET_FINE_GRAINED_FLOW_PROFIT_POOL_R1",
        "STATUS": snapshot["STATUS"],
        "ORDER_ALLOWED": False,
        "ORDER_ATTEMPTED": False,
        "FLOW_NE_PRICE_STRENGTH": True,
        "A_SHARE_OUTPUT": "MAPPING_PRIOR_ONLY",
        "BUILD_TIME": snapshot["BUILD_TIME_CN"],
        "US_MARKET_DATE": snapshot["US_MARKET_DATE"],
        "CN_RESEARCH_DATE": snapshot["CN_RESEARCH_DATE"],
        "PHASE": target_phase,
        "FIXED_PATHS": {
            "product_root": str(FINE_ROOT),
            "snapshot_current": str(cur_dir / "US_FINE_GRAINED_SNAPSHOT_CURRENT.json"),
            "flow_current": str(cur_dir / "TOP_REAL_FLOW_SECTORS_CURRENT.json"),
            "price_current": str(cur_dir / "TOP_PRICE_ACCEPTANCE_SECTORS_CURRENT.json"),
            "leadership_current": str(cur_dir / "FINE_GRAINED_LEADERSHIP_TABLE_CURRENT.json"),
            "mapping_prior_current": str(cur_dir / "A_SHARE_MAPPING_PRIOR_CURRENT.json"),
            "one_line_current": str(cur_dir / "ONE_LINE_CONCLUSION_CURRENT.json"),
            "taxonomy": str(TAXONOMY_PATH),
            "collector": str(Path(__file__)),
        },
    }
    atomic_write_json(CURRENT_POINTER, pointer)

    acceptance = run_acceptance_checks(flow_table, price_table, leadership, mapping, one_line)

    print("[US FINE]", flush=True)
    print(f"phase={target_phase} us_date={session_date} cn_research={cn_research}", flush=True)
    print(f"alignment={alignment.get('aligned')} market_state_date={alignment.get('market_state_date')}", flush=True)
    print(f"top_price={[r['l4_profit_pool'] for r in price_table.get('rows', [])[:3]]}", flush=True)
    print(f"one_line={one_line.get('text')}", flush=True)
    print(f"FINAL_STATUS={acceptance['FINAL_STATUS']}", flush=True)

    return {
        "acceptance": acceptance,
        "snapshot": snapshot,
        "pointer": pointer,
        "phase": target_phase,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="BLACKBOX US Fine-Grained Flow Profit Pool Collector R1")
    ap.add_argument(
        "--phase",
        default="daily",
        choices=["open", "intraday1", "intraday2", "intraday3", "close", "daily", "status"],
    )
    ap.add_argument("--cn-date", default=None, help="CN folder YYYY-MM-DD")
    args = ap.parse_args()
    if args.phase == "status":
        snap = load_json(FINE_ROOT / "CURRENT" / "US_FINE_GRAINED_SNAPSHOT_CURRENT.json")
        ptr = load_json(CURRENT_POINTER)
        print(json.dumps({"status": snap.get("STATUS"), "phase": snap.get("PHASE"), "us_date": snap.get("US_MARKET_DATE"), "pointer": ptr.get("STATUS")}, indent=2))
        return 0
    t0 = time.time()
    heartbeat("US_FINE", "START", 0, 1, note=f"phase={args.phase}")
    result = run_collector(phase=args.phase, cn_folder=args.cn_date)
    heartbeat("US_FINE", "DONE", 1, 1, note=f"elapsed={time.time()-t0:.1f}s")
    return 0 if result["acceptance"]["FINAL_STATUS"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
