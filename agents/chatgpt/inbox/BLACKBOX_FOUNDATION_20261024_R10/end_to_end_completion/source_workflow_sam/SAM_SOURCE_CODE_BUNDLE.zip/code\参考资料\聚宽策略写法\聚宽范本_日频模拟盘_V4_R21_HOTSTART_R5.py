# STRATEGY_VERSION=V4_R21_LOW_POSITION_REVERSAL_HOTSTART_R5_ETF_ALIGNED
# SOURCE_SHA=c0ac8b48aea1cd5599e522b78a24a919195da75568d221f0a6698e14c24a376c
# SIMULATION_HOT_REPLACE=YES
# BACKTEST_PROBE_HTTP=ZERO_AMOUNT_ONCE | HISTORICAL_TRADE_HTTP=NO | SIMULATION_BRIDGE_ENABLED=YES | HOTSTART_FORCE_FIRST_REBALANCE=YES
# 本文件由R4研究版生成：回测使用BACKTEST_PROBE_ONLY：仅允许一次0股真实HTTP探针，不发送历史交易订单；模拟盘恢复正常桥接。热替换首个可交易日09:20重算；09:30若当前持股不是当日排名第一名，则卖旧买第一名；当日无排名或第一名不可交易时保留旧仓。
# -*- coding: utf-8 -*-
# ============================================================
# 盘后热启动恢复版：买入/调仓主链恢复09:30，真实交易闸09:30:02；14:50非目标退出保持不变。
# QMT回执审计：桥接HTTP 200仅标记服务器接收成功，不再表述为QMT已成交；日志额外打印服务器msg与真实墙上时间。
# 本版用于同一R21模拟盘热替换：保留真实账户持仓/现金，但首个可交易日强制以V4重新排名并重置两交易日周期；不含一次性账户迁移。
# 单票持仓变体：仅将 g.stock_num 从 5 改为 1；其余R21、探针、热启动与桥接逻辑不变。
# R4 V4 长期低位短反转增强｜F0+L3+C1+RANK_B｜模拟盘热启动R2
# ============================================================
# 母策略：R20 绩优小市值（低PB -> ROE改善 -> 行业共振优先 -> 小流通市值）
#
# R21 顶层选股 + 轮换（不调 50%/10%/持仓数/共振阈值）：
# 1. 取消 EPS>0 硬门槛：允许亏损但 ROE 改善的标的进入池。
# 2. 最终排序：行业共振优先 -> BIAS60 升序 -> DAVOL5 降序 -> 流通市值升序。
# 3. 轮换：每 2 个交易日调仓（calendar_N2）。
# 4. 时点/撮合（对齐聚宽实盘）：09:30 先卖未封死非目标腾现金，保留仍在目标的仓，
#    再按 total_value/N + 100股整手补缺；开盘封死的非目标留到 14:50。
#    研究对照：理想整篮开买/收卖更高，但不如本撮合贴近实盘（见 RESEARCH_NOTE）。
# 5. 板块：科创/创业/北交先屏蔽再选股（exclude_kcb/cyb/bse=True）。
# 6. BIAS20 零轴退出默认关。
#
# 回测规则 SSOT：同目录 RESEARCH_NOTE.md
# 公式（规则库 factor_260_formula_CURRENT.csv）：
#   BIAS60 = (close - MA60(close)) / MA60(close) * 100
#   BIAS20 = (close - MA20(close)) / MA20(close) * 100
#   DAVOL5 = MA5(换手率) / MA120(换手率)
#   日换手率 ~ volume / (circulating_market_cap*1e8/close)
#
# PIT：选股截面一律用上一完整交易日 signal_date；get_fundamentals(..., date=signal_date)；
#      get_price end_date=signal_date；禁止 statDate 强取未披露财报。
# 聚宽建议：set_option('use_real_price', True)；set_option('avoid_future_data', True)。
#
# 本文件为聚宽模拟盘/实盘桥接版：保留R21策略逻辑，接入R20实盘探针、热启动、交易账本与易宽/QMT桥接码。
#
# 实盘层接入边界：
# - 不改变R21的PB/ROE/行业共振/BIAS60/DAVOL5/小流通市值排序；
# - 不改变每2交易日轮换、09:30买卖、09:35可选BIAS20退出、14:50非目标退出；
# - 仅新增R20探针、事件资金巡查、热启动重挂、交易账本和易宽/QMT桥接码。
# ============================================================

from jqdata import *
import numpy as np
import pandas as pd
import datetime as py_datetime
import json
import hashlib
import hmac
import time as py_time

try:
    import requests
except Exception:
    requests = None

BATCH_SIZE_PRICE = 300
BATCH_SIZE_INDUSTRY = 300
HISTORY_FUNDAMENTAL_BATCH_SIZE = 1000
REFERENCE_SECURITY = '000300.XSHG'

REMAINING_INDUSTRY_FILTERS = [
    '石油石化I',
    '房地产I',
    '交通运输I',
    '环保I',
    '银行I',
    '非银金融I',
]

def _safe_log_warning(message):
    try:
        log.warning(message)
    except Exception:
        try:
            log.warn(message)
        except Exception:
            pass

def get_name(security):
    try:
        return get_current_data()[security].name
    except Exception:
        try:
            return get_security_info(security).display_name
        except Exception:
            return '未知'

# ==================== 易宽 / QMT 桥接层（沿用此前小市值实盘配置） ====================
eq_user_name = 'zwdjwsam'
eq_user_key = 'ad16011be19c518fc5c20de076fc044c'
eq_strategy_name = '999'
eq_bridge_base_url = 'http://47.112.126.183:8000/eq/openapi'
eq_bridge_api_path = '/api/jq/v1/signals/putOrder'
eq_require_https_for_bridge = False
eq_bridge_request_timeout_seconds = 30
eq_send_non_today_signal = False

# 调度仍注册在09:30；真实/模拟盘订单及桥接HTTP最早09:30:02释放。
eq_live_trade_not_before_time = py_datetime.time(9, 30, 2)
eq_live_trade_preopen_wait_max_seconds = 600

def _bridge_new_day_summary():
    return {'sent': 0, 'dry_run': 0, 'failed': 0, 'skipped': 0}
def _trade_new_ledger_summary():
    return {'buy_total': 0, 'sell_total': 0, 'buy_amount': 0.0, 'sell_amount': 0.0}
def _bridge_context_date(context):
    try:
        if context is not None and getattr(context, 'current_dt', None) is not None:
            return context.current_dt.date()
    except Exception:
        pass
    return py_datetime.datetime.now().date()
def _bridge_wall_date():
    return py_datetime.datetime.now().date()
def _bridge_run_type(context):
    candidates = []
    try:
        candidates.append(getattr(context, 'run_type', ''))
    except Exception:
        pass
    try:
        params = getattr(context, 'run_params', None)
        candidates.append(getattr(params, 'type', ''))
        candidates.append(getattr(params, 'run_type', ''))
    except Exception:
        pass
    for value in candidates:
        if value:
            return str(value).lower()
    return ''
def _is_backtest_context(context):
    run_type = _bridge_run_type(context)
    if ('backtest' in run_type) or ('back_test' in run_type) or ('回测' in run_type):
        return True
    try:
        context_date = _bridge_context_date(context)
        wall_date = _bridge_wall_date()
        if context_date < (wall_date - py_datetime.timedelta(days=2)):
            return True
    except Exception:
        pass
    return False
def _bridge_should_shadow_verify(context):
    try:
        return bool(getattr(g, 'bridge_backtest_shadow_verify', True)) and _is_backtest_context(context)
    except Exception:
        return False
def _bridge_runtime_mode(context=None):
    if not eq_user_key:
        return 'DRY_RUN_KEY_EMPTY'
    if eq_require_https_for_bridge and not str(eq_bridge_base_url).lower().startswith('https://'):
        return 'LIVE_BLOCKED_HTTPS_REQUIRED'
    if _is_backtest_context(context):
        return 'BACKTEST_PROBE_ONLY'
    if bool(getattr(g, 'bridge_live_send_enabled', True)):
        return 'LIVE'
    return 'DRY_RUN_SWITCH_OFF'
def init_bridge_runtime_state(context=None):
    if not hasattr(g, 'bridge_live_send_enabled'):
        g.bridge_live_send_enabled = True
    if not hasattr(g, 'bridge_backtest_shadow_verify'):
        g.bridge_backtest_shadow_verify = False
    if not hasattr(g, 'bridge_backtest_probe_enabled'):
        g.bridge_backtest_probe_enabled = True
    if not hasattr(g, 'bridge_backtest_probe_sent'):
        g.bridge_backtest_probe_sent = False
    if not hasattr(g, 'bridge_backtest_probe_result'):
        g.bridge_backtest_probe_result = 'NOT_RUN'
    if not hasattr(g, 'bridge_day_summary') or not isinstance(g.bridge_day_summary, dict):
        g.bridge_day_summary = _bridge_new_day_summary()
    if not hasattr(g, 'bridge_event_today') or not isinstance(g.bridge_event_today, list):
        g.bridge_event_today = []
    if not hasattr(g, 'trade_ledger_today') or not isinstance(g.trade_ledger_today, list):
        g.trade_ledger_today = []
    if not hasattr(g, 'trade_ledger_summary') or not isinstance(g.trade_ledger_summary, dict):
        g.trade_ledger_summary = _trade_new_ledger_summary()
    if not hasattr(g, 'bridge_selfcheck_logged_once'):
        g.bridge_selfcheck_logged_once = False
    if not hasattr(g, 'bridge_last_selfcheck_signature'):
        g.bridge_last_selfcheck_signature = ''
    g.bridge_runtime_mode = _bridge_runtime_mode(context)
def _bridge_signature(user_key, timestamp, data):
    sorted_data = json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
    sign_string = '%s%s' % (sorted_data, timestamp)
    user_key_hash = hashlib.sha256(str(user_key).encode('utf-8')).digest()
    return hmac.new(user_key_hash, sign_string.encode('utf-8'), hashlib.sha256).hexdigest()
def _bridge_order_add_time(context, order_result=None):
    try:
        add_time = getattr(order_result, 'add_time', None)
        if add_time:
            return add_time
    except Exception:
        pass
    try:
        return context.current_dt
    except Exception:
        return py_datetime.datetime.now()
def _build_bridge_payload(context, security, is_buy, amount, price, order_result=None):
    add_time = _bridge_order_add_time(context, order_result)
    order_id = ''
    try:
        order_id = str(getattr(order_result, 'order_id', '') or '')
    except Exception:
        pass
    if not order_id:
        order_id = '%s_%s_%s_%s' % (
            str(security),
            'BUY' if bool(is_buy) else 'SELL',
            str(getattr(context, 'current_dt', '')),
            int(abs(amount or 0)),
        )
    return {
        'orderStatus': str(getattr(order_result, 'status', '')),
        'addTime': str(add_time),
        'isBuy': str(bool(is_buy)),
        'amount': int(abs(amount or 0)),
        'filled': int(getattr(order_result, 'filled', 0) or 0),
        'security': str(security),
        'orderId': order_id,
        'price': float(price or 0.0),
        'avgCost': float(getattr(order_result, 'avg_cost', price or 0.0) or 0.0),
        'side': str(getattr(order_result, 'side', '')),
        'action': str(getattr(order_result, 'action', '')),
        'commission': float(getattr(order_result, 'commission', 0.0) or 0.0),
        'stName': str(eq_strategy_name),
    }
def _bridge_payload_is_context_today(context, payload):
    try:
        add_day = str((payload or {}).get('addTime', ''))[:10]
        context_day = str(_bridge_context_date(context))
        return (not add_day) or (add_day == context_day)
    except Exception:
        return True
def _ensure_bridge_daily_books(context):
    today_key = str(_bridge_context_date(context))
    if getattr(g, 'bridge_trade_day', None) != today_key:
        g.bridge_trade_day = today_key
        g.bridge_day_summary = _bridge_new_day_summary()
        g.bridge_event_today = []
        g.trade_ledger_summary = _trade_new_ledger_summary()
        g.trade_ledger_today = []
def record_bridge_event(context, event_type, payload=None, extra=''):
    try:
        _ensure_bridge_daily_books(context)
        if event_type in g.bridge_day_summary:
            g.bridge_day_summary[event_type] = int(g.bridge_day_summary.get(event_type, 0) or 0) + 1
        g.bridge_event_today.append({
            'dt': str(getattr(context, 'current_dt', '')),
            'event_type': str(event_type),
            'security': str((payload or {}).get('security', '')),
            'is_buy': str((payload or {}).get('isBuy', '')),
            'extra': str(extra or '')[:200],
        })
    except Exception:
        pass
def _record_trade_ledger(context, security, is_buy, amount, price, money, reason='调仓', order_result=None):
    try:
        _ensure_bridge_daily_books(context)
        item = {
            'dt': str(getattr(context, 'current_dt', '')),
            'security': str(security),
            'name': get_name(security),
            'is_buy': bool(is_buy),
            'amount': int(abs(amount or 0)),
            'price': round(float(price or 0.0), 4),
            'money': round(float(money or 0.0), 2),
            'reason': str(reason),
            'order_id': str(getattr(order_result, 'order_id', '')),
        }
        g.trade_ledger_today.append(item)
        if bool(is_buy):
            g.trade_ledger_summary['buy_total'] += 1
            g.trade_ledger_summary['buy_amount'] += float(money or 0.0)
        else:
            g.trade_ledger_summary['sell_total'] += 1
            g.trade_ledger_summary['sell_amount'] += float(money or 0.0)
        log.info('📒 交易账本 | %s %s %s | 数量=%s | 金额=%.2f | 原因=%s' % (
            '买入' if is_buy else '卖出',
            str(security),
            get_name(security),
            int(abs(amount or 0)),
            float(money or 0.0),
            str(reason),
        ))
    except Exception as error:
        _safe_log_warning('交易账本记录异常：%s' % str(error))
def log_bridge_config_selfcheck_if_needed(context=None, force=False):
    try:
        init_bridge_runtime_state(context)
        mode = _bridge_runtime_mode(context)
        signature = '%s|%s|%s|%s|%s' % (
            str(mode),
            '1' if bool(eq_user_key) else '0',
            '1' if bool(getattr(g, 'bridge_live_send_enabled', True)) else '0',
            '1' if bool(eq_require_https_for_bridge) else '0',
            str(eq_strategy_name),
        )
        if (
            not force
            and bool(getattr(g, 'bridge_selfcheck_logged_once', False))
            and str(getattr(g, 'bridge_last_selfcheck_signature', '')) == signature
        ):
            return
        g.bridge_selfcheck_logged_once = True
        g.bridge_last_selfcheck_signature = signature
        log.info('[桥接自检] 模式=%s | 密钥=%s | 实盘发送=%s | 策略名=%s | HTTPS要求=%s | URL=%s' % (
            mode,
            '已配置' if bool(eq_user_key) else '未配置',
            '开启' if bool(getattr(g, 'bridge_live_send_enabled', True)) else '关闭',
            str(eq_strategy_name),
            '是' if bool(eq_require_https_for_bridge) else '否',
            str(eq_bridge_base_url),
        ))
    except Exception as error:
        _safe_log_warning('[桥接自检异常] %s' % str(error))
def _is_live_trade_time_gate_context(context):
    if _bridge_should_shadow_verify(context):
        return False
    if _is_backtest_context(context):
        return False
    return True
def _live_trade_wall_gate_093002(context, tag='live_trade_gate', security=''):
    """调度仍为09:30；仅防止模拟盘调度提前进入真实订单链。"""
    try:
        if not _is_live_trade_time_gate_context(context):
            return True
        now_dt = py_datetime.datetime.now()
        gate_dt = py_datetime.datetime.combine(now_dt.date(), eq_live_trade_not_before_time)
        if now_dt >= gate_dt:
            return True
        wait_seconds = float((gate_dt - now_dt).total_seconds())
        if wait_seconds > float(eq_live_trade_preopen_wait_max_seconds or 600):
            log.info('[09:30:02交易时间闸] 跳过 | tag=%s | security=%s | wall=%s | wait=%.1f' % (
                str(tag), str(security), now_dt.strftime('%H:%M:%S'), wait_seconds
            ))
            return False
        log.info('[09:30:02交易时间闸] 提前到达，等待释放 | tag=%s | security=%s | wait=%.1f' % (
            str(tag), str(security), wait_seconds
        ))
        py_time.sleep(max(0.0, wait_seconds))
        return True
    except Exception as error:
        _safe_log_warning('[09:30:02交易时间闸异常] 放行 | %s' % str(error))
        return True
def backtest_bridge_probe_0921(context):
    """回测盘前链路验证：真实HTTP只发一次0股探针；不发送任何历史买卖数量。"""
    try:
        ensure_runtime_defaults(context)
        if not _is_backtest_context(context):
            return
        if not bool(getattr(g, 'bridge_backtest_probe_enabled', True)):
            log.info('[回测桥接探针] 已关闭')
            return
        if bool(getattr(g, 'bridge_backtest_probe_sent', False)):
            return
        g.bridge_backtest_probe_sent = True

        ranked = list(getattr(g, 'weekly_ranked_candidates', []) or [])
        held = _held_codes(context) if '_held_codes' in globals() else []
        security = str(ranked[0] if ranked else (held[0] if held else '000001.XSHE'))
        try:
            item = get_current_data()[security]
            price = float(getattr(item, 'last_price', 0) or getattr(item, 'day_open', 0) or 0)
        except Exception:
            price = 0.0

        now = py_datetime.datetime.now()
        payload = {
            'orderStatus': 'PREOPEN_PROBE_ONLY',
            'addTime': str(now),
            'isBuy': str(True),
            'amount': 0,
            'filled': 0,
            'security': security,
            'orderId': 'PREOPEN_PROBE_%s' % now.strftime('%Y%m%d%H%M%S%f'),
            'price': float(price),
            'avgCost': float(price),
            'side': 'test',
            'action': 'test',
            'commission': 0.0,
            'stName': str(eq_strategy_name),
        }
        if not eq_user_key:
            g.bridge_backtest_probe_result = 'NO_KEY'
            log.error('[回测桥接探针] 失败：密钥为空')
            return
        if eq_require_https_for_bridge and not str(eq_bridge_base_url).lower().startswith('https://'):
            g.bridge_backtest_probe_result = 'HTTPS_BLOCKED'
            log.error('[回测桥接探针] 失败：https要求未满足')
            return
        if requests is None:
            g.bridge_backtest_probe_result = 'REQUESTS_UNAVAILABLE'
            log.error('[回测桥接探针] 失败：requests不可用')
            return

        timestamp = int(now.timestamp() * 1000)
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'eq_user_name': eq_user_name,
            'eq_user_key': eq_user_key,
            'eq_timestamp': str(timestamp),
            'eq_sign': _bridge_signature(eq_user_key, timestamp, payload),
        }
        url = str(eq_bridge_base_url).rstrip('/') + str(eq_bridge_api_path)
        response = requests.post(
            url=url, json=payload, headers=headers,
            timeout=float(eq_bridge_request_timeout_seconds or 30),
        )
        status_code = int(getattr(response, 'status_code', 0) or 0)
        try:
            response_data = response.json()
        except Exception:
            response_data = {'raw_text': str(getattr(response, 'text', ''))[:500]}
        if status_code == 200 and isinstance(response_data, dict) and response_data.get('code') == 200:
            g.bridge_backtest_probe_result = 'SERVER_ACCEPTED_QMT_RECEIPT_TO_VERIFY'
            record_bridge_event(context, 'sent', payload, 'zero_amount_preopen_probe')
            log.info('[回测桥接探针] 服务器接收成功_需在QMT端核对是否收到 | security=%s | amount=0 | stName=%s | server_msg=%s' % (
                security, str(eq_strategy_name), str(response_data.get('msg', ''))[:160]
            ))
            return
        g.bridge_backtest_probe_result = 'SERVER_REJECTED_%s' % status_code
        record_bridge_event(context, 'failed', payload, str(response_data)[:160])
        log.error('[回测桥接探针] 服务器拒绝 | status=%s | response=%s' % (
            status_code, str(response_data)[:220]
        ))
    except Exception as error:
        g.bridge_backtest_probe_result = 'EXCEPTION'
        _safe_log_warning('[回测桥接探针异常] %s' % str(error)[:220])

def maybe_send_bridge_signal(context, security, is_buy, amount, price, order_result=None, reason='调仓'):
    # 回测只允许09:21一次0股真实HTTP探针；所有历史交易数量一律拦截。模拟盘/实盘按原桥接配置发送。
    init_bridge_runtime_state(context)
    payload = _build_bridge_payload(
        context, security, is_buy, amount, price, order_result=order_result
    )

    if _is_backtest_context(context):
        record_bridge_event(context, 'skipped', payload, 'historical_trade_blocked_probe_only')
        log.info('[BACKTEST_PROBE_ONLY] 历史交易信号不外发 | %s %s | amount=%s | reason=%s | probe_result=%s' % (
            '买入' if is_buy else '卖出', str(security), int(abs(amount or 0)), str(reason),
            str(getattr(g, 'bridge_backtest_probe_result', 'NOT_RUN'))
        ))
        return False

    if not bool(getattr(g, 'bridge_live_send_enabled', True)) or not eq_user_key:
        record_bridge_event(context, 'dry_run', payload, 'bridge_live_disabled_or_key_empty')
        return False

    if (not bool(eq_send_non_today_signal)) and (not _bridge_payload_is_context_today(context, payload)):
        record_bridge_event(context, 'skipped', payload, 'non_context_today_signal_blocked')
        log.info('🌉 桥接拦截 | 非context当日信号 | security=%s | addTime=%s' % (
            str(security), str(payload.get('addTime', ''))
        ))
        return False

    if eq_require_https_for_bridge and not str(eq_bridge_base_url).lower().startswith('https://'):
        record_bridge_event(context, 'failed', payload, 'https_required')
        return False

    if requests is None:
        record_bridge_event(context, 'failed', payload, 'requests_unavailable')
        return False

    if bool(is_buy):
        if not _live_trade_wall_gate_093002(context, tag='bridge_before_buy_http', security=str(security)):
            record_bridge_event(context, 'skipped', payload, 'buy_before_093002_gate_blocked')
            return False

    try:
        timestamp = int(py_datetime.datetime.now().timestamp() * 1000)
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'eq_user_name': eq_user_name,
            'eq_user_key': eq_user_key,
            'eq_timestamp': str(timestamp),
            'eq_sign': _bridge_signature(eq_user_key, timestamp, payload),
        }
        url = str(eq_bridge_base_url).rstrip('/') + str(eq_bridge_api_path)
        response = requests.post(
            url=url,
            json=payload,
            headers=headers,
            timeout=float(eq_bridge_request_timeout_seconds or 30),
        )
        status_code = int(getattr(response, 'status_code', 0) or 0)
        try:
            response_data = response.json()
        except Exception:
            response_data = {'raw_text': str(getattr(response, 'text', ''))[:500]}

        if status_code == 200 and isinstance(response_data, dict) and response_data.get('code') == 200:
            server_msg = str(response_data.get('msg', ''))[:160]
            record_bridge_event(context, 'sent', payload, 'server_accepted_not_qmt_filled')
            log.info('🌉 桥接服务器接收成功_不代表QMT成交 | %s %s | orderId=%s | stName=%s | wall=%s | server_msg=%s' % (
                str(security), get_name(security), str(payload.get('orderId', '')), str(eq_strategy_name),
                py_datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), server_msg
            ))
            return True

        message = str(response_data.get('msg', response_data)) if isinstance(response_data, dict) else str(response_data)
        record_bridge_event(context, 'failed', payload, 'status=%s msg=%s' % (status_code, message[:120]))
        log.info('🌉 桥接发送失败 | %s | status=%s | msg=%s' % (
            str(security), status_code, message[:120]
        ))
        return False
    except Exception as error:
        record_bridge_event(context, 'failed', payload, str(error))
        log.info('🌉 桥接发送异常 | %s | %s' % (str(security), str(error)[:160]))
        return False
def _safe_unschedule_all_for_jq():
    try:
        unschedule_all()
        log.info('[调度-清空] unschedule_all 完成')
        return True
    except Exception as error:
        _safe_log_warning('[调度-清空] unschedule_all 异常：%s' % str(error))
        return False

def _chunks(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]

def _to_date_safe(value):
    if hasattr(value, 'date'):
        try:
            return value.date()
        except Exception:
            pass
    if isinstance(value, py_datetime.date) and not isinstance(value, py_datetime.datetime):
        return value
    return pd.Timestamp(value).date()

def apply_strategy_parameters():
    g.stock_num = 1
    g.limit_days = 20
    g.industry_control = True
    g.industry_filter_list = list(REMAINING_INDUSTRY_FILTERS)
    g.industry_resonance_enabled = True
    g.industry_resonance_min_count = 3
    g.industry_resonance_min_up_ratio = 0.60
    g.industry_resonance_min_avg_return = 0.0
    # R21：允许亏损股；超跌量能排序；最优轮换=每2交易日
    g.allow_nonpositive_eps = True
    g.rank_mode = 'bias60_davol5_cap'
    g.rebalance_every_n_days = 2
    g.bias20_zero_cross_exit = False  # 同窗因子卖未优于时序，默认关
    g.limit_privilege_only_if_sealed = True
    # 时点：开盘买；换出：调仓日先卖未封死非目标，封死留 14:50
    g.buy_time_mode = 'open'
    g.sell_time_mode = 'close'  # close~14:50 尾盘卖仍封死后开板的非目标
    # 板块屏蔽: 全组合演算最优=科创关+创业关+北交关(短窗 REVIEW_REQUIRED)
    g.exclude_kcb = True   # 688
    g.exclude_cyb = True   # 300/301
    g.exclude_bse = True   # XBJ / BJ

def ensure_runtime_defaults(context=None):
    """热启动/进程恢复统一补齐运行状态；不改变R21策略参数。"""
    apply_strategy_parameters()

    if not hasattr(g, 'weekly_ranked_candidates') or not isinstance(g.weekly_ranked_candidates, list):
        g.weekly_ranked_candidates = []
    if not hasattr(g, 'weekly_resonance_meta') or not isinstance(g.weekly_resonance_meta, dict):
        g.weekly_resonance_meta = {}
    if not hasattr(g, 'weekly_factor_map') or not isinstance(g.weekly_factor_map, dict):
        g.weekly_factor_map = {}
    if not hasattr(g, 'weekly_cache_status'):
        g.weekly_cache_status = 'EMPTY'
    if not hasattr(g, 'weekly_cache_error'):
        g.weekly_cache_error = ''
    if not hasattr(g, 'weekly_cache_trade_date'):
        g.weekly_cache_trade_date = None
    if not hasattr(g, 'weekly_cache_signal_date'):
        g.weekly_cache_signal_date = None
    if not hasattr(g, 'high_limit_list') or not isinstance(g.high_limit_list, list):
        g.high_limit_list = []
    if not hasattr(g, 'hold_list') or not isinstance(g.hold_list, list):
        g.hold_list = []
    if not hasattr(g, 'target_list') or not isinstance(g.target_list, list):
        g.target_list = []
    if not hasattr(g, 'trade_day_index'):
        g.trade_day_index = -1

    # V4热启动与两交易日持有周期。账户持仓不迁移、不硬编码，始终以context.portfolio为准。
    if not hasattr(g, 'hot_start_force_rebalance_pending'):
        g.hot_start_force_rebalance_pending = False
    if not hasattr(g, 'hot_start_requested_date'):
        g.hot_start_requested_date = None
    if not hasattr(g, 'hot_start_snapshot_holdings') or not isinstance(g.hot_start_snapshot_holdings, dict):
        g.hot_start_snapshot_holdings = {}
    if not hasattr(g, 'last_successful_rebalance_date'):
        g.last_successful_rebalance_date = None
    if not hasattr(g, 'rebalance_due_today'):
        g.rebalance_due_today = False
    if not hasattr(g, 'pending_rebalance_target_list') or not isinstance(g.pending_rebalance_target_list, list):
        g.pending_rebalance_target_list = []
    if not hasattr(g, 'expected_target_amount_map') or not isinstance(g.expected_target_amount_map, dict):
        g.expected_target_amount_map = {}
    if not hasattr(g, 'sell_orders_submitted_today') or not isinstance(g.sell_orders_submitted_today, dict):
        g.sell_orders_submitted_today = {}
    if not hasattr(g, 'buy_orders_submitted_today') or not isinstance(g.buy_orders_submitted_today, dict):
        g.buy_orders_submitted_today = {}
    if not hasattr(g, 'trade_reconcile_attempts'):
        g.trade_reconcile_attempts = 0

    if not hasattr(g, 'event_patrol_last_state') or not isinstance(g.event_patrol_last_state, dict):
        g.event_patrol_last_state = {}
    if not hasattr(g, 'event_patrol_total_value_change_ratio'):
        g.event_patrol_total_value_change_ratio = 0.005
    if not hasattr(g, 'event_patrol_cash_change_abs'):
        g.event_patrol_cash_change_abs = 1000.0
    if not hasattr(g, 'light_probe_version'):
        g.light_probe_version = 'SMALLCAP_R21_BIAS_DAVOL_BRIDGE_PROBE_R1'
    if not hasattr(g, 'activation_probe_file'):
        g.activation_probe_file = 'smallcap_r21_activation_probe.json'
    if not hasattr(g, 'post_close_activation_probe_file'):
        g.post_close_activation_probe_file = 'smallcap_r21_post_close_activation_probe.json'
    if not hasattr(g, 'hard_probe_file_0931'):
        g.hard_probe_file_0931 = 'smallcap_r21_live_alive_0931.json'
    if not hasattr(g, 'hard_probe_file_1030'):
        g.hard_probe_file_1030 = 'smallcap_r21_live_alive_1030.json'
    if not hasattr(g, 'hard_probe_file_1440'):
        g.hard_probe_file_1440 = 'smallcap_r21_live_alive_1440.json'
    if not hasattr(g, 'hard_probe_file_1456'):
        g.hard_probe_file_1456 = 'smallcap_r21_live_alive_1456.json'
    if not hasattr(g, 'hard_probe_file_1510'):
        g.hard_probe_file_1510 = 'smallcap_r21_live_alive_1510.json'
    if not hasattr(g, 'hard_probe_file_1530'):
        g.hard_probe_file_1530 = 'smallcap_r21_live_alive_1530.json'

    init_bridge_runtime_state(context)

def _runtime_position_snapshot(context):
    total_value = float(getattr(context.portfolio, 'total_value', 0.0) or 0.0)
    cash = float(getattr(context.portfolio, 'cash', getattr(context.portfolio, 'available_cash', 0.0)) or 0.0)
    available_cash = float(getattr(context.portfolio, 'available_cash', cash) or 0.0)
    holdings = []
    try:
        for security, position in context.portfolio.positions.items():
            amount = int(getattr(position, 'total_amount', 0) or 0)
            if amount > 0:
                holdings.append('%s:%s' % (str(security), amount))
    except Exception:
        pass
    holdings.sort()
    return {
        'dt': str(getattr(context, 'current_dt', '')),
        'total_value': total_value,
        'cash': cash,
        'available_cash': available_cash,
        'positions': len(holdings),
        'holdings_key': '|'.join(holdings),
    }
def _position_amount_map(context):
    """读取聚宽模拟盘真实持仓股数；不使用旧缓存，不写死天齐股数。"""
    out = {}
    try:
        for code in list(context.portfolio.positions.keys()):
            pos = context.portfolio.positions[code]
            amount = int(getattr(pos, 'total_amount', 0) or 0)
            if amount > 0:
                out[str(code)] = amount
    except Exception:
        pass
    return out

def _log_hot_start_position_snapshot(context, source='unknown'):
    snapshot = _position_amount_map(context)
    g.hot_start_snapshot_holdings = dict(snapshot)
    log.info('[V4热启动持仓快照] source=%s | holdings=%s | count=%s | cash=%.2f | total_value=%.2f' % (
        str(source), str(snapshot), len(snapshot),
        float(getattr(context.portfolio, 'available_cash', 0.0) or 0.0),
        float(getattr(context.portfolio, 'total_value', 0.0) or 0.0),
    ))
    return snapshot

def _trade_date(context):
    try:
        return context.current_dt.date()
    except Exception:
        return _bridge_context_date(context)

def _trading_days_elapsed(start_date, end_date):
    """含起止日期的交易日序列减1：买入日为0，下一交易日为1，第二个交易日为2。"""
    if start_date is None or end_date is None:
        return None
    try:
        s = _to_date_safe(start_date)
        e = _to_date_safe(end_date)
        days = list(get_trade_days(start_date=s, end_date=e))
        return max(0, len(days) - 1)
    except Exception as error:
        _safe_log_warning('[两日周期计算失败] start=%s end=%s error=%s' % (
            str(start_date), str(end_date), str(error)[:160]
        ))
        return None

def _rebalance_due_today(context):
    """热替换首个可交易日强制评估；评估完成后按上次成功评估日起每2交易日再评估。"""
    if bool(getattr(g, 'hot_start_force_rebalance_pending', False)):
        return True
    today = _trade_date(context)
    last_date = getattr(g, 'last_successful_rebalance_date', None)
    if last_date is None:
        return True
    elapsed = _trading_days_elapsed(last_date, today)
    if elapsed is None:
        return False
    g.trade_day_index = int(elapsed)
    return int(elapsed) >= max(1, int(getattr(g, 'rebalance_every_n_days', 2)))

def _cache_usable_for_today(context):
    return (
        getattr(g, 'weekly_cache_status', '') == 'OK'
        and getattr(g, 'weekly_cache_trade_date', None) == _trade_date(context)
        and isinstance(getattr(g, 'weekly_ranked_candidates', None), list)
    )

def _mark_rebalance_cycle_complete(context, source='alignment_pass'):
    today = _trade_date(context)
    g.last_successful_rebalance_date = today
    g.hot_start_force_rebalance_pending = False
    g.hot_start_requested_date = None
    g.rebalance_due_today = False
    g.trade_day_index = 0
    g.trade_reconcile_attempts = 0
    g.pending_rebalance_target_list = []
    g.expected_target_amount_map = {}
    log.info('[V4两日周期重置] source=%s | last_successful_rebalance_date=%s | next_due=第二个后续交易日' % (
        str(source), str(today)
    ))

def _target_alignment_state(context):
    target = list(getattr(g, 'pending_rebalance_target_list', []) or [])
    actual = _position_amount_map(context)
    expected = dict(getattr(g, 'expected_target_amount_map', {}) or {})
    target_set = set(target)
    non_target = {code: amount for code, amount in actual.items() if code not in target_set}
    missing = [code for code in target if int(actual.get(code, 0) or 0) <= 0]
    quantity_mismatch = {}
    for code in target:
        exp = int(expected.get(code, 0) or 0)
        act = int(actual.get(code, 0) or 0)
        if exp > 0 and act != exp:
            quantity_mismatch[code] = {'expected': exp, 'actual': act}
    aligned = bool(target) and not non_target and not missing and not quantity_mismatch and len(actual) == len(target)
    return {
        'aligned': aligned,
        'target': target,
        'actual': actual,
        'expected': expected,
        'non_target': non_target,
        'missing': missing,
        'quantity_mismatch': quantity_mismatch,
    }

def _audit_and_finalize_rebalance(context, source='audit'):
    state = _target_alignment_state(context)
    log.info('[V4持仓股数对齐] source=%s | aligned=%s | target=%s | expected=%s | actual=%s | non_target=%s | missing=%s | qty_mismatch=%s' % (
        str(source), str(state['aligned']), str(state['target']), str(state['expected']),
        str(state['actual']), str(state['non_target']), str(state['missing']),
        str(state['quantity_mismatch'])
    ))
    if state['aligned']:
        _mark_rebalance_cycle_complete(context, source=source)
        return True
    return False

def runtime_alive_probe(context, tag='runtime_alive_probe'):
    try:
        snapshot = _runtime_position_snapshot(context)
        log.info('[调度-探针] %s | total_value=%.2f | cash=%.2f | available_cash=%.2f | positions=%s' % (
            str(tag),
            float(snapshot['total_value']),
            float(snapshot['cash']),
            float(snapshot['available_cash']),
            int(snapshot['positions']),
        ))
    except Exception as error:
        _safe_log_warning('[调度-探针异常] %s | %s' % (str(tag), str(error)))
def event_triggered_fund_patrol(context, tag='event_patrol', force=False, write_file_name=None):
    try:
        ensure_runtime_defaults(context)
        snapshot = _runtime_position_snapshot(context)
        last = getattr(g, 'event_patrol_last_state', {}) or {}
        reasons = []
        if not last:
            reasons.append('first_snapshot')
        elif snapshot.get('positions') != last.get('positions'):
            reasons.append('positions_changed')
        elif snapshot.get('holdings_key') != last.get('holdings_key'):
            reasons.append('holdings_changed')

        if last:
            cash_delta = abs(float(snapshot.get('available_cash', 0.0)) - float(last.get('available_cash', 0.0)))
            if cash_delta >= float(getattr(g, 'event_patrol_cash_change_abs', 1000.0)):
                reasons.append('cash_changed')
            base_value = max(1.0, abs(float(last.get('total_value', 0.0) or 0.0)))
            value_delta_ratio = abs(float(snapshot.get('total_value', 0.0)) - float(last.get('total_value', 0.0))) / base_value
            if value_delta_ratio >= float(getattr(g, 'event_patrol_total_value_change_ratio', 0.005)):
                reasons.append('total_value_changed')

        if force:
            reasons.append('hard_probe')
        g.event_patrol_last_state = snapshot
        if not reasons:
            return False

        log.info('[事件资金巡查] %s | reason=%s | total_value=%.2f | cash=%.2f | available_cash=%.2f | positions=%s' % (
            str(tag), ','.join(reasons), float(snapshot['total_value']), float(snapshot['cash']),
            float(snapshot['available_cash']), int(snapshot['positions'])
        ))

        if write_file_name:
            payload = dict(snapshot)
            payload['probe_version'] = str(getattr(g, 'light_probe_version', ''))
            payload['tag'] = str(tag)
            payload['reason'] = ','.join(reasons)
            payload['write_wall_time'] = py_datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            try:
                write_file(write_file_name, json.dumps(payload, ensure_ascii=False), append=False)
            except TypeError:
                write_file(write_file_name, json.dumps(payload, ensure_ascii=False))
        return True
    except Exception as error:
        _safe_log_warning('[事件资金巡查异常] %s | %s' % (str(tag), str(error)))
        return False
def post_close_activation_probe(context, source='unknown'):
    try:
        ensure_runtime_defaults(context)
        snapshot = _runtime_position_snapshot(context)
        payload = dict(snapshot)
        payload['probe_version'] = str(getattr(g, 'light_probe_version', ''))
        payload['source'] = str(source)
        payload['message'] = 'activation_probe_ok'
        payload['write_wall_time'] = py_datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log.info('[轻探针] 激活确认 | source=%s | dt=%s | wall=%s | total_value=%.2f | positions=%s' % (
            str(source), str(payload.get('dt', '')), str(payload.get('write_wall_time', '')),
            float(payload.get('total_value', 0.0)), int(payload.get('positions', 0))
        ))
        for file_name in [
            getattr(g, 'activation_probe_file', 'smallcap_activation_probe.json'),
            getattr(g, 'post_close_activation_probe_file', 'smallcap_post_close_activation_probe.json'),
        ]:
            try:
                write_file(file_name, json.dumps(payload, ensure_ascii=False), append=False)
            except TypeError:
                write_file(file_name, json.dumps(payload, ensure_ascii=False))
        return True
    except Exception as error:
        _safe_log_warning('[轻探针] 激活确认异常 | %s' % str(error))
        return False
def light_probe_0931(context):
    runtime_alive_probe(context, '09:31_light_probe')
    event_triggered_fund_patrol(context, '09:31_light_probe', True, getattr(g, 'hard_probe_file_0931'))
def light_probe_1030(context):
    runtime_alive_probe(context, '10:30_light_probe')
    event_triggered_fund_patrol(context, '10:30_light_probe', True, getattr(g, 'hard_probe_file_1030'))
    if getattr(g, 'pending_rebalance_target_list', None):
        _audit_and_finalize_rebalance(context, source='10:30')
def light_probe_1440(context):
    runtime_alive_probe(context, '14:40_light_probe')
    event_triggered_fund_patrol(context, '14:40_light_probe', True, getattr(g, 'hard_probe_file_1440'))
def light_probe_1456(context):
    runtime_alive_probe(context, '14:56_light_probe')
    event_triggered_fund_patrol(context, '14:56_light_probe', True, getattr(g, 'hard_probe_file_1456'))
def scheduled_eod_probe(context):
    runtime_alive_probe(context, '15:10_eod_probe')
    event_triggered_fund_patrol(context, '15:10_eod_probe', True, getattr(g, 'hard_probe_file_1510'))
def after_close_alive_probe(context):
    event_triggered_fund_patrol(context, 'after_close_1530_hard_probe', True, getattr(g, 'hard_probe_file_1530'))
    post_close_activation_probe(context, source='after_close_run_daily')
def after_trading_end(context):
    event_triggered_fund_patrol(context, 'after_trading_end', True, getattr(g, 'hard_probe_file_1510'))
    post_close_activation_probe(context, source='after_trading_end')

def prepare_yday_limit_list(context):
    """昨日收盘涨停的持仓名单（对照/日志用）。"""
    g.hold_list = [
        str(code) for code, pos in context.portfolio.positions.items()
        if float(getattr(pos, 'total_amount', 0) or 0) > 0
    ]
    g.high_limit_list = []
    if not g.hold_list:
        return
    try:
        df = get_price(
            g.hold_list,
            end_date=context.previous_date,
            frequency='daily',
            fields=['close', 'high_limit'],
            count=1,
            skip_paused=False,
            fq='pre',
            panel=False,
        )
        if df is None or len(df) == 0:
            return
        for code, group in df.groupby('code'):
            row = group.iloc[-1]
            cl = float(row.get('close') or 0)
            hl = float(row.get('high_limit') or 0)
            if hl > 0 and cl >= hl * 0.995:
                g.high_limit_list.append(str(code))
    except Exception as error:
        _safe_log_warning('[昨日涨停名单] %s' % str(error)[:160])
    log.info('[昨日涨停持仓] %s' % str(g.high_limit_list))

def _is_rebalance_day(context=None):
    if context is None:
        return bool(getattr(g, 'rebalance_due_today', False))
    return _rebalance_due_today(context)

def prepare_stock_list_cache_if_due(context):
    """09:20主计算。热替换首日无条件重算；其后按成功评估日起每2交易日重算。"""
    due = _rebalance_due_today(context)
    g.rebalance_due_today = bool(due)
    if not due:
        elapsed = _trading_days_elapsed(getattr(g, 'last_successful_rebalance_date', None), _trade_date(context))
        log.info('[V4两日持有] today=%s | last_rebalance=%s | elapsed=%s | 09:20不重算' % (
            str(_trade_date(context)), str(getattr(g, 'last_successful_rebalance_date', None)), str(elapsed)
        ))
        return
    log.info('[V4-09:20选股启动] today=%s | signal_date=%s | hot_start_force=%s | 当前持仓=%s' % (
        str(_trade_date(context)), str(context.previous_date),
        str(bool(getattr(g, 'hot_start_force_rebalance_pending', False))),
        str(_position_amount_map(context))
    ))
    prepare_stock_list_cache(context)

def retry_stock_list_cache_0925(context):
    """R20经验：09:20失败时只在09:25重试；09:30交易函数不重新全市场扫描。"""
    if not _rebalance_due_today(context):
        return
    if _cache_usable_for_today(context):
        log.info('[V4-09:25缓存重试跳过] 今日缓存已可用')
        return
    log.warning('[V4-09:25缓存重试] previous_status=%s | error=%s' % (
        str(getattr(g, 'weekly_cache_status', 'EMPTY')),
        str(getattr(g, 'weekly_cache_error', ''))[:180]
    ))
    prepare_stock_list_cache(context)

def _held_codes(context):
    """只枚举已有持仓键，避免对未持仓 code 访问 positions[code] 触发聚宽警告。"""
    held = []
    for code in list(context.portfolio.positions.keys()):
        try:
            pos = context.portfolio.positions[code]
            if float(getattr(pos, 'total_amount', 0) or 0) > 0:
                held.append(str(code))
        except Exception:
            continue
    return held

def rebalance_buy_open(context):
    """09:30：只读09:20/09:25缓存；当前持股仅在等于当日排名第一名时保留，否则换到第一名；空排名不卖。"""
    if not _rebalance_due_today(context):
        return
    g.rebalance_due_today = True
    weekly_adjustment_buy(context)

def rebalance_sell_close(context):
    """每日14:50：卖出仍持有的非目标（开盘因涨停暂留、尾盘已开板）。"""
    if not getattr(g, 'target_list', None):
        return
    sell_non_targets(context, reason='14:50近收盘卖非目标', force_check_sealed=True)
    if getattr(g, 'pending_rebalance_target_list', None):
        _audit_and_finalize_rebalance(context, source='14:50')

def sell_non_targets(context, reason='卖非目标', force_check_sealed=True):
    target_set = set(getattr(g, 'target_list', []) or [])
    current_data = get_current_data()
    for stock in _held_codes(context):
        if stock in target_set:
            continue
        position = context.portfolio.positions[stock]
        sealed_now = False
        try:
            last = float(getattr(current_data[stock], 'last_price', 0) or 0)
            high_limit = float(getattr(current_data[stock], 'high_limit', 0) or 0)
            sealed_now = high_limit > 0 and last >= high_limit * 0.999
        except Exception:
            pass
        if force_check_sealed and sealed_now:
            log.info('[暂留-仍封死] %s %s' % (stock, get_name(stock)))
            continue
        close_position(context, position, reason=reason)

def _select_first_tradeable_targets(context, ranked, target_count):
    """从完整排名向下找可交易标的，防止第一名停牌/封涨停后误卖旧仓并空仓。"""
    current_data = get_current_data()
    selected = []
    for stock in list(ranked or []):
        try:
            item = current_data[stock]
            if bool(getattr(item, 'paused', False)):
                continue
            last = float(getattr(item, 'last_price', 0) or 0)
            high_limit = float(getattr(item, 'high_limit', 0) or 0)
            if high_limit > 0 and last >= high_limit * 0.999:
                continue
            selected.append(str(stock))
            if len(selected) >= int(target_count):
                break
        except Exception:
            continue
    return selected

def weekly_adjustment_buy(context):
    """09:30按第一名执行：当前持股等于当日排名第一名则保留；否则卖旧买第一名；空排名不卖。"""
    today = _trade_date(context)
    held_amounts = _position_amount_map(context)
    held_codes = list(held_amounts.keys())

    if not _cache_usable_for_today(context):
        # 选股失败绝不卖旧仓；保留持仓并在下一交易日继续重试。
        g.target_list = list(held_codes)
        g.pending_rebalance_target_list = []
        log.error('[V4-09:30评估取消] 09:20/09:25缓存不可用，保留当前持仓和真实股数 | holdings=%s | status=%s | cache_date=%s | error=%s' % (
            str(held_amounts), str(getattr(g, 'weekly_cache_status', 'EMPTY')),
            str(getattr(g, 'weekly_cache_trade_date', None)),
            str(getattr(g, 'weekly_cache_error', ''))[:180]
        ))
        return False

    ranked = list(getattr(g, 'weekly_ranked_candidates', []) or [])
    if not ranked:
        # 当日没有任何有效排名：理论上不应强制卖出，下一交易日继续评估。
        g.target_list = list(held_codes)
        g.pending_rebalance_target_list = []
        log.warning('[V4-09:30空排名保留] ranked_n=0 | holdings=%s | 不卖出、不重置两日周期，下一交易日继续重算' % (
            str(held_amounts)
        ))
        return False

    # 单票策略若账户意外存在多只持仓，先fail-closed，避免热启动误清仓。
    if len(held_codes) > int(g.stock_num):
        g.target_list = list(held_codes)
        g.pending_rebalance_target_list = []
        log.error('[V4-09:30多持仓保护] stock_num=%s | holdings=%s | 不自动卖出，请先人工核对账户' % (
            int(g.stock_num), str(held_amounts)
        ))
        return False

    rank_index = {str(code): idx + 1 for idx, code in enumerate(ranked)}
    top1 = str(ranked[0])

    # 单票策略只保留当日第一名：当前唯一持股就是Top1时，保持原股数不动。
    if len(held_codes) == 1 and str(held_codes[0]) == top1:
        keep = top1
        g.target_list = [keep]
        g.pending_rebalance_target_list = [keep]
        g.expected_target_amount_map = {keep: int(held_amounts.get(keep, 0) or 0)}
        g.sell_orders_submitted_today = {}
        g.buy_orders_submitted_today = {}
        g.trade_reconcile_attempts = 0
        log.info('[V4-09:30持股仍为第一名_继续持有] stock=%s %s | rank=1/%s | amount=%s | ranked_top5=%s' % (
            keep, get_name(keep), len(ranked),
            int(held_amounts.get(keep, 0) or 0), str(ranked[:5])
        ))
        _audit_and_finalize_rebalance(context, source='09:30_held_is_top1')
        return True

    # 目标必须严格是排名第一名，不向第二名及以后递补。
    target_list = _select_first_tradeable_targets(context, [top1], 1)
    if not target_list:
        g.target_list = list(held_codes)
        g.pending_rebalance_target_list = []
        log.error('[V4-09:30第一名不可交易_保留旧仓] top1=%s | holdings=%s | 不卖出、不向后递补' % (
            top1, str(held_amounts)
        ))
        return False

    g.target_list = list(target_list)
    g.pending_rebalance_target_list = list(target_list)
    g.expected_target_amount_map = {}
    g.sell_orders_submitted_today = {}
    g.buy_orders_submitted_today = {}
    g.trade_reconcile_attempts = 0

    target_set = set(target_list)
    if held_codes:
        held_rank = {code: rank_index.get(code, 'OUT') for code in held_codes}
        log.info('[V4-09:30持股非第一名_执行换仓] before=%s | held_rank=%s | top1=%s | signal_date=%s | ranked_top5=%s' % (
            str(held_amounts), str(held_rank), top1, str(context.previous_date), str(ranked[:5])
        ))
        sell_non_targets(context, reason='09:30_V4持股非第一名卖出', force_check_sealed=True)
    else:
        log.info('[V4-09:30空仓建仓] target=%s | signal_date=%s | ranked_top5=%s' % (
            str(target_list), str(context.previous_date), str(ranked[:5])
        ))

    current_after_sell = _position_amount_map(context)
    for code in target_list:
        if int(current_after_sell.get(code, 0) or 0) > 0:
            g.expected_target_amount_map[code] = int(current_after_sell[code])

    missing = [s for s in target_list if int(current_after_sell.get(s, 0) or 0) <= 0]
    if missing:
        per_value = float(context.portfolio.total_value) / max(len(target_list), 1)
        for stock in missing:
            cash = float(context.portfolio.available_cash)
            value = min(per_value, cash)
            if value < 1000:
                log.warning('[V4-09:30买入暂缓] 卖出现金尚未释放 | stock=%s | cash=%.2f | 09:32仅在未提交买单时补买' % (
                    str(stock), cash
                ))
                continue
            filled = order_value_lot100(context, stock, value, cash, reason='09:30_V4买入排名第一名')
            if filled:
                g.expected_target_amount_map[stock] = int(filled[1])
                log.info('[V4-09:30开盘买入] %s %s | value~%.0f amount=%s' % (
                    stock, get_name(stock), filled[0], filled[1]
                ))

    _audit_and_finalize_rebalance(context, source='09:30_after_top1_switch_orders')
    return True

def reconcile_hot_start_trade_0932(context):
    """09:32只补未提交的订单，不重复发送已提交桥接信号；并核对模拟盘实际股数。"""
    if not bool(getattr(g, 'rebalance_due_today', False)) and not bool(getattr(g, 'hot_start_force_rebalance_pending', False)):
        return
    if not getattr(g, 'pending_rebalance_target_list', None):
        return
    g.trade_reconcile_attempts = int(getattr(g, 'trade_reconcile_attempts', 0)) + 1
    if _audit_and_finalize_rebalance(context, source='09:32_pre_retry'):
        return

    target_set = set(getattr(g, 'pending_rebalance_target_list', []) or [])
    actual = _position_amount_map(context)
    # 仅当09:30根本未成功创建卖单时补一次；已创建卖单则不重复桥接。
    for code in [c for c in actual if c not in target_set]:
        if bool((getattr(g, 'sell_orders_submitted_today', {}) or {}).get(code)):
            continue
        try:
            close_position(context, context.portfolio.positions[code], reason='09:32_V4未提交卖单补偿')
        except Exception as error:
            _safe_log_warning('[V4-09:32卖出补偿失败] %s | %s' % (str(code), str(error)[:160]))

    actual = _position_amount_map(context)
    non_target_remaining = [c for c in actual if c not in target_set]
    if not non_target_remaining:
        for stock in list(target_set):
            if int(actual.get(stock, 0) or 0) > 0:
                continue
            if bool((getattr(g, 'buy_orders_submitted_today', {}) or {}).get(stock)):
                continue
            cash = float(context.portfolio.available_cash)
            if cash < 1000:
                continue
            value = min(float(context.portfolio.total_value), cash)
            filled = order_value_lot100(context, stock, value, cash, reason='09:32_V4卖出现金释放后补买')
            if filled:
                g.expected_target_amount_map[stock] = int(filled[1])

    _audit_and_finalize_rebalance(context, source='09:32_post_retry')

def order_value_lot100(context, stock, value, available_cash=None, reason='09:30调仓买入'):
    """按100股整数倍下单；聚宽订单成功进入交易账本与桥接入口。"""
    try:
        value = float(value)
    except Exception:
        return None
    if value < 1000:
        return None

    if not _live_trade_wall_gate_093002(context, tag='before_buy_order', security=str(stock)):
        log.info('[09:30:02交易时间闸] 买入跳过 | security=%s' % str(stock))
        return None

    try:
        item = get_current_data()[stock]
        price = float(getattr(item, 'last_price', 0) or 0)
        if price <= 0:
            price = float(getattr(item, 'day_open', 0) or 0)
    except Exception:
        price = 0.0
    if price <= 0:
        log.info('[买入跳过] %s 无有效实时价' % str(stock))
        return None

    cap = value
    if available_cash is not None:
        try:
            cap = min(cap, float(available_cash))
        except Exception:
            pass

    # 保留R21原撮合：预留约0.3%费用缓冲，100股整数倍下单。
    budget = cap * 0.997
    amount = int(budget / price / 100) * 100
    if amount < 100:
        return None

    order_result = order(stock, amount)
    if order_result is None:
        log.error('[买入委托返回空] security=%s | amount=%s | reason=%s' % (
            str(stock), amount, str(reason)
        ))
        return None

    try:
        g.buy_orders_submitted_today[str(stock)] = True
    except Exception:
        pass
    filled = int(abs(getattr(order_result, 'filled', 0) or 0))
    bridge_amount = filled if filled > 0 else int(abs(getattr(order_result, 'amount', amount) or amount))
    estimated_money = float(bridge_amount or amount) * price
    _record_trade_ledger(
        context, stock, True, bridge_amount, price, estimated_money,
        reason=reason, order_result=order_result
    )
    maybe_send_bridge_signal(
        context, stock, True, bridge_amount, price,
        order_result=order_result, reason=reason
    )
    event_triggered_fund_patrol(context, tag='buy_order_submitted', force=False)
    return (amount * price, amount)

def filter_new_stock(stock_list, security_df, signal_date):
    output = []
    for stock in stock_list:
        try:
            start_date = _to_date_safe(security_df.loc[stock, 'start_date'])
            if (signal_date - start_date).days >= 250:
                output.append(stock)
        except Exception:
            continue
    return output

def _is_kcb(code):
    return str(code).startswith('688')

def _is_cyb(code):
    s = str(code)
    return s.startswith('300') or s.startswith('301')

def _is_bse(code):
    s = str(code)
    return s.endswith('.XBJ') or s.endswith('.BJ')

def filter_kcb_stock(stock_list):
    """兼容旧名：仅屏蔽科创板。"""
    return [stock for stock in stock_list if not _is_kcb(stock)]

def filter_board_universe(stock_list):
    """按 g.exclude_* 屏蔽科创/创业/北交所。"""
    out = []
    ex_kcb = bool(getattr(g, 'exclude_kcb', True))
    ex_cyb = bool(getattr(g, 'exclude_cyb', True))
    ex_bse = bool(getattr(g, 'exclude_bse', True))
    for stock in stock_list:
        if ex_kcb and _is_kcb(stock):
            continue
        if ex_cyb and _is_cyb(stock):
            continue
        if ex_bse and _is_bse(stock):
            continue
        out.append(stock)
    return out

def filter_st_stock(stock_list):
    current_data = get_current_data()
    output = []
    for stock in stock_list:
        try:
            item = current_data[stock]
            name = str(getattr(item, 'name', ''))
            if bool(getattr(item, 'is_st', False)):
                continue
            if ('ST' in name) or ('*' in name) or ('退' in name):
                continue
            output.append(stock)
        except Exception:
            continue
    return output

def get_history_roe_frame(pb_list, signal_date):
    frames = []
    for part in _chunks(pb_list, HISTORY_FUNDAMENTAL_BATCH_SIZE):
        if not part:
            continue
        try:
            frame = get_history_fundamentals(
                part,
                fields=[indicator.code, indicator.roe],
                watch_date=signal_date,
                count=5,
                interval='1q',
            )
            if frame is not None and len(frame) > 0:
                frames.append(frame.copy())
        except Exception as error:
            _safe_log_warning('[历史ROE批量查询失败] size=%s | signal_date=%s | error=%s' % (
                len(part), str(signal_date), str(error)[:180]
            ))
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)

def calculate_roe_increase_ranking(roe_frame):
    """母策略公式：4×最新季ROE－前四季ROE之和。"""
    if roe_frame is None or len(roe_frame) == 0:
        return []
    if 'code' not in roe_frame.columns or 'roe' not in roe_frame.columns:
        return []
    records = []
    for code, group in roe_frame.groupby('code', sort=False):
        values = pd.to_numeric(group['roe'], errors='coerce').dropna().tolist()
        if len(values) < 5:
            continue
        values = values[-5:]
        increase = 4.0 * float(values[-1]) - float(np.sum(values[:-1]))
        records.append((str(code), increase))
    records.sort(key=lambda item: item[1], reverse=True)
    return records

def filter_industry_codes(codes, industry_map, filtered_industries):
    blocked = set(filtered_industries or [])
    return [code for code in codes if industry_map.get(code) not in blocked]

def batch_get_industry_map(codes, signal_date, level='sw_l1'):
    industry_map = {}
    calls = 0
    for part in _chunks(list(codes), BATCH_SIZE_INDUSTRY):
        if not part:
            continue
        calls += 1
        try:
            raw = get_industry(part, date=signal_date)
        except Exception as error:
            _safe_log_warning('[行业批量失败] %s' % str(error)[:160])
            continue
        if not isinstance(raw, dict):
            continue
        for code in part:
            info = raw.get(code) or {}
            sw = info.get(level) or {}
            industry_map[str(code)] = sw.get('industry_name') or sw.get('industry_code') or ''
    return industry_map, calls

def batch_get_price_map(codes, count, end_date, fields, fq='pre', fill_paused=False):
    price_map = {}
    calls = 0
    for part in _chunks(list(codes), BATCH_SIZE_PRICE):
        if not part:
            continue
        calls += 1
        try:
            frame = get_price(
                part,
                end_date=end_date,
                frequency='daily',
                fields=fields,
                count=count,
                skip_paused=False,
                fq=fq,
                panel=False,
            )
        except Exception as error:
            _safe_log_warning('[行情批量失败] %s' % str(error)[:160])
            continue
        if frame is None or len(frame) == 0:
            continue
        for code, group in frame.groupby('code'):
            price_map[str(code)] = group.sort_values('time') if 'time' in group.columns else group
    return price_map, calls

def calculate_industry_resonance(candidates, industry_map, signal_date):
    metadata = {}
    if not candidates:
        return metadata
    price_map, calls = batch_get_price_map(
        candidates, count=2, end_date=signal_date, fields=['close'], fq='pre'
    )
    rows = []
    for code in candidates:
        frame = price_map.get(code)
        industry = industry_map.get(code)
        if not industry or frame is None or len(frame) < 2:
            continue
        try:
            closes = pd.to_numeric(frame['close'], errors='coerce').dropna()
            if len(closes) < 2 or float(closes.iloc[-2]) <= 0:
                continue
            daily_return = float(closes.iloc[-1] / closes.iloc[-2] - 1.0)
            rows.append({'code': code, 'industry': industry, 'return': daily_return})
        except Exception:
            continue
    if not rows:
        return metadata
    frame = pd.DataFrame(rows)
    min_count = int(getattr(g, 'industry_resonance_min_count', 3))
    min_up_ratio = float(getattr(g, 'industry_resonance_min_up_ratio', 0.60))
    min_avg_return = float(getattr(g, 'industry_resonance_min_avg_return', 0.0))
    resonant_industries = {}
    for industry, group in frame.groupby('industry'):
        count = int(len(group))
        up_ratio = float((group['return'] > 0).mean()) if count > 0 else 0.0
        avg_return = float(group['return'].mean()) if count > 0 else 0.0
        resonant_industries[industry] = {
            'count': count,
            'up_ratio': up_ratio,
            'avg_return': avg_return,
            'is_resonant': bool(count >= min_count and up_ratio >= min_up_ratio and avg_return > min_avg_return),
        }
    return_map = frame.set_index('code')['return'].to_dict()
    for code in candidates:
        industry = industry_map.get(code, '')
        industry_state = resonant_industries.get(industry, {})
        metadata[code] = {
            'industry': industry,
            'candidate_return': float(return_map.get(code, -999.0)),
            'industry_count': int(industry_state.get('count', 0)),
            'industry_up_ratio': float(industry_state.get('up_ratio', 0.0)),
            'industry_avg_return': float(industry_state.get('avg_return', 0.0)),
            'is_resonant': bool(industry_state.get('is_resonant', False)),
        }
    return metadata

def compute_bias_davol_map(codes, signal_date, cap_map):
    """按聚宽公式重算 BIAS60 / BIAS20 / DAVOL5；截面截止 signal_date。"""
    result = {}
    if not codes:
        return result
    price_map, _ = batch_get_price_map(
        codes, count=140, end_date=signal_date, fields=['close', 'volume'], fq='pre'
    )
    for code in codes:
        frame = price_map.get(code)
        if frame is None or len(frame) < 60:
            continue
        close = pd.to_numeric(frame['close'], errors='coerce')
        vol = pd.to_numeric(frame['volume'], errors='coerce')
        ma60 = close.rolling(60).mean().iloc[-1]
        if not ma60 or not np.isfinite(ma60):
            continue
        bias60 = float(close.iloc[-1] / ma60 - 1.0) * 100.0
        bias20 = np.nan
        if len(close) >= 20:
            ma20 = close.rolling(20).mean().iloc[-1]
            if ma20 and np.isfinite(ma20):
                bias20 = float(close.iloc[-1] / ma20 - 1.0) * 100.0
        davol5 = np.nan
        cap = float(cap_map.get(code, np.nan))
        if np.isfinite(cap) and cap > 0:
            shares = (cap * 1e8) / close.replace(0, np.nan)
            turnover = (vol / shares).replace([np.inf, -np.inf], np.nan)
            if turnover.dropna().shape[0] >= 120:
                t5 = float(turnover.tail(5).mean())
                t120 = float(turnover.tail(120).mean())
                if t120:
                    davol5 = t5 / t120
            elif vol.dropna().shape[0] >= 120 and float(vol.tail(120).mean()) > 0:
                davol5 = float(vol.tail(5).mean() / vol.tail(120).mean())
        result[code] = {
            'bias60': bias60,
            'bias20': float(bias20) if np.isfinite(bias20) else np.nan,
            'davol5': float(davol5) if np.isfinite(davol5) else np.nan,
        }
    return result

# ========== R4 V4: L3_LOW_POSITION_RANK + C1_REVERSAL + RANK_B (from R3.1 freeze) ==========
# Source: R21_LOW_ANCHOR_FACTOR_MATRIX_R3_1/engine/02_run_matrix_r31.py
#   compute_anchor L:88-125 | apply_L L3:253-254 | bias_n/roc_n | rank_candidates RANK_B:765-782
# Formulas (factor_260_formula_CURRENT.csv):
#   ROC6: (close/close_n6 - 1)*100   [JQ260_195; R3.1 uses ratio form equivalent to return *100]
#   BIAS5: (close-MA5)/MA5*100       [JQ260_024]
#   BIAS60: (close-MA60)/MA60*100    [JQ260_025]
#   DAVOL5: MA5(turnover)/MA120(turnover) [JQ260_053]
# L3 gate (exact R3.1): close_position>=0.55 and (close/open)>=0.98; N=250 history excluding signal bar for low/high.
# L3 requires industry resonance True (R3.1 select_candidates).
# RANK_B equal-weight cross-section percentile sum (higher better):
#   ind_up(+), ind_avg(+), position_N(lower better), roc6(lower better), bias60(lower better), davol5(+), circ_mv(lower better)
# Note: R3.1 uses only f_score[0]=roc6 in f_pct; bias5 is computed for audit/C1 but not separate score term.

def r4_compute_l3_anchor(code, signal_date, N=250):
    """R3.1 compute_anchor: previous window = N bars BEFORE signal bar (signal day not in min/max)."""
    frame = get_price(
        code, end_date=signal_date, frequency='daily',
        fields=['open', 'high', 'low', 'close', 'volume'],
        count=N + 5, skip_paused=False, fq='pre', panel=False,
    )
    if frame is None or len(frame) < N + 1:
        return None
    frame = frame.sort_values('time') if 'time' in frame.columns else frame
    # last row = signal_date bar
    i = len(frame) - 1
    if i < N:
        return None
    lo = np.asarray(pd.to_numeric(frame['low'].iloc[i - N:i], errors='coerce').values, dtype=float)
    hi = np.asarray(pd.to_numeric(frame['high'].iloc[i - N:i], errors='coerce').values, dtype=float)
    if len(lo) < N or np.any(~np.isfinite(lo)) or np.any(~np.isfinite(hi)):
        return None
    previous_low_N = float(np.min(lo))
    range_high_N = float(np.max(hi))
    signal_open = float(frame['open'].iloc[i])
    signal_high = float(frame['high'].iloc[i])
    signal_low = float(frame['low'].iloc[i])
    signal_close = float(frame['close'].iloc[i])
    denom = range_high_N - previous_low_N
    position_N = (signal_close - previous_low_N) / denom if denom > 1e-12 else np.nan
    bar_den = signal_high - signal_low
    close_position = (signal_close - signal_low) / bar_den if bar_den > 1e-12 else np.nan
    return {
        'previous_low_N': previous_low_N,
        'range_high_N': range_high_N,
        'position_N': position_N,
        'close_position': close_position,
        'signal_open': signal_open,
        'signal_close': signal_close,
        'signal_low': signal_low,
    }

def r4_l3_pass(anc):
    """R3.1 apply_L L3_LOW_POSITION_RANK exact."""
    if not anc:
        return False
    cp = anc.get('close_position')
    so = anc.get('signal_open')
    sc = anc.get('signal_close')
    if not np.isfinite(cp) or not so:
        return False
    return float(cp) >= 0.55 and (float(sc) / float(so)) >= 0.98

def r4_bias_n(code, signal_date, n):
    frame = get_price(code, end_date=signal_date, frequency='daily', fields=['close'], count=n, skip_paused=False, fq='pre', panel=False)
    if frame is None or len(frame) < n:
        return np.nan
    c = pd.to_numeric(frame['close'], errors='coerce').dropna()
    if len(c) < n:
        return np.nan
    ma = float(c.tail(n).mean())
    if ma == 0 or not np.isfinite(ma):
        return np.nan
    return (float(c.iloc[-1]) - ma) / ma * 100.0

def r4_roc6(code, signal_date):
    """(close/close_6ago - 1)*100  equivalent to AX/prev*100 with AX=close-close6."""
    frame = get_price(code, end_date=signal_date, frequency='daily', fields=['close'], count=7, skip_paused=False, fq='pre', panel=False)
    if frame is None or len(frame) < 7:
        return np.nan
    c = pd.to_numeric(frame['close'], errors='coerce').dropna()
    if len(c) < 7:
        return np.nan
    c0 = float(c.iloc[-7])
    c1 = float(c.iloc[-1])
    if c0 == 0:
        return np.nan
    return (c1 / c0 - 1.0) * 100.0

def r4_pct_rank(vals, higher_better=True):
    s = pd.Series(vals, dtype=float)
    r = s.rank(pct=True, method='average')
    if not higher_better:
        r = 1.0 - r
    return np.asarray(r.fillna(0.5).values, dtype=float)

def r4_rank_b(candidates):
    """R3.1 RANK_B equal-weight cross-section percentiles; higher score better."""
    if not candidates:
        return []
    ind_up = r4_pct_rank([x['ind_up'] for x in candidates], True)
    ind_avg = r4_pct_rank([x['ind_avg'] for x in candidates], True)
    pos = r4_pct_rank([x['position_N'] for x in candidates], False)
    roc = r4_pct_rank([x['roc6'] for x in candidates], False)
    bias = r4_pct_rank([x['bias60'] for x in candidates], False)
    dav = r4_pct_rank([x['davol5'] for x in candidates], True)
    mv = r4_pct_rank([x['circ_mv'] for x in candidates], False)
    scores = ind_up + ind_avg + pos + roc + bias + dav + mv
    order = np.argsort(-scores)
    ranked = []
    for rank_i, idx in enumerate(order, 1):
        row = dict(candidates[idx])
        row['final_score'] = float(scores[idx])
        row['final_rank'] = rank_i
        ranked.append(row)
    return ranked

def get_stock_list(context, signal_date):
    """V4: mother F0 funnel -> L3 + C1 + RANK_B (R3.1 frozen path). No loss channel."""
    security_df = get_all_securities(types=['stock'], date=signal_date)
    initial_list = security_df.index.astype(str).tolist()
    initial_list = filter_new_stock(initial_list, security_df, signal_date)
    initial_list = filter_board_universe(initial_list)
    initial_list = filter_st_stock(initial_list)

    query_pb = query(
        valuation.code,
        valuation.pb_ratio,
        indicator.eps,
    ).filter(
        valuation.code.in_(initial_list)
    ).order_by(
        valuation.pb_ratio.asc()
    )
    pb_frame = get_fundamentals(query_pb, date=signal_date)
    if pb_frame is None or len(pb_frame) == 0:
        raise RuntimeError('PB_EPS_FUNDAMENTAL_EMPTY')

    pb_frame = pb_frame.copy()
    pb_frame['eps'] = pd.to_numeric(pb_frame['eps'], errors='coerce')
    pb_frame['pb_ratio'] = pd.to_numeric(pb_frame['pb_ratio'], errors='coerce')
    pb_frame = pb_frame[pb_frame['pb_ratio'] > 0]
    if not bool(getattr(g, 'allow_nonpositive_eps', True)):
        pb_frame = pb_frame[pb_frame['eps'] > 0]
    pb_half_count = int(0.5 * len(pb_frame))
    pb_list = pb_frame['code'].astype(str).tolist()[:pb_half_count]
    pb_map = pb_frame.set_index(pb_frame['code'].astype(str))['pb_ratio'].to_dict()
    if not pb_list:
        raise RuntimeError('PB_FILTER_EMPTY')

    roe_frame = get_history_roe_frame(pb_list, signal_date)
    roe_ranking = calculate_roe_increase_ranking(roe_frame)
    if not roe_ranking:
        raise RuntimeError('ROE_HISTORY_EMPTY_OR_INVALID')
    roe_top_count = max(1, int(0.1 * len(roe_ranking)))
    roe_list = [code for code, _ in roe_ranking[:roe_top_count]]
    roe_score_map = {code: float(score) for code, score in roe_ranking}

    industry_map, _ = batch_get_industry_map(roe_list, signal_date, level='sw_l1')
    if bool(getattr(g, 'industry_control', True)):
        filtered_list = filter_industry_codes(
            roe_list, industry_map, getattr(g, 'industry_filter_list', [])
        )
    else:
        filtered_list = list(roe_list)
    if not filtered_list:
        g.weekly_candidate_detail = {}
        g.weekly_channel_stats = {'empty': True}
        return [], {}

    query_cap = query(
        valuation.code,
        valuation.circulating_market_cap,
    ).filter(
        valuation.code.in_(filtered_list)
    ).order_by(
        valuation.circulating_market_cap.asc()
    )
    cap_frame = get_fundamentals(query_cap, date=signal_date)
    if cap_frame is None or len(cap_frame) == 0:
        raise RuntimeError('CIRCULATING_MARKET_CAP_EMPTY')
    cap_frame = cap_frame.dropna(subset=['code', 'circulating_market_cap']).copy()
    cap_frame['code'] = cap_frame['code'].astype(str)
    cap_frame['circulating_market_cap'] = pd.to_numeric(
        cap_frame['circulating_market_cap'], errors='coerce'
    )
    cap_frame = cap_frame.dropna(subset=['circulating_market_cap'])
    market_cap_map = cap_frame.set_index('code')['circulating_market_cap'].to_dict()
    original_market_cap_rank = cap_frame['code'].tolist()

    resonance_meta = {}
    if bool(getattr(g, 'industry_resonance_enabled', True)):
        resonance_meta = calculate_industry_resonance(
            original_market_cap_rank, industry_map, signal_date
        )

    factor_map = compute_bias_davol_map(original_market_cap_rank, signal_date, market_cap_map)
    g.weekly_factor_map = dict(factor_map)

    # --- V4 only: L3 filter + C1 factor_ok + RANK_B ---
    candidates = []
    n_l3 = 0
    n_c1 = 0
    for code in original_market_cap_rank:
        if code not in factor_map or not np.isfinite(factor_map[code].get('bias60', np.nan)):
            continue
        rm = resonance_meta.get(code, {})
        is_res = bool(rm.get('is_resonant', False))
        # R3.1 L3 requires resonance
        if not is_res:
            continue
        anc = r4_compute_l3_anchor(code, signal_date, N=250)
        if not r4_l3_pass(anc):
            continue
        n_l3 += 1
        roc6 = r4_roc6(code, signal_date)
        bias5 = r4_bias_n(code, signal_date, 5)
        if not np.isfinite(roc6):
            continue
        n_c1 += 1
        dav = factor_map[code].get('davol5', np.nan)
        candidates.append({
            'code': code,
            'ind_up': float(rm.get('industry_up_ratio', 0.0)),
            'ind_avg': float(rm.get('industry_avg_return', 0.0)),
            'is_resonant': is_res,
            'industry': rm.get('industry') or industry_map.get(code, ''),
            'position_N': float(anc['position_N']) if anc and np.isfinite(anc.get('position_N', np.nan)) else np.nan,
            'previous_low_250': float(anc['previous_low_N']) if anc else np.nan,
            'range_high_250': float(anc['range_high_N']) if anc else np.nan,
            'close_position': float(anc['close_position']) if anc else np.nan,
            'roc6': float(roc6),
            'bias5': float(bias5) if np.isfinite(bias5) else np.nan,
            'bias60': float(factor_map[code]['bias60']),
            'davol5': float(dav) if np.isfinite(dav) else np.nan,
            'circ_mv': float(market_cap_map.get(code, np.nan)),
            'pb': float(pb_map.get(code, np.nan)) if code in pb_map else np.nan,
            'roe_improvement_score': float(roe_score_map.get(code, np.nan)),
        })

    ranked_rows = r4_rank_b(candidates)
    ranked = [r['code'] for r in ranked_rows]
    detail = {r['code']: r for r in ranked_rows}
    g.weekly_candidate_detail = detail
    g.weekly_channel_stats = {
        'initial_n': len(initial_list),
        'pb_half_n': len(pb_list),
        'roe_pool_n': len(roe_list),
        'industry_filtered_n': len(filtered_list),
        'l3_n': n_l3,
        'c1_n': n_c1,
        'ranked_n': len(ranked),
        'version': 'V4_R21_LOW_POSITION_REVERSAL_HOTSTART_R5_ETF_ALIGNED',
    }

    log.info('[R21-V4选股] STRATEGY_VERSION=V4_R21_LOW_POSITION_REVERSAL_HOTSTART_R5_ETF_ALIGNED | signal_date=%s | n=%s | top=%s' % (
        str(signal_date), len(ranked), ranked[:5],
    ))
    log.info('[R21-V4漏斗] initial=%s | pb_half=%s | roe_pool=%s | industry_filtered=%s | l3=%s | c1=%s | ranked=%s' % (
        len(initial_list), len(pb_list), len(roe_list), len(filtered_list),
        n_l3, n_c1, len(ranked),
    ))
    return ranked, resonance_meta

def prepare_stock_list_cache(context):
    today = context.current_dt.date()
    signal_date = context.previous_date
    try:
        ranked, resonance_meta = get_stock_list(context, signal_date)
        g.weekly_ranked_candidates = list(ranked)
        g.weekly_resonance_meta = dict(resonance_meta)
        g.weekly_cache_status = 'OK'
        g.weekly_cache_trade_date = today
        g.weekly_cache_signal_date = signal_date
        g.weekly_cache_error = ''
    except Exception as error:
        g.weekly_ranked_candidates = []
        g.weekly_resonance_meta = {}
        g.weekly_cache_status = 'FAIL'
        g.weekly_cache_error = str(error)[:200]
        _safe_log_warning('[周度缓存失败] %s' % g.weekly_cache_error)

def filter_paused_stock(stock_list):
    current_data = get_current_data()
    return [s for s in stock_list if not bool(getattr(current_data[s], 'paused', False))]

def filter_limitup_stock(context, stock_list):
    current_data = get_current_data()
    output = []
    for stock in stock_list:
        try:
            item = current_data[stock]
            last = float(getattr(item, 'last_price', 0) or 0)
            high_limit = float(getattr(item, 'high_limit', 0) or 0)
            if high_limit > 0 and last >= high_limit * 0.999:
                continue
            output.append(stock)
        except Exception:
            continue
    return output

def close_position(context, position, reason='卖出'):
    """卖出持仓；订单提交后写入交易账本并进入桥接发送入口。"""
    security = str(position.security)
    closeable_amount = int(getattr(position, 'closeable_amount', 0) or 0)
    if closeable_amount <= 0:
        log.info('[卖出跳过_T+1或无可卖] %s %s | reason=%s' % (
            security, get_name(security), str(reason)
        ))
        return False

    if not _live_trade_wall_gate_093002(context, tag='before_sell_order', security=security):
        return False

    pre_value = float(getattr(position, 'value', 0.0) or 0.0)
    pre_amount = int(getattr(position, 'total_amount', closeable_amount) or closeable_amount)
    try:
        item = get_current_data()[security]
        price = float(getattr(item, 'last_price', 0) or 0)
        if price <= 0:
            price = float(getattr(item, 'day_open', 0) or 0)
    except Exception:
        price = float(getattr(position, 'price', 0.0) or 0.0)

    order_result = order_target(security, 0)
    if order_result is None:
        log.error('[卖出委托返回空] %s %s | reason=%s' % (
            security, get_name(security), str(reason)
        ))
        return False

    try:
        g.sell_orders_submitted_today[str(security)] = True
    except Exception:
        pass
    filled = int(abs(getattr(order_result, 'filled', 0) or 0))
    bridge_amount = filled if filled > 0 else int(closeable_amount or pre_amount)
    _record_trade_ledger(
        context, security, False, bridge_amount, price, pre_value,
        reason=reason, order_result=order_result
    )
    maybe_send_bridge_signal(
        context, security, False, bridge_amount, price,
        order_result=order_result, reason=reason
    )
    log.info('[卖出委托] %s %s | amount=%s | %s' % (
        security, get_name(security), bridge_amount, str(reason)
    ))
    event_triggered_fund_patrol(context, tag='sell_order_submitted', force=False)
    return True

def weekly_adjustment(context):
    """兼容旧名：等价于开盘买入流程。"""
    weekly_adjustment_buy(context)

def _bias20_at_series(close, i):
    window = close.iloc[i - 19:i + 1]
    ma = float(window.mean())
    if not ma:
        return np.nan
    return float(close.iloc[i] / ma - 1.0) * 100.0

def check_bias20_zero_cross_exit(context):
    """退出逻辑: BIAS20由负转正(零轴穿越)则卖出。默认关闭。"""
    if not bool(getattr(g, 'bias20_zero_cross_exit', False)):
        return
    signal_date = context.previous_date
    for stock in list(context.portfolio.positions.keys()):
        position = context.portfolio.positions[stock]
        if position.closeable_amount <= 0:
            continue
        try:
            frame = get_price(
                stock,
                end_date=signal_date,
                frequency='daily',
                fields=['close'],
                count=25,
                skip_paused=False,
                fq='pre',
            )
            if frame is None or len(frame) < 21:
                continue
            close = pd.to_numeric(frame['close'], errors='coerce')
            prev_bias = _bias20_at_series(close, -2)
            last_bias = _bias20_at_series(close, -1)
            if np.isfinite(prev_bias) and np.isfinite(last_bias) and prev_bias < 0 and last_bias >= 0:
                close_position(context, position, reason='BIAS20零轴穿越提前卖出')
        except Exception as error:
            _safe_log_warning('[BIAS20退出检查失败] %s | %s' % (stock, str(error)[:120]))

def check_limit_up_open_sell(context):
    """兼容旧入口: 转调14:50近收盘卖非目标。"""
    rebalance_sell_close(context)

def print_position_info(context):
    log.info('\n========== 当日成交与持仓 ==========')
    try:
        trades = get_trades()
        for trade in list(trades.values()):
            log.info('成交记录：%s' % str(trade))
    except Exception as error:
        _safe_log_warning('[成交记录读取异常] %s' % str(error))

    for position in list(context.portfolio.positions.values()):
        try:
            security = str(position.security)
            cost = float(position.avg_cost or 0.0)
            price = float(position.price or 0.0)
            return_pct = 100.0 * (price / cost - 1.0) if cost > 0 else 0.0
            log.info('%s %s | 成本=%.2f | 现价=%.2f | 收益率=%.2f%% | 持仓=%s | 市值=%.2f' % (
                security,
                get_name(security),
                cost,
                price,
                return_pct,
                int(position.total_amount or 0),
                float(position.value or 0.0),
            ))
        except Exception as error:
            _safe_log_warning('[持仓打印异常] %s' % str(error))

    log.info('持仓数量=%s | 最大持仓=%s | 桥接日汇总=%s | 交易账本=%s' % (
        sum(1 for p in context.portfolio.positions.values() if float(getattr(p, 'total_amount', 0) or 0) > 0),
        int(g.stock_num),
        str(getattr(g, 'bridge_day_summary', {})),
        str(getattr(g, 'trade_ledger_summary', {})),
    ))

# ===================== ETF同级调度幂等与分钟兜底 =====================
def _runtime_date_key(context):
    try:
        return str(context.current_dt.date())
    except Exception:
        return 'unknown_date'

def _runtime_hhmm(context):
    try:
        return context.current_dt.strftime('%H:%M')
    except Exception:
        return ''

def _runtime_minutes(context):
    try:
        return int(context.current_dt.hour) * 60 + int(context.current_dt.minute)
    except Exception:
        return -1

def _in_minute_window(now_minutes, target_hhmm, tolerance_minutes=1):
    try:
        hour, minute = [int(x) for x in str(target_hhmm).split(':')[:2]]
        target = hour * 60 + minute
        return target <= int(now_minutes) <= target + int(tolerance_minutes)
    except Exception:
        return False

def _ensure_trigger_books():
    if not hasattr(g, 'runtime_once_trigger_book') or not isinstance(g.runtime_once_trigger_book, dict):
        g.runtime_once_trigger_book = {}
    if not hasattr(g, 'runtime_last_minute_heartbeat'):
        g.runtime_last_minute_heartbeat = ''

def _trigger_book_key(context, trigger_key):
    return '%s|%s' % (_runtime_date_key(context), str(trigger_key))

def _already_triggered_today(context, trigger_key):
    _ensure_trigger_books()
    return str(g.runtime_once_trigger_book.get(_trigger_book_key(context, trigger_key), '')) == 'DONE'

def _run_once_per_day(context, trigger_key, label, func):
    """run_daily与handle_data共用幂等入口；异常时允许同日后续兜底重试。"""
    _ensure_trigger_books()
    key = _trigger_book_key(context, trigger_key)
    state = str(g.runtime_once_trigger_book.get(key, ''))
    if state in ('RUNNING', 'DONE'):
        return False
    g.runtime_once_trigger_book[key] = 'RUNNING'
    try:
        result = func(context)
        g.runtime_once_trigger_book[key] = 'DONE'
        log.info('[V4幂等执行完成] %s | key=%s | result=%s' % (
            str(label), str(trigger_key), str(result)
        ))
        return result
    except Exception as error:
        g.runtime_once_trigger_book.pop(key, None)
        log.error('[V4幂等执行异常_允许后续重试] %s | key=%s | %s' % (
            str(label), str(trigger_key), str(error)[:220]
        ))
        return False

def scheduled_v4_yday_0905(context):
    return _run_once_per_day(
        context, '09:05_yday_limit', '09:05昨日涨停持仓',
        prepare_yday_limit_list
    )

def scheduled_v4_select_0920(context):
    return _run_once_per_day(
        context, '09:20_select', '09:20 V4排名缓存',
        prepare_stock_list_cache_if_due
    )

def scheduled_v4_retry_0925(context):
    return _run_once_per_day(
        context, '09:25_retry', '09:25 V4缓存失败重试',
        retry_stock_list_cache_0925
    )

def scheduled_v4_trade_0930(context):
    return _run_once_per_day(
        context, '09:30_trade', '09:30 V4第一名换仓',
        rebalance_buy_open
    )

def scheduled_v4_reconcile_0932(context):
    return _run_once_per_day(
        context, '09:32_reconcile', '09:32持仓股数与漏单核对',
        reconcile_hot_start_trade_0932
    )

def scheduled_v4_bias_exit_0935(context):
    return _run_once_per_day(
        context, '09:35_bias_exit', '09:35 BIAS20可选退出',
        check_bias20_zero_cross_exit
    )

def scheduled_v4_sell_cleanup_1450(context):
    return _run_once_per_day(
        context, '14:50_sell_cleanup', '14:50非目标持仓补卖',
        rebalance_sell_close
    )

def handle_data(context, data):
    """与长期ETF模拟盘一致的分钟兜底；所有交易入口均有当日幂等保护。"""
    try:
        ensure_runtime_defaults(context)
        now_min = _runtime_minutes(context)
        event_triggered_fund_patrol(context, tag='handle_data_event_patrol', force=False)

        # 09:20全市场计算只允许在09:20至09:22兜底，禁止09:30临时冷扫描。
        if _in_minute_window(now_min, '09:20', 2):
            scheduled_v4_select_0920(context)

        if _in_minute_window(now_min, '09:25', 2):
            scheduled_v4_retry_0925(context)

        # 交易主链最多允许09:31补触发；不会在更晚时点追单。
        if _in_minute_window(now_min, '09:30', 1):
            scheduled_v4_trade_0930(context)

        if _in_minute_window(now_min, '09:32', 1):
            scheduled_v4_reconcile_0932(context)

        if _in_minute_window(now_min, '14:50', 1):
            scheduled_v4_sell_cleanup_1450(context)
    except Exception as error:
        try:
            log.error('[V4分钟兜底异常] %s' % str(error)[:220])
        except Exception:
            pass

# ===================== 实盘调度、进程恢复与热启动 =====================
def register_runtime_schedules(context, from_after_code_changed=False):
    ensure_runtime_defaults(context)
    source = 'after_code_changed' if from_after_code_changed else 'initialize'

    # run_daily与handle_data共用同一幂等包装器，避免热更新后重复交易。
    run_daily(scheduled_v4_yday_0905, time='09:05', reference_security=REFERENCE_SECURITY)
    run_daily(scheduled_v4_select_0920, time='09:20', reference_security=REFERENCE_SECURITY)
    run_daily(backtest_bridge_probe_0921, time='09:21', reference_security=REFERENCE_SECURITY)
    run_daily(scheduled_v4_retry_0925, time='09:25', reference_security=REFERENCE_SECURITY)
    run_daily(scheduled_v4_trade_0930, time='09:30', reference_security=REFERENCE_SECURITY)
    run_daily(scheduled_v4_reconcile_0932, time='09:32', reference_security=REFERENCE_SECURITY)
    run_daily(scheduled_v4_bias_exit_0935, time='09:35', reference_security=REFERENCE_SECURITY)
    run_daily(scheduled_v4_sell_cleanup_1450, time='14:50', reference_security=REFERENCE_SECURITY)

    run_daily(light_probe_0931, time='09:31', reference_security=REFERENCE_SECURITY)
    run_daily(light_probe_1030, time='10:30', reference_security=REFERENCE_SECURITY)
    run_daily(light_probe_1440, time='14:40', reference_security=REFERENCE_SECURITY)
    run_daily(light_probe_1456, time='14:56', reference_security=REFERENCE_SECURITY)
    run_daily(print_position_info, time='15:10', reference_security=REFERENCE_SECURITY)
    run_daily(scheduled_eod_probe, time='15:10', reference_security=REFERENCE_SECURITY)
    run_daily(after_close_alive_probe, time='after_close', reference_security=REFERENCE_SECURITY)

    log.info('[调度-注册] 来源=%s | V4主链=09:05/09:20/09:21回测0股探针/09:25/09:30/09:32/09:35/14:50 | '
             '分钟兜底=09:20/09:25/09:30/09:32/14:50且当日幂等 | '
             '探针=09:31/10:30/14:40/14:56/15:10/after_close | 桥接策略名=%s' % (
                 source, str(eq_strategy_name)
             ))

def process_initialize(context):
    """进程恢复：重新读取账户真实持仓和核心运行状态，但不重复注册run_daily。"""
    ensure_runtime_defaults(context)
    init_bridge_runtime_state(context)
    _log_hot_start_position_snapshot(context, source='process_initialize')

    # 旧日缓存不得跨交易日使用；热启动待评估状态和最近成功评估日保持原值。
    today = _trade_date(context)
    if getattr(g, 'weekly_cache_trade_date', None) != today:
        g.weekly_cache_status = 'EMPTY'
        g.weekly_cache_error = 'PROCESS_INITIALIZE_STALE_CACHE_CLEARED'
        g.weekly_cache_trade_date = None
        g.weekly_cache_signal_date = None
        g.weekly_ranked_candidates = []
        g.weekly_resonance_meta = {}
        g.weekly_factor_map = {}

    if getattr(g, 'last_successful_rebalance_date', None) is None:
        g.hot_start_force_rebalance_pending = True
        g.rebalance_due_today = True

    log.info('[进程恢复] process_initialize完成 | 持仓已重新捕获 | '
             'hot_start_pending=%s | last_rebalance=%s | 不重复注册run_daily' % (
                 str(bool(getattr(g, 'hot_start_force_rebalance_pending', False))),
                 str(getattr(g, 'last_successful_rebalance_date', None))
             ))
    runtime_alive_probe(context, 'process_initialize_probe')
    event_triggered_fund_patrol(context, 'process_initialize_event_probe', True)
    post_close_activation_probe(context, source='process_initialize')

def initialize(context):
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_benchmark('000300.XSHG')
    set_order_cost(OrderCost(
        open_tax=0, close_tax=0.001,
        open_commission=0.0003, close_commission=0.0003,
        close_today_commission=0, min_commission=5,
    ), type='stock')
    log.set_level('order', 'error')

    ensure_runtime_defaults(context)
    # 新建模拟盘首个可交易日也强制执行一次V4排名；不改现金，不硬编码持仓。
    g.trade_day_index = -1
    g.weekly_cache_status = 'EMPTY'
    g.weekly_cache_error = ''
    g.weekly_cache_trade_date = None
    g.weekly_cache_signal_date = None
    g.weekly_ranked_candidates = []
    g.weekly_resonance_meta = {}
    g.weekly_factor_map = {}
    g.target_list = []
    g.pending_rebalance_target_list = []
    g.expected_target_amount_map = {}
    g.hot_start_force_rebalance_pending = True
    g.hot_start_requested_date = _trade_date(context)
    g.bridge_live_send_enabled = True
    g.bridge_backtest_shadow_verify = False
    g.last_successful_rebalance_date = None
    g.rebalance_due_today = True
    g.bridge_backtest_probe_sent = False
    g.bridge_backtest_probe_result = 'NOT_RUN'
    g.runtime_once_trigger_book = {}
    g.runtime_last_minute_heartbeat = ''
    _log_hot_start_position_snapshot(context, source='initialize')

    log_bridge_config_selfcheck_if_needed(context, force=True)
    register_runtime_schedules(context, from_after_code_changed=False)
    runtime_alive_probe(context, 'immediate_startup_probe')
    event_triggered_fund_patrol(context, 'immediate_startup_event_probe', True)
    post_close_activation_probe(context, source='initialize')

    log.info('========== V4_R21_LOW_POSITION_REVERSAL_HOTSTART_R5_ETF_ALIGNED 初始化完成 | SIMULATION_HOT_REPLACE | '
             '09:20选股 | 09:30持股仅在仍为第一名时保留、否则换第一名 | 每2交易日重新评估 | 14:50非目标退出 | '
             'signal_date=previous_date | 桥接策略名=%s ==========' % str(eq_strategy_name))

def after_code_changed(context):
    """同一聚宽模拟盘热替换：保留账户持仓/现金，清旧缓存与旧调度，首个可交易日强制重算；仅当前持股不是排名第一名时换仓。"""
    log.info('[版本确认] V4_R21_LOW_POSITION_REVERSAL_HOTSTART_R5_ETF_ALIGNED | after_code_changed触发')

    # 先读取真实模拟盘持仓。这里不做一次性迁移、不调用inout_cash，也不写死天齐18900股。
    ensure_runtime_defaults(context)
    _log_hot_start_position_snapshot(context, source='after_code_changed_before_reset')

    # 保留历史成功评估日期用于审计，但热替换首日强制覆盖旧V0/V1轮换相位并重新评估。
    old_last_rebalance_date = getattr(g, 'last_successful_rebalance_date', None)
    g.hot_start_force_rebalance_pending = True
    g.hot_start_requested_date = _trade_date(context)
    g.bridge_live_send_enabled = True
    g.bridge_backtest_shadow_verify = False
    g.rebalance_due_today = True
    g.trade_day_index = 0

    # 旧版本排名/目标绝不可沿用；但context.portfolio中的天齐等真实持仓完全保留。
    g.weekly_cache_status = 'EMPTY'
    g.weekly_cache_error = 'AFTER_CODE_CHANGED_V4_CACHE_CLEARED'
    g.weekly_cache_trade_date = None
    g.weekly_cache_signal_date = None
    g.weekly_ranked_candidates = []
    g.weekly_resonance_meta = {}
    g.weekly_factor_map = {}
    g.target_list = []
    g.pending_rebalance_target_list = []
    g.expected_target_amount_map = {}
    g.sell_orders_submitted_today = {}
    g.buy_orders_submitted_today = {}
    g.trade_reconcile_attempts = 0
    g.runtime_once_trigger_book = {}
    g.runtime_last_minute_heartbeat = ''

    log.info('[V4热启动闸] today=%s | force_rebalance_pending=True | old_last_rebalance_date=%s | '
             '09:20使用previous_date重算；09:30当前持股仅在等于排名第一名时保留，否则卖旧买第一名；空排名不卖' % (
                 str(_trade_date(context)), str(old_last_rebalance_date)
             ))

    log_bridge_config_selfcheck_if_needed(context, force=True)
    _safe_unschedule_all_for_jq()
    register_runtime_schedules(context, from_after_code_changed=True)
    runtime_alive_probe(context, 'after_code_changed_probe')
    event_triggered_fund_patrol(context, 'after_code_changed_event_probe', True)
    post_close_activation_probe(context, source='after_code_changed')
