#!/usr/bin/env python3
"""JQ_P7_60M_MATRIX_LAUNCHER — HAND-gated 3-pool 60m missing-only download."""
import sys
import json
import time
import subprocess
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path("E:/BLACKBOX/脚本")))
import p7_gate_common as gc
import p7_60m_batch_code_mapping_r17 as m60

SCRIPT_SELF = Path(__file__).resolve()
NOW_TS = gc.now_ts()
NOW_ISO = gc.now_iso()
TASK = "JQ_P7_60M_MATRIX_DOWNLOAD_R17"
MATRIX = m60.R17_ROOT
PYTHON = "E:/BLACKBOX/.venv/Scripts/python.exe"
WORKER = str(gc.SCRIPTS / "p7_60m_matrix_worker.py")

for s in ["logs", "reports", "manifest", "gates"]:
    (MATRIX / s).mkdir(parents=True, exist_ok=True)

print("=" * 60)
print(f"{TASK} — 60M MATRIX LAUNCHER (HAND-GATED)")
print("=" * 60)

seal = m60.load_r17_30m_seal()
if not seal:
    print("BLOCK: 30m R17 seal not COMPLETE")
    sys.exit(2)

hand = gc.enforce_hand_gate(
    script_path=SCRIPT_SELF, required_stage="60m", require_sixty_m=True
)
mon = gc.ensure_hand_download_monitor(trigger=TASK, stage="60m")
print(f"HAND monitor: spawned={mon.get('spawned')} reason={mon.get('reason','ok')}")
gc.clear_global_stop()
POOLS = gc.active_worker_pools(hand)
print(f"HAND level: {hand.get('hand_release_level')} | active_workers={hand.get('active_workers')}")

import jq_download_base as jdb

jdb.auth()
ql = jdb.quota_left(force=True) or 0
print(f"Quota: {gc.quota_fmt(ql)}")
if ql <= 0:
    print("STOP: quota_left_zero")
    sys.exit(0)

print(f"\nLaunching {len(POOLS)} worker(s)...")
procs = {}
for pool in POOLS:
    lp = MATRIX / "logs" / f"worker_{pool}_{NOW_TS}.log"
    lf = open(str(lp), "w", encoding="utf-8")
    procs[pool] = {
        "proc": subprocess.Popen(
            [PYTHON, "-u", WORKER, pool],
            stdout=lf,
            stderr=subprocess.STDOUT,
        ),
        "log": lf,
    }
    print(f"  {pool}: PID={procs[pool]['proc'].pid}")

try:
    while procs:
        for pool in list(procs):
            if procs[pool]["proc"].poll() is not None:
                procs[pool]["log"].close()
                print(f"\n[{pool}] DONE")
                del procs[pool]
        if procs:
            time.sleep(5)
except KeyboardInterrupt:
    for i in procs.values():
        try:
            i["proc"].terminate()
            i["log"].close()
        except Exception:
            pass
    sys.exit(1)

tc = tf = tp = tq = 0
all_ok = True
for pool in POOLS:
    cks = sorted((MATRIX / pool / "checkpoint").glob("*.json"))
    if cks:
        ck = json.loads(cks[-1].read_text(encoding="utf-8"))
        tc += ck.get("completed", 0)
        tf += ck.get("failed", 0)
        tp += ck.get("parquet", 0)
        tq += ck.get("quota_used", 0)
    else:
        all_ok = False

fs = "ALL_COMPLETE" if all_ok else "PARTIAL"
man = {
    "task": TASK,
    "final_status": fs,
    "done": tc,
    "fail": tf,
    "pq": tp,
    "quota_used": tq,
    "sixty_m_allowed": True,
    "returned_to_HAND_for_review": True,
    "generated_at": NOW_ISO,
}
(MATRIX / f"manifest/{TASK.lower()}_manifest_{NOW_TS}.json").write_text(
    json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8"
)
print(f"\nDONE: {fs} | returned_to_HAND_for_review: true")
