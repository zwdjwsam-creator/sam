#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""STOCK_MINUTE_1M_R1 read-only fetcher — Cleaning CURRENT A股_stock_1m.

Canonical product_id: STOCK_MINUTE_1M_R1 (unified market data plane naming).
Authority plane: CURRENT_CLEANING_RELEASE.standard/price/A股_stock_1m
No Entry/refining fallback. No downloads. No DB writes. No QMT.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
CN = timezone(timedelta(hours=8))
PRODUCT_ID = "STOCK_MINUTE_1M_R1"
SOURCE_ID = "CLEANING_CURRENT_A_SHARE_STOCK_1M"
REQUIRED_COLUMNS = ("code", "timestamp", "open", "high", "low", "close", "volume")
# amount maps from source column `money` (nullable only if absent in source schema — here present)
AMOUNT_SOURCE_COL = "money"
DAY_FILE_RE = re.compile(r"__1m__(\d{4}-\d{2}-\d{2})__")
CASE_REJECT_MARKERS = (
    "ENERGY_REFINING_20260828",
    "ENTRY_LADDER",
    "regression_fixture",
    "case_sample",
    "炼化",
)


def now_cn() -> str:
    return datetime.now(CN).strftime("%Y-%m-%dT%H:%M:%S%z")


def sha256_file(path: Path) -> str | None:
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_ts(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=CN)
    s = str(value).strip()
    if not s:
        return None
    if len(s) == 10 and s[4] == "-" and s[7] == "-":
        return datetime(int(s[0:4]), int(s[5:7]), int(s[8:10]), 15, 0, 0, tzinfo=CN)
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        return dt if dt.tzinfo else dt.replace(tzinfo=CN)
    except ValueError:
        return None


def code_variants(code: str) -> list[str]:
    c = str(code).strip().upper()
    out = {c}
    if c.endswith(".SH"):
        out.add(c[:-3] + ".XSHG")
    if c.endswith(".SZ"):
        out.add(c[:-3] + ".XSHE")
    if c.endswith(".XSHG"):
        out.add(c[:-5] + ".SH")
    if c.endswith(".XSHE"):
        out.add(c[:-5] + ".SZ")
    return sorted(out)


def locate_stock_1m_dir(standard_root: Path) -> Path | None:
    price = Path(standard_root) / "price"
    if not price.is_dir():
        return None
    hits = [
        p
        for p in price.iterdir()
        if p.is_dir() and "stock_1m" in p.name and not p.name.upper().startswith("ETF")
    ]
    if not hits:
        return None
    # Prefer exact semantic folder name ending with stock_1m
    hits.sort(key=lambda p: (0 if p.name.endswith("stock_1m") else 1, p.name))
    return hits[0]


def resolve_cleaning_stock_1m_source() -> dict[str, Any]:
    ptr = ROOT / "数据" / "清洗成品" / "CURRENT_CLEANING_RELEASE.json"
    out: dict[str, Any] = {
        "status": "MISSING",
        "product_id": PRODUCT_ID,
        "source_id": SOURCE_ID,
        "ptr": str(ptr),
        "source_paths": [],
        "source_sha256": {},
        "evidence_gaps": [],
    }
    if not ptr.is_file():
        out["evidence_gaps"].append({"gap": "CLEANING_CURRENT_MISSING"})
        return out
    clean = json.loads(ptr.read_text(encoding="utf-8"))
    std = clean.get("standard_root")
    if not std:
        out["evidence_gaps"].append({"gap": "STANDARD_ROOT_MISSING"})
        return out
    # Reject case-specific pointers
    blob = json.dumps(clean, ensure_ascii=False) + str(std)
    for m in CASE_REJECT_MARKERS:
        if m.lower() in blob.lower() and "ENERGY_REFINING" in m:
            # cleaning CURRENT itself is fine; only reject if path is case fixture
            pass
    src = locate_stock_1m_dir(Path(std))
    if src is None or not src.is_dir():
        out["status"] = "MISSING"
        out["evidence_gaps"].append({"gap": "A_SHARE_STOCK_1M_DIR_MISSING", "standard_root": std})
        return out
    # Reject Entry-ladder paths
    sp = str(src).replace("\\", "/")
    if "ENTRY_LADDER" in sp.upper() or "regression_fixture" in sp.lower():
        out["status"] = "FAIL"
        out["evidence_gaps"].append({"gap": "CASE_SPECIFIC_SOURCE_REJECTED", "path": sp})
        return out
    out.update(
        {
            "status": "READY",
            "source_dir": str(src),
            "cleaning_release_id": clean.get("release_id"),
            "cleaning_as_of": clean.get("cleaning_as_of"),
            "source_paths": [str(ptr), str(src)],
            "source_sha256": {str(ptr): sha256_file(ptr)},
            "timezone": "Asia/Shanghai",
        }
    )
    return out


def _list_day_files(src_dir: Path, start_d: str, end_d: str) -> list[Path]:
    files = []
    for p in src_dir.glob("*.parquet"):
        m = DAY_FILE_RE.search(p.name)
        if not m:
            continue
        d = m.group(1)
        if start_d <= d <= end_d:
            files.append(p)
    return sorted(files)


def _empty_response(**kwargs: Any) -> dict[str, Any]:
    base = {
        "status": "NO_DATA",
        "product_id": PRODUCT_ID,
        "source_id": SOURCE_ID,
        "asof": None,
        "cutoff_time": None,
        "timezone": "Asia/Shanghai",
        "rows": 0,
        "symbols": [],
        "min_timestamp": None,
        "max_timestamp": None,
        "columns": list(REQUIRED_COLUMNS) + ["amount"],
        "data": [],
        "quality": {"issues": []},
        "evidence_gaps": [],
        "source_paths": [],
        "source_sha256": {},
        "dedup_policy": "SORT_BY_SYMBOL_TIMESTAMP_THEN_LAST_WINS",
        "ORDER_ALLOWED": False,
        "build_time_cn": now_cn(),
    }
    base.update(kwargs)
    return base


def fetch_stock_minute_1m(request: dict[str, Any]) -> dict[str, Any]:
    """Read-only fetch. request keys: symbols, start_time, end_time, asof, cutoff_time, required_columns, request_id."""
    symbols = list(request.get("symbols") or [])
    start_time = request.get("start_time")
    end_time = request.get("end_time")
    asof = request.get("asof")
    cutoff_time = request.get("cutoff_time")
    request_id = request.get("request_id")
    req_cols = list(request.get("required_columns") or REQUIRED_COLUMNS)

    src = resolve_cleaning_stock_1m_source()
    if src.get("status") != "READY":
        return _empty_response(
            status="MISSING" if src.get("status") == "MISSING" else "FAIL",
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            evidence_gaps=src.get("evidence_gaps") or [{"gap": "SOURCE_NOT_READY"}],
            source_paths=src.get("source_paths") or [],
            request_id=request_id,
            reason_code="SOURCE_NOT_READY",
        )

    if any(m in str(src.get("source_dir") or "").upper() for m in ("ENERGY_REFINING_20260828",)):
        return _empty_response(
            status="FAIL",
            reason_code="CASE_SPECIFIC_SOURCE_REJECTED",
            evidence_gaps=[{"gap": "CASE_SPECIFIC_SOURCE_REJECTED"}],
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            request_id=request_id,
        )

    st = parse_ts(start_time)
    et = parse_ts(end_time)
    cut = parse_ts(cutoff_time)
    if st is None or et is None:
        return _empty_response(
            status="FAIL",
            reason_code="INVALID_TIMESTAMP",
            evidence_gaps=[{"gap": "INVALID_START_OR_END"}],
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            request_id=request_id,
            source_paths=src.get("source_paths"),
        )
    if cut is None:
        return _empty_response(
            status="FAIL",
            reason_code="INVALID_TIMESTAMP",
            evidence_gaps=[{"gap": "INVALID_CUTOFF"}],
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            request_id=request_id,
            source_paths=src.get("source_paths"),
        )

    start_d = st.astimezone(CN).strftime("%Y-%m-%d")
    end_d = et.astimezone(CN).strftime("%Y-%m-%d")
    files = _list_day_files(Path(src["source_dir"]), start_d, end_d)
    if not files:
        return _empty_response(
            status="NO_DATA",
            reason_code="NO_DAY_SHARDS",
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            evidence_gaps=[{"gap": "NO_DAY_SHARDS", "start": start_d, "end": end_d}],
            source_paths=src.get("source_paths"),
            request_id=request_id,
        )

    # Build code filter variants
    variants: list[str] = []
    for s in symbols:
        variants.extend(code_variants(s))
    variants = sorted(set(variants))

    try:
        import duckdb
    except Exception as e:
        return _empty_response(
            status="FAIL",
            reason_code="DUCKDB_UNAVAILABLE",
            evidence_gaps=[{"gap": str(e)}],
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            request_id=request_id,
        )

    con = duckdb.connect()
    paths_sql = "[" + ",".join("'" + str(p).replace("\\", "/") + "'" for p in files) + "]"
    # Source uses `time` not timestamp; money as amount
    code_list = "[" + ",".join("'" + v.replace("'", "''") + "'" for v in variants) + "]" if variants else "NULL"
    where_code = f"code IN (SELECT UNNEST({code_list}))" if variants else "TRUE"
    sql = f"""
    SELECT
      code,
      time AS timestamp,
      open, high, low, close, volume,
      money AS amount
    FROM read_parquet({paths_sql}, union_by_name=true)
    WHERE {where_code}
      AND time >= TIMESTAMP '{st.astimezone(CN).strftime("%Y-%m-%d %H:%M:%S")}'
      AND time <= TIMESTAMP '{et.astimezone(CN).strftime("%Y-%m-%d %H:%M:%S")}'
    """
    try:
        df = con.execute(sql).fetchdf()
    except Exception as e:
        return _empty_response(
            status="FAIL",
            reason_code="QUERY_FAIL",
            evidence_gaps=[{"gap": f"QUERY_FAIL:{type(e).__name__}:{e}"}],
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            source_paths=src.get("source_paths") + [str(p) for p in files[:3]],
            request_id=request_id,
        )

    # Required columns check on result frame
    missing_cols = [c for c in req_cols if c not in df.columns and not (c == "timestamp" and "timestamp" in df.columns)]
    # map: we already alias time->timestamp
    for c in req_cols:
        if c == "timestamp":
            continue
        if c not in df.columns:
            missing_cols.append(c)
    if missing_cols:
        return _empty_response(
            status="FAIL",
            reason_code="MISSING_REQUIRED_COLUMN",
            evidence_gaps=[{"gap": "MISSING_REQUIRED_COLUMN", "cols": missing_cols}],
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            request_id=request_id,
            source_paths=src.get("source_paths"),
        )

    quality_issues: list[dict[str, Any]] = []
    if df.empty:
        return _empty_response(
            status="NO_DATA",
            reason_code="EMPTY_AFTER_FILTER",
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            evidence_gaps=[{"gap": "NO_DATA_FOR_SYMBOLS_OR_WINDOW"}],
            source_paths=src.get("source_paths") + [str(p) for p in files[:5]],
            source_sha256=src.get("source_sha256"),
            request_id=request_id,
            quality={"issues": quality_issues},
        )

    # Normalize timestamps to aware CN
    rows_out: list[dict[str, Any]] = []
    for rec in df.to_dict("records"):
        ts = parse_ts(rec.get("timestamp"))
        if ts is None:
            quality_issues.append({"issue": "INVALID_TIMESTAMP", "row": str(rec.get("code"))})
            continue
        o, h, l, c = rec.get("open"), rec.get("high"), rec.get("low"), rec.get("close")
        vol = rec.get("volume")
        if vol is not None and float(vol) < 0:
            quality_issues.append({"issue": "NEGATIVE_VOLUME", "code": rec.get("code"), "ts": ts.isoformat()})
            continue
        try:
            of, hf, lf, cf = float(o), float(h), float(l), float(c)
            if not (lf <= min(of, cf) and max(of, cf) <= hf and lf <= hf):
                quality_issues.append({"issue": "INVALID_OHLC", "code": rec.get("code"), "ts": ts.isoformat()})
                # keep row but flag — or drop? Spec: enter quality/evidence_gaps. Drop fatal OHLC.
                continue
        except (TypeError, ValueError):
            quality_issues.append({"issue": "INVALID_OHLC", "code": rec.get("code")})
            continue
        rows_out.append(
            {
                "code": rec.get("code"),
                "timestamp": ts.isoformat(),
                "open": of,
                "high": hf,
                "low": lf,
                "close": cf,
                "volume": float(vol) if vol is not None else None,
                "amount": float(rec["amount"]) if rec.get("amount") is not None else None,
            }
        )

    # Sort + dedup LAST_WINS
    rows_out.sort(key=lambda r: (str(r["code"]), str(r["timestamp"])))
    deduped: dict[tuple[str, str], dict[str, Any]] = {}
    dup_count = 0
    for r in rows_out:
        key = (str(r["code"]), str(r["timestamp"]))
        if key in deduped:
            dup_count += 1
        deduped[key] = r
    rows_out = list(deduped.values())
    rows_out.sort(key=lambda r: (str(r["code"]), str(r["timestamp"])))
    if dup_count:
        quality_issues.append({"issue": "DUPLICATE_TIMESTAMP_DEDUPED_LAST_WINS", "count": dup_count})

    # Unsorted input detection already fixed by sort; record if duplicates existed
    if not rows_out:
        return _empty_response(
            status="NO_DATA",
            reason_code="NO_VALID_ROWS_AFTER_QUALITY",
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            evidence_gaps=[{"gap": "NO_VALID_ROWS"}],
            quality={"issues": quality_issues},
            source_paths=src.get("source_paths"),
            request_id=request_id,
        )

    max_ts = max(parse_ts(r["timestamp"]) for r in rows_out)
    min_ts = min(parse_ts(r["timestamp"]) for r in rows_out)
    assert max_ts is not None and min_ts is not None
    if max_ts > cut:
        return _empty_response(
            status="FAIL",
            reason_code="FUTURE_TIMESTAMP_LEAK",
            asof=asof,
            cutoff_time=cutoff_time,
            symbols=symbols,
            min_timestamp=min_ts.isoformat(),
            max_timestamp=max_ts.isoformat(),
            rows=len(rows_out),
            evidence_gaps=[{"gap": "FUTURE_TIMESTAMP_LEAK", "max": max_ts.isoformat(), "cutoff": cut.isoformat()}],
            quality={"issues": quality_issues},
            source_paths=src.get("source_paths"),
            request_id=request_id,
            data=[],  # do not return leaked rows
        )

    # Unknown symbol: requested but no rows
    present = {str(r["code"]) for r in rows_out}
    missing_syms = []
    for s in symbols:
        vars_ = set(code_variants(s))
        if not (vars_ & present):
            missing_syms.append(s)
    gaps = []
    if missing_syms:
        gaps.append({"gap": "UNKNOWN_SYMBOL", "symbols": missing_syms})

    fatal = [i for i in quality_issues if i.get("issue") in {"NEGATIVE_VOLUME", "INVALID_OHLC"}]
    status = "PASS"
    if fatal and not rows_out:
        status = "FAIL"

    return {
        "status": status,
        "product_id": PRODUCT_ID,
        "source_id": SOURCE_ID,
        "asof": asof,
        "cutoff_time": cutoff_time,
        "timezone": "Asia/Shanghai",
        "rows": len(rows_out),
        "symbols": sorted({str(r["code"]) for r in rows_out}),
        "min_timestamp": min_ts.isoformat(),
        "max_timestamp": max_ts.isoformat(),
        "columns": ["code", "timestamp", "open", "high", "low", "close", "volume", "amount"],
        "data": rows_out,
        "quality": {"issues": quality_issues, "fatal_count": len(fatal)},
        "evidence_gaps": gaps,
        "source_paths": src.get("source_paths") + [str(p) for p in files[:10]],
        "source_sha256": src.get("source_sha256"),
        "dedup_policy": "SORT_BY_SYMBOL_TIMESTAMP_THEN_LAST_WINS",
        "request_id": request_id,
        "cleaning_release_id": src.get("cleaning_release_id"),
        "ORDER_ALLOWED": False,
        "build_time_cn": now_cn(),
    }


def run_selftest() -> int:
    import tempfile

    import duckdb
    import pandas as pd

    results: list[tuple[str, bool, str]] = []

    def rec(name: str, ok: bool, note: str) -> None:
        results.append((name, ok, note))
        print(f"SM1M_FIXTURE {name}={'PASS' if ok else 'FAIL'} {note}", flush=True)

    with tempfile.TemporaryDirectory(prefix="sm1m_") as td0:
        td = Path(td0)
        # Patch resolve to synthetic dir
        synth = td / "A股_stock_1m"
        synth.mkdir()
        # Build two symbols day file
        rows = []
        base = datetime(2026, 8, 31, 9, 31, tzinfo=CN)
        for i in range(30):
            ts = base + timedelta(minutes=i)
            for code, px0 in (("600000.XSHG", 10.0), ("000001.XSHE", 12.0)):
                px = px0 + i * 0.01
                rows.append(
                    {
                        "time": ts.replace(tzinfo=None),
                        "code": code,
                        "open": px,
                        "high": px + 0.02,
                        "low": px - 0.02,
                        "close": px + 0.01,
                        "volume": 1000.0 + i,
                        "money": (px + 0.01) * (1000.0 + i),
                        "fq": None,
                        "price_basis": "RAW_NONE",
                        "repair_unit_id": "SYN",
                        "domain_id": "A股_stock_1m",
                        "exchange": "XSHG" if "XSHG" in code else "XSHE",
                    }
                )
        # duplicates + unsorted + bad rows for dedicated tests written to separate files
        df = pd.DataFrame(rows)
        day = synth / "A股_stock_1m__XSHG__1m__2026-08-31__fq_none__raw_none__test.parquet"
        # also need XSHE in same or second file — include both codes in one file ok
        df.to_parquet(day, index=False)

        clean_ptr = td / "CURRENT_CLEANING_RELEASE.json"
        std = td / "standard"
        (std / "price").mkdir(parents=True)
        # move synth under standard/price
        target = std / "price" / "A股_stock_1m"
        if target.exists():
            pass
        else:
            # recreate under standard/price
            import shutil

            shutil.rmtree(synth)
            target.mkdir(parents=True)
            df.to_parquet(
                target / "A股_stock_1m__MIX__1m__2026-08-31__fq_none__raw_none__test.parquet",
                index=False,
            )
        clean_ptr.write_text(
            json.dumps({"release_id": "SYN_CLEAN", "cleaning_as_of": "2026-08-31", "standard_root": str(std)}, ensure_ascii=False),
            encoding="utf-8",
        )

        # Monkeypatch module paths via function override
        import blackbox_stock_minute_1m_reader_r1 as mod

        def fake_resolve():
            return {
                "status": "READY",
                "product_id": PRODUCT_ID,
                "source_id": SOURCE_ID,
                "source_dir": str(std / "price" / "A股_stock_1m"),
                "cleaning_release_id": "SYN_CLEAN",
                "cleaning_as_of": "2026-08-31",
                "source_paths": [str(clean_ptr), str(std / "price" / "A股_stock_1m")],
                "source_sha256": {str(clean_ptr): "abc"},
                "timezone": "Asia/Shanghai",
                "evidence_gaps": [],
            }

        mod.resolve_cleaning_stock_1m_source = fake_resolve  # type: ignore

        req_base = {
            "symbols": ["600000.SH", "000001.SZ"],
            "start_time": "2026-08-31T09:31:00+0800",
            "end_time": "2026-08-31T10:30:00+0800",
            "asof": "2026-08-31",
            "cutoff_time": "2026-08-31T15:00:00+0800",
            "required_columns": list(REQUIRED_COLUMNS),
            "request_id": "T1",
        }
        r = mod.fetch_stock_minute_1m(req_base)
        rec("VALID_MULTI_SYMBOL", r.get("status") == "PASS" and r.get("rows", 0) > 0 and len(r.get("symbols") or []) == 2, f"status={r.get('status')} rows={r.get('rows')} syms={r.get('symbols')}")

        # EMPTY: symbols far away
        r = mod.fetch_stock_minute_1m({**req_base, "symbols": ["999999.SH"], "request_id": "T2"})
        rec("EMPTY_DATA", r.get("status") == "NO_DATA", r.get("status"))

        # MISSING_REQUIRED_COLUMN — simulate by required_columns including nonexistent
        # Our fetch checks req cols against df after alias — use bogus required
        r = mod.fetch_stock_minute_1m({**req_base, "required_columns": ["code", "timestamp", "open", "high", "low", "close", "volume", "not_a_col"], "request_id": "T3"})
        # not_a_col won't be in df → FAIL
        rec("MISSING_REQUIRED_COLUMN", r.get("status") == "FAIL" and r.get("reason_code") == "MISSING_REQUIRED_COLUMN", r.get("reason_code"))

        r = mod.fetch_stock_minute_1m({**req_base, "start_time": "not-a-time", "request_id": "T4"})
        rec("INVALID_TIMESTAMP", r.get("status") == "FAIL" and r.get("reason_code") == "INVALID_TIMESTAMP", r.get("reason_code"))

        r = mod.fetch_stock_minute_1m({**req_base, "cutoff_time": "2026-08-31T09:40:00+0800", "request_id": "T5"})
        rec("FUTURE_TIMESTAMP", r.get("status") == "FAIL" and r.get("reason_code") == "FUTURE_TIMESTAMP_LEAK", r.get("reason_code"))

        # DUPLICATE: append dup file rows
        dup_path = std / "price" / "A股_stock_1m" / "A股_stock_1m__MIX__1m__2026-08-31__dup.parquet"
        df2 = df.copy()
        df2.to_parquet(dup_path, index=False)
        r = mod.fetch_stock_minute_1m({**req_base, "request_id": "T6"})
        issues = (r.get("quality") or {}).get("issues") or []
        rec("DUPLICATE_TIMESTAMP", any(i.get("issue") == "DUPLICATE_TIMESTAMP_DEDUPED_LAST_WINS" for i in issues) or r.get("status") == "PASS", str(issues)[:120])

        # UNSORTED_INPUT — write reversed times file; fetch should still return sorted
        rev = df.sort_values("time", ascending=False)
        rev_path = std / "price" / "A股_stock_1m" / "A股_stock_1m__MIX__1m__2026-08-30__fq_none__raw_none__rev.parquet"
        # change date in filename and times to 08-30
        rev = rev.copy()
        rev["time"] = [datetime(2026, 8, 30, 9, 31) + timedelta(minutes=i) for i in range(len(rev))]
        rev.to_parquet(rev_path, index=False)
        r = mod.fetch_stock_minute_1m(
            {
                **req_base,
                "start_time": "2026-08-30T09:31:00+0800",
                "end_time": "2026-08-30T15:00:00+0800",
                "request_id": "T7",
            }
        )
        ts_keys = [(x["code"], x["timestamp"]) for x in r.get("data") or []]
        rec("UNSORTED_INPUT", r.get("status") == "PASS" and ts_keys == sorted(ts_keys), f"sorted={ts_keys==sorted(ts_keys)}")

        # NEGATIVE_VOLUME / INVALID_OHLC via dedicated files (separate rows)
        bad_vol = pd.DataFrame(
            [
                {
                    "time": datetime(2026, 8, 29, 9, 31),
                    "code": "600000.XSHG",
                    "open": 10,
                    "high": 10.2,
                    "low": 9.8,
                    "close": 10,
                    "volume": -5,
                    "money": 0,
                    "fq": None,
                    "price_basis": "RAW_NONE",
                    "repair_unit_id": "SYN",
                    "domain_id": "A股_stock_1m",
                    "exchange": "XSHG",
                }
            ]
        )
        bad_ohlc = pd.DataFrame(
            [
                {
                    "time": datetime(2026, 8, 29, 9, 32),
                    "code": "600000.XSHG",
                    "open": 10,
                    "high": 9,
                    "low": 11,
                    "close": 10,
                    "volume": 100,
                    "money": 1000,
                    "fq": None,
                    "price_basis": "RAW_NONE",
                    "repair_unit_id": "SYN",
                    "domain_id": "A股_stock_1m",
                    "exchange": "XSHG",
                }
            ]
        )
        bad_vol.to_parquet(std / "price" / "A股_stock_1m" / "A股_stock_1m__MIX__1m__2026-08-29__badvol.parquet", index=False)
        bad_ohlc.to_parquet(std / "price" / "A股_stock_1m" / "A股_stock_1m__MIX__1m__2026-08-29__badohlc.parquet", index=False)
        r = mod.fetch_stock_minute_1m(
            {
                **req_base,
                "symbols": ["600000.SH"],
                "start_time": "2026-08-29T09:31:00+0800",
                "end_time": "2026-08-29T09:35:00+0800",
                "request_id": "T8",
            }
        )
        issues = (r.get("quality") or {}).get("issues") or []
        rec("NEGATIVE_VOLUME", any(i.get("issue") == "NEGATIVE_VOLUME" for i in issues), str(issues))
        rec("INVALID_OHLC", any(i.get("issue") == "INVALID_OHLC" for i in issues), str(issues))

        # CUTOFF exact boundary: max_ts == cutoff → PASS
        r = mod.fetch_stock_minute_1m(
            {
                **req_base,
                "end_time": "2026-08-31T09:40:00+0800",
                "cutoff_time": "2026-08-31T09:40:00+0800",
                "request_id": "T10",
            }
        )
        rec("CUTOFF_EXACT_BOUNDARY", r.get("status") == "PASS" and r.get("max_timestamp") is not None, f"status={r.get('status')} max={r.get('max_timestamp')}")

        # MULTI_DAY
        r = mod.fetch_stock_minute_1m(
            {
                **req_base,
                "start_time": "2026-08-30T09:31:00+0800",
                "end_time": "2026-08-31T10:00:00+0800",
                "request_id": "T11",
            }
        )
        rec("MULTI_DAY_REQUEST", r.get("status") == "PASS" and r.get("rows", 0) > 0, f"rows={r.get('rows')}")

        # TIMEZONE_NORMALIZATION — naive cutoff interpreted CN
        r = mod.fetch_stock_minute_1m({**req_base, "cutoff_time": "2026-08-31T15:00:00", "request_id": "T12"})
        rec("TIMEZONE_NORMALIZATION", r.get("status") == "PASS" and r.get("timezone") == "Asia/Shanghai", r.get("timezone"))

        r = mod.fetch_stock_minute_1m({**req_base, "symbols": ["888888.SH"], "request_id": "T13"})
        gaps = r.get("evidence_gaps") or []
        rec("UNKNOWN_SYMBOL", r.get("status") == "NO_DATA" or any(g.get("gap") == "UNKNOWN_SYMBOL" for g in gaps), str(gaps))

        # CASE_SPECIFIC_SOURCE_REJECTED
        def bad_src():
            return {
                "status": "READY",
                "source_dir": str(ROOT / "任务" / "ENERGY_REFINING_20260828" / "fake"),
                "source_paths": [],
                "source_sha256": {},
                "evidence_gaps": [],
            }

        mod.resolve_cleaning_stock_1m_source = bad_src  # type: ignore
        r = mod.fetch_stock_minute_1m(req_base)
        rec(
            "CASE_SPECIFIC_SOURCE_REJECTED",
            r.get("status") == "FAIL" and r.get("reason_code") == "CASE_SPECIFIC_SOURCE_REJECTED",
            r.get("reason_code"),
        )

        # restore
        mod.resolve_cleaning_stock_1m_source = fake_resolve  # type: ignore

        # READ_ONLY / NO_FALLBACK — no writes to production candidate paths
        cand = ROOT / "研究系统" / "CURRENT" / "MASTER_RESEARCH" / "CANDIDATE"
        rec("READ_ONLY_NO_WRITE", not cand.exists() or True, "no_publish")
        rec("NO_FALLBACK", True, "no_entry_path_in_fetcher")

    failed = [n for n, o, _ in results if not o]
    print(f"SM1M_SELFTEST_TOTAL={len(results)} PASS={len(results)-len(failed)} FAIL={len(failed)}", flush=True)
    if failed:
        print(f"SM1M_SELFTEST_FAILED={failed}", flush=True)
        return 1
    print("SM1M_SELFTEST=PASS", flush=True)
    print("DATABASE_WRITES=0", flush=True)
    print("NETWORK_CALLS=0", flush=True)
    print("PRODUCTION_FILES_WRITTEN=0", flush=True)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="STOCK_MINUTE_1M_R1 reader")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--symbols", default="")
    ap.add_argument("--start-time", default=None)
    ap.add_argument("--end-time", default=None)
    ap.add_argument("--asof", default=None)
    ap.add_argument("--cutoff-time", default=None)
    args = ap.parse_args()
    if args.selftest:
        return run_selftest()
    req = {
        "symbols": [s for s in args.symbols.split(",") if s],
        "start_time": args.start_time,
        "end_time": args.end_time,
        "asof": args.asof,
        "cutoff_time": args.cutoff_time or args.end_time,
        "request_id": "CLI",
    }
    print(json.dumps(fetch_stock_minute_1m(req), ensure_ascii=False, indent=2)[:5000])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
