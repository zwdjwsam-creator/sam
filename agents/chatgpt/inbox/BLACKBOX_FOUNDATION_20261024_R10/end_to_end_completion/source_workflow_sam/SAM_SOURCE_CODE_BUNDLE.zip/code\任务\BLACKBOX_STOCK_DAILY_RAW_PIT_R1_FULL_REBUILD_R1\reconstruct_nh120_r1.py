# -*- coding: utf-8 -*-
"""PRE_PIT reconstruction + NH120 population on RAW candidate. No R26. No CURRENT switch."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

TASK = Path(r"E:\BLACKBOX\任务\BLACKBOX_STOCK_DAILY_RAW_PIT_R1_FULL_REBUILD_R1")
CACHE_PTR = Path(r"E:\BLACKBOX\数据\回测缓存\CURRENT_CACHE_RELEASE.json")
sys.path.insert(0, r"E:\BLACKBOX\脚本")
from jq_download_base import auth  # noqa: E402

RESIDUAL = ["002870.XSHE", "301336.XSHE", "300143.XSHE", "300406.XSHE", "603236.XSHG", "688767.XSHG"]


def now_cn() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S+0800")


def log(msg: str) -> None:
    print("[%s] %s" % (now_cn(), msg), flush=True)


def wjson(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def candidate_root() -> Path:
    return Path(json.loads((TASK / "CACHE_CANDIDATE.json").read_text(encoding="utf-8"))["release_root"])


def load_raw(root: Path, years=(2025, 2026)) -> pd.DataFrame:
    frames = []
    for y in years:
        p = root / "STOCK_DAILY_RAW_PIT_R1" / ("year=%s" % y) / ("part_%s.parquet" % y)
        frames.append(pd.read_parquet(p, columns=["date", "code", "close", "volume"]))
    out = pd.concat(frames, ignore_index=True)
    out["date"] = pd.to_datetime(out["date"]).dt.normalize()
    out["code"] = out["code"].astype(str)
    out["close"] = pd.to_numeric(out["close"], errors="coerce")
    return out.dropna(subset=["date", "code", "close"])


def load_factor(cur_root: Path) -> pd.DataFrame:
    files = sorted((cur_root / "ADJUST_FACTOR_PIT_R1" / "data").glob("year=*/part_*.parquet"))
    if not files:
        files = sorted((cur_root / "ADJUST_FACTOR_PIT_R1").glob("year=*/part_*.parquet"))
    df = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
    df["date"] = pd.to_datetime(df["date"]).dt.normalize()
    df["code"] = df["code"].astype(str)
    df["factor"] = pd.to_numeric(df["factor"], errors="coerce")
    return df.dropna(subset=["date", "code", "factor"])


def nh120(g: pd.DataFrame, t: pd.Timestamp):
    g = g.sort_values("date")
    sub = g.loc[g["date"] <= t]
    if sub.empty or sub.iloc[-1]["date"] != t:
        return None
    last = float(sub.iloc[-1]["close"])
    prior = sub.iloc[:-1].tail(120)
    if len(prior) < 120:
        return None
    return bool(last > float(prior["close"].max()) > 0)


def pre_pit(raw: pd.DataFrame, fac: pd.DataFrame, t: pd.Timestamp) -> pd.DataFrame:
    win = t - pd.Timedelta(days=400)
    r = raw.loc[(raw["date"] >= win) & (raw["date"] <= t)].copy()
    f = fac.loc[(fac["date"] >= win) & (fac["date"] <= t), ["date", "code", "factor"]]
    m = r.merge(f, on=["date", "code"], how="left")
    ft = f.loc[f["date"] == t, ["code", "factor"]].rename(columns={"factor": "factor_T"})
    m = m.merge(ft, on="code", how="left")
    miss = m["factor"].isna() | m["factor_T"].isna() | (m["factor"] <= 0) | (m["factor_T"] <= 0)
    m = m.loc[~miss].copy()
    m["close"] = m["close"] * m["factor"] / m["factor_T"]
    return m[["date", "code", "close"]]


def jq_pre_close(codes, start, end) -> pd.DataFrame:
    import jqdatasdk as jq

    parts = []
    for i in range(0, len(codes), 400):
        batch = codes[i : i + 400]
        df = jq.get_price(security=batch, start_date=start, end_date=end, frequency="daily", fields=["close"], fq="pre")
        if df is None or len(df) == 0:
            continue
        x = df.reset_index() if "code" not in getattr(df, "columns", []) else df.copy()
        if "time" in x.columns and "date" not in x.columns:
            x = x.rename(columns={"time": "date"})
        x["date"] = pd.to_datetime(x["date"]).dt.normalize()
        x["code"] = x["code"].astype(str)
        x["close"] = pd.to_numeric(x["close"], errors="coerce")
        parts.append(x[["date", "code", "close"]].dropna())
        log("jq pre batch %s n=%s" % (i // 400 + 1, len(batch)))
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=["date", "code", "close"])


def pop_at(pre: pd.DataFrame, jq: pd.DataFrame, t: pd.Timestamp) -> dict:
    bb, jq_c = [], []
    for code, g in pre.groupby("code"):
        if nh120(g, t):
            bb.append(code)
    jq_t = jq.loc[jq["date"] <= t]
    for code, g in jq_t.groupby("code"):
        if nh120(g, t):
            jq_c.append(code)
    bb_s, jq_s = set(bb), set(jq_c)
    return {
        "signal_date": str(t.date()),
        "BLACKBOX_PRE_PIT_NH120_N": len(bb_s),
        "JQ_PRE_NH120_N": len(jq_s),
        "BLACKBOX_ONLY_N": len(bb_s - jq_s),
        "JQ_ONLY_N": len(jq_s - bb_s),
        "INTERSECT_N": len(bb_s & jq_s),
        "BLACKBOX_ONLY": sorted(bb_s - jq_s),
        "JQ_ONLY": sorted(jq_s - bb_s),
        "match": bb_s == jq_s,
        "old_residual_inherited": False,
    }


def main() -> int:
    cand = candidate_root()
    cur = Path(json.loads(CACHE_PTR.read_text(encoding="utf-8"))["release_root"])
    raw = load_raw(cand)
    fac = load_factor(cur)
    log("raw_rows=%s factor_rows=%s" % (len(raw), len(fac)))
    gold = []
    for code, t, expect_raw, expect_pre in [
        ("001230.XSHE", pd.Timestamp("2026-08-11"), False, True),
        ("600351.XSHG", pd.Timestamp("2026-08-13"), False, True),
    ]:
        r = raw.loc[raw["code"] == code]
        raw_nh = nh120(r, t)
        pre = pre_pit(r, fac.loc[fac["code"] == code], t)
        pre_nh = nh120(pre, t)
        rec = {
            "code": code,
            "T": str(t.date()),
            "RAW_NH120": raw_nh,
            "PRE_PIT_NH120": pre_nh,
            "expect_raw": expect_raw,
            "expect_pre": expect_pre,
            "PASS": raw_nh is expect_raw and pre_nh is expect_pre,
        }
        gold.append(rec)
        log("GOLDEN %s" % rec)
    residual = []
    for code in RESIDUAL:
        t = pd.Timestamp("2026-08-11") if code in ("002870.XSHE", "301336.XSHE") else pd.Timestamp("2026-08-13")
        r = raw.loc[raw["code"] == code]
        raw_nh = nh120(r, t)
        pre = pre_pit(r, fac.loc[fac["code"] == code], t)
        pre_nh = nh120(pre, t)
        residual.append({"code": code, "T": str(t.date()), "RAW_NH120": raw_nh, "PRE_PIT_NH120": pre_nh})
    wjson(TASK / "PRE_PIT_RECONSTRUCTION_GOLDEN.json", {
        "formula": "PRE_PIT(d|T)=RAW_OHLC(d)*factor(d)/factor(T)",
        "RAW_OHLC": "STOCK_DAILY_RAW_PIT_R1",
        "factor": "ADJUST_FACTOR_PIT_R1",
        "cases": gold,
        "residual_codes": residual,
        "PRE_PIT_RECONSTRUCTION_PASS": all(x["PASS"] for x in gold),
    })
    auth()
    codes = sorted(set(raw["code"].unique()) & set(fac["code"].unique()))
    jq = jq_pre_close(codes, "2025-01-01", "2026-08-14")
    pops = []
    for t in (pd.Timestamp("2026-08-11"), pd.Timestamp("2026-08-13")):
        pre = pre_pit(raw, fac, t)
        pops.append(pop_at(pre, jq, t))
        log("POP %s BB_ONLY=%s JQ_ONLY=%s" % (pops[-1]["signal_date"], pops[-1]["BLACKBOX_ONLY_N"], pops[-1]["JQ_ONLY_N"]))
    wjson(TASK / "NH120_POPULATION_RECALIBRATION.json", {
        "windows": pops,
        "old_class_PASS_WITH_DECLARED_RESIDUAL": "NOT_INHERITED",
        "NH120_POPULATION_RECALIBRATED": True,
        "exact_match_both_days": all(p["match"] for p in pops),
    })
    ok = all(x["PASS"] for x in gold)
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
