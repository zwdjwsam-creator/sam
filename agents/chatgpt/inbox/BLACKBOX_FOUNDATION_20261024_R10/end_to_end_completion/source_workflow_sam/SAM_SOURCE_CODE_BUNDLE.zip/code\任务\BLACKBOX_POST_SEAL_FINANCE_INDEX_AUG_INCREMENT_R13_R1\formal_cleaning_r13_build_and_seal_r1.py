#!/usr/bin/env python3
"""Formal Cleaning R13 — parent R12 hardlink + finance/valuation asof 2026-08-07; switch CURRENT."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

sys.stdout.reconfigure(encoding="utf-8")

TASK = "BLACKBOX_POST_SEAL_FINANCE_INDEX_AUG_INCREMENT_R13_R1"
ROOT = Path(r"E:\BLACKBOX\任务") / TASK
RELEASES = Path(r"E:\BLACKBOX\数据\清洗成品\releases")
CURRENT = Path(r"E:\BLACKBOX\数据\清洗成品\CURRENT_CLEANING_RELEASE.json")
PARENT_ID = "BLACKBOX_FORMAL_CLEANING_R12_ASOF_20260807_20260808_004052"
PARENT_SEAL = "BLACKBOX_CLEANING_LAYER_SEAL_R12_20260808_004052"
PARENT = RELEASES / PARENT_ID
CLEANING_AS_OF = "2026-08-07"
HAND = Path(r"E:\BLACKBOX\运行\HAND_DECISION.json")
SWITCH_CURRENT = "--switch-current" in sys.argv


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ts_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(1024 * 1024)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def wjson(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def log(msg: str) -> None:
    line = f"[{now_iso()}] {msg}"
    print(line, flush=True)
    p = ROOT / "11_LOGS" / "r13_build.log"
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def hardlink_tree(src: Path, dst: Path) -> tuple[int, int]:
    ok = fail = 0
    for f in src.rglob("*"):
        if not f.is_file():
            continue
        out = dst / f.relative_to(src)
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists():
            ok += 1
            continue
        try:
            os.link(f, out)
            ok += 1
        except OSError:
            try:
                shutil.copy2(f, out)
                ok += 1
            except Exception:
                fail += 1
    return ok, fail


def place_file(src: Path, out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    try:
        os.link(src, out)
    except OSError:
        shutil.copy2(src, out)


def load_staging() -> list[dict]:
    man = ROOT / "08_FINANCE_SOURCE_HANDOFF" / "STAGING_MANIFEST.json"
    obj = json.loads(man.read_text(encoding="utf-8"))
    items = list(obj.get("items") or [])
    if not items:
        raise RuntimeError("no_finance_staging_items")
    return items


def ingest_item(item: dict, release_root: Path) -> dict:
    src = Path(item["raw_path"])
    if not src.exists():
        raise RuntimeError(f"missing_raw:{src}")
    rel = str(item["clean_rel"]).replace("\\", "/")
    out = release_root / "standard" / rel
    place_file(src, out)
    return {
        "repair_unit_id": item["unit_id"],
        "domain_id": item.get("domain_id"),
        "trade_date": item.get("as_of") or item.get("statDate") or item.get("half") or CLEANING_AS_OF,
        "status": "COMMITTED",
        "source_file": str(src),
        "source_sha256": item.get("file_sha256") or sha256_file(src),
        "active_path": str(out),
        "active_sha256": sha256_file(out),
        "active_row_count": int(item.get("rows") or 0),
        "quarantine_path": None,
        "quarantine_row_count": 0,
    }


def seal_release(release_root: Path, release_id: str, seal_id: str, repair_results: list[dict]) -> dict:
    inv = []
    for f in release_root.rglob("*.parquet"):
        if not f.is_file():
            continue
        rel = str(f.relative_to(release_root)).replace("\\", "/")
        art = "quarantine" if "/_quarantine/" in ("/" + rel) else "standard"
        inv.append({"relative_path": rel, "sha256": sha256_file(f), "size": f.stat().st_size, "artifact_type": art})
    inv_df = pd.DataFrame(inv)
    seal_dir = release_root / "_seal"
    seal_dir.mkdir(parents=True, exist_ok=True)
    inv_df.to_parquet(seal_dir / "SEALED_CONTENT_INVENTORY.parquet", index=False)
    root_sha = hashlib.sha256(
        ("\n".join(sorted(f"{r.relative_path}:{r.sha256}" for r in inv_df.itertuples()))).encode("utf-8")
    ).hexdigest()
    cert = {
        "release_id": release_id,
        "seal_id": seal_id,
        "parent_release_id": PARENT_ID,
        "parent_seal_id": PARENT_SEAL,
        "cleaning_as_of": CLEANING_AS_OF,
        "finance_asof": CLEANING_AS_OF,
        "daily_asof": CLEANING_AS_OF,
        "release_version": "R13",
        "repair_unit_count": len(repair_results),
        "repair_committed": sum(1 for r in repair_results if r["status"] == "COMMITTED"),
        "release_content_root_sha256": root_sha,
        "sealed_at": now_iso(),
        "scope": "FINANCE_VALUATION_INCREMENTAL_20260807_ON_TOP_OF_R12",
    }
    wjson(seal_dir / "CLEANING_LAYER_SEAL_CERTIFICATE.json", cert)
    (release_root / ".BLACKBOX_SEALED").write_text(seal_id + "\n", encoding="utf-8")
    db = release_root / "_control" / "cleaning_ledger.sqlite"
    db.parent.mkdir(parents=True, exist_ok=True)
    if db.exists():
        db.unlink()
    con = sqlite3.connect(str(db))
    con.execute("CREATE TABLE cleaning_release(release_id TEXT, parent_release_id TEXT, cleaning_as_of TEXT, seal_id TEXT, sealed INTEGER)")
    con.execute("INSERT INTO cleaning_release VALUES (?,?,?,?,1)", (release_id, PARENT_ID, CLEANING_AS_OF, seal_id))
    con.execute("CREATE TABLE repair_unit_lineage(repair_unit_id TEXT, domain_id TEXT, trade_date TEXT, active_sha256 TEXT, active_row_count INTEGER, status TEXT)")
    for r in repair_results:
        con.execute(
            "INSERT INTO repair_unit_lineage VALUES (?,?,?,?,?,?)",
            (r["repair_unit_id"], r["domain_id"], r["trade_date"], r["active_sha256"], r["active_row_count"], r["status"]),
        )
    con.commit()
    con.close()
    return cert


def switch_current(release_id: str, seal_id: str, root_sha: str, release_root: Path) -> None:
    obj = {
        "release_id": release_id,
        "seal_id": seal_id,
        "sealed": True,
        "cleaning_as_of": CLEANING_AS_OF,
        "finance_asof": CLEANING_AS_OF,
        "daily_asof": CLEANING_AS_OF,
        "standard_root": str(release_root / "standard"),
        "quarantine_root": str(release_root / "_quarantine"),
        "ledger_path": str(release_root / "_control" / "cleaning_ledger.sqlite"),
        "release_content_root_sha256": root_sha,
        "created_at": now_iso(),
        "parent_release_id": PARENT_ID,
        "switch_reason": "AUG_FINANCE_VALUATION_INCREMENT_R13_USER_AUTHORIZED",
    }
    bak = CURRENT.with_suffix(".json.bak_before_r13_" + ts_stamp())
    if CURRENT.exists():
        bak.write_text(CURRENT.read_text(encoding="utf-8"), encoding="utf-8")
    tmp = CURRENT.with_name(CURRENT.name + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, CURRENT)


def patch_hand(release_id: str, seal_id: str) -> None:
    if not HAND.exists():
        return
    sys.path.insert(0, r"E:\BLACKBOX\脚本")
    import p7_gate_common as gc
    d = json.loads(HAND.read_text(encoding="utf-8"))
    d.update({
        "cleaning_allowed": False,
        "formal_cleaning_r13_allowed": False,
        "cleaning_r13_pending_after_download": False,
        "post_seal_finance_incremental_download_allowed": False,
        "post_seal_finance_r13_status": "PASS",
        "post_seal_finance_r13_release_id": release_id,
        "post_seal_finance_r13_seal_id": seal_id,
        "finance_asof_current": CLEANING_AS_OF,
        "current_stage_complete": True,
        "next_stage": "POST_SEAL_FINANCE_R13_DONE",
        "next_action": "Finance/valuation R13 sealed CURRENT; antileak next",
        "updated_at": now_iso(),
    })
    gc.write_hand_decision(d)
    try:
        gc.write_hand_md(d)
    except Exception:
        pass


def main() -> int:
    (ROOT / "11_LOGS").mkdir(parents=True, exist_ok=True)
    dl = json.loads((ROOT / "10_ACCEPTANCE" / "DOWNLOAD_ACCEPTANCE.json").read_text(encoding="utf-8"))
    if dl.get("status") not in ("PASS", "REVIEW_REQUIRED"):
        log(f"download not ready: {dl.get('status')}")
        return 2
    if not PARENT.exists() or not (PARENT / ".BLACKBOX_SEALED").exists():
        log("parent R12 missing/unsealed")
        return 2
    hand = json.loads(HAND.read_text(encoding="utf-8")) if HAND.exists() else {}
    if hand.get("cleaning_allowed") is not True and hand.get("formal_cleaning_r13_allowed") is not True:
        log("HAND cleaning not allowed")
        return 2

    items = load_staging()
    log(f"finance staging units={len(items)}")

    build_ts = ts_stamp()
    release_id = f"BLACKBOX_FORMAL_CLEANING_R13_ASOF_{CLEANING_AS_OF.replace('-', '')}_{build_ts}"
    seal_id = f"BLACKBOX_CLEANING_LAYER_SEAL_R13_{build_ts}"
    release_root = RELEASES / release_id
    if release_root.exists():
        return 2
    release_root.mkdir(parents=True)

    log("CARRY_FORWARD hardlink from R12")
    n_std, f_std = hardlink_tree(PARENT / "standard", release_root / "standard")
    n_q, f_q = hardlink_tree(PARENT / "_quarantine", release_root / "_quarantine")
    log(f"carry std={n_std}/{f_std} q={n_q}/{f_q}")
    if f_std or f_q:
        return 2

    repair = []
    for item in items:
        r = ingest_item(item, release_root)
        repair.append(r)
        log(f"ingest {item['unit_id']} rows={item.get('rows')}")

    cert = seal_release(release_root, release_id, seal_id, repair)
    log(f"SEALED {seal_id}")
    if SWITCH_CURRENT:
        switch_current(release_id, seal_id, cert["release_content_root_sha256"], release_root)
        patch_hand(release_id, seal_id)
        log("CURRENT switched to R13")
    out = {
        "final_status": "PASS",
        "release_id": release_id,
        "seal_id": seal_id,
        "parent_release_id": PARENT_ID,
        "repair_committed": len(repair),
        "cleaning_as_of": CLEANING_AS_OF,
        "CURRENT_switched": SWITCH_CURRENT,
        "generated_at": now_iso(),
    }
    wjson(ROOT / "12_ACCEPTANCE" / "R13_SEAL_RESULT.json", out)
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
